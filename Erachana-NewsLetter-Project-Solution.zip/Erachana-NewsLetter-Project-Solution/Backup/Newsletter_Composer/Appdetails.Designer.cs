using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Appdetails {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpAppdetails = new Kushal.Controls.KushalGroupBox();
            this.btnClearImage = new Kushal.Controls.KushalButton();
            this.btnAppImage = new Kushal.Controls.KushalButton();
            this.btnClearImage2 = new Kushal.Controls.KushalButton();
            this.btnCustomerImage = new Kushal.Controls.KushalButton();
            this.btn_CheckLink = new Kushal.Controls.KushalButton();
            this.dtp_AppDetails_DOR = new DateTextBox();
            this.txt_AppDetails_TypeId = new Kushal.Controls.KushalComboBox();
            this.txt_AppDetails_CategoryId = new Kushal.Controls.KushalComboBox();
            this.custCompanyLogo = new Kushal.Controls.KushalPictureBox();
            this.CompanyLogo = new Kushal.Controls.KushalPictureBox();
            this.lbl_AppDetails_AppId = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_TypeId = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppDescription = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_DOR = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_Remarks = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_CategoryId = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppName = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppLink = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_LogoUrl = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_LogoPath = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppLogo = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_CustomerCompany = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_CustomerLogo = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyTitle1 = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyLogo = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyTitle = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyLogo1 = new Kushal.Controls.KushalLabel();
            this.txt_AppDetails_AppId = new NumericTextBox();
            this.txt_AppDetails_AppDescription = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_Remarks = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_AppName = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_AppLink = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_LogoUrl = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_LogoPath = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_AppLogo = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_CustomerCompany = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_CustomerLogo = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnAppId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnTypeId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCategoryId = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnAppDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnAppName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnDOR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnAppLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnLogoUrl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnLogoPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnAppLogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCustomerCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCustomerLogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(9, 345);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 28;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(302, 345);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 29;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(595, 345);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 30;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(888, 345);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 33;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(869, 680);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpAppdetails.Location = new System.Drawing.Point(7, 8);
            this.grpAppdetails.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpAppdetails.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpAppdetails.Name = "grpAppdetails";
            this.grpAppdetails.Enabled = true;
            this.grpAppdetails.Visible = true;
            this.grpAppdetails.TabIndex = 1;
            this.grpAppdetails.TabStop = false;
            this.grpAppdetails.Size = new System.Drawing.Size(957, 334);
            this.grpAppdetails.Text = @"";
            this.grpAppdetails.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAppdetails.SendToBack();
            this.toolTip1.SetToolTip(this.grpAppdetails, @"");

            this.btnClearImage.Location = new System.Drawing.Point(587, 293);
            this.btnClearImage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClearImage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClearImage.Name = "btnClearImage";
            this.btnClearImage.Enabled = true;
            this.btnClearImage.Visible = true;
            this.btnClearImage.TabIndex = 10;
            this.btnClearImage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClearImage.Size = new System.Drawing.Size(177, 30);
            this.btnClearImage.Text = @"Clear Image";
            this.btnClearImage.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearImage.UseVisualStyleBackColor = false;
            this.btnClearImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClearImage, @"");
            
            

            this.btnAppImage.Location = new System.Drawing.Point(587, 261);
            this.btnAppImage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnAppImage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnAppImage.Name = "btnAppImage";
            this.btnAppImage.Enabled = true;
            this.btnAppImage.Visible = true;
            this.btnAppImage.TabIndex = 9;
            this.btnAppImage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnAppImage.Size = new System.Drawing.Size(177, 30);
            this.btnAppImage.Text = @"Browse Image";
            this.btnAppImage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppImage.UseVisualStyleBackColor = false;
            this.btnAppImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnAppImage, @"");
            
            

            this.btnClearImage2.Location = new System.Drawing.Point(774, 293);
            this.btnClearImage2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClearImage2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClearImage2.Name = "btnClearImage2";
            this.btnClearImage2.Enabled = true;
            this.btnClearImage2.Visible = true;
            this.btnClearImage2.TabIndex = 12;
            this.btnClearImage2.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClearImage2.Size = new System.Drawing.Size(177, 30);
            this.btnClearImage2.Text = @"Clear Image";
            this.btnClearImage2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearImage2.UseVisualStyleBackColor = false;
            this.btnClearImage2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClearImage2, @"");
            
            

            this.btnCustomerImage.Location = new System.Drawing.Point(774, 261);
            this.btnCustomerImage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnCustomerImage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnCustomerImage.Name = "btnCustomerImage";
            this.btnCustomerImage.Enabled = true;
            this.btnCustomerImage.Visible = true;
            this.btnCustomerImage.TabIndex = 11;
            this.btnCustomerImage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnCustomerImage.Size = new System.Drawing.Size(177, 30);
            this.btnCustomerImage.Text = @"Browse Customer Logo";
            this.btnCustomerImage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerImage.UseVisualStyleBackColor = false;
            this.btnCustomerImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnCustomerImage, @"");
            
            

            this.btn_CheckLink.Location = new System.Drawing.Point(497, 122);
            this.btn_CheckLink.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btn_CheckLink.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btn_CheckLink.Name = "btn_CheckLink";
            this.btn_CheckLink.Enabled = true;
            this.btn_CheckLink.Visible = true;
            this.btn_CheckLink.TabIndex = 5;
            this.btn_CheckLink.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btn_CheckLink.Size = new System.Drawing.Size(80, 30);
            this.btn_CheckLink.Text = @"Check";
            this.btn_CheckLink.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CheckLink.UseVisualStyleBackColor = false;
            this.btn_CheckLink.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btn_CheckLink, @"");
            
            

            this.dtp_AppDetails_DOR.Location = new System.Drawing.Point(466, 53);
            this.dtp_AppDetails_DOR.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.dtp_AppDetails_DOR.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.dtp_AppDetails_DOR.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_AppDetails_DOR.Name = "dtp_AppDetails_DOR";
            this.dtp_AppDetails_DOR.DefaultValue = null;
            this.dtp_AppDetails_DOR.Text = "";
            this.dtp_AppDetails_DOR.Value = null;
            this.dtp_AppDetails_DOR.FriendlyName = "";
            this.dtp_AppDetails_DOR.Enabled = true;
            this.dtp_AppDetails_DOR.Visible = true;
            this.dtp_AppDetails_DOR.TabIndex = 2;
            this.dtp_AppDetails_DOR.MinValue = new System.DateTime(((long)(0)));
            this.dtp_AppDetails_DOR.MaxValue = new System.DateTime(((long)(0)));
            this.dtp_AppDetails_DOR.ValidationMessage = "";
            this.dtp_AppDetails_DOR.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dtp_AppDetails_DOR.Size = new System.Drawing.Size(111, 29);
            this.dtp_AppDetails_DOR.SelectAllOnFocus = true;
            this.dtp_AppDetails_DOR.DoValidation = false;
            this.dtp_AppDetails_DOR.AllowNull = true;
            this.dtp_AppDetails_DOR.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.dtp_AppDetails_DOR, @"");

            this.txt_AppDetails_TypeId.Location = new System.Drawing.Point(1284, 130);
            this.txt_AppDetails_TypeId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_AppDetails_TypeId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_AppDetails_TypeId.MaxDropDownItems = 10;
            this.txt_AppDetails_TypeId.IntegralHeight = false;
            this.txt_AppDetails_TypeId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_TypeId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_TypeId.FormattingEnabled = true;
            this.txt_AppDetails_TypeId.Name = "txt_AppDetails_TypeId";
            this.txt_AppDetails_TypeId.AllowNull = false;
            this.txt_AppDetails_TypeId.FriendlyName = "";
            this.txt_AppDetails_TypeId.Enabled = false;
            this.txt_AppDetails_TypeId.Visible = false;
            this.txt_AppDetails_TypeId.TabIndex = 4;
            this.txt_AppDetails_TypeId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_AppDetails_TypeId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_AppDetails_TypeId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_TypeId.Size = new System.Drawing.Size(129, 29);
            this.txt_AppDetails_TypeId.Tag = "Select ListID,ListCode from ListMaster where ListTypeID = 2";
            this.toolTip1.SetToolTip(this.txt_AppDetails_TypeId, @"");
            

            this.txt_AppDetails_CategoryId.Location = new System.Drawing.Point(146, 53);
            this.txt_AppDetails_CategoryId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_AppDetails_CategoryId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_AppDetails_CategoryId.MaxDropDownItems = 10;
            this.txt_AppDetails_CategoryId.IntegralHeight = false;
            this.txt_AppDetails_CategoryId.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_CategoryId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_CategoryId.FormattingEnabled = true;
            this.txt_AppDetails_CategoryId.Name = "txt_AppDetails_CategoryId";
            this.txt_AppDetails_CategoryId.AllowNull = true;
            this.txt_AppDetails_CategoryId.FriendlyName = "";
            this.txt_AppDetails_CategoryId.Enabled = true;
            this.txt_AppDetails_CategoryId.Visible = true;
            this.txt_AppDetails_CategoryId.TabIndex = 1;
            this.txt_AppDetails_CategoryId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_AppDetails_CategoryId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_AppDetails_CategoryId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_CategoryId.Size = new System.Drawing.Size(182, 29);
            this.txt_AppDetails_CategoryId.Tag = "select * from ProductTypeMaster";
            this.toolTip1.SetToolTip(this.txt_AppDetails_CategoryId, @"");
            

            this.custCompanyLogo.Location = new System.Drawing.Point(773, 43);
            this.custCompanyLogo.Name = "custCompanyLogo";
            this.custCompanyLogo.AllowNull = true;
            this.custCompanyLogo.FriendlyName = "";
            this.custCompanyLogo.Enabled = true;
            this.custCompanyLogo.Visible = true;
            this.custCompanyLogo.Size = new System.Drawing.Size(177, 162);
            this.custCompanyLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.custCompanyLogo.TabIndex = 0;
            this.custCompanyLogo.TabStop = false;
            this.custCompanyLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolTip1.SetToolTip(this.custCompanyLogo, @"");
            
            

            this.CompanyLogo.Location = new System.Drawing.Point(587, 43);
            this.CompanyLogo.Name = "CompanyLogo";
            this.CompanyLogo.AllowNull = true;
            this.CompanyLogo.FriendlyName = "";
            this.CompanyLogo.Enabled = true;
            this.CompanyLogo.Visible = true;
            this.CompanyLogo.Size = new System.Drawing.Size(177, 162);
            this.CompanyLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CompanyLogo.TabIndex = 0;
            this.CompanyLogo.TabStop = false;
            this.CompanyLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolTip1.SetToolTip(this.CompanyLogo, @"");
            
            

            this.lbl_AppDetails_AppId.AutoSize = false;
            this.lbl_AppDetails_AppId.Location = new System.Drawing.Point(8, 21);
            this.lbl_AppDetails_AppId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppId.Name = "lbl_AppDetails_AppId";
            this.lbl_AppDetails_AppId.Enabled = true;
            this.lbl_AppDetails_AppId.Visible = true;
            this.lbl_AppDetails_AppId.TabIndex = 3;
            this.lbl_AppDetails_AppId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppId.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_AppId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppId.Text = @"* Project ID";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppId, @"");

            this.lbl_AppDetails_TypeId.AutoSize = false;
            this.lbl_AppDetails_TypeId.Location = new System.Drawing.Point(1275, 100);
            this.lbl_AppDetails_TypeId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_TypeId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_TypeId.Name = "lbl_AppDetails_TypeId";
            this.lbl_AppDetails_TypeId.Enabled = true;
            this.lbl_AppDetails_TypeId.Visible = false;
            this.lbl_AppDetails_TypeId.TabIndex = 5;
            this.lbl_AppDetails_TypeId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_TypeId.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_TypeId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_TypeId.Text = @"* Type";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_TypeId, @"");

            this.lbl_AppDetails_AppDescription.AutoSize = false;
            this.lbl_AppDetails_AppDescription.Location = new System.Drawing.Point(8, 193);
            this.lbl_AppDetails_AppDescription.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppDescription.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppDescription.Name = "lbl_AppDetails_AppDescription";
            this.lbl_AppDetails_AppDescription.Enabled = true;
            this.lbl_AppDetails_AppDescription.Visible = true;
            this.lbl_AppDetails_AppDescription.TabIndex = 7;
            this.lbl_AppDetails_AppDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppDescription.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_AppDescription.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppDescription.Text = @"  Description";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppDescription, @"");

            this.lbl_AppDetails_DOR.AutoSize = false;
            this.lbl_AppDetails_DOR.Location = new System.Drawing.Point(358, 56);
            this.lbl_AppDetails_DOR.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_DOR.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_DOR.Name = "lbl_AppDetails_DOR";
            this.lbl_AppDetails_DOR.Enabled = true;
            this.lbl_AppDetails_DOR.Visible = true;
            this.lbl_AppDetails_DOR.TabIndex = 9;
            this.lbl_AppDetails_DOR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_DOR.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_DOR.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_DOR.Text = @"* Release Date";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_DOR, @"");

            this.lbl_AppDetails_Remarks.AutoSize = false;
            this.lbl_AppDetails_Remarks.Location = new System.Drawing.Point(10, 260);
            this.lbl_AppDetails_Remarks.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_Remarks.Name = "lbl_AppDetails_Remarks";
            this.lbl_AppDetails_Remarks.Enabled = true;
            this.lbl_AppDetails_Remarks.Visible = true;
            this.lbl_AppDetails_Remarks.TabIndex = 11;
            this.lbl_AppDetails_Remarks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_Remarks.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_Remarks.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_Remarks.Text = @"  Remarks";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_Remarks, @"");

            this.lbl_AppDetails_CategoryId.AutoSize = false;
            this.lbl_AppDetails_CategoryId.Location = new System.Drawing.Point(8, 56);
            this.lbl_AppDetails_CategoryId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_CategoryId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_CategoryId.Name = "lbl_AppDetails_CategoryId";
            this.lbl_AppDetails_CategoryId.Enabled = true;
            this.lbl_AppDetails_CategoryId.Visible = true;
            this.lbl_AppDetails_CategoryId.TabIndex = 13;
            this.lbl_AppDetails_CategoryId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_CategoryId.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_CategoryId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_CategoryId.Text = @"  Category";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_CategoryId, @"");

            this.lbl_AppDetails_AppName.AutoSize = false;
            this.lbl_AppDetails_AppName.Location = new System.Drawing.Point(8, 91);
            this.lbl_AppDetails_AppName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppName.Name = "lbl_AppDetails_AppName";
            this.lbl_AppDetails_AppName.Enabled = true;
            this.lbl_AppDetails_AppName.Visible = true;
            this.lbl_AppDetails_AppName.TabIndex = 15;
            this.lbl_AppDetails_AppName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppName.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_AppName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppName.Text = @"* Project Name";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppName, @"");

            this.lbl_AppDetails_AppLink.AutoSize = false;
            this.lbl_AppDetails_AppLink.Location = new System.Drawing.Point(8, 126);
            this.lbl_AppDetails_AppLink.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppLink.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppLink.Name = "lbl_AppDetails_AppLink";
            this.lbl_AppDetails_AppLink.Enabled = true;
            this.lbl_AppDetails_AppLink.Visible = true;
            this.lbl_AppDetails_AppLink.TabIndex = 17;
            this.lbl_AppDetails_AppLink.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppLink.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_AppLink.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppLink.Text = @"  Project Link";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppLink, @"");

            this.lbl_AppDetails_LogoUrl.AutoSize = false;
            this.lbl_AppDetails_LogoUrl.Location = new System.Drawing.Point(1281, 156);
            this.lbl_AppDetails_LogoUrl.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_LogoUrl.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_LogoUrl.Name = "lbl_AppDetails_LogoUrl";
            this.lbl_AppDetails_LogoUrl.Enabled = true;
            this.lbl_AppDetails_LogoUrl.Visible = false;
            this.lbl_AppDetails_LogoUrl.TabIndex = 19;
            this.lbl_AppDetails_LogoUrl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_LogoUrl.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_LogoUrl.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_LogoUrl.Text = @"Logourl";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_LogoUrl, @"");

            this.lbl_AppDetails_LogoPath.AutoSize = false;
            this.lbl_AppDetails_LogoPath.Location = new System.Drawing.Point(102, 348);
            this.lbl_AppDetails_LogoPath.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_LogoPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_LogoPath.Name = "lbl_AppDetails_LogoPath";
            this.lbl_AppDetails_LogoPath.Enabled = true;
            this.lbl_AppDetails_LogoPath.Visible = false;
            this.lbl_AppDetails_LogoPath.TabIndex = 21;
            this.lbl_AppDetails_LogoPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_LogoPath.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_LogoPath.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_LogoPath.Text = @"Logopath";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_LogoPath, @"");

            this.lbl_AppDetails_AppLogo.AutoSize = false;
            this.lbl_AppDetails_AppLogo.Location = new System.Drawing.Point(1281, 211);
            this.lbl_AppDetails_AppLogo.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppLogo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppLogo.Name = "lbl_AppDetails_AppLogo";
            this.lbl_AppDetails_AppLogo.Enabled = true;
            this.lbl_AppDetails_AppLogo.Visible = false;
            this.lbl_AppDetails_AppLogo.TabIndex = 23;
            this.lbl_AppDetails_AppLogo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppLogo.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_AppLogo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppLogo.Text = @"Applogo";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppLogo, @"");

            this.lbl_AppDetails_CustomerCompany.AutoSize = false;
            this.lbl_AppDetails_CustomerCompany.Location = new System.Drawing.Point(8, 161);
            this.lbl_AppDetails_CustomerCompany.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_CustomerCompany.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_CustomerCompany.Name = "lbl_AppDetails_CustomerCompany";
            this.lbl_AppDetails_CustomerCompany.Enabled = true;
            this.lbl_AppDetails_CustomerCompany.Visible = true;
            this.lbl_AppDetails_CustomerCompany.TabIndex = 25;
            this.lbl_AppDetails_CustomerCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_CustomerCompany.Size = new System.Drawing.Size(134, 23);
            this.lbl_AppDetails_CustomerCompany.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_CustomerCompany.Text = @"* Customer Company";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_CustomerCompany, @"");

            this.lbl_AppDetails_CustomerLogo.AutoSize = false;
            this.lbl_AppDetails_CustomerLogo.Location = new System.Drawing.Point(211, 346);
            this.lbl_AppDetails_CustomerLogo.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_CustomerLogo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_CustomerLogo.Name = "lbl_AppDetails_CustomerLogo";
            this.lbl_AppDetails_CustomerLogo.Enabled = true;
            this.lbl_AppDetails_CustomerLogo.Visible = false;
            this.lbl_AppDetails_CustomerLogo.TabIndex = 27;
            this.lbl_AppDetails_CustomerLogo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_CustomerLogo.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_CustomerLogo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_CustomerLogo.Text = @"Customerlogo";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_CustomerLogo, @"");

            this.lbl_CompanyTitle1.AutoSize = false;
            this.lbl_CompanyTitle1.Location = new System.Drawing.Point(773, 207);
            this.lbl_CompanyTitle1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyTitle1.ForeColor = System.Drawing.Color.FromArgb(-8355712);
            this.lbl_CompanyTitle1.Name = "lbl_CompanyTitle1";
            this.lbl_CompanyTitle1.Enabled = true;
            this.lbl_CompanyTitle1.Visible = true;
            this.lbl_CompanyTitle1.TabIndex = 4;
            this.lbl_CompanyTitle1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_CompanyTitle1.Size = new System.Drawing.Size(177, 22);
            this.lbl_CompanyTitle1.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyTitle1.Text = @"(Preferred Size 200px)";
            this.toolTip1.SetToolTip(this.lbl_CompanyTitle1, @"");

            this.lbl_CompanyLogo.AutoSize = false;
            this.lbl_CompanyLogo.Location = new System.Drawing.Point(773, 19);
            this.lbl_CompanyLogo.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyLogo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CompanyLogo.Name = "lbl_CompanyLogo";
            this.lbl_CompanyLogo.Enabled = true;
            this.lbl_CompanyLogo.Visible = true;
            this.lbl_CompanyLogo.TabIndex = 50;
            this.lbl_CompanyLogo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CompanyLogo.Size = new System.Drawing.Size(162, 23);
            this.lbl_CompanyLogo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyLogo.Text = @"Customer Company Logo";
            this.toolTip1.SetToolTip(this.lbl_CompanyLogo, @"");

            this.lbl_CompanyTitle.AutoSize = false;
            this.lbl_CompanyTitle.Location = new System.Drawing.Point(587, 207);
            this.lbl_CompanyTitle.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyTitle.ForeColor = System.Drawing.Color.FromArgb(-8355712);
            this.lbl_CompanyTitle.Name = "lbl_CompanyTitle";
            this.lbl_CompanyTitle.Enabled = true;
            this.lbl_CompanyTitle.Visible = true;
            this.lbl_CompanyTitle.TabIndex = 4;
            this.lbl_CompanyTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_CompanyTitle.Size = new System.Drawing.Size(177, 22);
            this.lbl_CompanyTitle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyTitle.Text = @"(Preferred Size 200px)";
            this.toolTip1.SetToolTip(this.lbl_CompanyTitle, @"");

            this.lbl_CompanyLogo1.AutoSize = false;
            this.lbl_CompanyLogo1.Location = new System.Drawing.Point(587, 19);
            this.lbl_CompanyLogo1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyLogo1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CompanyLogo1.Name = "lbl_CompanyLogo1";
            this.lbl_CompanyLogo1.Enabled = true;
            this.lbl_CompanyLogo1.Visible = true;
            this.lbl_CompanyLogo1.TabIndex = 50;
            this.lbl_CompanyLogo1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CompanyLogo1.Size = new System.Drawing.Size(116, 23);
            this.lbl_CompanyLogo1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyLogo1.Text = @"Application Logo";
            this.toolTip1.SetToolTip(this.lbl_CompanyLogo1, @"");

            this.txt_AppDetails_AppId.Location = new System.Drawing.Point(146, 18);
            this.txt_AppDetails_AppId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_AppId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppId.Name = "txt_AppDetails_AppId";
            this.txt_AppDetails_AppId.DefaultValue = null;
            this.txt_AppDetails_AppId.FriendlyName = "";
            this.txt_AppDetails_AppId.Enabled = true;
            this.txt_AppDetails_AppId.Visible = true;
            this.txt_AppDetails_AppId.ReadOnly = false;
            this.txt_AppDetails_AppId.TabIndex = 0;
            this.txt_AppDetails_AppId.MaxValue = 2147483647;
            this.txt_AppDetails_AppId.MinValue = -2147483648;
            this.txt_AppDetails_AppId.ValidationMessage = "";
            this.txt_AppDetails_AppId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppId.Size = new System.Drawing.Size(85, 29);
            this.txt_AppDetails_AppId.SelectAllOnFocus = true;
            this.txt_AppDetails_AppId.DoValidation = false;
            this.txt_AppDetails_AppId.AllowNull = false;
            this.txt_AppDetails_AppId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppId, @"");

            this.txt_AppDetails_AppDescription.Location = new System.Drawing.Point(146, 193);
            this.txt_AppDetails_AppDescription.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_AppDescription.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppDescription.Multiline = true;
            this.txt_AppDetails_AppDescription.MaxLength = 1000;
            this.txt_AppDetails_AppDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_AppDetails_AppDescription.Name = "txt_AppDetails_AppDescription";
            this.txt_AppDetails_AppDescription.Text = @"";
            
            this.txt_AppDetails_AppDescription.AllowNull = true;
            this.txt_AppDetails_AppDescription.DefaultValue = "";
            this.txt_AppDetails_AppDescription.FriendlyName = "";
            this.txt_AppDetails_AppDescription.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppDescription.ValidationExpression = @"";
            this.txt_AppDetails_AppDescription.ValidationMessage = @"";
            this.txt_AppDetails_AppDescription.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppDescription.Enabled = true;
            this.txt_AppDetails_AppDescription.ReadOnly = false;
            this.txt_AppDetails_AppDescription.Visible = true;
            this.txt_AppDetails_AppDescription.TabIndex = 7;
            this.txt_AppDetails_AppDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppDescription.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppDescription.Size = new System.Drawing.Size(431, 58);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppDescription, @"");

            this.txt_AppDetails_Remarks.Location = new System.Drawing.Point(146, 257);
            this.txt_AppDetails_Remarks.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_Remarks.Multiline = true;
            this.txt_AppDetails_Remarks.MaxLength = 1000;
            this.txt_AppDetails_Remarks.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_AppDetails_Remarks.Name = "txt_AppDetails_Remarks";
            this.txt_AppDetails_Remarks.Text = @"";
            
            this.txt_AppDetails_Remarks.AllowNull = true;
            this.txt_AppDetails_Remarks.DefaultValue = "";
            this.txt_AppDetails_Remarks.FriendlyName = "";
            this.txt_AppDetails_Remarks.ValidationType = TextValidation.None;
            this.txt_AppDetails_Remarks.ValidationExpression = @"";
            this.txt_AppDetails_Remarks.ValidationMessage = @"";
            this.txt_AppDetails_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_Remarks.Enabled = true;
            this.txt_AppDetails_Remarks.ReadOnly = false;
            this.txt_AppDetails_Remarks.Visible = true;
            this.txt_AppDetails_Remarks.TabIndex = 8;
            this.txt_AppDetails_Remarks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_Remarks.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_Remarks.Size = new System.Drawing.Size(431, 58);
            this.toolTip1.SetToolTip(this.txt_AppDetails_Remarks, @"");

            this.txt_AppDetails_AppName.Location = new System.Drawing.Point(146, 88);
            this.txt_AppDetails_AppName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_AppName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppName.Multiline = false;
            this.txt_AppDetails_AppName.MaxLength = 255;
            this.txt_AppDetails_AppName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_AppName.Name = "txt_AppDetails_AppName";
            this.txt_AppDetails_AppName.Text = @"";
            
            this.txt_AppDetails_AppName.AllowNull = false;
            this.txt_AppDetails_AppName.DefaultValue = "";
            this.txt_AppDetails_AppName.FriendlyName = "";
            this.txt_AppDetails_AppName.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppName.ValidationExpression = @"";
            this.txt_AppDetails_AppName.ValidationMessage = @"";
            this.txt_AppDetails_AppName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppName.Enabled = true;
            this.txt_AppDetails_AppName.ReadOnly = false;
            this.txt_AppDetails_AppName.Visible = true;
            this.txt_AppDetails_AppName.TabIndex = 3;
            this.txt_AppDetails_AppName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppName.Size = new System.Drawing.Size(431, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppName, @"");

            this.txt_AppDetails_AppLink.Location = new System.Drawing.Point(146, 123);
            this.txt_AppDetails_AppLink.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_AppLink.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppLink.Multiline = false;
            this.txt_AppDetails_AppLink.MaxLength = 250;
            this.txt_AppDetails_AppLink.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_AppLink.Name = "txt_AppDetails_AppLink";
            this.txt_AppDetails_AppLink.Text = @"";
            
            this.txt_AppDetails_AppLink.AllowNull = true;
            this.txt_AppDetails_AppLink.DefaultValue = "";
            this.txt_AppDetails_AppLink.FriendlyName = "";
            this.txt_AppDetails_AppLink.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppLink.ValidationExpression = @"";
            this.txt_AppDetails_AppLink.ValidationMessage = @"";
            this.txt_AppDetails_AppLink.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppLink.Enabled = true;
            this.txt_AppDetails_AppLink.ReadOnly = false;
            this.txt_AppDetails_AppLink.Visible = true;
            this.txt_AppDetails_AppLink.TabIndex = 4;
            this.txt_AppDetails_AppLink.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppLink.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppLink.Size = new System.Drawing.Size(345, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppLink, @"");

            this.txt_AppDetails_LogoUrl.Location = new System.Drawing.Point(1282, 182);
            this.txt_AppDetails_LogoUrl.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_LogoUrl.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_LogoUrl.Multiline = false;
            this.txt_AppDetails_LogoUrl.MaxLength = 250;
            this.txt_AppDetails_LogoUrl.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_LogoUrl.Name = "txt_AppDetails_LogoUrl";
            this.txt_AppDetails_LogoUrl.Text = @"";
            
            this.txt_AppDetails_LogoUrl.AllowNull = true;
            this.txt_AppDetails_LogoUrl.DefaultValue = "";
            this.txt_AppDetails_LogoUrl.FriendlyName = "";
            this.txt_AppDetails_LogoUrl.ValidationType = TextValidation.None;
            this.txt_AppDetails_LogoUrl.ValidationExpression = @"";
            this.txt_AppDetails_LogoUrl.ValidationMessage = @"";
            this.txt_AppDetails_LogoUrl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_LogoUrl.Enabled = true;
            this.txt_AppDetails_LogoUrl.ReadOnly = false;
            this.txt_AppDetails_LogoUrl.Visible = false;
            this.txt_AppDetails_LogoUrl.TabIndex = 18;
            this.txt_AppDetails_LogoUrl.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_LogoUrl.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_LogoUrl.Size = new System.Drawing.Size(100, 20);
            this.toolTip1.SetToolTip(this.txt_AppDetails_LogoUrl, @"");

            this.txt_AppDetails_LogoPath.Location = new System.Drawing.Point(588, 231);
            this.txt_AppDetails_LogoPath.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_LogoPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_LogoPath.Multiline = false;
            this.txt_AppDetails_LogoPath.MaxLength = 250;
            this.txt_AppDetails_LogoPath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_LogoPath.Name = "txt_AppDetails_LogoPath";
            this.txt_AppDetails_LogoPath.Text = @"";
            
            this.txt_AppDetails_LogoPath.AllowNull = true;
            this.txt_AppDetails_LogoPath.DefaultValue = "";
            this.txt_AppDetails_LogoPath.FriendlyName = "";
            this.txt_AppDetails_LogoPath.ValidationType = TextValidation.None;
            this.txt_AppDetails_LogoPath.ValidationExpression = @"";
            this.txt_AppDetails_LogoPath.ValidationMessage = @"";
            this.txt_AppDetails_LogoPath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_LogoPath.Enabled = false;
            this.txt_AppDetails_LogoPath.ReadOnly = true;
            this.txt_AppDetails_LogoPath.Visible = false;
            this.txt_AppDetails_LogoPath.TabIndex = 20;
            this.txt_AppDetails_LogoPath.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_LogoPath.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_LogoPath.Size = new System.Drawing.Size(177, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_LogoPath, @"");
            this.txt_AppDetails_LogoPath.TextChanged += new System.EventHandler(this.txt_AppDetails_LogoPath_Evaluate_TextChanged);

            this.txt_AppDetails_AppLogo.Location = new System.Drawing.Point(1281, 238);
            this.txt_AppDetails_AppLogo.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_AppLogo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppLogo.Multiline = false;
            this.txt_AppDetails_AppLogo.MaxLength = 1000;
            this.txt_AppDetails_AppLogo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_AppLogo.Name = "txt_AppDetails_AppLogo";
            this.txt_AppDetails_AppLogo.Text = @"";
            
            this.txt_AppDetails_AppLogo.AllowNull = true;
            this.txt_AppDetails_AppLogo.DefaultValue = "";
            this.txt_AppDetails_AppLogo.FriendlyName = "";
            this.txt_AppDetails_AppLogo.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppLogo.ValidationExpression = @"";
            this.txt_AppDetails_AppLogo.ValidationMessage = @"";
            this.txt_AppDetails_AppLogo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppLogo.Enabled = true;
            this.txt_AppDetails_AppLogo.ReadOnly = false;
            this.txt_AppDetails_AppLogo.Visible = false;
            this.txt_AppDetails_AppLogo.TabIndex = 22;
            this.txt_AppDetails_AppLogo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppLogo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppLogo.Size = new System.Drawing.Size(100, 20);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppLogo, @"");
            this.txt_AppDetails_AppLogo.TextChanged += new System.EventHandler(this.txt_AppDetails_AppLogo_Evaluate_TextChanged);

            this.txt_AppDetails_CustomerCompany.Location = new System.Drawing.Point(146, 158);
            this.txt_AppDetails_CustomerCompany.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_CustomerCompany.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_CustomerCompany.Multiline = false;
            this.txt_AppDetails_CustomerCompany.MaxLength = 300;
            this.txt_AppDetails_CustomerCompany.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_CustomerCompany.Name = "txt_AppDetails_CustomerCompany";
            this.txt_AppDetails_CustomerCompany.Text = @"";
            
            this.txt_AppDetails_CustomerCompany.AllowNull = true;
            this.txt_AppDetails_CustomerCompany.DefaultValue = "";
            this.txt_AppDetails_CustomerCompany.FriendlyName = "";
            this.txt_AppDetails_CustomerCompany.ValidationType = TextValidation.None;
            this.txt_AppDetails_CustomerCompany.ValidationExpression = @"";
            this.txt_AppDetails_CustomerCompany.ValidationMessage = @"";
            this.txt_AppDetails_CustomerCompany.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_CustomerCompany.Enabled = true;
            this.txt_AppDetails_CustomerCompany.ReadOnly = false;
            this.txt_AppDetails_CustomerCompany.Visible = true;
            this.txt_AppDetails_CustomerCompany.TabIndex = 6;
            this.txt_AppDetails_CustomerCompany.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_CustomerCompany.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_CustomerCompany.Size = new System.Drawing.Size(431, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_CustomerCompany, @"");

            this.txt_AppDetails_CustomerLogo.Location = new System.Drawing.Point(774, 231);
            this.txt_AppDetails_CustomerLogo.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_CustomerLogo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_CustomerLogo.Multiline = false;
            this.txt_AppDetails_CustomerLogo.MaxLength = 1000;
            this.txt_AppDetails_CustomerLogo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_CustomerLogo.Name = "txt_AppDetails_CustomerLogo";
            this.txt_AppDetails_CustomerLogo.Text = @"";
            
            this.txt_AppDetails_CustomerLogo.AllowNull = true;
            this.txt_AppDetails_CustomerLogo.DefaultValue = "";
            this.txt_AppDetails_CustomerLogo.FriendlyName = "";
            this.txt_AppDetails_CustomerLogo.ValidationType = TextValidation.None;
            this.txt_AppDetails_CustomerLogo.ValidationExpression = @"";
            this.txt_AppDetails_CustomerLogo.ValidationMessage = @"";
            this.txt_AppDetails_CustomerLogo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_CustomerLogo.Enabled = false;
            this.txt_AppDetails_CustomerLogo.ReadOnly = true;
            this.txt_AppDetails_CustomerLogo.Visible = false;
            this.txt_AppDetails_CustomerLogo.TabIndex = 26;
            this.txt_AppDetails_CustomerLogo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_CustomerLogo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_CustomerLogo.Size = new System.Drawing.Size(177, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_CustomerLogo, @"");
            this.txt_AppDetails_CustomerLogo.TextChanged += new System.EventHandler(this.txt_AppDetails_CustomerLogo_Evaluate_TextChanged);

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(8, 378);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(962, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnAppId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnAppId.HeaderText = "Appid";
            this.dgrDataColumnAppId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppId.Name = "dgrDataColumnAppId";
            this.dgrDataColumnAppId.DataPropertyName = "AppId";
            this.dgrDataColumnAppId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppId.Width = 100;
            this.dgrDataColumnAppId.Visible = false;
            this.dgrDataColumnAppId.DisplayIndex = 0;
            this.dgrDataColumnAppId.ReadOnly = false;
            this.dgrDataColumnAppId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppId);

            this.dgrDataColumnTypeId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnTypeId.HeaderText = "Typeid";
            this.dgrDataColumnTypeId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnTypeId.Name = "dgrDataColumnTypeId";
            this.dgrDataColumnTypeId.DataPropertyName = "TypeId";
            this.dgrDataColumnTypeId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnTypeId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnTypeId.Width = 100;
            this.dgrDataColumnTypeId.Visible = false;
            this.dgrDataColumnTypeId.DisplayIndex = 1;
            this.dgrDataColumnTypeId.ReadOnly = false;
            this.dgrDataColumnTypeId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnTypeId);

            this.dgrDataColumnCategoryId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCategoryId.HeaderText = "Category";
            this.dgrDataColumnCategoryId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCategoryId.Name = "dgrDataColumnCategoryId";
            this.dgrDataColumnCategoryId.DataPropertyName = "CategoryId";
            this.dgrDataColumnCategoryId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnCategoryId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCategoryId.Width = 150;
            this.dgrDataColumnCategoryId.Visible = true;
            this.dgrDataColumnCategoryId.DisplayIndex = 1;
            this.dgrDataColumnCategoryId.ReadOnly = false;
            this.dgrDataColumnCategoryId.Tag = "select * from ProductTypeMaster";
            this.dgrDataColumnCategoryId.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCategoryId);

            this.dgrDataColumnAppDescription.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppDescription.HeaderText = "Appdescription";
            this.dgrDataColumnAppDescription.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppDescription.Name = "dgrDataColumnAppDescription";
            this.dgrDataColumnAppDescription.DataPropertyName = "AppDescription";
            this.dgrDataColumnAppDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppDescription.Width = 100;
            this.dgrDataColumnAppDescription.Visible = false;
            this.dgrDataColumnAppDescription.DisplayIndex = 2;
            this.dgrDataColumnAppDescription.ReadOnly = false;
            this.dgrDataColumnAppDescription.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppDescription);

            this.dgrDataColumnAppName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppName.HeaderText = "Project Name";
            this.dgrDataColumnAppName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppName.Name = "dgrDataColumnAppName";
            this.dgrDataColumnAppName.DataPropertyName = "AppName";
            this.dgrDataColumnAppName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnAppName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppName.Width = 300;
            this.dgrDataColumnAppName.Visible = true;
            this.dgrDataColumnAppName.DisplayIndex = 2;
            this.dgrDataColumnAppName.ReadOnly = false;
            this.dgrDataColumnAppName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppName);

            this.dgrDataColumnDOR.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnDOR.HeaderText = "Release Date";
            this.dgrDataColumnDOR.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnDOR.Name = "dgrDataColumnDOR";
            this.dgrDataColumnDOR.DataPropertyName = "DOR";
            this.dgrDataColumnDOR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnDOR.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnDOR.Width = 100;
            this.dgrDataColumnDOR.Visible = true;
            this.dgrDataColumnDOR.DisplayIndex = 3;
            this.dgrDataColumnDOR.ReadOnly = false;
            this.dgrDataColumnDOR.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnDOR);

            this.dgrDataColumnRemarks.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnRemarks.HeaderText = "Remarks";
            this.dgrDataColumnRemarks.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnRemarks.Name = "dgrDataColumnRemarks";
            this.dgrDataColumnRemarks.DataPropertyName = "Remarks";
            this.dgrDataColumnRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnRemarks.Width = 100;
            this.dgrDataColumnRemarks.Visible = false;
            this.dgrDataColumnRemarks.DisplayIndex = 4;
            this.dgrDataColumnRemarks.ReadOnly = false;
            this.dgrDataColumnRemarks.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnRemarks);

            this.dgrDataColumnAppLink.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppLink.HeaderText = "Applink";
            this.dgrDataColumnAppLink.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppLink.Name = "dgrDataColumnAppLink";
            this.dgrDataColumnAppLink.DataPropertyName = "AppLink";
            this.dgrDataColumnAppLink.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppLink.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppLink.Width = 100;
            this.dgrDataColumnAppLink.Visible = false;
            this.dgrDataColumnAppLink.DisplayIndex = 7;
            this.dgrDataColumnAppLink.ReadOnly = false;
            this.dgrDataColumnAppLink.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppLink);

            this.dgrDataColumnLogoUrl.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnLogoUrl.HeaderText = "Logourl";
            this.dgrDataColumnLogoUrl.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnLogoUrl.Name = "dgrDataColumnLogoUrl";
            this.dgrDataColumnLogoUrl.DataPropertyName = "LogoUrl";
            this.dgrDataColumnLogoUrl.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnLogoUrl.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnLogoUrl.Width = 100;
            this.dgrDataColumnLogoUrl.Visible = false;
            this.dgrDataColumnLogoUrl.DisplayIndex = 8;
            this.dgrDataColumnLogoUrl.ReadOnly = false;
            this.dgrDataColumnLogoUrl.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnLogoUrl);

            this.dgrDataColumnLogoPath.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnLogoPath.HeaderText = "Logopath";
            this.dgrDataColumnLogoPath.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnLogoPath.Name = "dgrDataColumnLogoPath";
            this.dgrDataColumnLogoPath.DataPropertyName = "LogoPath";
            this.dgrDataColumnLogoPath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnLogoPath.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnLogoPath.Width = 100;
            this.dgrDataColumnLogoPath.Visible = false;
            this.dgrDataColumnLogoPath.DisplayIndex = 9;
            this.dgrDataColumnLogoPath.ReadOnly = false;
            this.dgrDataColumnLogoPath.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnLogoPath);

            this.dgrDataColumnAppLogo.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppLogo.HeaderText = "Applogo";
            this.dgrDataColumnAppLogo.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppLogo.Name = "dgrDataColumnAppLogo";
            this.dgrDataColumnAppLogo.DataPropertyName = "AppLogo";
            this.dgrDataColumnAppLogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppLogo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppLogo.Width = 100;
            this.dgrDataColumnAppLogo.Visible = false;
            this.dgrDataColumnAppLogo.DisplayIndex = 10;
            this.dgrDataColumnAppLogo.ReadOnly = false;
            this.dgrDataColumnAppLogo.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppLogo);

            this.dgrDataColumnCustomerCompany.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCustomerCompany.HeaderText = "Customer Company";
            this.dgrDataColumnCustomerCompany.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCustomerCompany.Name = "dgrDataColumnCustomerCompany";
            this.dgrDataColumnCustomerCompany.DataPropertyName = "CustomerCompany";
            this.dgrDataColumnCustomerCompany.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnCustomerCompany.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCustomerCompany.Width = 300;
            this.dgrDataColumnCustomerCompany.Visible = true;
            this.dgrDataColumnCustomerCompany.DisplayIndex = 11;
            this.dgrDataColumnCustomerCompany.ReadOnly = false;
            this.dgrDataColumnCustomerCompany.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCustomerCompany);

            this.dgrDataColumnCustomerLogo.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCustomerLogo.HeaderText = "Customerlogo";
            this.dgrDataColumnCustomerLogo.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCustomerLogo.Name = "dgrDataColumnCustomerLogo";
            this.dgrDataColumnCustomerLogo.DataPropertyName = "CustomerLogo";
            this.dgrDataColumnCustomerLogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnCustomerLogo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCustomerLogo.Width = 100;
            this.dgrDataColumnCustomerLogo.Visible = false;
            this.dgrDataColumnCustomerLogo.DisplayIndex = 12;
            this.dgrDataColumnCustomerLogo.ReadOnly = false;
            this.dgrDataColumnCustomerLogo.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCustomerLogo);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpAppdetails);
            this.grpAppdetails.Controls.Add(this.btnClearImage);
            this.grpAppdetails.Controls.Add(this.btnAppImage);
            this.grpAppdetails.Controls.Add(this.btnClearImage2);
            this.grpAppdetails.Controls.Add(this.btnCustomerImage);
            this.grpAppdetails.Controls.Add(this.btn_CheckLink);
            this.grpAppdetails.Controls.Add(this.dtp_AppDetails_DOR);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_TypeId);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_CategoryId);
            this.grpAppdetails.Controls.Add(this.custCompanyLogo);
            this.grpAppdetails.Controls.Add(this.CompanyLogo);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_AppId);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_TypeId);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_AppDescription);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_DOR);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_Remarks);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_CategoryId);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_AppName);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_AppLink);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_LogoUrl);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_LogoPath);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_AppLogo);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_CustomerCompany);
            this.grpAppdetails.Controls.Add(this.lbl_AppDetails_CustomerLogo);
            this.grpAppdetails.Controls.Add(this.lbl_CompanyTitle1);
            this.grpAppdetails.Controls.Add(this.lbl_CompanyLogo);
            this.grpAppdetails.Controls.Add(this.lbl_CompanyTitle);
            this.grpAppdetails.Controls.Add(this.lbl_CompanyLogo1);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_AppId);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_AppDescription);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_Remarks);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_AppName);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_AppLink);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_LogoUrl);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_LogoPath);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_AppLogo);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_CustomerCompany);
            this.grpAppdetails.Controls.Add(this.txt_AppDetails_CustomerLogo);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Appdetails";
            this.Text = "Project Details";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(993, 747);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpAppdetails;
        private Kushal.Controls.KushalButton btnClearImage;
        private Kushal.Controls.KushalButton btnAppImage;
        private Kushal.Controls.KushalButton btnClearImage2;
        private Kushal.Controls.KushalButton btnCustomerImage;
        private Kushal.Controls.KushalButton btn_CheckLink;
        private DateTextBox dtp_AppDetails_DOR;
        private Kushal.Controls.KushalComboBox txt_AppDetails_TypeId;
        private Kushal.Controls.KushalComboBox txt_AppDetails_CategoryId;
        private Kushal.Controls.KushalPictureBox custCompanyLogo;
        private Kushal.Controls.KushalPictureBox CompanyLogo;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppId;
        private Kushal.Controls.KushalLabel lbl_AppDetails_TypeId;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppDescription;
        private Kushal.Controls.KushalLabel lbl_AppDetails_DOR;
        private Kushal.Controls.KushalLabel lbl_AppDetails_Remarks;
        private Kushal.Controls.KushalLabel lbl_AppDetails_CategoryId;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppName;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppLink;
        private Kushal.Controls.KushalLabel lbl_AppDetails_LogoUrl;
        private Kushal.Controls.KushalLabel lbl_AppDetails_LogoPath;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppLogo;
        private Kushal.Controls.KushalLabel lbl_AppDetails_CustomerCompany;
        private Kushal.Controls.KushalLabel lbl_AppDetails_CustomerLogo;
        private Kushal.Controls.KushalLabel lbl_CompanyTitle1;
        private Kushal.Controls.KushalLabel lbl_CompanyLogo;
        private Kushal.Controls.KushalLabel lbl_CompanyTitle;
        private Kushal.Controls.KushalLabel lbl_CompanyLogo1;
        private NumericTextBox txt_AppDetails_AppId;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppDescription;
        private Kushal.Controls.KushalTextBox txt_AppDetails_Remarks;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppName;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppLink;
        private Kushal.Controls.KushalTextBox txt_AppDetails_LogoUrl;
        private Kushal.Controls.KushalTextBox txt_AppDetails_LogoPath;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppLogo;
        private Kushal.Controls.KushalTextBox txt_AppDetails_CustomerCompany;
        private Kushal.Controls.KushalTextBox txt_AppDetails_CustomerLogo;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnTypeId;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnCategoryId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnDOR;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnLogoUrl;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnLogoPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppLogo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCustomerCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCustomerLogo;
    }
}