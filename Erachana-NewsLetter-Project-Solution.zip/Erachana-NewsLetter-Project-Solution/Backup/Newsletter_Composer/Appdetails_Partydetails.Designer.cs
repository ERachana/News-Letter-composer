using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Appdetails_Partydetails {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpAppdetails_Partydetails = new Kushal.Controls.KushalGroupBox();
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.btnClearImage = new Kushal.Controls.KushalButton();
            this.btnAppImage = new Kushal.Controls.KushalButton();
            this.btn_Check_Link = new Kushal.Controls.KushalButton();
            this.dtp_AppDetails_DOR = new DateTextBox();
            this.txt_AppDetails_TypeId = new Kushal.Controls.KushalComboBox();
            this.txt_AppDetails_CategoryId = new Kushal.Controls.KushalComboBox();
            this.CompanyLogo = new Kushal.Controls.KushalPictureBox();
            this.lbl_AppDetails_AppId = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_TypeId = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppDescription = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_DOR = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_Remarks = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_CategoryId = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppName = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_AppLink = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_LogoUrl = new Kushal.Controls.KushalLabel();
            this.lbl_AppDetails_LogoPath = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyTitle = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyLogo1 = new Kushal.Controls.KushalLabel();
            this.txt_AppDetails_AppId = new NumericTextBox();
            this.txt_AppDetails_AppDescription = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_Remarks = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_AppName = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_AppLink = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_LogoUrl = new Kushal.Controls.KushalTextBox();
            this.txt_AppDetails_LogoPath = new Kushal.Controls.KushalTextBox();
            this.dgr2 = new System.Windows.Forms.DataGridView();
            this.dgr2ColumnPartyId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnProdId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnCustomerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnCustomerCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnJoinDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnLogoPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnLogoURL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnCustomerLogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpAppdetails_PartydetailsChild = new Kushal.Controls.KushalGroupBox();
            this.btnAdd = new Kushal.Controls.KushalButton();
            this.btnUpdate = new Kushal.Controls.KushalButton();
            this.btnRemove = new Kushal.Controls.KushalButton();
            this.btnClearImage2 = new Kushal.Controls.KushalButton();
            this.btnCustomerImage = new Kushal.Controls.KushalButton();
            this.dtp_PartyDetails_JoinDate = new DateTextBox();
            this.custCompanyLogo = new Kushal.Controls.KushalPictureBox();
            this.lbl_PartyDetails_PartyId = new Kushal.Controls.KushalLabel();
            this.lbl_PartyDetails_ProdId = new Kushal.Controls.KushalLabel();
            this.lbl_PartyDetails_CustomerType = new Kushal.Controls.KushalLabel();
            this.lbl_PartyDetails_CustomerCompany = new Kushal.Controls.KushalLabel();
            this.lbl_PartyDetails_CustomerName = new Kushal.Controls.KushalLabel();
            this.lbl_PartyDetails_JoinDate = new Kushal.Controls.KushalLabel();
            this.lbl_PartyDetails_Remarks = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyTitle1 = new Kushal.Controls.KushalLabel();
            this.lbl_CompanyLogo = new Kushal.Controls.KushalLabel();
            this.lbl_logoURL = new Kushal.Controls.KushalLabel();
            this.lbl_logoPath = new Kushal.Controls.KushalLabel();
            this.txt_PartyDetails_PartyId = new NumericTextBox();
            this.txt_PartyDetails_ProdId = new NumericTextBox();
            this.txt_PartyDetails_CustomerType = new NumericTextBox();
            this.txt_PartyDetails_CustomerCompany = new Kushal.Controls.KushalTextBox();
            this.txt_PartyDetails_CustomerName = new Kushal.Controls.KushalTextBox();
            this.txt_PartyDetails_Remarks = new Kushal.Controls.KushalTextBox();
            this.txtLogoUrl = new Kushal.Controls.KushalTextBox();
            this.txtlogoPath = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnAppId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnTypeId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCategoryId = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnAppDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnAppName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnDOR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnAppLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnLogoUrl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnLogoPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnAppLogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCustomerCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCustomerLogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(1216, 587);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpAppdetails_Partydetails.Location = new System.Drawing.Point(8, -1);
            this.grpAppdetails_Partydetails.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpAppdetails_Partydetails.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpAppdetails_Partydetails.Name = "grpAppdetails_Partydetails";
            this.grpAppdetails_Partydetails.Enabled = true;
            this.grpAppdetails_Partydetails.Visible = true;
            this.grpAppdetails_Partydetails.TabIndex = 1;
            this.grpAppdetails_Partydetails.TabStop = false;
            this.grpAppdetails_Partydetails.Size = new System.Drawing.Size(991, 608);
            this.grpAppdetails_Partydetails.Text = @"Application Details";
            this.grpAppdetails_Partydetails.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAppdetails_Partydetails.SendToBack();
            this.toolTip1.SetToolTip(this.grpAppdetails_Partydetails, @"");

            this.btnNew.Location = new System.Drawing.Point(11, 259);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 18;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(238, 259);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 19;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(465, 259);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 20;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(692, 259);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 21;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.btnClearImage.Location = new System.Drawing.Point(880, 223);
            this.btnClearImage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClearImage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClearImage.Name = "btnClearImage";
            this.btnClearImage.Enabled = true;
            this.btnClearImage.Visible = true;
            this.btnClearImage.TabIndex = 8;
            this.btnClearImage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClearImage.Size = new System.Drawing.Size(103, 30);
            this.btnClearImage.Text = @"Clear Image";
            this.btnClearImage.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearImage.UseVisualStyleBackColor = false;
            this.btnClearImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClearImage, @"");
            
            

            this.btnAppImage.Location = new System.Drawing.Point(777, 223);
            this.btnAppImage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnAppImage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnAppImage.Name = "btnAppImage";
            this.btnAppImage.Enabled = true;
            this.btnAppImage.Visible = true;
            this.btnAppImage.TabIndex = 8;
            this.btnAppImage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnAppImage.Size = new System.Drawing.Size(103, 30);
            this.btnAppImage.Text = @"Browse Image";
            this.btnAppImage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppImage.UseVisualStyleBackColor = false;
            this.btnAppImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnAppImage, @"");
            
            

            this.btn_Check_Link.Location = new System.Drawing.Point(689, 160);
            this.btn_Check_Link.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btn_Check_Link.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btn_Check_Link.Name = "btn_Check_Link";
            this.btn_Check_Link.Enabled = true;
            this.btn_Check_Link.Visible = true;
            this.btn_Check_Link.TabIndex = 6;
            this.btn_Check_Link.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btn_Check_Link.Size = new System.Drawing.Size(80, 30);
            this.btn_Check_Link.Text = @"Check";
            this.btn_Check_Link.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Check_Link.UseVisualStyleBackColor = false;
            this.btn_Check_Link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btn_Check_Link, @"");
            
            

            this.dtp_AppDetails_DOR.Location = new System.Drawing.Point(544, 47);
            this.dtp_AppDetails_DOR.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.dtp_AppDetails_DOR.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.dtp_AppDetails_DOR.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_AppDetails_DOR.Name = "dtp_AppDetails_DOR";
            this.dtp_AppDetails_DOR.DefaultValue = null;
            this.dtp_AppDetails_DOR.Text = "";
            this.dtp_AppDetails_DOR.Value = null;
            this.dtp_AppDetails_DOR.FriendlyName = "";
            this.dtp_AppDetails_DOR.Enabled = true;
            this.dtp_AppDetails_DOR.Visible = true;
            this.dtp_AppDetails_DOR.TabIndex = 2;
            this.dtp_AppDetails_DOR.MinValue = new System.DateTime(((long)(0)));
            this.dtp_AppDetails_DOR.MaxValue = new System.DateTime(((long)(0)));
            this.dtp_AppDetails_DOR.ValidationMessage = "";
            this.dtp_AppDetails_DOR.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dtp_AppDetails_DOR.Size = new System.Drawing.Size(109, 29);
            this.dtp_AppDetails_DOR.SelectAllOnFocus = true;
            this.dtp_AppDetails_DOR.DoValidation = false;
            this.dtp_AppDetails_DOR.AllowNull = true;
            this.dtp_AppDetails_DOR.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.dtp_AppDetails_DOR, @"");

            this.txt_AppDetails_TypeId.Location = new System.Drawing.Point(477, 16);
            this.txt_AppDetails_TypeId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_AppDetails_TypeId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_AppDetails_TypeId.MaxDropDownItems = 10;
            this.txt_AppDetails_TypeId.IntegralHeight = false;
            this.txt_AppDetails_TypeId.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_TypeId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_TypeId.FormattingEnabled = true;
            this.txt_AppDetails_TypeId.Name = "txt_AppDetails_TypeId";
            this.txt_AppDetails_TypeId.AllowNull = false;
            this.txt_AppDetails_TypeId.FriendlyName = "";
            this.txt_AppDetails_TypeId.Enabled = false;
            this.txt_AppDetails_TypeId.Visible = false;
            this.txt_AppDetails_TypeId.TabIndex = 4;
            this.txt_AppDetails_TypeId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_AppDetails_TypeId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_AppDetails_TypeId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_TypeId.Size = new System.Drawing.Size(234, 29);
            this.txt_AppDetails_TypeId.Tag = "Select ListID,ListCode from ListMaster where ListTypeID = 2";
            this.toolTip1.SetToolTip(this.txt_AppDetails_TypeId, @"");
            

            this.txt_AppDetails_CategoryId.Location = new System.Drawing.Point(140, 50);
            this.txt_AppDetails_CategoryId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_AppDetails_CategoryId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_AppDetails_CategoryId.MaxDropDownItems = 10;
            this.txt_AppDetails_CategoryId.IntegralHeight = false;
            this.txt_AppDetails_CategoryId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_CategoryId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_CategoryId.FormattingEnabled = true;
            this.txt_AppDetails_CategoryId.Name = "txt_AppDetails_CategoryId";
            this.txt_AppDetails_CategoryId.AllowNull = true;
            this.txt_AppDetails_CategoryId.FriendlyName = "";
            this.txt_AppDetails_CategoryId.Enabled = true;
            this.txt_AppDetails_CategoryId.Visible = true;
            this.txt_AppDetails_CategoryId.TabIndex = 1;
            this.txt_AppDetails_CategoryId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_AppDetails_CategoryId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_AppDetails_CategoryId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_CategoryId.Size = new System.Drawing.Size(229, 29);
            this.txt_AppDetails_CategoryId.Tag = "select * from ProductTypeMaster";
            this.toolTip1.SetToolTip(this.txt_AppDetails_CategoryId, @"");
            

            this.CompanyLogo.Location = new System.Drawing.Point(777, 39);
            this.CompanyLogo.Name = "CompanyLogo";
            this.CompanyLogo.AllowNull = true;
            this.CompanyLogo.FriendlyName = "";
            this.CompanyLogo.Enabled = true;
            this.CompanyLogo.Visible = true;
            this.CompanyLogo.Size = new System.Drawing.Size(200, 162);
            this.CompanyLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CompanyLogo.TabIndex = 0;
            this.CompanyLogo.TabStop = false;
            this.CompanyLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolTip1.SetToolTip(this.CompanyLogo, @"");
            
            

            this.lbl_AppDetails_AppId.AutoSize = false;
            this.lbl_AppDetails_AppId.Location = new System.Drawing.Point(7, 23);
            this.lbl_AppDetails_AppId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppId.Name = "lbl_AppDetails_AppId";
            this.lbl_AppDetails_AppId.Enabled = true;
            this.lbl_AppDetails_AppId.Visible = true;
            this.lbl_AppDetails_AppId.TabIndex = 3;
            this.lbl_AppDetails_AppId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppId.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_AppId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppId.Text = @"* ID";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppId, @"");

            this.lbl_AppDetails_TypeId.AutoSize = false;
            this.lbl_AppDetails_TypeId.Location = new System.Drawing.Point(982, 146);
            this.lbl_AppDetails_TypeId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_TypeId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_TypeId.Name = "lbl_AppDetails_TypeId";
            this.lbl_AppDetails_TypeId.Enabled = true;
            this.lbl_AppDetails_TypeId.Visible = false;
            this.lbl_AppDetails_TypeId.TabIndex = 5;
            this.lbl_AppDetails_TypeId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_TypeId.Size = new System.Drawing.Size(100, 24);
            this.lbl_AppDetails_TypeId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_TypeId.Text = @"* Type";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_TypeId, @"");

            this.lbl_AppDetails_AppDescription.AutoSize = false;
            this.lbl_AppDetails_AppDescription.Location = new System.Drawing.Point(7, 113);
            this.lbl_AppDetails_AppDescription.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppDescription.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppDescription.Name = "lbl_AppDetails_AppDescription";
            this.lbl_AppDetails_AppDescription.Enabled = true;
            this.lbl_AppDetails_AppDescription.Visible = true;
            this.lbl_AppDetails_AppDescription.TabIndex = 7;
            this.lbl_AppDetails_AppDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppDescription.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_AppDescription.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppDescription.Text = @"  Description";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppDescription, @"");

            this.lbl_AppDetails_DOR.AutoSize = false;
            this.lbl_AppDetails_DOR.Location = new System.Drawing.Point(436, 50);
            this.lbl_AppDetails_DOR.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_DOR.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_DOR.Name = "lbl_AppDetails_DOR";
            this.lbl_AppDetails_DOR.Enabled = true;
            this.lbl_AppDetails_DOR.Visible = true;
            this.lbl_AppDetails_DOR.TabIndex = 9;
            this.lbl_AppDetails_DOR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_DOR.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_DOR.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_DOR.Text = @"* Release Date";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_DOR, @"");

            this.lbl_AppDetails_Remarks.AutoSize = false;
            this.lbl_AppDetails_Remarks.Location = new System.Drawing.Point(7, 195);
            this.lbl_AppDetails_Remarks.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_Remarks.Name = "lbl_AppDetails_Remarks";
            this.lbl_AppDetails_Remarks.Enabled = true;
            this.lbl_AppDetails_Remarks.Visible = true;
            this.lbl_AppDetails_Remarks.TabIndex = 11;
            this.lbl_AppDetails_Remarks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_Remarks.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_Remarks.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_Remarks.Text = @"  Remarks";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_Remarks, @"");

            this.lbl_AppDetails_CategoryId.AutoSize = false;
            this.lbl_AppDetails_CategoryId.Location = new System.Drawing.Point(7, 50);
            this.lbl_AppDetails_CategoryId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_CategoryId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_CategoryId.Name = "lbl_AppDetails_CategoryId";
            this.lbl_AppDetails_CategoryId.Enabled = true;
            this.lbl_AppDetails_CategoryId.Visible = true;
            this.lbl_AppDetails_CategoryId.TabIndex = 13;
            this.lbl_AppDetails_CategoryId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_CategoryId.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_CategoryId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_CategoryId.Text = @"* App Category";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_CategoryId, @"");

            this.lbl_AppDetails_AppName.AutoSize = false;
            this.lbl_AppDetails_AppName.Location = new System.Drawing.Point(7, 85);
            this.lbl_AppDetails_AppName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppName.Name = "lbl_AppDetails_AppName";
            this.lbl_AppDetails_AppName.Enabled = true;
            this.lbl_AppDetails_AppName.Visible = true;
            this.lbl_AppDetails_AppName.TabIndex = 15;
            this.lbl_AppDetails_AppName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppName.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_AppName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppName.Text = @"* App Name";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppName, @"");

            this.lbl_AppDetails_AppLink.AutoSize = false;
            this.lbl_AppDetails_AppLink.Location = new System.Drawing.Point(7, 164);
            this.lbl_AppDetails_AppLink.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_AppLink.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_AppLink.Name = "lbl_AppDetails_AppLink";
            this.lbl_AppDetails_AppLink.Enabled = true;
            this.lbl_AppDetails_AppLink.Visible = true;
            this.lbl_AppDetails_AppLink.TabIndex = 17;
            this.lbl_AppDetails_AppLink.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_AppLink.Size = new System.Drawing.Size(130, 23);
            this.lbl_AppDetails_AppLink.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_AppLink.Text = @"  App/Website link";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_AppLink, @"");

            this.lbl_AppDetails_LogoUrl.AutoSize = false;
            this.lbl_AppDetails_LogoUrl.Location = new System.Drawing.Point(984, 18);
            this.lbl_AppDetails_LogoUrl.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_LogoUrl.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_LogoUrl.Name = "lbl_AppDetails_LogoUrl";
            this.lbl_AppDetails_LogoUrl.Enabled = true;
            this.lbl_AppDetails_LogoUrl.Visible = false;
            this.lbl_AppDetails_LogoUrl.TabIndex = 19;
            this.lbl_AppDetails_LogoUrl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_LogoUrl.Size = new System.Drawing.Size(100, 23);
            this.lbl_AppDetails_LogoUrl.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_LogoUrl.Text = @"  URL";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_LogoUrl, @"");

            this.lbl_AppDetails_LogoPath.AutoSize = false;
            this.lbl_AppDetails_LogoPath.Location = new System.Drawing.Point(298, 227);
            this.lbl_AppDetails_LogoPath.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AppDetails_LogoPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AppDetails_LogoPath.Name = "lbl_AppDetails_LogoPath";
            this.lbl_AppDetails_LogoPath.Enabled = true;
            this.lbl_AppDetails_LogoPath.Visible = false;
            this.lbl_AppDetails_LogoPath.TabIndex = 21;
            this.lbl_AppDetails_LogoPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AppDetails_LogoPath.Size = new System.Drawing.Size(76, 23);
            this.lbl_AppDetails_LogoPath.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppDetails_LogoPath.Text = @"  File Path";
            this.toolTip1.SetToolTip(this.lbl_AppDetails_LogoPath, @"");

            this.lbl_CompanyTitle.AutoSize = false;
            this.lbl_CompanyTitle.Location = new System.Drawing.Point(806, 201);
            this.lbl_CompanyTitle.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyTitle.ForeColor = System.Drawing.Color.FromArgb(-8355712);
            this.lbl_CompanyTitle.Name = "lbl_CompanyTitle";
            this.lbl_CompanyTitle.Enabled = true;
            this.lbl_CompanyTitle.Visible = true;
            this.lbl_CompanyTitle.TabIndex = 4;
            this.lbl_CompanyTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_CompanyTitle.Size = new System.Drawing.Size(141, 22);
            this.lbl_CompanyTitle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyTitle.Text = @"(Preferred Size 200px)";
            this.toolTip1.SetToolTip(this.lbl_CompanyTitle, @"");

            this.lbl_CompanyLogo1.AutoSize = false;
            this.lbl_CompanyLogo1.Location = new System.Drawing.Point(777, 15);
            this.lbl_CompanyLogo1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyLogo1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CompanyLogo1.Name = "lbl_CompanyLogo1";
            this.lbl_CompanyLogo1.Enabled = true;
            this.lbl_CompanyLogo1.Visible = true;
            this.lbl_CompanyLogo1.TabIndex = 50;
            this.lbl_CompanyLogo1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CompanyLogo1.Size = new System.Drawing.Size(116, 23);
            this.lbl_CompanyLogo1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyLogo1.Text = @"Application Logo";
            this.toolTip1.SetToolTip(this.lbl_CompanyLogo1, @"");

            this.txt_AppDetails_AppId.Location = new System.Drawing.Point(140, 20);
            this.txt_AppDetails_AppId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_AppId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppId.Name = "txt_AppDetails_AppId";
            this.txt_AppDetails_AppId.DefaultValue = null;
            this.txt_AppDetails_AppId.FriendlyName = "";
            this.txt_AppDetails_AppId.Enabled = true;
            this.txt_AppDetails_AppId.Visible = true;
            this.txt_AppDetails_AppId.ReadOnly = false;
            this.txt_AppDetails_AppId.TabIndex = 0;
            this.txt_AppDetails_AppId.MaxValue = 2147483647;
            this.txt_AppDetails_AppId.MinValue = -2147483648;
            this.txt_AppDetails_AppId.ValidationMessage = "";
            this.txt_AppDetails_AppId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppId.Size = new System.Drawing.Size(96, 29);
            this.txt_AppDetails_AppId.SelectAllOnFocus = true;
            this.txt_AppDetails_AppId.DoValidation = false;
            this.txt_AppDetails_AppId.AllowNull = false;
            this.txt_AppDetails_AppId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppId, @"");

            this.txt_AppDetails_AppDescription.Location = new System.Drawing.Point(140, 113);
            this.txt_AppDetails_AppDescription.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_AppDescription.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppDescription.Multiline = true;
            this.txt_AppDetails_AppDescription.MaxLength = 4000;
            this.txt_AppDetails_AppDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_AppDetails_AppDescription.Name = "txt_AppDetails_AppDescription";
            this.txt_AppDetails_AppDescription.Text = @"";
            
            this.txt_AppDetails_AppDescription.AllowNull = true;
            this.txt_AppDetails_AppDescription.DefaultValue = "";
            this.txt_AppDetails_AppDescription.FriendlyName = "";
            this.txt_AppDetails_AppDescription.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppDescription.ValidationExpression = @"";
            this.txt_AppDetails_AppDescription.ValidationMessage = @"";
            this.txt_AppDetails_AppDescription.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppDescription.Enabled = true;
            this.txt_AppDetails_AppDescription.ReadOnly = false;
            this.txt_AppDetails_AppDescription.Visible = true;
            this.txt_AppDetails_AppDescription.TabIndex = 4;
            this.txt_AppDetails_AppDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppDescription.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppDescription.Size = new System.Drawing.Size(633, 46);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppDescription, @"");

            this.txt_AppDetails_Remarks.Location = new System.Drawing.Point(140, 192);
            this.txt_AppDetails_Remarks.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_Remarks.Multiline = false;
            this.txt_AppDetails_Remarks.MaxLength = 1000;
            this.txt_AppDetails_Remarks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_Remarks.Name = "txt_AppDetails_Remarks";
            this.txt_AppDetails_Remarks.Text = @"";
            
            this.txt_AppDetails_Remarks.AllowNull = true;
            this.txt_AppDetails_Remarks.DefaultValue = "";
            this.txt_AppDetails_Remarks.FriendlyName = "";
            this.txt_AppDetails_Remarks.ValidationType = TextValidation.None;
            this.txt_AppDetails_Remarks.ValidationExpression = @"";
            this.txt_AppDetails_Remarks.ValidationMessage = @"";
            this.txt_AppDetails_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_Remarks.Enabled = true;
            this.txt_AppDetails_Remarks.ReadOnly = false;
            this.txt_AppDetails_Remarks.Visible = true;
            this.txt_AppDetails_Remarks.TabIndex = 7;
            this.txt_AppDetails_Remarks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_Remarks.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_Remarks.Size = new System.Drawing.Size(633, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_Remarks, @"");

            this.txt_AppDetails_AppName.Location = new System.Drawing.Point(140, 82);
            this.txt_AppDetails_AppName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_AppDetails_AppName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppName.Multiline = false;
            this.txt_AppDetails_AppName.MaxLength = 255;
            this.txt_AppDetails_AppName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_AppName.Name = "txt_AppDetails_AppName";
            this.txt_AppDetails_AppName.Text = @"";
            
            this.txt_AppDetails_AppName.AllowNull = false;
            this.txt_AppDetails_AppName.DefaultValue = "";
            this.txt_AppDetails_AppName.FriendlyName = "";
            this.txt_AppDetails_AppName.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppName.ValidationExpression = @"";
            this.txt_AppDetails_AppName.ValidationMessage = @"";
            this.txt_AppDetails_AppName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppName.Enabled = true;
            this.txt_AppDetails_AppName.ReadOnly = false;
            this.txt_AppDetails_AppName.Visible = true;
            this.txt_AppDetails_AppName.TabIndex = 3;
            this.txt_AppDetails_AppName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppName.Size = new System.Drawing.Size(633, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppName, @"");

            this.txt_AppDetails_AppLink.Location = new System.Drawing.Point(140, 161);
            this.txt_AppDetails_AppLink.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AppDetails_AppLink.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_AppLink.Multiline = false;
            this.txt_AppDetails_AppLink.MaxLength = 4000;
            this.txt_AppDetails_AppLink.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_AppLink.Name = "txt_AppDetails_AppLink";
            this.txt_AppDetails_AppLink.Text = @"";
            
            this.txt_AppDetails_AppLink.AllowNull = true;
            this.txt_AppDetails_AppLink.DefaultValue = "";
            this.txt_AppDetails_AppLink.FriendlyName = "";
            this.txt_AppDetails_AppLink.ValidationType = TextValidation.None;
            this.txt_AppDetails_AppLink.ValidationExpression = @"";
            this.txt_AppDetails_AppLink.ValidationMessage = @"";
            this.txt_AppDetails_AppLink.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_AppLink.Enabled = true;
            this.txt_AppDetails_AppLink.ReadOnly = false;
            this.txt_AppDetails_AppLink.Visible = true;
            this.txt_AppDetails_AppLink.TabIndex = 5;
            this.txt_AppDetails_AppLink.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_AppLink.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_AppLink.Size = new System.Drawing.Size(542, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_AppLink, @"");

            this.txt_AppDetails_LogoUrl.Location = new System.Drawing.Point(986, 40);
            this.txt_AppDetails_LogoUrl.BackColor = System.Drawing.Color.FromArgb(-4144897);
            this.txt_AppDetails_LogoUrl.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_LogoUrl.Multiline = false;
            this.txt_AppDetails_LogoUrl.MaxLength = 4000;
            this.txt_AppDetails_LogoUrl.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_LogoUrl.Name = "txt_AppDetails_LogoUrl";
            this.txt_AppDetails_LogoUrl.Text = @"";
            
            this.txt_AppDetails_LogoUrl.AllowNull = true;
            this.txt_AppDetails_LogoUrl.DefaultValue = "";
            this.txt_AppDetails_LogoUrl.FriendlyName = "";
            this.txt_AppDetails_LogoUrl.ValidationType = TextValidation.None;
            this.txt_AppDetails_LogoUrl.ValidationExpression = @"";
            this.txt_AppDetails_LogoUrl.ValidationMessage = @"";
            this.txt_AppDetails_LogoUrl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_LogoUrl.Enabled = true;
            this.txt_AppDetails_LogoUrl.ReadOnly = false;
            this.txt_AppDetails_LogoUrl.Visible = false;
            this.txt_AppDetails_LogoUrl.TabIndex = 18;
            this.txt_AppDetails_LogoUrl.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_LogoUrl.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_LogoUrl.Size = new System.Drawing.Size(234, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_LogoUrl, @"");

            this.txt_AppDetails_LogoPath.Location = new System.Drawing.Point(381, 224);
            this.txt_AppDetails_LogoPath.BackColor = System.Drawing.Color.FromArgb(-4144897);
            this.txt_AppDetails_LogoPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AppDetails_LogoPath.Multiline = false;
            this.txt_AppDetails_LogoPath.MaxLength = 4000;
            this.txt_AppDetails_LogoPath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AppDetails_LogoPath.Name = "txt_AppDetails_LogoPath";
            this.txt_AppDetails_LogoPath.Text = @"";
            
            this.txt_AppDetails_LogoPath.AllowNull = true;
            this.txt_AppDetails_LogoPath.DefaultValue = "";
            this.txt_AppDetails_LogoPath.FriendlyName = "";
            this.txt_AppDetails_LogoPath.ValidationType = TextValidation.None;
            this.txt_AppDetails_LogoPath.ValidationExpression = @"";
            this.txt_AppDetails_LogoPath.ValidationMessage = @"";
            this.txt_AppDetails_LogoPath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AppDetails_LogoPath.Enabled = true;
            this.txt_AppDetails_LogoPath.ReadOnly = true;
            this.txt_AppDetails_LogoPath.Visible = false;
            this.txt_AppDetails_LogoPath.TabIndex = 20;
            this.txt_AppDetails_LogoPath.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AppDetails_LogoPath.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppDetails_LogoPath.Size = new System.Drawing.Size(391, 29);
            this.toolTip1.SetToolTip(this.txt_AppDetails_LogoPath, @"");
            this.txt_AppDetails_LogoPath.TextChanged += new System.EventHandler(this.txt_AppDetails_LogoPath_Evaluate_TextChanged);

            this.dgr2.AllowUserToAddRows = false;
            this.dgr2.AllowUserToDeleteRows = false;
            this.dgr2.ColumnHeadersHeight = 25;
            this.dgr2.Dock = System.Windows.Forms.DockStyle.None;
            this.dgr2.Location = new System.Drawing.Point(631, 298);
            this.dgr2.Name = "dgr2";
            this.dgr2.Enabled = true;
            this.dgr2.Visible = true;
            this.dgr2.MultiSelect = false;
            this.dgr2.ReadOnly = true;
            this.dgr2.ShowRowErrors = false;
            this.dgr2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgr2.Size = new System.Drawing.Size(349, 300);
            this.dgr2.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgr2.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgr2.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgr2.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgr2.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgr2.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgr2.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgr2.TabIndex = 34;
            this.dgr2.Tag = @"";
            this.toolTip1.SetToolTip(this.dgr2, @"");
            this.dgr2.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgr2_DataError);
            this.dgr2.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgr2_RowStateChanged);
            

            this.dgr2ColumnPartyId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgr2ColumnPartyId.HeaderText = "Partyid";
            this.dgr2ColumnPartyId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnPartyId.Name = "dgr2ColumnPartyId";
            this.dgr2ColumnPartyId.DataPropertyName = "PartyId";
            this.dgr2ColumnPartyId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnPartyId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnPartyId.Width = 100;
            this.dgr2ColumnPartyId.Visible = false;
            this.dgr2ColumnPartyId.DisplayIndex = 0;
            this.dgr2ColumnPartyId.ReadOnly = false;
            this.dgr2ColumnPartyId.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnPartyId);

            this.dgr2ColumnProdId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgr2ColumnProdId.HeaderText = "Prodid";
            this.dgr2ColumnProdId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnProdId.Name = "dgr2ColumnProdId";
            this.dgr2ColumnProdId.DataPropertyName = "ProdId";
            this.dgr2ColumnProdId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnProdId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnProdId.Width = 100;
            this.dgr2ColumnProdId.Visible = false;
            this.dgr2ColumnProdId.DisplayIndex = 1;
            this.dgr2ColumnProdId.ReadOnly = false;
            this.dgr2ColumnProdId.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnProdId);

            this.dgr2ColumnCustomerType.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgr2ColumnCustomerType.HeaderText = "Customertype";
            this.dgr2ColumnCustomerType.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnCustomerType.Name = "dgr2ColumnCustomerType";
            this.dgr2ColumnCustomerType.DataPropertyName = "CustomerType";
            this.dgr2ColumnCustomerType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnCustomerType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnCustomerType.Width = 100;
            this.dgr2ColumnCustomerType.Visible = false;
            this.dgr2ColumnCustomerType.DisplayIndex = 2;
            this.dgr2ColumnCustomerType.ReadOnly = false;
            this.dgr2ColumnCustomerType.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnCustomerType);

            this.dgr2ColumnCustomerCompany.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnCustomerCompany.HeaderText = "Customer Company";
            this.dgr2ColumnCustomerCompany.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnCustomerCompany.Name = "dgr2ColumnCustomerCompany";
            this.dgr2ColumnCustomerCompany.DataPropertyName = "CustomerCompany";
            this.dgr2ColumnCustomerCompany.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr2ColumnCustomerCompany.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnCustomerCompany.Width = 150;
            this.dgr2ColumnCustomerCompany.Visible = true;
            this.dgr2ColumnCustomerCompany.DisplayIndex = 3;
            this.dgr2ColumnCustomerCompany.ReadOnly = false;
            this.dgr2ColumnCustomerCompany.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnCustomerCompany);

            this.dgr2ColumnCustomerName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnCustomerName.HeaderText = "Customer Name";
            this.dgr2ColumnCustomerName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnCustomerName.Name = "dgr2ColumnCustomerName";
            this.dgr2ColumnCustomerName.DataPropertyName = "CustomerName";
            this.dgr2ColumnCustomerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr2ColumnCustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnCustomerName.Width = 150;
            this.dgr2ColumnCustomerName.Visible = true;
            this.dgr2ColumnCustomerName.DisplayIndex = 4;
            this.dgr2ColumnCustomerName.ReadOnly = false;
            this.dgr2ColumnCustomerName.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnCustomerName);

            this.dgr2ColumnJoinDate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnJoinDate.HeaderText = "Joindate";
            this.dgr2ColumnJoinDate.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnJoinDate.Name = "dgr2ColumnJoinDate";
            this.dgr2ColumnJoinDate.DataPropertyName = "JoinDate";
            this.dgr2ColumnJoinDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnJoinDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnJoinDate.Width = 100;
            this.dgr2ColumnJoinDate.Visible = false;
            this.dgr2ColumnJoinDate.DisplayIndex = 5;
            this.dgr2ColumnJoinDate.ReadOnly = false;
            this.dgr2ColumnJoinDate.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnJoinDate);

            this.dgr2ColumnRemarks.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnRemarks.HeaderText = "Remarks";
            this.dgr2ColumnRemarks.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnRemarks.Name = "dgr2ColumnRemarks";
            this.dgr2ColumnRemarks.DataPropertyName = "Remarks";
            this.dgr2ColumnRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnRemarks.Width = 100;
            this.dgr2ColumnRemarks.Visible = false;
            this.dgr2ColumnRemarks.DisplayIndex = 6;
            this.dgr2ColumnRemarks.ReadOnly = false;
            this.dgr2ColumnRemarks.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnRemarks);

            this.dgr2ColumnLogoPath.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnLogoPath.HeaderText = "Logopath";
            this.dgr2ColumnLogoPath.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnLogoPath.Name = "dgr2ColumnLogoPath";
            this.dgr2ColumnLogoPath.DataPropertyName = "LogoPath";
            this.dgr2ColumnLogoPath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnLogoPath.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnLogoPath.Width = 100;
            this.dgr2ColumnLogoPath.Visible = false;
            this.dgr2ColumnLogoPath.DisplayIndex = 7;
            this.dgr2ColumnLogoPath.ReadOnly = false;
            this.dgr2ColumnLogoPath.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnLogoPath);

            this.dgr2ColumnLogoURL.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnLogoURL.HeaderText = "Logourl";
            this.dgr2ColumnLogoURL.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnLogoURL.Name = "dgr2ColumnLogoURL";
            this.dgr2ColumnLogoURL.DataPropertyName = "LogoURL";
            this.dgr2ColumnLogoURL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnLogoURL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnLogoURL.Width = 100;
            this.dgr2ColumnLogoURL.Visible = false;
            this.dgr2ColumnLogoURL.DisplayIndex = 8;
            this.dgr2ColumnLogoURL.ReadOnly = false;
            this.dgr2ColumnLogoURL.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnLogoURL);

            this.dgr2ColumnCustomerLogo.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnCustomerLogo.HeaderText = "Customerlogo";
            this.dgr2ColumnCustomerLogo.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnCustomerLogo.Name = "dgr2ColumnCustomerLogo";
            this.dgr2ColumnCustomerLogo.DataPropertyName = "CustomerLogo";
            this.dgr2ColumnCustomerLogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnCustomerLogo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnCustomerLogo.Width = 100;
            this.dgr2ColumnCustomerLogo.Visible = false;
            this.dgr2ColumnCustomerLogo.DisplayIndex = 9;
            this.dgr2ColumnCustomerLogo.ReadOnly = false;
            this.dgr2ColumnCustomerLogo.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnCustomerLogo);

            this.grpAppdetails_PartydetailsChild.Location = new System.Drawing.Point(7, 292);
            this.grpAppdetails_PartydetailsChild.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpAppdetails_PartydetailsChild.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpAppdetails_PartydetailsChild.Name = "grpAppdetails_PartydetailsChild";
            this.grpAppdetails_PartydetailsChild.Enabled = true;
            this.grpAppdetails_PartydetailsChild.Visible = true;
            this.grpAppdetails_PartydetailsChild.TabIndex = 29;
            this.grpAppdetails_PartydetailsChild.TabStop = false;
            this.grpAppdetails_PartydetailsChild.Size = new System.Drawing.Size(615, 308);
            this.grpAppdetails_PartydetailsChild.Text = @"Customer Details";
            this.grpAppdetails_PartydetailsChild.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAppdetails_PartydetailsChild.SendToBack();
            this.toolTip1.SetToolTip(this.grpAppdetails_PartydetailsChild, @"");

            this.btnAdd.Location = new System.Drawing.Point(5, 273);
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Enabled = true;
            this.btnAdd.Visible = true;
            this.btnAdd.TabIndex = 15;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnAdd.Size = new System.Drawing.Size(80, 30);
            this.btnAdd.Text = @"&Add";
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnAdd, @"");
            
            

            this.btnUpdate.Location = new System.Drawing.Point(170, 273);
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Enabled = true;
            this.btnUpdate.Visible = true;
            this.btnUpdate.TabIndex = 16;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnUpdate.Size = new System.Drawing.Size(80, 30);
            this.btnUpdate.Text = @"&Update";
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnUpdate, @"");
            
            

            this.btnRemove.Location = new System.Drawing.Point(335, 273);
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnRemove.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Enabled = true;
            this.btnRemove.Visible = true;
            this.btnRemove.TabIndex = 17;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnRemove.Size = new System.Drawing.Size(80, 30);
            this.btnRemove.Text = @"&Remove";
            this.btnRemove.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnRemove, @"");
            
            

            this.btnClearImage2.Location = new System.Drawing.Point(426, 273);
            this.btnClearImage2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClearImage2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClearImage2.Name = "btnClearImage2";
            this.btnClearImage2.Enabled = true;
            this.btnClearImage2.Visible = true;
            this.btnClearImage2.TabIndex = 14;
            this.btnClearImage2.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClearImage2.Size = new System.Drawing.Size(179, 30);
            this.btnClearImage2.Text = @"Clear Image";
            this.btnClearImage2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearImage2.UseVisualStyleBackColor = false;
            this.btnClearImage2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClearImage2, @"");
            
            

            this.btnCustomerImage.Location = new System.Drawing.Point(427, 239);
            this.btnCustomerImage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnCustomerImage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnCustomerImage.Name = "btnCustomerImage";
            this.btnCustomerImage.Enabled = true;
            this.btnCustomerImage.Visible = true;
            this.btnCustomerImage.TabIndex = 13;
            this.btnCustomerImage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnCustomerImage.Size = new System.Drawing.Size(179, 30);
            this.btnCustomerImage.Text = @"Browse Customer Logo";
            this.btnCustomerImage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerImage.UseVisualStyleBackColor = false;
            this.btnCustomerImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnCustomerImage, @"");
            
            

            this.dtp_PartyDetails_JoinDate.Location = new System.Drawing.Point(121, 110);
            this.dtp_PartyDetails_JoinDate.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.dtp_PartyDetails_JoinDate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.dtp_PartyDetails_JoinDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_PartyDetails_JoinDate.Name = "dtp_PartyDetails_JoinDate";
            this.dtp_PartyDetails_JoinDate.DefaultValue = null;
            this.dtp_PartyDetails_JoinDate.Text = "";
            this.dtp_PartyDetails_JoinDate.Value = null;
            this.dtp_PartyDetails_JoinDate.FriendlyName = "";
            this.dtp_PartyDetails_JoinDate.Enabled = true;
            this.dtp_PartyDetails_JoinDate.Visible = true;
            this.dtp_PartyDetails_JoinDate.TabIndex = 11;
            this.dtp_PartyDetails_JoinDate.MinValue = new System.DateTime(((long)(0)));
            this.dtp_PartyDetails_JoinDate.MaxValue = new System.DateTime(((long)(0)));
            this.dtp_PartyDetails_JoinDate.ValidationMessage = "";
            this.dtp_PartyDetails_JoinDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dtp_PartyDetails_JoinDate.Size = new System.Drawing.Size(100, 29);
            this.dtp_PartyDetails_JoinDate.SelectAllOnFocus = true;
            this.dtp_PartyDetails_JoinDate.DoValidation = false;
            this.dtp_PartyDetails_JoinDate.AllowNull = true;
            this.dtp_PartyDetails_JoinDate.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.dtp_PartyDetails_JoinDate, @"");

            this.custCompanyLogo.Location = new System.Drawing.Point(426, 44);
            this.custCompanyLogo.Name = "custCompanyLogo";
            this.custCompanyLogo.AllowNull = true;
            this.custCompanyLogo.FriendlyName = "";
            this.custCompanyLogo.Enabled = true;
            this.custCompanyLogo.Visible = true;
            this.custCompanyLogo.Size = new System.Drawing.Size(179, 171);
            this.custCompanyLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.custCompanyLogo.TabIndex = 0;
            this.custCompanyLogo.TabStop = false;
            this.custCompanyLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolTip1.SetToolTip(this.custCompanyLogo, @"");
            
            

            this.lbl_PartyDetails_PartyId.AutoSize = false;
            this.lbl_PartyDetails_PartyId.Location = new System.Drawing.Point(10, 311);
            this.lbl_PartyDetails_PartyId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_PartyId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_PartyId.Name = "lbl_PartyDetails_PartyId";
            this.lbl_PartyDetails_PartyId.Enabled = true;
            this.lbl_PartyDetails_PartyId.Visible = false;
            this.lbl_PartyDetails_PartyId.TabIndex = 31;
            this.lbl_PartyDetails_PartyId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_PartyId.Size = new System.Drawing.Size(100, 23);
            this.lbl_PartyDetails_PartyId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_PartyId.Text = @"Partyid";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_PartyId, @"");

            this.lbl_PartyDetails_ProdId.AutoSize = false;
            this.lbl_PartyDetails_ProdId.Location = new System.Drawing.Point(10, 341);
            this.lbl_PartyDetails_ProdId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_ProdId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_ProdId.Name = "lbl_PartyDetails_ProdId";
            this.lbl_PartyDetails_ProdId.Enabled = true;
            this.lbl_PartyDetails_ProdId.Visible = false;
            this.lbl_PartyDetails_ProdId.TabIndex = 33;
            this.lbl_PartyDetails_ProdId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_ProdId.Size = new System.Drawing.Size(100, 23);
            this.lbl_PartyDetails_ProdId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_ProdId.Text = @"Prodid";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_ProdId, @"");

            this.lbl_PartyDetails_CustomerType.AutoSize = false;
            this.lbl_PartyDetails_CustomerType.Location = new System.Drawing.Point(171, 313);
            this.lbl_PartyDetails_CustomerType.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_CustomerType.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_CustomerType.Name = "lbl_PartyDetails_CustomerType";
            this.lbl_PartyDetails_CustomerType.Enabled = true;
            this.lbl_PartyDetails_CustomerType.Visible = false;
            this.lbl_PartyDetails_CustomerType.TabIndex = 35;
            this.lbl_PartyDetails_CustomerType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_CustomerType.Size = new System.Drawing.Size(100, 23);
            this.lbl_PartyDetails_CustomerType.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_CustomerType.Text = @"Customertype";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_CustomerType, @"");

            this.lbl_PartyDetails_CustomerCompany.AutoSize = false;
            this.lbl_PartyDetails_CustomerCompany.Location = new System.Drawing.Point(4, 52);
            this.lbl_PartyDetails_CustomerCompany.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_CustomerCompany.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_CustomerCompany.Name = "lbl_PartyDetails_CustomerCompany";
            this.lbl_PartyDetails_CustomerCompany.Enabled = true;
            this.lbl_PartyDetails_CustomerCompany.Visible = true;
            this.lbl_PartyDetails_CustomerCompany.TabIndex = 37;
            this.lbl_PartyDetails_CustomerCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_CustomerCompany.Size = new System.Drawing.Size(106, 23);
            this.lbl_PartyDetails_CustomerCompany.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_CustomerCompany.Text = @"* Company";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_CustomerCompany, @"");

            this.lbl_PartyDetails_CustomerName.AutoSize = false;
            this.lbl_PartyDetails_CustomerName.Location = new System.Drawing.Point(4, 22);
            this.lbl_PartyDetails_CustomerName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_CustomerName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_CustomerName.Name = "lbl_PartyDetails_CustomerName";
            this.lbl_PartyDetails_CustomerName.Enabled = true;
            this.lbl_PartyDetails_CustomerName.Visible = true;
            this.lbl_PartyDetails_CustomerName.TabIndex = 39;
            this.lbl_PartyDetails_CustomerName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_CustomerName.Size = new System.Drawing.Size(115, 23);
            this.lbl_PartyDetails_CustomerName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_CustomerName.Text = @"  Customer Name";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_CustomerName, @"");

            this.lbl_PartyDetails_JoinDate.AutoSize = false;
            this.lbl_PartyDetails_JoinDate.Location = new System.Drawing.Point(4, 108);
            this.lbl_PartyDetails_JoinDate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_JoinDate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_JoinDate.Name = "lbl_PartyDetails_JoinDate";
            this.lbl_PartyDetails_JoinDate.Enabled = true;
            this.lbl_PartyDetails_JoinDate.Visible = true;
            this.lbl_PartyDetails_JoinDate.TabIndex = 41;
            this.lbl_PartyDetails_JoinDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_JoinDate.Size = new System.Drawing.Size(100, 23);
            this.lbl_PartyDetails_JoinDate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_JoinDate.Text = @"* Date";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_JoinDate, @"");

            this.lbl_PartyDetails_Remarks.AutoSize = false;
            this.lbl_PartyDetails_Remarks.Location = new System.Drawing.Point(4, 140);
            this.lbl_PartyDetails_Remarks.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyDetails_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyDetails_Remarks.Name = "lbl_PartyDetails_Remarks";
            this.lbl_PartyDetails_Remarks.Enabled = true;
            this.lbl_PartyDetails_Remarks.Visible = true;
            this.lbl_PartyDetails_Remarks.TabIndex = 43;
            this.lbl_PartyDetails_Remarks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyDetails_Remarks.Size = new System.Drawing.Size(100, 23);
            this.lbl_PartyDetails_Remarks.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyDetails_Remarks.Text = @"  Remarks";
            this.toolTip1.SetToolTip(this.lbl_PartyDetails_Remarks, @"");

            this.lbl_CompanyTitle1.AutoSize = false;
            this.lbl_CompanyTitle1.Location = new System.Drawing.Point(447, 218);
            this.lbl_CompanyTitle1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyTitle1.ForeColor = System.Drawing.Color.FromArgb(-8355712);
            this.lbl_CompanyTitle1.Name = "lbl_CompanyTitle1";
            this.lbl_CompanyTitle1.Enabled = true;
            this.lbl_CompanyTitle1.Visible = true;
            this.lbl_CompanyTitle1.TabIndex = 4;
            this.lbl_CompanyTitle1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_CompanyTitle1.Size = new System.Drawing.Size(141, 22);
            this.lbl_CompanyTitle1.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyTitle1.Text = @"(Preferred Size 200px)";
            this.toolTip1.SetToolTip(this.lbl_CompanyTitle1, @"");

            this.lbl_CompanyLogo.AutoSize = false;
            this.lbl_CompanyLogo.Location = new System.Drawing.Point(425, 13);
            this.lbl_CompanyLogo.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CompanyLogo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CompanyLogo.Name = "lbl_CompanyLogo";
            this.lbl_CompanyLogo.Enabled = true;
            this.lbl_CompanyLogo.Visible = true;
            this.lbl_CompanyLogo.TabIndex = 50;
            this.lbl_CompanyLogo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CompanyLogo.Size = new System.Drawing.Size(162, 23);
            this.lbl_CompanyLogo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CompanyLogo.Text = @"Customer Company Logo";
            this.toolTip1.SetToolTip(this.lbl_CompanyLogo, @"");

            this.lbl_logoURL.AutoSize = false;
            this.lbl_logoURL.Location = new System.Drawing.Point(613, 68);
            this.lbl_logoURL.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_logoURL.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_logoURL.Name = "lbl_logoURL";
            this.lbl_logoURL.Enabled = true;
            this.lbl_logoURL.Visible = false;
            this.lbl_logoURL.TabIndex = 0;
            this.lbl_logoURL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_logoURL.Size = new System.Drawing.Size(100, 23);
            this.lbl_logoURL.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_logoURL.Text = @"  LogoURL";
            this.toolTip1.SetToolTip(this.lbl_logoURL, @"");

            this.lbl_logoPath.AutoSize = false;
            this.lbl_logoPath.Location = new System.Drawing.Point(5, 237);
            this.lbl_logoPath.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_logoPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_logoPath.Name = "lbl_logoPath";
            this.lbl_logoPath.Enabled = true;
            this.lbl_logoPath.Visible = false;
            this.lbl_logoPath.TabIndex = 0;
            this.lbl_logoPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_logoPath.Size = new System.Drawing.Size(100, 23);
            this.lbl_logoPath.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_logoPath.Text = @"  LogoPath";
            this.toolTip1.SetToolTip(this.lbl_logoPath, @"");

            this.txt_PartyDetails_PartyId.Location = new System.Drawing.Point(110, 311);
            this.txt_PartyDetails_PartyId.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_PartyDetails_PartyId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyDetails_PartyId.Name = "txt_PartyDetails_PartyId";
            this.txt_PartyDetails_PartyId.DefaultValue = null;
            this.txt_PartyDetails_PartyId.FriendlyName = "";
            this.txt_PartyDetails_PartyId.Enabled = true;
            this.txt_PartyDetails_PartyId.Visible = false;
            this.txt_PartyDetails_PartyId.ReadOnly = false;
            this.txt_PartyDetails_PartyId.TabIndex = 30;
            this.txt_PartyDetails_PartyId.MaxValue = 2147483647;
            this.txt_PartyDetails_PartyId.MinValue = -2147483648;
            this.txt_PartyDetails_PartyId.ValidationMessage = "";
            this.txt_PartyDetails_PartyId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyDetails_PartyId.Size = new System.Drawing.Size(100, 20);
            this.txt_PartyDetails_PartyId.SelectAllOnFocus = true;
            this.txt_PartyDetails_PartyId.DoValidation = false;
            this.txt_PartyDetails_PartyId.AllowNull = false;
            this.txt_PartyDetails_PartyId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_PartyDetails_PartyId, @"");

            this.txt_PartyDetails_ProdId.Location = new System.Drawing.Point(110, 341);
            this.txt_PartyDetails_ProdId.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_PartyDetails_ProdId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyDetails_ProdId.Name = "txt_PartyDetails_ProdId";
            this.txt_PartyDetails_ProdId.DefaultValue = null;
            this.txt_PartyDetails_ProdId.FriendlyName = "";
            this.txt_PartyDetails_ProdId.Enabled = true;
            this.txt_PartyDetails_ProdId.Visible = false;
            this.txt_PartyDetails_ProdId.ReadOnly = false;
            this.txt_PartyDetails_ProdId.TabIndex = 32;
            this.txt_PartyDetails_ProdId.MaxValue = 2147483647;
            this.txt_PartyDetails_ProdId.MinValue = -2147483648;
            this.txt_PartyDetails_ProdId.ValidationMessage = "";
            this.txt_PartyDetails_ProdId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyDetails_ProdId.Size = new System.Drawing.Size(100, 20);
            this.txt_PartyDetails_ProdId.SelectAllOnFocus = true;
            this.txt_PartyDetails_ProdId.DoValidation = false;
            this.txt_PartyDetails_ProdId.AllowNull = false;
            this.txt_PartyDetails_ProdId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_PartyDetails_ProdId, @"");

            this.txt_PartyDetails_CustomerType.Location = new System.Drawing.Point(271, 313);
            this.txt_PartyDetails_CustomerType.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_PartyDetails_CustomerType.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyDetails_CustomerType.Name = "txt_PartyDetails_CustomerType";
            this.txt_PartyDetails_CustomerType.DefaultValue = null;
            this.txt_PartyDetails_CustomerType.FriendlyName = "";
            this.txt_PartyDetails_CustomerType.Enabled = true;
            this.txt_PartyDetails_CustomerType.Visible = false;
            this.txt_PartyDetails_CustomerType.ReadOnly = false;
            this.txt_PartyDetails_CustomerType.TabIndex = 34;
            this.txt_PartyDetails_CustomerType.MaxValue = 2147483647;
            this.txt_PartyDetails_CustomerType.MinValue = -2147483648;
            this.txt_PartyDetails_CustomerType.ValidationMessage = "";
            this.txt_PartyDetails_CustomerType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyDetails_CustomerType.Size = new System.Drawing.Size(100, 20);
            this.txt_PartyDetails_CustomerType.SelectAllOnFocus = true;
            this.txt_PartyDetails_CustomerType.DoValidation = false;
            this.txt_PartyDetails_CustomerType.AllowNull = true;
            this.txt_PartyDetails_CustomerType.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_PartyDetails_CustomerType, @"");

            this.txt_PartyDetails_CustomerCompany.Location = new System.Drawing.Point(121, 50);
            this.txt_PartyDetails_CustomerCompany.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_PartyDetails_CustomerCompany.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyDetails_CustomerCompany.Multiline = true;
            this.txt_PartyDetails_CustomerCompany.MaxLength = 500;
            this.txt_PartyDetails_CustomerCompany.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_PartyDetails_CustomerCompany.Name = "txt_PartyDetails_CustomerCompany";
            this.txt_PartyDetails_CustomerCompany.Text = @"";
            
            this.txt_PartyDetails_CustomerCompany.AllowNull = true;
            this.txt_PartyDetails_CustomerCompany.DefaultValue = "";
            this.txt_PartyDetails_CustomerCompany.FriendlyName = "";
            this.txt_PartyDetails_CustomerCompany.ValidationType = TextValidation.None;
            this.txt_PartyDetails_CustomerCompany.ValidationExpression = @"";
            this.txt_PartyDetails_CustomerCompany.ValidationMessage = @"";
            this.txt_PartyDetails_CustomerCompany.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_PartyDetails_CustomerCompany.Enabled = true;
            this.txt_PartyDetails_CustomerCompany.ReadOnly = false;
            this.txt_PartyDetails_CustomerCompany.Visible = true;
            this.txt_PartyDetails_CustomerCompany.TabIndex = 10;
            this.txt_PartyDetails_CustomerCompany.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_PartyDetails_CustomerCompany.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyDetails_CustomerCompany.Size = new System.Drawing.Size(294, 58);
            this.toolTip1.SetToolTip(this.txt_PartyDetails_CustomerCompany, @"");

            this.txt_PartyDetails_CustomerName.Location = new System.Drawing.Point(121, 19);
            this.txt_PartyDetails_CustomerName.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_PartyDetails_CustomerName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyDetails_CustomerName.Multiline = false;
            this.txt_PartyDetails_CustomerName.MaxLength = 500;
            this.txt_PartyDetails_CustomerName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_PartyDetails_CustomerName.Name = "txt_PartyDetails_CustomerName";
            this.txt_PartyDetails_CustomerName.Text = @"";
            
            this.txt_PartyDetails_CustomerName.AllowNull = true;
            this.txt_PartyDetails_CustomerName.DefaultValue = "";
            this.txt_PartyDetails_CustomerName.FriendlyName = "";
            this.txt_PartyDetails_CustomerName.ValidationType = TextValidation.None;
            this.txt_PartyDetails_CustomerName.ValidationExpression = @"";
            this.txt_PartyDetails_CustomerName.ValidationMessage = @"";
            this.txt_PartyDetails_CustomerName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_PartyDetails_CustomerName.Enabled = true;
            this.txt_PartyDetails_CustomerName.ReadOnly = false;
            this.txt_PartyDetails_CustomerName.Visible = true;
            this.txt_PartyDetails_CustomerName.TabIndex = 9;
            this.txt_PartyDetails_CustomerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_PartyDetails_CustomerName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyDetails_CustomerName.Size = new System.Drawing.Size(294, 29);
            this.toolTip1.SetToolTip(this.txt_PartyDetails_CustomerName, @"");

            this.txt_PartyDetails_Remarks.Location = new System.Drawing.Point(121, 141);
            this.txt_PartyDetails_Remarks.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_PartyDetails_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyDetails_Remarks.Multiline = true;
            this.txt_PartyDetails_Remarks.MaxLength = 500;
            this.txt_PartyDetails_Remarks.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_PartyDetails_Remarks.Name = "txt_PartyDetails_Remarks";
            this.txt_PartyDetails_Remarks.Text = @"";
            
            this.txt_PartyDetails_Remarks.AllowNull = true;
            this.txt_PartyDetails_Remarks.DefaultValue = "";
            this.txt_PartyDetails_Remarks.FriendlyName = "";
            this.txt_PartyDetails_Remarks.ValidationType = TextValidation.None;
            this.txt_PartyDetails_Remarks.ValidationExpression = @"";
            this.txt_PartyDetails_Remarks.ValidationMessage = @"";
            this.txt_PartyDetails_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_PartyDetails_Remarks.Enabled = true;
            this.txt_PartyDetails_Remarks.ReadOnly = false;
            this.txt_PartyDetails_Remarks.Visible = true;
            this.txt_PartyDetails_Remarks.TabIndex = 12;
            this.txt_PartyDetails_Remarks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_PartyDetails_Remarks.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyDetails_Remarks.Size = new System.Drawing.Size(294, 86);
            this.toolTip1.SetToolTip(this.txt_PartyDetails_Remarks, @"");

            this.txtLogoUrl.Location = new System.Drawing.Point(610, 88);
            this.txtLogoUrl.BackColor = System.Drawing.Color.FromArgb(-4144897);
            this.txtLogoUrl.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtLogoUrl.Multiline = false;
            this.txtLogoUrl.MaxLength = 256;
            this.txtLogoUrl.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLogoUrl.Name = "txtLogoUrl";
            this.txtLogoUrl.Text = @"";
            
            this.txtLogoUrl.AllowNull = true;
            this.txtLogoUrl.DefaultValue = "";
            this.txtLogoUrl.FriendlyName = "txtNewText1";
            this.txtLogoUrl.ValidationType = TextValidation.None;
            this.txtLogoUrl.ValidationExpression = @"";
            this.txtLogoUrl.ValidationMessage = @"";
            this.txtLogoUrl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtLogoUrl.Enabled = true;
            this.txtLogoUrl.ReadOnly = false;
            this.txtLogoUrl.Visible = false;
            this.txtLogoUrl.TabIndex = 0;
            this.txtLogoUrl.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLogoUrl.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogoUrl.Size = new System.Drawing.Size(296, 29);
            this.toolTip1.SetToolTip(this.txtLogoUrl, @"");

            this.txtlogoPath.Location = new System.Drawing.Point(121, 234);
            this.txtlogoPath.BackColor = System.Drawing.Color.FromArgb(-4144897);
            this.txtlogoPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtlogoPath.Multiline = false;
            this.txtlogoPath.MaxLength = 256;
            this.txtlogoPath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtlogoPath.Name = "txtlogoPath";
            this.txtlogoPath.Text = @"";
            
            this.txtlogoPath.AllowNull = true;
            this.txtlogoPath.DefaultValue = "";
            this.txtlogoPath.FriendlyName = "txtNewText2";
            this.txtlogoPath.ValidationType = TextValidation.None;
            this.txtlogoPath.ValidationExpression = @"";
            this.txtlogoPath.ValidationMessage = @"";
            this.txtlogoPath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtlogoPath.Enabled = true;
            this.txtlogoPath.ReadOnly = false;
            this.txtlogoPath.Visible = false;
            this.txtlogoPath.TabIndex = 0;
            this.txtlogoPath.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtlogoPath.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlogoPath.Size = new System.Drawing.Size(294, 29);
            this.toolTip1.SetToolTip(this.txtlogoPath, @"");
            this.txtlogoPath.TextChanged += new System.EventHandler(this.txtlogoPath_Evaluate_TextChanged);

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(1002, 7);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(313, 576);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnAppId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnAppId.HeaderText = "Appid";
            this.dgrDataColumnAppId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppId.Name = "dgrDataColumnAppId";
            this.dgrDataColumnAppId.DataPropertyName = "AppId";
            this.dgrDataColumnAppId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppId.Width = 100;
            this.dgrDataColumnAppId.Visible = false;
            this.dgrDataColumnAppId.DisplayIndex = 0;
            this.dgrDataColumnAppId.ReadOnly = false;
            this.dgrDataColumnAppId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppId);

            this.dgrDataColumnTypeId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnTypeId.HeaderText = "Typeid";
            this.dgrDataColumnTypeId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnTypeId.Name = "dgrDataColumnTypeId";
            this.dgrDataColumnTypeId.DataPropertyName = "TypeId";
            this.dgrDataColumnTypeId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnTypeId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnTypeId.Width = 100;
            this.dgrDataColumnTypeId.Visible = false;
            this.dgrDataColumnTypeId.DisplayIndex = 1;
            this.dgrDataColumnTypeId.ReadOnly = false;
            this.dgrDataColumnTypeId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnTypeId);

            this.dgrDataColumnCategoryId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnCategoryId.HeaderText = "Category";
            this.dgrDataColumnCategoryId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCategoryId.Name = "dgrDataColumnCategoryId";
            this.dgrDataColumnCategoryId.DataPropertyName = "CategoryId";
            this.dgrDataColumnCategoryId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnCategoryId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCategoryId.Width = 100;
            this.dgrDataColumnCategoryId.Visible = true;
            this.dgrDataColumnCategoryId.DisplayIndex = 2;
            this.dgrDataColumnCategoryId.ReadOnly = false;
            this.dgrDataColumnCategoryId.Tag = "select * from ProductTypeMaster";
            this.dgrDataColumnCategoryId.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCategoryId);

            this.dgrDataColumnAppDescription.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppDescription.HeaderText = "Appdescription";
            this.dgrDataColumnAppDescription.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppDescription.Name = "dgrDataColumnAppDescription";
            this.dgrDataColumnAppDescription.DataPropertyName = "AppDescription";
            this.dgrDataColumnAppDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppDescription.Width = 100;
            this.dgrDataColumnAppDescription.Visible = false;
            this.dgrDataColumnAppDescription.DisplayIndex = 2;
            this.dgrDataColumnAppDescription.ReadOnly = false;
            this.dgrDataColumnAppDescription.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppDescription);

            this.dgrDataColumnAppName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppName.HeaderText = "Application Name";
            this.dgrDataColumnAppName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppName.Name = "dgrDataColumnAppName";
            this.dgrDataColumnAppName.DataPropertyName = "AppName";
            this.dgrDataColumnAppName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnAppName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppName.Width = 200;
            this.dgrDataColumnAppName.Visible = true;
            this.dgrDataColumnAppName.DisplayIndex = 3;
            this.dgrDataColumnAppName.ReadOnly = false;
            this.dgrDataColumnAppName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppName);

            this.dgrDataColumnDOR.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnDOR.HeaderText = "Release Date";
            this.dgrDataColumnDOR.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnDOR.Name = "dgrDataColumnDOR";
            this.dgrDataColumnDOR.DataPropertyName = "DOR";
            this.dgrDataColumnDOR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnDOR.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnDOR.Width = 100;
            this.dgrDataColumnDOR.Visible = true;
            this.dgrDataColumnDOR.DisplayIndex = 3;
            this.dgrDataColumnDOR.ReadOnly = false;
            this.dgrDataColumnDOR.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnDOR);

            this.dgrDataColumnRemarks.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnRemarks.HeaderText = "Remarks";
            this.dgrDataColumnRemarks.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnRemarks.Name = "dgrDataColumnRemarks";
            this.dgrDataColumnRemarks.DataPropertyName = "Remarks";
            this.dgrDataColumnRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnRemarks.Width = 100;
            this.dgrDataColumnRemarks.Visible = false;
            this.dgrDataColumnRemarks.DisplayIndex = 4;
            this.dgrDataColumnRemarks.ReadOnly = false;
            this.dgrDataColumnRemarks.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnRemarks);

            this.dgrDataColumnAppLink.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppLink.HeaderText = "Applink";
            this.dgrDataColumnAppLink.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppLink.Name = "dgrDataColumnAppLink";
            this.dgrDataColumnAppLink.DataPropertyName = "AppLink";
            this.dgrDataColumnAppLink.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppLink.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppLink.Width = 100;
            this.dgrDataColumnAppLink.Visible = false;
            this.dgrDataColumnAppLink.DisplayIndex = 7;
            this.dgrDataColumnAppLink.ReadOnly = false;
            this.dgrDataColumnAppLink.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppLink);

            this.dgrDataColumnLogoUrl.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnLogoUrl.HeaderText = "Logourl";
            this.dgrDataColumnLogoUrl.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnLogoUrl.Name = "dgrDataColumnLogoUrl";
            this.dgrDataColumnLogoUrl.DataPropertyName = "LogoUrl";
            this.dgrDataColumnLogoUrl.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnLogoUrl.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnLogoUrl.Width = 100;
            this.dgrDataColumnLogoUrl.Visible = false;
            this.dgrDataColumnLogoUrl.DisplayIndex = 8;
            this.dgrDataColumnLogoUrl.ReadOnly = false;
            this.dgrDataColumnLogoUrl.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnLogoUrl);

            this.dgrDataColumnLogoPath.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnLogoPath.HeaderText = "Logopath";
            this.dgrDataColumnLogoPath.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnLogoPath.Name = "dgrDataColumnLogoPath";
            this.dgrDataColumnLogoPath.DataPropertyName = "LogoPath";
            this.dgrDataColumnLogoPath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnLogoPath.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnLogoPath.Width = 100;
            this.dgrDataColumnLogoPath.Visible = false;
            this.dgrDataColumnLogoPath.DisplayIndex = 9;
            this.dgrDataColumnLogoPath.ReadOnly = false;
            this.dgrDataColumnLogoPath.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnLogoPath);

            this.dgrDataColumnAppLogo.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnAppLogo.HeaderText = "Applogo";
            this.dgrDataColumnAppLogo.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnAppLogo.Name = "dgrDataColumnAppLogo";
            this.dgrDataColumnAppLogo.DataPropertyName = "AppLogo";
            this.dgrDataColumnAppLogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnAppLogo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnAppLogo.Width = 100;
            this.dgrDataColumnAppLogo.Visible = false;
            this.dgrDataColumnAppLogo.DisplayIndex = 10;
            this.dgrDataColumnAppLogo.ReadOnly = false;
            this.dgrDataColumnAppLogo.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnAppLogo);

            this.dgrDataColumnCustomerCompany.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCustomerCompany.HeaderText = "Customercompany";
            this.dgrDataColumnCustomerCompany.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCustomerCompany.Name = "dgrDataColumnCustomerCompany";
            this.dgrDataColumnCustomerCompany.DataPropertyName = "CustomerCompany";
            this.dgrDataColumnCustomerCompany.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnCustomerCompany.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCustomerCompany.Width = 100;
            this.dgrDataColumnCustomerCompany.Visible = false;
            this.dgrDataColumnCustomerCompany.DisplayIndex = 11;
            this.dgrDataColumnCustomerCompany.ReadOnly = false;
            this.dgrDataColumnCustomerCompany.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCustomerCompany);

            this.dgrDataColumnCustomerLogo.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCustomerLogo.HeaderText = "Customerlogo";
            this.dgrDataColumnCustomerLogo.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCustomerLogo.Name = "dgrDataColumnCustomerLogo";
            this.dgrDataColumnCustomerLogo.DataPropertyName = "CustomerLogo";
            this.dgrDataColumnCustomerLogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnCustomerLogo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCustomerLogo.Width = 100;
            this.dgrDataColumnCustomerLogo.Visible = false;
            this.dgrDataColumnCustomerLogo.DisplayIndex = 12;
            this.dgrDataColumnCustomerLogo.ReadOnly = false;
            this.dgrDataColumnCustomerLogo.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCustomerLogo);


            
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpAppdetails_Partydetails);
            this.grpAppdetails_Partydetails.Controls.Add(this.btnNew);
            this.grpAppdetails_Partydetails.Controls.Add(this.btnSave);
            this.grpAppdetails_Partydetails.Controls.Add(this.btnDelete);
            this.grpAppdetails_Partydetails.Controls.Add(this.btnClose);
            this.grpAppdetails_Partydetails.Controls.Add(this.btnClearImage);
            this.grpAppdetails_Partydetails.Controls.Add(this.btnAppImage);
            this.grpAppdetails_Partydetails.Controls.Add(this.btn_Check_Link);
            this.grpAppdetails_Partydetails.Controls.Add(this.dtp_AppDetails_DOR);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_TypeId);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_CategoryId);
            this.grpAppdetails_Partydetails.Controls.Add(this.CompanyLogo);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_AppId);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_TypeId);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_AppDescription);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_DOR);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_Remarks);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_CategoryId);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_AppName);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_AppLink);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_LogoUrl);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_AppDetails_LogoPath);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_CompanyTitle);
            this.grpAppdetails_Partydetails.Controls.Add(this.lbl_CompanyLogo1);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_AppId);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_AppDescription);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_Remarks);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_AppName);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_AppLink);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_LogoUrl);
            this.grpAppdetails_Partydetails.Controls.Add(this.txt_AppDetails_LogoPath);
            this.grpAppdetails_Partydetails.Controls.Add(this.dgr2);
            this.grpAppdetails_Partydetails.Controls.Add(this.grpAppdetails_PartydetailsChild);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.btnAdd);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.btnUpdate);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.btnRemove);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.btnClearImage2);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.btnCustomerImage);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.dtp_PartyDetails_JoinDate);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.custCompanyLogo);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_PartyId);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_ProdId);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_CustomerType);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_CustomerCompany);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_CustomerName);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_JoinDate);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_PartyDetails_Remarks);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_CompanyTitle1);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_CompanyLogo);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_logoURL);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.lbl_logoPath);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txt_PartyDetails_PartyId);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txt_PartyDetails_ProdId);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txt_PartyDetails_CustomerType);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txt_PartyDetails_CustomerCompany);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txt_PartyDetails_CustomerName);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txt_PartyDetails_Remarks);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txtLogoUrl);
            this.grpAppdetails_PartydetailsChild.Controls.Add(this.txtlogoPath);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Appdetails_Partydetails";
            this.Text = "Product Details";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(1335, 651);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpAppdetails_Partydetails;
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalButton btnClearImage;
        private Kushal.Controls.KushalButton btnAppImage;
        private Kushal.Controls.KushalButton btn_Check_Link;
        private DateTextBox dtp_AppDetails_DOR;
        private Kushal.Controls.KushalComboBox txt_AppDetails_TypeId;
        private Kushal.Controls.KushalComboBox txt_AppDetails_CategoryId;
        private Kushal.Controls.KushalPictureBox CompanyLogo;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppId;
        private Kushal.Controls.KushalLabel lbl_AppDetails_TypeId;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppDescription;
        private Kushal.Controls.KushalLabel lbl_AppDetails_DOR;
        private Kushal.Controls.KushalLabel lbl_AppDetails_Remarks;
        private Kushal.Controls.KushalLabel lbl_AppDetails_CategoryId;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppName;
        private Kushal.Controls.KushalLabel lbl_AppDetails_AppLink;
        private Kushal.Controls.KushalLabel lbl_AppDetails_LogoUrl;
        private Kushal.Controls.KushalLabel lbl_AppDetails_LogoPath;
        private Kushal.Controls.KushalLabel lbl_CompanyTitle;
        private Kushal.Controls.KushalLabel lbl_CompanyLogo1;
        private NumericTextBox txt_AppDetails_AppId;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppDescription;
        private Kushal.Controls.KushalTextBox txt_AppDetails_Remarks;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppName;
        private Kushal.Controls.KushalTextBox txt_AppDetails_AppLink;
        private Kushal.Controls.KushalTextBox txt_AppDetails_LogoUrl;
        private Kushal.Controls.KushalTextBox txt_AppDetails_LogoPath;
        private System.Windows.Forms.DataGridView dgr2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnPartyId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnProdId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnCustomerType;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnCustomerCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnJoinDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnLogoPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnLogoURL;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnCustomerLogo;
        private Kushal.Controls.KushalGroupBox grpAppdetails_PartydetailsChild;
        private Kushal.Controls.KushalButton btnAdd;
        private Kushal.Controls.KushalButton btnUpdate;
        private Kushal.Controls.KushalButton btnRemove;
        private Kushal.Controls.KushalButton btnClearImage2;
        private Kushal.Controls.KushalButton btnCustomerImage;
        private DateTextBox dtp_PartyDetails_JoinDate;
        private Kushal.Controls.KushalPictureBox custCompanyLogo;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_PartyId;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_ProdId;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_CustomerType;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_CustomerCompany;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_CustomerName;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_JoinDate;
        private Kushal.Controls.KushalLabel lbl_PartyDetails_Remarks;
        private Kushal.Controls.KushalLabel lbl_CompanyTitle1;
        private Kushal.Controls.KushalLabel lbl_CompanyLogo;
        private Kushal.Controls.KushalLabel lbl_logoURL;
        private Kushal.Controls.KushalLabel lbl_logoPath;
        private NumericTextBox txt_PartyDetails_PartyId;
        private NumericTextBox txt_PartyDetails_ProdId;
        private NumericTextBox txt_PartyDetails_CustomerType;
        private Kushal.Controls.KushalTextBox txt_PartyDetails_CustomerCompany;
        private Kushal.Controls.KushalTextBox txt_PartyDetails_CustomerName;
        private Kushal.Controls.KushalTextBox txt_PartyDetails_Remarks;
        private Kushal.Controls.KushalTextBox txtLogoUrl;
        private Kushal.Controls.KushalTextBox txtlogoPath;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnTypeId;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnCategoryId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnDOR;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnLogoUrl;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnLogoPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnAppLogo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCustomerCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCustomerLogo;
    }
}