using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Country {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpCmncountry = new Kushal.Controls.KushalGroupBox();
            this.lbl_CountryId = new Kushal.Controls.KushalLabel();
            this.lbl_CountryName = new Kushal.Controls.KushalLabel();
            this.txt_CountryId = new NumericTextBox();
            this.txt_CountryName = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnCountryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnCountryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(5, 60);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 10;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(89, 60);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 11;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(173, 60);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 12;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(257, 60);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 15;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(234, 482);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 21);
            this.lbl_Count.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpCmncountry.Location = new System.Drawing.Point(5, 2);
            this.grpCmncountry.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpCmncountry.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpCmncountry.Name = "grpCmncountry";
            this.grpCmncountry.Enabled = true;
            this.grpCmncountry.Visible = true;
            this.grpCmncountry.TabIndex = 1;
            this.grpCmncountry.TabStop = false;
            this.grpCmncountry.Size = new System.Drawing.Size(331, 51);
            this.grpCmncountry.Text = @"Country Details";
            this.grpCmncountry.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCmncountry.SendToBack();
            this.toolTip1.SetToolTip(this.grpCmncountry, @"");

            this.lbl_CountryId.AutoSize = false;
            this.lbl_CountryId.Location = new System.Drawing.Point(31, 43);
            this.lbl_CountryId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CountryId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CountryId.Name = "lbl_CountryId";
            this.lbl_CountryId.Enabled = true;
            this.lbl_CountryId.Visible = false;
            this.lbl_CountryId.TabIndex = 3;
            this.lbl_CountryId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CountryId.Size = new System.Drawing.Size(88, 23);
            this.lbl_CountryId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CountryId.Text = @"* Country Id";
            this.toolTip1.SetToolTip(this.lbl_CountryId, @"");

            this.lbl_CountryName.AutoSize = false;
            this.lbl_CountryName.Location = new System.Drawing.Point(10, 20);
            this.lbl_CountryName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CountryName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CountryName.Name = "lbl_CountryName";
            this.lbl_CountryName.Enabled = true;
            this.lbl_CountryName.Visible = true;
            this.lbl_CountryName.TabIndex = 5;
            this.lbl_CountryName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CountryName.Size = new System.Drawing.Size(106, 23);
            this.lbl_CountryName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CountryName.Text = @"* Country Name";
            this.toolTip1.SetToolTip(this.lbl_CountryName, @"");

            this.txt_CountryId.Location = new System.Drawing.Point(118, 43);
            this.txt_CountryId.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_CountryId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_CountryId.Name = "txt_CountryId";
            this.txt_CountryId.DefaultValue = null;
            this.txt_CountryId.FriendlyName = "";
            this.txt_CountryId.Enabled = true;
            this.txt_CountryId.Visible = false;
            this.txt_CountryId.ReadOnly = false;
            this.txt_CountryId.TabIndex = 2;
            this.txt_CountryId.MaxValue = 2147483647;
            this.txt_CountryId.MinValue = -2147483648;
            this.txt_CountryId.ValidationMessage = "";
            this.txt_CountryId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CountryId.Size = new System.Drawing.Size(100, 29);
            this.txt_CountryId.SelectAllOnFocus = true;
            this.txt_CountryId.DoValidation = false;
            this.txt_CountryId.AllowNull = false;
            this.txt_CountryId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_CountryId, @"");

            this.txt_CountryName.Location = new System.Drawing.Point(126, 18);
            this.txt_CountryName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_CountryName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_CountryName.Multiline = false;
            this.txt_CountryName.MaxLength = 50;
            this.txt_CountryName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_CountryName.Name = "txt_CountryName";
            this.txt_CountryName.Text = @"";
            
            this.txt_CountryName.AllowNull = false;
            this.txt_CountryName.DefaultValue = "";
            this.txt_CountryName.FriendlyName = "";
            this.txt_CountryName.ValidationType = TextValidation.None;
            this.txt_CountryName.ValidationExpression = @"";
            this.txt_CountryName.ValidationMessage = @"";
            this.txt_CountryName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_CountryName.Enabled = true;
            this.txt_CountryName.ReadOnly = false;
            this.txt_CountryName.Visible = true;
            this.txt_CountryName.TabIndex = 4;
            this.txt_CountryName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_CountryName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CountryName.Size = new System.Drawing.Size(200, 27);
            this.toolTip1.SetToolTip(this.txt_CountryName, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 45;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(5, 94);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(331, 385);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnCountryID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnCountryID.HeaderText = "Country Id";
            this.dgrDataColumnCountryID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCountryID.Name = "dgrDataColumnCountryID";
            this.dgrDataColumnCountryID.DataPropertyName = "CountryID";
            this.dgrDataColumnCountryID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnCountryID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCountryID.Width = 50;
            this.dgrDataColumnCountryID.Visible = false;
            this.dgrDataColumnCountryID.DisplayIndex = 0;
            this.dgrDataColumnCountryID.ReadOnly = false;
            this.dgrDataColumnCountryID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCountryID);

            this.dgrDataColumnCountryName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCountryName.HeaderText = "Country Name";
            this.dgrDataColumnCountryName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCountryName.Name = "dgrDataColumnCountryName";
            this.dgrDataColumnCountryName.DataPropertyName = "CountryName";
            this.dgrDataColumnCountryName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnCountryName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCountryName.Width = 250;
            this.dgrDataColumnCountryName.Visible = true;
            this.dgrDataColumnCountryName.DisplayIndex = 1;
            this.dgrDataColumnCountryName.ReadOnly = false;
            this.dgrDataColumnCountryName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCountryName);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpCmncountry);
            this.grpCmncountry.Controls.Add(this.lbl_CountryId);
            this.grpCmncountry.Controls.Add(this.lbl_CountryName);
            this.grpCmncountry.Controls.Add(this.txt_CountryId);
            this.grpCmncountry.Controls.Add(this.txt_CountryName);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Country";
            this.Text = "Country Master";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(357, 542);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpCmncountry;
        private Kushal.Controls.KushalLabel lbl_CountryId;
        private Kushal.Controls.KushalLabel lbl_CountryName;
        private NumericTextBox txt_CountryId;
        private Kushal.Controls.KushalTextBox txt_CountryName;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCountryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCountryName;
    }
}