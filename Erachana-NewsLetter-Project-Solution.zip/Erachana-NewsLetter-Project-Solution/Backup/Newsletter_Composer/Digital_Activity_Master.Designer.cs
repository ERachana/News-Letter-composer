using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Digital_Activity_Master {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpSocialmediamaster = new Kushal.Controls.KushalGroupBox();
            this.lbl_SocialMediaMaster_Id = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMediaMaster_ActivityName = new Kushal.Controls.KushalLabel();
            this.txt_SocialMediaMaster_Id = new NumericTextBox();
            this.txt_SocialMediaMaster_ActivityName = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnActivityName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(4, 92);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 6;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(112, 92);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 7;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(220, 92);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 8;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(328, 92);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 11;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(306, 445);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpSocialmediamaster.Location = new System.Drawing.Point(7, 0);
            this.grpSocialmediamaster.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpSocialmediamaster.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpSocialmediamaster.Name = "grpSocialmediamaster";
            this.grpSocialmediamaster.Enabled = true;
            this.grpSocialmediamaster.Visible = true;
            this.grpSocialmediamaster.TabIndex = 1;
            this.grpSocialmediamaster.TabStop = false;
            this.grpSocialmediamaster.Size = new System.Drawing.Size(402, 85);
            this.grpSocialmediamaster.Text = @"Digital Activity";
            this.grpSocialmediamaster.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSocialmediamaster.SendToBack();
            this.toolTip1.SetToolTip(this.grpSocialmediamaster, @"");

            this.lbl_SocialMediaMaster_Id.AutoSize = false;
            this.lbl_SocialMediaMaster_Id.Location = new System.Drawing.Point(4, 20);
            this.lbl_SocialMediaMaster_Id.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMediaMaster_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMediaMaster_Id.Name = "lbl_SocialMediaMaster_Id";
            this.lbl_SocialMediaMaster_Id.Enabled = true;
            this.lbl_SocialMediaMaster_Id.Visible = true;
            this.lbl_SocialMediaMaster_Id.TabIndex = 3;
            this.lbl_SocialMediaMaster_Id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMediaMaster_Id.Size = new System.Drawing.Size(100, 23);
            this.lbl_SocialMediaMaster_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMediaMaster_Id.Text = @"* ID";
            this.toolTip1.SetToolTip(this.lbl_SocialMediaMaster_Id, @"");

            this.lbl_SocialMediaMaster_ActivityName.AutoSize = false;
            this.lbl_SocialMediaMaster_ActivityName.Location = new System.Drawing.Point(4, 50);
            this.lbl_SocialMediaMaster_ActivityName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMediaMaster_ActivityName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMediaMaster_ActivityName.Name = "lbl_SocialMediaMaster_ActivityName";
            this.lbl_SocialMediaMaster_ActivityName.Enabled = true;
            this.lbl_SocialMediaMaster_ActivityName.Visible = true;
            this.lbl_SocialMediaMaster_ActivityName.TabIndex = 5;
            this.lbl_SocialMediaMaster_ActivityName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMediaMaster_ActivityName.Size = new System.Drawing.Size(100, 23);
            this.lbl_SocialMediaMaster_ActivityName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMediaMaster_ActivityName.Text = @"* Activity Name";
            this.toolTip1.SetToolTip(this.lbl_SocialMediaMaster_ActivityName, @"");

            this.txt_SocialMediaMaster_Id.Location = new System.Drawing.Point(104, 20);
            this.txt_SocialMediaMaster_Id.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_SocialMediaMaster_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMediaMaster_Id.Name = "txt_SocialMediaMaster_Id";
            this.txt_SocialMediaMaster_Id.DefaultValue = null;
            this.txt_SocialMediaMaster_Id.FriendlyName = "";
            this.txt_SocialMediaMaster_Id.Enabled = true;
            this.txt_SocialMediaMaster_Id.Visible = true;
            this.txt_SocialMediaMaster_Id.ReadOnly = false;
            this.txt_SocialMediaMaster_Id.TabIndex = 2;
            this.txt_SocialMediaMaster_Id.MaxValue = 2147483647;
            this.txt_SocialMediaMaster_Id.MinValue = -2147483648;
            this.txt_SocialMediaMaster_Id.ValidationMessage = "";
            this.txt_SocialMediaMaster_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMediaMaster_Id.Size = new System.Drawing.Size(100, 20);
            this.txt_SocialMediaMaster_Id.SelectAllOnFocus = true;
            this.txt_SocialMediaMaster_Id.DoValidation = false;
            this.txt_SocialMediaMaster_Id.AllowNull = false;
            this.txt_SocialMediaMaster_Id.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_SocialMediaMaster_Id, @"");

            this.txt_SocialMediaMaster_ActivityName.Location = new System.Drawing.Point(104, 50);
            this.txt_SocialMediaMaster_ActivityName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_SocialMediaMaster_ActivityName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMediaMaster_ActivityName.Multiline = false;
            this.txt_SocialMediaMaster_ActivityName.MaxLength = 500;
            this.txt_SocialMediaMaster_ActivityName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_SocialMediaMaster_ActivityName.Name = "txt_SocialMediaMaster_ActivityName";
            this.txt_SocialMediaMaster_ActivityName.Text = @"";
            
            this.txt_SocialMediaMaster_ActivityName.AllowNull = true;
            this.txt_SocialMediaMaster_ActivityName.DefaultValue = "";
            this.txt_SocialMediaMaster_ActivityName.FriendlyName = "";
            this.txt_SocialMediaMaster_ActivityName.ValidationType = TextValidation.None;
            this.txt_SocialMediaMaster_ActivityName.ValidationExpression = @"";
            this.txt_SocialMediaMaster_ActivityName.ValidationMessage = @"";
            this.txt_SocialMediaMaster_ActivityName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_SocialMediaMaster_ActivityName.Enabled = true;
            this.txt_SocialMediaMaster_ActivityName.ReadOnly = false;
            this.txt_SocialMediaMaster_ActivityName.Visible = true;
            this.txt_SocialMediaMaster_ActivityName.TabIndex = 4;
            this.txt_SocialMediaMaster_ActivityName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_SocialMediaMaster_ActivityName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMediaMaster_ActivityName.Size = new System.Drawing.Size(291, 29);
            this.toolTip1.SetToolTip(this.txt_SocialMediaMaster_ActivityName, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(4, 128);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(402, 314);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnId.HeaderText = "ID";
            this.dgrDataColumnId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnId.Name = "dgrDataColumnId";
            this.dgrDataColumnId.DataPropertyName = "Id";
            this.dgrDataColumnId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnId.Width = 70;
            this.dgrDataColumnId.Visible = true;
            this.dgrDataColumnId.DisplayIndex = 0;
            this.dgrDataColumnId.ReadOnly = false;
            this.dgrDataColumnId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnId);

            this.dgrDataColumnActivityName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnActivityName.HeaderText = "Activity Name";
            this.dgrDataColumnActivityName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnActivityName.Name = "dgrDataColumnActivityName";
            this.dgrDataColumnActivityName.DataPropertyName = "ActivityName";
            this.dgrDataColumnActivityName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnActivityName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnActivityName.Width = 250;
            this.dgrDataColumnActivityName.Visible = true;
            this.dgrDataColumnActivityName.DisplayIndex = 1;
            this.dgrDataColumnActivityName.ReadOnly = false;
            this.dgrDataColumnActivityName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnActivityName);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpSocialmediamaster);
            this.grpSocialmediamaster.Controls.Add(this.lbl_SocialMediaMaster_Id);
            this.grpSocialmediamaster.Controls.Add(this.lbl_SocialMediaMaster_ActivityName);
            this.grpSocialmediamaster.Controls.Add(this.txt_SocialMediaMaster_Id);
            this.grpSocialmediamaster.Controls.Add(this.txt_SocialMediaMaster_ActivityName);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Digital_Activity_Master";
            this.Text = "Digital Activity Master";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(427, 507);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpSocialmediamaster;
        private Kushal.Controls.KushalLabel lbl_SocialMediaMaster_Id;
        private Kushal.Controls.KushalLabel lbl_SocialMediaMaster_ActivityName;
        private NumericTextBox txt_SocialMediaMaster_Id;
        private Kushal.Controls.KushalTextBox txt_SocialMediaMaster_ActivityName;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnActivityName;
    }
}