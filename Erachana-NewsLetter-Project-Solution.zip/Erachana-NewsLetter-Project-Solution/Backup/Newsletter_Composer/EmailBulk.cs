using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Web;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class EmailBulk : Form {
        private AdminDetails adminDetails = Settings.GetDatabaseAdminDetails();
        private Dictionary<string, string> fieldSqls = new Dictionary<string, string>();
        private Dictionary<string, ColumnValidationInfo> colValidations = new Dictionary<string, ColumnValidationInfo>();
        private List<string> ExportableColumnNames = new List<string>() { };
        private long dgr_ErrorCount = 0;
        public EmailBulk() {
            InitializeComponent();
            this.Load += new System.EventHandler(this.EmailBulk_PreLoad);
            this.Load += new System.EventHandler(this.EmailBulk_PostLoad);
            this.Activated += new System.EventHandler(this.EmailBulk_Activated);
            DoEventSubscriptions();
            
            fieldSqls.Add("txt_From", "select ID,EmailID from EmailList");
            fieldSqls.Add("lst_Email_ID", "select '' as EMAIL,'' as NAME  from EmailList");
            fieldSqls.Add("dgrAttachment", @"select '' as file_name, '' as file_path from emaillist");
            ControlAdapter.LoadControlDataSource(this.Controls.Cast<Control>().ToList(), fieldSqls);
            ControlAdapter.ProcessDropdownColumns(this.Controls.Cast<Control>().ToList());
            ControlAdapter.AssociateSelectAllListbox(chk_Email_ID, lst_Email_ID);

            
            ControlAdapter.ProcessColumnValidation(this.Controls.Cast<Control>().ToList(), colValidations);
            
            ExportableColumnNames = getExportableColumnNames();
        }

        private List<string> getExportableColumnNames() {
            List<string> ExportableColumnList = new List<string>();
            
            ExportableColumnList.Add("dgrAttachmentColumnfile_name");
            ExportableColumnList.Add("dgrAttachmentColumnfile_path");
            return ExportableColumnList;
        }

        private void printErrorOnlyOnce() {
            if (dgr_ErrorCount > 0) { //DataGridViewComboBoxCell value is not valid
                MessageBox.Show("Some of the columns in the Grid could have problem with it's SQL statement.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dgr_ErrorCount = 0;
            }
        }
        
        

        public object gFrom { get; set; }
        public object gEmailList { get; set; }
        public object gSubject { get; set; }
        public object gMessage { get; set; }
        public object gAttachment { get; set; }
        public object gFilter { get; set; }
        private void EmailBulk_PreLoad(object sender, EventArgs e) {
            
        }
        private void EmailBulk_PostLoad(object sender, EventArgs e) {
            Load_Details();
        }
        private void EmailBulk_Activated(object sender, EventArgs e) {
        }
        private void DoEventSubscriptions() {
            
            this.btnSend.Click += new System.EventHandler(this.btnSend_Evaluate_Click);
            this.btnClose.Click += this.btnClose_Click;
            this.btnAttachment.Click += new System.EventHandler(this.btnAttachment_Evaluate_Click);
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Evaluate_Click);
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Evaluate_Click);
            this.btnConfigure.Click += this.btnConfigure_Click;
        }
        #region Event Handers
        
        private void btnSend_Evaluate_Click(Object sender, EventArgs e) {
            Send_Email();
        }
        private void btnAttachment_Evaluate_Click(Object sender, EventArgs e) {
            File_Add();
        }
        private void btnRemove_Evaluate_Click(Object sender, EventArgs e) {
            File_Remove();
        }
        private void btnOpen_Evaluate_Click(Object sender, EventArgs e) {
            File_Open();
        }
        private void EmailBulk_Evaluate_Load(Object sender, EventArgs e) {
            Load_Details();
        }
        private void btnClose_Click(object sender, EventArgs e) {
            this.Close();
        }
        private void btnConfigure_Click(object sender, EventArgs e) {
            Form form = ControlAdapter.CreateForm("EmailIdMaster");
            
            
            form.ShowDialog();

            int selectedIndex = txt_From.SelectedIndex;
            ReloadData(txt_From);
            if (txt_From.Items.Count > selectedIndex) {
                txt_From.SelectedIndex = selectedIndex;
            } else {
                txt_From.SelectedIndex = -1;
            }
        }
        #endregion
        private void ReloadData(ListControl listControl) {
            if (fieldSqls.ContainsKey(listControl.Name)) {
                DataTable dt = DataAdapter.Current.LoadData(fieldSqls[listControl.Name], "datasource" + listControl.Name);
                if (dt != null) {
                    listControl.ValueMember = dt.Columns[0].ColumnName;
                    listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    listControl.DataSource = dt;
                }
            }
        }
    }
}
