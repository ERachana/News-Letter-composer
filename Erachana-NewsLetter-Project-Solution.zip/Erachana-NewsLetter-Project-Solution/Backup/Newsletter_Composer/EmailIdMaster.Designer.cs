using Kushal.Controls;
namespace Newsletter_Composer {
    partial class EmailIdMaster {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpTmp_Email_Id = new Kushal.Controls.KushalGroupBox();
            this.txt_SERVER_ID = new Kushal.Controls.KushalComboBox();
            this.lbl_ID = new Kushal.Controls.KushalLabel();
            this.lbl_SERVER_ID = new Kushal.Controls.KushalLabel();
            this.lbl_EMAIL_ID = new Kushal.Controls.KushalLabel();
            this.lbl_PASSWORD = new Kushal.Controls.KushalLabel();
            this.lbl_SIGNATURE = new Kushal.Controls.KushalLabel();
            this.txt_ID = new NumericTextBox();
            this.txt_EMAIL_ID = new Kushal.Controls.KushalTextBox();
            this.txt_PASSWORD = new Kushal.Controls.KushalTextBox();
            this.txt_SIGNATURE = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnSERVER_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnEMAIL_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnPASSWORD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnSIGNATURE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(6, 204);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 7;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(104, 204);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 9;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(212, 204);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 11;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(311, 205);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 12;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(292, 505);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpTmp_Email_Id.Location = new System.Drawing.Point(7, 1);
            this.grpTmp_Email_Id.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpTmp_Email_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpTmp_Email_Id.Name = "grpTmp_Email_Id";
            this.grpTmp_Email_Id.Enabled = true;
            this.grpTmp_Email_Id.Visible = true;
            this.grpTmp_Email_Id.TabIndex = 1;
            this.grpTmp_Email_Id.TabStop = false;
            this.grpTmp_Email_Id.Size = new System.Drawing.Size(384, 199);
            this.grpTmp_Email_Id.Text = @"";
            this.grpTmp_Email_Id.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTmp_Email_Id.SendToBack();
            this.toolTip1.SetToolTip(this.grpTmp_Email_Id, @"");

            this.txt_SERVER_ID.Location = new System.Drawing.Point(109, 15);
            this.txt_SERVER_ID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_SERVER_ID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_SERVER_ID.MaxDropDownItems = 10;
            this.txt_SERVER_ID.IntegralHeight = false;
            this.txt_SERVER_ID.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_SERVER_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SERVER_ID.FormattingEnabled = true;
            this.txt_SERVER_ID.Name = "txt_SERVER_ID";
            this.txt_SERVER_ID.AllowNull = true;
            this.txt_SERVER_ID.FriendlyName = "";
            this.txt_SERVER_ID.Enabled = true;
            this.txt_SERVER_ID.Visible = true;
            this.txt_SERVER_ID.TabIndex = 3;
            this.txt_SERVER_ID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_SERVER_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_SERVER_ID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SERVER_ID.Size = new System.Drawing.Size(262, 30);
            this.txt_SERVER_ID.Tag = "select ServerID, ServerName from EmailServer";
            this.toolTip1.SetToolTip(this.txt_SERVER_ID, @"Select Server");
            

            this.lbl_ID.AutoSize = false;
            this.lbl_ID.Location = new System.Drawing.Point(19, 136);
            this.lbl_ID.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Enabled = true;
            this.lbl_ID.Visible = false;
            this.lbl_ID.TabIndex = 5;
            this.lbl_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ID.Size = new System.Drawing.Size(63, 23);
            this.lbl_ID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Text = @"Id";
            this.toolTip1.SetToolTip(this.lbl_ID, @"");

            this.lbl_SERVER_ID.AutoSize = false;
            this.lbl_SERVER_ID.Location = new System.Drawing.Point(5, 18);
            this.lbl_SERVER_ID.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SERVER_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SERVER_ID.Name = "lbl_SERVER_ID";
            this.lbl_SERVER_ID.Enabled = true;
            this.lbl_SERVER_ID.Visible = true;
            this.lbl_SERVER_ID.TabIndex = 7;
            this.lbl_SERVER_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SERVER_ID.Size = new System.Drawing.Size(100, 23);
            this.lbl_SERVER_ID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SERVER_ID.Text = @"* Server";
            this.toolTip1.SetToolTip(this.lbl_SERVER_ID, @"");

            this.lbl_EMAIL_ID.AutoSize = false;
            this.lbl_EMAIL_ID.Location = new System.Drawing.Point(5, 46);
            this.lbl_EMAIL_ID.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_EMAIL_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_EMAIL_ID.Name = "lbl_EMAIL_ID";
            this.lbl_EMAIL_ID.Enabled = true;
            this.lbl_EMAIL_ID.Visible = true;
            this.lbl_EMAIL_ID.TabIndex = 9;
            this.lbl_EMAIL_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_EMAIL_ID.Size = new System.Drawing.Size(100, 23);
            this.lbl_EMAIL_ID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EMAIL_ID.Text = @"* Email Id";
            this.toolTip1.SetToolTip(this.lbl_EMAIL_ID, @"");

            this.lbl_PASSWORD.AutoSize = false;
            this.lbl_PASSWORD.Location = new System.Drawing.Point(5, 77);
            this.lbl_PASSWORD.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PASSWORD.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PASSWORD.Name = "lbl_PASSWORD";
            this.lbl_PASSWORD.Enabled = true;
            this.lbl_PASSWORD.Visible = true;
            this.lbl_PASSWORD.TabIndex = 11;
            this.lbl_PASSWORD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PASSWORD.Size = new System.Drawing.Size(100, 23);
            this.lbl_PASSWORD.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PASSWORD.Text = @"* Password";
            this.toolTip1.SetToolTip(this.lbl_PASSWORD, @"");

            this.lbl_SIGNATURE.AutoSize = false;
            this.lbl_SIGNATURE.Location = new System.Drawing.Point(5, 108);
            this.lbl_SIGNATURE.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SIGNATURE.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SIGNATURE.Name = "lbl_SIGNATURE";
            this.lbl_SIGNATURE.Enabled = true;
            this.lbl_SIGNATURE.Visible = true;
            this.lbl_SIGNATURE.TabIndex = 13;
            this.lbl_SIGNATURE.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SIGNATURE.Size = new System.Drawing.Size(100, 23);
            this.lbl_SIGNATURE.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SIGNATURE.Text = @"  Signature";
            this.toolTip1.SetToolTip(this.lbl_SIGNATURE, @"");

            this.txt_ID.Location = new System.Drawing.Point(7, 161);
            this.txt_ID.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.DefaultValue = 0;
            this.txt_ID.FriendlyName = "";
            this.txt_ID.Enabled = true;
            this.txt_ID.Visible = false;
            this.txt_ID.ReadOnly = false;
            this.txt_ID.TabIndex = 1;
            this.txt_ID.MaxValue = 2147483647;
            this.txt_ID.MinValue = -2147483648;
            this.txt_ID.ValidationMessage = "";
            this.txt_ID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ID.Size = new System.Drawing.Size(53, 27);
            this.txt_ID.SelectAllOnFocus = true;
            this.txt_ID.DoValidation = false;
            this.txt_ID.AllowNull = false;
            this.txt_ID.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_ID, @"");

            this.txt_EMAIL_ID.Location = new System.Drawing.Point(109, 48);
            this.txt_EMAIL_ID.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_EMAIL_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_EMAIL_ID.Multiline = false;
            this.txt_EMAIL_ID.MaxLength = 100;
            this.txt_EMAIL_ID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_EMAIL_ID.Name = "txt_EMAIL_ID";
            this.txt_EMAIL_ID.Text = @"";
            
            this.txt_EMAIL_ID.AllowNull = true;
            this.txt_EMAIL_ID.DefaultValue = "";
            this.txt_EMAIL_ID.FriendlyName = "";
            this.txt_EMAIL_ID.ValidationType = TextValidation.None;
            this.txt_EMAIL_ID.ValidationExpression = @"";
            this.txt_EMAIL_ID.ValidationMessage = @"";
            this.txt_EMAIL_ID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_EMAIL_ID.Enabled = true;
            this.txt_EMAIL_ID.ReadOnly = false;
            this.txt_EMAIL_ID.Visible = true;
            this.txt_EMAIL_ID.TabIndex = 4;
            this.txt_EMAIL_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_EMAIL_ID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EMAIL_ID.Size = new System.Drawing.Size(262, 27);
            this.toolTip1.SetToolTip(this.txt_EMAIL_ID, @"Email Id");

            this.txt_PASSWORD.Location = new System.Drawing.Point(109, 78);
            this.txt_PASSWORD.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_PASSWORD.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PASSWORD.Multiline = false;
            this.txt_PASSWORD.MaxLength = 20;
            this.txt_PASSWORD.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_PASSWORD.Name = "txt_PASSWORD";
            this.txt_PASSWORD.Text = @"";
            this.txt_PASSWORD.PasswordChar = '*';
            this.txt_PASSWORD.AllowNull = true;
            this.txt_PASSWORD.DefaultValue = "";
            this.txt_PASSWORD.FriendlyName = "";
            this.txt_PASSWORD.ValidationType = TextValidation.None;
            this.txt_PASSWORD.ValidationExpression = @"";
            this.txt_PASSWORD.ValidationMessage = @"";
            this.txt_PASSWORD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_PASSWORD.Enabled = true;
            this.txt_PASSWORD.ReadOnly = false;
            this.txt_PASSWORD.Visible = true;
            this.txt_PASSWORD.TabIndex = 5;
            this.txt_PASSWORD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_PASSWORD.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PASSWORD.Size = new System.Drawing.Size(262, 27);
            this.toolTip1.SetToolTip(this.txt_PASSWORD, @"Password");

            this.txt_SIGNATURE.Location = new System.Drawing.Point(109, 108);
            this.txt_SIGNATURE.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_SIGNATURE.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SIGNATURE.Multiline = true;
            this.txt_SIGNATURE.MaxLength = 100;
            this.txt_SIGNATURE.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_SIGNATURE.Name = "txt_SIGNATURE";
            this.txt_SIGNATURE.Text = @"";
            
            this.txt_SIGNATURE.AllowNull = true;
            this.txt_SIGNATURE.DefaultValue = "";
            this.txt_SIGNATURE.FriendlyName = "";
            this.txt_SIGNATURE.ValidationType = TextValidation.None;
            this.txt_SIGNATURE.ValidationExpression = @"";
            this.txt_SIGNATURE.ValidationMessage = @"";
            this.txt_SIGNATURE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_SIGNATURE.Enabled = true;
            this.txt_SIGNATURE.ReadOnly = false;
            this.txt_SIGNATURE.Visible = true;
            this.txt_SIGNATURE.TabIndex = 6;
            this.txt_SIGNATURE.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_SIGNATURE.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SIGNATURE.Size = new System.Drawing.Size(262, 86);
            this.toolTip1.SetToolTip(this.txt_SIGNATURE, @"Signature");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(7, 238);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(387, 266);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnID.HeaderText = "Id";
            this.dgrDataColumnID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnID.Name = "dgrDataColumnID";
            this.dgrDataColumnID.DataPropertyName = "ID";
            this.dgrDataColumnID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnID.Width = 100;
            this.dgrDataColumnID.Visible = false;
            this.dgrDataColumnID.DisplayIndex = 1;
            this.dgrDataColumnID.ReadOnly = false;
            this.dgrDataColumnID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnID);

            this.dgrDataColumnSERVER_ID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnSERVER_ID.HeaderText = "Server";
            this.dgrDataColumnSERVER_ID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnSERVER_ID.Name = "dgrDataColumnSERVER_ID";
            this.dgrDataColumnSERVER_ID.DataPropertyName = "ServerID";
            this.dgrDataColumnSERVER_ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnSERVER_ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnSERVER_ID.Width = 100;
            this.dgrDataColumnSERVER_ID.Visible = true;
            this.dgrDataColumnSERVER_ID.DisplayIndex = 2;
            this.dgrDataColumnSERVER_ID.ReadOnly = false;
            this.dgrDataColumnSERVER_ID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnSERVER_ID);

            this.dgrDataColumnEMAIL_ID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnEMAIL_ID.HeaderText = "Email Id";
            this.dgrDataColumnEMAIL_ID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnEMAIL_ID.Name = "dgrDataColumnEMAIL_ID";
            this.dgrDataColumnEMAIL_ID.DataPropertyName = "EmailID";
            this.dgrDataColumnEMAIL_ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnEMAIL_ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnEMAIL_ID.Width = 200;
            this.dgrDataColumnEMAIL_ID.Visible = true;
            this.dgrDataColumnEMAIL_ID.DisplayIndex = 3;
            this.dgrDataColumnEMAIL_ID.ReadOnly = false;
            this.dgrDataColumnEMAIL_ID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnEMAIL_ID);

            this.dgrDataColumnPASSWORD.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnPASSWORD.HeaderText = "Password";
            this.dgrDataColumnPASSWORD.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPASSWORD.Name = "dgrDataColumnPASSWORD";
            this.dgrDataColumnPASSWORD.DataPropertyName = "Password";
            this.dgrDataColumnPASSWORD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnPASSWORD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPASSWORD.Width = 100;
            this.dgrDataColumnPASSWORD.Visible = false;
            this.dgrDataColumnPASSWORD.DisplayIndex = 4;
            this.dgrDataColumnPASSWORD.ReadOnly = false;
            this.dgrDataColumnPASSWORD.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPASSWORD);

            this.dgrDataColumnSIGNATURE.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnSIGNATURE.HeaderText = "Signature";
            this.dgrDataColumnSIGNATURE.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnSIGNATURE.Name = "dgrDataColumnSIGNATURE";
            this.dgrDataColumnSIGNATURE.DataPropertyName = "Signature";
            this.dgrDataColumnSIGNATURE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnSIGNATURE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnSIGNATURE.Width = 100;
            this.dgrDataColumnSIGNATURE.Visible = false;
            this.dgrDataColumnSIGNATURE.DisplayIndex = 5;
            this.dgrDataColumnSIGNATURE.ReadOnly = false;
            this.dgrDataColumnSIGNATURE.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnSIGNATURE);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpTmp_Email_Id);
            this.grpTmp_Email_Id.Controls.Add(this.txt_SERVER_ID);
            this.grpTmp_Email_Id.Controls.Add(this.lbl_ID);
            this.grpTmp_Email_Id.Controls.Add(this.lbl_SERVER_ID);
            this.grpTmp_Email_Id.Controls.Add(this.lbl_EMAIL_ID);
            this.grpTmp_Email_Id.Controls.Add(this.lbl_PASSWORD);
            this.grpTmp_Email_Id.Controls.Add(this.lbl_SIGNATURE);
            this.grpTmp_Email_Id.Controls.Add(this.txt_ID);
            this.grpTmp_Email_Id.Controls.Add(this.txt_EMAIL_ID);
            this.grpTmp_Email_Id.Controls.Add(this.txt_PASSWORD);
            this.grpTmp_Email_Id.Controls.Add(this.txt_SIGNATURE);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "EmailIdMaster";
            this.Text = "Email Id Configuration";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(410, 561);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpTmp_Email_Id;
        private Kushal.Controls.KushalComboBox txt_SERVER_ID;
        private Kushal.Controls.KushalLabel lbl_ID;
        private Kushal.Controls.KushalLabel lbl_SERVER_ID;
        private Kushal.Controls.KushalLabel lbl_EMAIL_ID;
        private Kushal.Controls.KushalLabel lbl_PASSWORD;
        private Kushal.Controls.KushalLabel lbl_SIGNATURE;
        private NumericTextBox txt_ID;
        private Kushal.Controls.KushalTextBox txt_EMAIL_ID;
        private Kushal.Controls.KushalTextBox txt_PASSWORD;
        private Kushal.Controls.KushalTextBox txt_SIGNATURE;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnSERVER_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnEMAIL_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPASSWORD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnSIGNATURE;
    }
}