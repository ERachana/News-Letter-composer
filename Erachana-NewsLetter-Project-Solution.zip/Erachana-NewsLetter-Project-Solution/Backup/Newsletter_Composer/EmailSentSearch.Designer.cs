using Kushal.Controls;
namespace Newsletter_Composer {
    partial class EmailSentSearch {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnList = new Kushal.Controls.KushalButton();
            this.btnClear = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpAdvancedSearchForm = new Kushal.Controls.KushalGroupBox();
            this.chk_MailFrom = new Kushal.Controls.KushalComboBox();
            this.chk_MailTo = new Kushal.Controls.KushalComboBox();
            this.lbl_MailFrom = new Kushal.Controls.KushalLabel();
            this.lbl_MailTo = new Kushal.Controls.KushalLabel();
            this.lblAnywhere = new Kushal.Controls.KushalLabel();
            this.txtAnywhere = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.ColumnSentDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMailFrom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMailTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSubject = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnContentBody = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnList.Location = new System.Drawing.Point(1, 158);
            this.btnList.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnList.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnList.Name = "btnList";
            this.btnList.Enabled = true;
            this.btnList.Visible = true;
            this.btnList.TabIndex = 27;
            this.btnList.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnList.Size = new System.Drawing.Size(80, 30);
            this.btnList.Text = @"&List";
            this.btnList.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnList.UseVisualStyleBackColor = false;
            this.btnList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnList, @"");
            
            

            this.btnClear.Location = new System.Drawing.Point(318, 158);
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClear.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClear.Name = "btnClear";
            this.btnClear.Enabled = true;
            this.btnClear.Visible = true;
            this.btnClear.TabIndex = 30;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClear.Size = new System.Drawing.Size(80, 30);
            this.btnClear.Text = @"Clea&r";
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClear, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(635, 158);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 31;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(613, 496);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpAdvancedSearchForm.Location = new System.Drawing.Point(3, 3);
            this.grpAdvancedSearchForm.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpAdvancedSearchForm.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpAdvancedSearchForm.Name = "grpAdvancedSearchForm";
            this.grpAdvancedSearchForm.Enabled = true;
            this.grpAdvancedSearchForm.Visible = true;
            this.grpAdvancedSearchForm.TabIndex = 19;
            this.grpAdvancedSearchForm.TabStop = false;
            this.grpAdvancedSearchForm.Size = new System.Drawing.Size(710, 153);
            this.grpAdvancedSearchForm.Text = @"";
            this.grpAdvancedSearchForm.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAdvancedSearchForm.SendToBack();
            this.toolTip1.SetToolTip(this.grpAdvancedSearchForm, @"");

            this.chk_MailFrom.Location = new System.Drawing.Point(139, 50);
            this.chk_MailFrom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.chk_MailFrom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.chk_MailFrom.MaxDropDownItems = 10;
            this.chk_MailFrom.IntegralHeight = false;
            this.chk_MailFrom.BackColor = System.Drawing.Color.FromArgb(-1);
            this.chk_MailFrom.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chk_MailFrom.FormattingEnabled = true;
            this.chk_MailFrom.Name = "chk_MailFrom";
            this.chk_MailFrom.AllowNull = true;
            this.chk_MailFrom.FriendlyName = "chk_MailFrom";
            this.chk_MailFrom.Enabled = true;
            this.chk_MailFrom.Visible = true;
            this.chk_MailFrom.TabIndex = 21;
            this.chk_MailFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.chk_MailFrom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chk_MailFrom.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_MailFrom.Size = new System.Drawing.Size(323, 29);
            this.chk_MailFrom.Tag = "select MailFrom, MailFrom as Mf1 From EmailSentList";
            this.toolTip1.SetToolTip(this.chk_MailFrom, @"");
            

            this.chk_MailTo.Location = new System.Drawing.Point(139, 87);
            this.chk_MailTo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.chk_MailTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.chk_MailTo.MaxDropDownItems = 10;
            this.chk_MailTo.IntegralHeight = false;
            this.chk_MailTo.BackColor = System.Drawing.Color.FromArgb(-1);
            this.chk_MailTo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chk_MailTo.FormattingEnabled = true;
            this.chk_MailTo.Name = "chk_MailTo";
            this.chk_MailTo.AllowNull = true;
            this.chk_MailTo.FriendlyName = "chk_MailTo";
            this.chk_MailTo.Enabled = true;
            this.chk_MailTo.Visible = true;
            this.chk_MailTo.TabIndex = 23;
            this.chk_MailTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.chk_MailTo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chk_MailTo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_MailTo.Size = new System.Drawing.Size(323, 29);
            this.chk_MailTo.Tag = "select MailTo, MailTo as mt1 From EmailSentList";
            this.toolTip1.SetToolTip(this.chk_MailTo, @"");
            

            this.lbl_MailFrom.AutoSize = false;
            this.lbl_MailFrom.Location = new System.Drawing.Point(8, 56);
            this.lbl_MailFrom.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_MailFrom.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_MailFrom.Name = "lbl_MailFrom";
            this.lbl_MailFrom.Enabled = true;
            this.lbl_MailFrom.Visible = true;
            this.lbl_MailFrom.TabIndex = 20;
            this.lbl_MailFrom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_MailFrom.Size = new System.Drawing.Size(80, 23);
            this.lbl_MailFrom.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MailFrom.Text = @"Mail From";
            this.toolTip1.SetToolTip(this.lbl_MailFrom, @"");

            this.lbl_MailTo.AutoSize = false;
            this.lbl_MailTo.Location = new System.Drawing.Point(8, 90);
            this.lbl_MailTo.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_MailTo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_MailTo.Name = "lbl_MailTo";
            this.lbl_MailTo.Enabled = true;
            this.lbl_MailTo.Visible = true;
            this.lbl_MailTo.TabIndex = 22;
            this.lbl_MailTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_MailTo.Size = new System.Drawing.Size(80, 23);
            this.lbl_MailTo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MailTo.Text = @"Mail To";
            this.toolTip1.SetToolTip(this.lbl_MailTo, @"");

            this.lblAnywhere.AutoSize = false;
            this.lblAnywhere.Location = new System.Drawing.Point(8, 127);
            this.lblAnywhere.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblAnywhere.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblAnywhere.Name = "lblAnywhere";
            this.lblAnywhere.Enabled = true;
            this.lblAnywhere.Visible = true;
            this.lblAnywhere.TabIndex = 26;
            this.lblAnywhere.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAnywhere.Size = new System.Drawing.Size(80, 23);
            this.lblAnywhere.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnywhere.Text = @"Anywhere";
            this.toolTip1.SetToolTip(this.lblAnywhere, @"");

            this.txtAnywhere.Location = new System.Drawing.Point(141, 124);
            this.txtAnywhere.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtAnywhere.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtAnywhere.Multiline = false;
            this.txtAnywhere.MaxLength = 256;
            this.txtAnywhere.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAnywhere.Name = "txtAnywhere";
            this.txtAnywhere.Text = @"";
            
            this.txtAnywhere.AllowNull = true;
            this.txtAnywhere.DefaultValue = "";
            this.txtAnywhere.FriendlyName = "txtAnywhere";
            this.txtAnywhere.ValidationType = TextValidation.None;
            this.txtAnywhere.ValidationExpression = @"";
            this.txtAnywhere.ValidationMessage = @"";
            this.txtAnywhere.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtAnywhere.Enabled = true;
            this.txtAnywhere.ReadOnly = false;
            this.txtAnywhere.Visible = true;
            this.txtAnywhere.TabIndex = 25;
            this.txtAnywhere.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtAnywhere.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnywhere.Size = new System.Drawing.Size(323, 29);
            this.toolTip1.SetToolTip(this.txtAnywhere, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(3, 193);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(710, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 18;
            this.dgrData.Tag = @"select mailfrom, mailto, sentdate, subject, contentbody from emailsentlist";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.ColumnSentDate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ColumnSentDate.HeaderText = "Sent On";
            this.ColumnSentDate.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnSentDate.Name = "ColumnSentDate";
            this.ColumnSentDate.DataPropertyName = "SentDate";
            this.ColumnSentDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.ColumnSentDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumnSentDate.Width = 100;
            this.ColumnSentDate.Visible = true;
            this.ColumnSentDate.DisplayIndex = 0;
            this.ColumnSentDate.ReadOnly = false;
            this.ColumnSentDate.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.ColumnSentDate);

            this.ColumnMailFrom.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ColumnMailFrom.HeaderText = "Mail From";
            this.ColumnMailFrom.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnMailFrom.Name = "ColumnMailFrom";
            this.ColumnMailFrom.DataPropertyName = "MailFrom";
            this.ColumnMailFrom.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnMailFrom.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumnMailFrom.Width = 120;
            this.ColumnMailFrom.Visible = true;
            this.ColumnMailFrom.DisplayIndex = 1;
            this.ColumnMailFrom.ReadOnly = false;
            this.ColumnMailFrom.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.ColumnMailFrom);

            this.ColumnMailTo.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ColumnMailTo.HeaderText = "Mail To";
            this.ColumnMailTo.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnMailTo.Name = "ColumnMailTo";
            this.ColumnMailTo.DataPropertyName = "MailTo";
            this.ColumnMailTo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnMailTo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumnMailTo.Width = 120;
            this.ColumnMailTo.Visible = true;
            this.ColumnMailTo.DisplayIndex = 2;
            this.ColumnMailTo.ReadOnly = false;
            this.ColumnMailTo.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.ColumnMailTo);

            this.ColumnSubject.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ColumnSubject.HeaderText = "Subject";
            this.ColumnSubject.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnSubject.Name = "ColumnSubject";
            this.ColumnSubject.DataPropertyName = "Subject";
            this.ColumnSubject.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.ColumnSubject.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumnSubject.Width = 100;
            this.ColumnSubject.Visible = true;
            this.ColumnSubject.DisplayIndex = 3;
            this.ColumnSubject.ReadOnly = false;
            this.ColumnSubject.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.ColumnSubject);

            this.ColumnContentBody.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ColumnContentBody.HeaderText = "Content";
            this.ColumnContentBody.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnContentBody.Name = "ColumnContentBody";
            this.ColumnContentBody.DataPropertyName = "ContentBody";
            this.ColumnContentBody.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnContentBody.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumnContentBody.Width = 200;
            this.ColumnContentBody.Visible = true;
            this.ColumnContentBody.DisplayIndex = 4;
            this.ColumnContentBody.ReadOnly = false;
            this.ColumnContentBody.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.ColumnContentBody);


            
            this.Controls.Add(this.btnList);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpAdvancedSearchForm);
            this.grpAdvancedSearchForm.Controls.Add(this.chk_MailFrom);
            this.grpAdvancedSearchForm.Controls.Add(this.chk_MailTo);
            this.grpAdvancedSearchForm.Controls.Add(this.lbl_MailFrom);
            this.grpAdvancedSearchForm.Controls.Add(this.lbl_MailTo);
            this.grpAdvancedSearchForm.Controls.Add(this.lblAnywhere);
            this.grpAdvancedSearchForm.Controls.Add(this.txtAnywhere);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "EmailSentSearch";
            this.Text = "Sent Email List";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(734, 559);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnList;
        private Kushal.Controls.KushalButton btnClear;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpAdvancedSearchForm;
        private Kushal.Controls.KushalComboBox chk_MailFrom;
        private Kushal.Controls.KushalComboBox chk_MailTo;
        private Kushal.Controls.KushalLabel lbl_MailFrom;
        private Kushal.Controls.KushalLabel lbl_MailTo;
        private Kushal.Controls.KushalLabel lblAnywhere;
        private Kushal.Controls.KushalTextBox txtAnywhere;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSentDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMailFrom;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMailTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSubject;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnContentBody;
    }
}