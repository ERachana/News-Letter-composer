using System;	
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class EmailSentSearch : Form {
        private DataAdapter dataAdapter;
        private AdminDetails adminDetails = Settings.GetDatabaseAdminDetails();
        private Dictionary<string, Control> associatedControls = new Dictionary<string, Control>();
        private Dictionary<string, string> fieldSqls = new Dictionary<string, string>();
        private Dictionary<string, ColumnValidationInfo> colValidations = new Dictionary<string, ColumnValidationInfo>();
        private List<string> ExportableColumnNames = new List<string>() { };
        private long dgr_ErrorCount = 0;
        public EmailSentSearch() {
            InitializeComponent();
            this.Load += new System.EventHandler(this.EmailSentSearch_PreLoad);
            this.Load += new System.EventHandler(this.EmailSentSearch_Load);
            this.Load += new System.EventHandler(this.EmailSentSearch_PostLoad);
            this.Activated += new System.EventHandler(this.EmailSentSearch_Activated);
            DoEventSubscriptions();
            
            associatedControls.Add("MailFrom", chk_MailFrom);
            associatedControls.Add("MailTo", chk_MailTo);
            associatedControls.Add("__Anywhere", txtAnywhere);
            
            fieldSqls.Add("chk_MailFrom", "select MailFrom, MailFrom as Mf1 From EmailSentList");
            fieldSqls.Add("chk_MailTo", "select MailTo, MailTo as mt1 From EmailSentList");
            fieldSqls.Add("dgrData", @"select mailfrom, mailto, sentdate, subject, contentbody from emailsentlist");
            ControlAdapter.LoadControlDataSource(this.Controls.Cast<Control>().ToList(), fieldSqls);
            ControlAdapter.ProcessDropdownColumns(this.Controls.Cast<Control>().ToList());
            
            
            ControlAdapter.ProcessColumnValidation(this.Controls.Cast<Control>().ToList(), colValidations);
            
            ExportableColumnNames = getExportableColumnNames();
        }

        private List<string> getExportableColumnNames() {
            List<string> ExportableColumnList = new List<string>();
            
            ExportableColumnList.Add("ColumnSentDate");
            ExportableColumnList.Add("ColumnMailFrom");
            ExportableColumnList.Add("ColumnMailTo");
            ExportableColumnList.Add("ColumnSubject");
            ExportableColumnList.Add("ColumnContentBody");
            return ExportableColumnList;
        }

        private void printErrorOnlyOnce() {
            if (dgr_ErrorCount > 0) { //DataGridViewComboBoxCell value is not valid
                MessageBox.Show("Some of the columns in the Grid could have problem with its SQL statement.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dgr_ErrorCount = 0;
            }
        }
        
        

        private void DoEventSubscriptions() {
            
            this.btnList.Click += this.btnList_Click;
            this.btnList.Click += new System.EventHandler(this.btnList_Evaluate_Click);
            this.btnClear.Click += this.btnClear_Click;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Evaluate_Click);
            this.btnClose.Click += this.btnClose_Click;
        }
        private void EmailSentSearch_PreLoad(object sender, EventArgs e) {
            
        }
        private void EmailSentSearch_Load(object sender, EventArgs e) {
            LoadData();
            ResetControls();
        }
        private void EmailSentSearch_PostLoad(object sender, EventArgs e) {
            
        }
        private void EmailSentSearch_Activated(object sender, EventArgs e) {
        }
        #region Event Handers
        
        private void btnList_Evaluate_Click(Object sender, EventArgs e) {
            Count_Exp();
        }
        private void btnClear_Evaluate_Click(Object sender, EventArgs e) {
            Count_Exp();
        }
        private void btnList_Click(object sender, EventArgs e) {
            string anywhereFilter = string.Empty;
            if (associatedControls.ContainsKey("__Anywhere")) {
                KushalTextBox txt = (KushalTextBox)associatedControls["__Anywhere"];
                anywhereFilter = txt.Text;
            }
            string filter = string.Empty;
            if (String.IsNullOrEmpty(anywhereFilter) == false) {
                filter = GetAnywhereFilter(anywhereFilter);
            } else {
                filter = GetFilter();
            }
            string sql = (string)dgrData.Tag;
            DataTable dt1 = dataAdapter.LoadData(String.Format("{0} {1}", sql, (String.IsNullOrEmpty(filter) ? "" : "WHERE " + filter)), Guid.NewGuid().ToString());
            if (dt1 != null) {
                BindingSource source = new BindingSource();
                source.DataSource = dt1;
                dgrData.DataSource = source;
            }
        }
        private void btnClear_Click(object sender, EventArgs e) {
            ResetControls();
        }
        private void btnClose_Click(object sender, EventArgs e) {
            this.Close();
        }
		
        private void dgrData_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e) {
            if (e.StateChanged != DataGridViewElementStates.Selected)
                return;
            printErrorOnlyOnce();
        }
        private void dgrData_DataError(object sender, DataGridViewDataErrorEventArgs e) {
            if (!e.Exception.Message.Contains("DataGridViewComboBoxCell value is not valid")) {
                MessageBox.Show(e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                dgr_ErrorCount++;
            }
            e.Cancel = true;
        }
        #endregion
        private bool LoadData() {
            return LoadData(true);
        }

        private bool LoadData(bool showMessage) {
            try {
                string sql = (string)dgrData.Tag;
                if (String.IsNullOrEmpty(sql) == false) {
                    dataAdapter = DataAdapter.Current;
                    DataTable dt = dataAdapter.LoadData(sql, "LoadAdvancedSearchGrid");
                    if (dt != null) {
                        dgrData.DataSource = dt;
                    }
                }

            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private string GetAnywhereFilter(string anywhere) {
            List<string> filters = new List<string>();
            
            filters.Add(GetStringFilter("SentDate", anywhere));
            filters.Add(GetStringFilter("MailFrom", anywhere));
            filters.Add(GetStringFilter("MailTo", anywhere));
            filters.Add(GetStringFilter("Subject", anywhere));
            filters.Add(GetStringFilter("ContentBody", anywhere));
            return String.Join(" OR ", filters.ToArray());
        }

        private string GetStringFilter(string fieldName, string anywhere) {
            return fieldName + String.Format(@" LIKE '%{0}%'", anywhere);
        }

        private string GetNumericFilter(string fieldName, string anywhere) {
            return String.Format(@"Convert(Id, 'System.String') LIKE '%{0}%'", anywhere, fieldName);
        }

        public string GetFilter() {
            List<string> filters = new List<string>();
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (ctrl.GetType() == typeof(NumericSearchCtrl) || ctrl.GetType() == typeof(DateSearchCtrl) || ctrl.GetType() == typeof(StringSearchCtrl)) {
                    ISearchFilter searchFilter = (ISearchFilter)ctrl;
                    string filter = searchFilter.GetFilter();
                    if (String.IsNullOrEmpty(filter) == false) {
                        filters.Add(filter);
                    }
                } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                    KushalComboBox cmb = (KushalComboBox)ctrl;
                    object val = (ctrl.Tag != null && String.IsNullOrEmpty((string)ctrl.Tag) == false) ? cmb.SelectedValue : cmb.SelectedItem;
                    if (val != null) {
                        bool isText = val.GetType() == typeof(string) || val.GetType() == typeof(DateTime);
                        string filter = String.Format("{0} = {1}{2}{1}", key, isText ? "'" : "", val);
                        filters.Add(filter);
                    }
                } else if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                    List<string> listConditions = new List<string>();
                    KushalCheckedListBox listbox = (KushalCheckedListBox)ctrl;
                    foreach (object item in listbox.CheckedItems) {
                        object val = item;
                        if (item is DataRowView) {
                            DataRowView rowView = item as DataRowView;
                            val = rowView[0];
                        }
                        bool isText = val.GetType() == typeof(string) || val.GetType() == typeof(DateTime);
                        string condition = String.Format("{0} = {1}{2}{1}", key, isText ? "'" : "", val);
                        listConditions.Add(condition);
                    }
                    if (listConditions.Count > 0) {
                        string filter = "(" + String.Join(" OR ", listConditions.ToArray()) + ")";
                        filters.Add(filter);
                    }
                } else if (ctrl.GetType() == typeof(KushalCheckBox)) {
                    KushalCheckBox chk = (KushalCheckBox)ctrl;
                    filters.Add(String.Format("{0} = {1}", key, (chk.Checked ? "1" : "0")));
                } else if (ctrl.GetType() == typeof(RadioButtonPanel)) {
                    RadioButtonPanel pnl = (RadioButtonPanel)ctrl;
                    foreach (Control control in pnl.Controls) {
                        if (control is KushalRadioButton) {
                            KushalRadioButton rb = (KushalRadioButton)control;
                            if (rb.Checked) {
                                int val = (int)rb.Value;
                                filters.Add(String.Format("{0} = {1}", key, val));
                                break;
                            }
                        }
                    }
                }
            }
            return String.Join(" AND ", filters.ToArray());
        }

        public void ResetControls() {
            foreach (Control ctrl in associatedControls.Values) {
                if (ctrl is ISearchFilter) {
                    ((ISearchFilter)ctrl).Clear();
                } else if (ctrl is KushalCheckedListBox) {
                    KushalCheckedListBox lst = (KushalCheckedListBox)ctrl;
                    for (int i = 0; i < lst.Items.Count; i++) {
                        lst.SetItemChecked(i, false);
                    }
                } else if (ctrl is ComboBox) {
                    ((ComboBox)ctrl).SelectedIndex = -1;
                } else if (ctrl is TextBox) {
                    ((TextBox)ctrl).Text = string.Empty;
                } else if (ctrl is CheckBox) {
                    ((CheckBox)ctrl).Checked = false;
                } else if (ctrl is RadioButtonPanel) {
                    RadioButtonPanel pnl = (RadioButtonPanel)ctrl;
                    foreach (Control control in pnl.Controls) {
                        if (control is KushalRadioButton) {
                            KushalRadioButton rb = (KushalRadioButton)control;
                            rb.Checked = false;
                        }
                    }
                }
            }
        }
    }
}
