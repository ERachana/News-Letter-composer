using Kushal.Controls;
namespace Newsletter_Composer {
    partial class EmailServer {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpEmailserver = new Kushal.Controls.KushalGroupBox();
            this.lbl_ServerName = new Kushal.Controls.KushalLabel();
            this.lbl_ServerSMTP = new Kushal.Controls.KushalLabel();
            this.lbl_ServerSMTPPort = new Kushal.Controls.KushalLabel();
            this.lblSSL = new Kushal.Controls.KushalLabel();
            this.lbl_ServerID = new Kushal.Controls.KushalLabel();
            this.txt_ServerID = new NumericTextBox();
            this.pnlSSL = new Kushal.Controls.RadioButtonPanel();
            this.rbTrue = new Kushal.Controls.KushalRadioButton();
            this.rbFalse = new Kushal.Controls.KushalRadioButton();
            this.txt_ServerName = new Kushal.Controls.KushalTextBox();
            this.txt_ServerSMTP = new Kushal.Controls.KushalTextBox();
            this.txt_ServerSMTPPort = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnServerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnServerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnServerSMTP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnServerSMTPPort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnServerSSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(9, 155);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 12;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(104, 155);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 13;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(199, 155);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 14;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(294, 155);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 17;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(267, 492);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpEmailserver.Location = new System.Drawing.Point(9, 4);
            this.grpEmailserver.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpEmailserver.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpEmailserver.Name = "grpEmailserver";
            this.grpEmailserver.Enabled = true;
            this.grpEmailserver.Visible = true;
            this.grpEmailserver.TabIndex = 1;
            this.grpEmailserver.TabStop = false;
            this.grpEmailserver.Size = new System.Drawing.Size(362, 147);
            this.grpEmailserver.Text = @"Server Master";
            this.grpEmailserver.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEmailserver.SendToBack();
            this.toolTip1.SetToolTip(this.grpEmailserver, @"");

            this.lbl_ServerName.AutoSize = false;
            this.lbl_ServerName.Location = new System.Drawing.Point(6, 20);
            this.lbl_ServerName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ServerName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ServerName.Name = "lbl_ServerName";
            this.lbl_ServerName.Enabled = true;
            this.lbl_ServerName.Visible = true;
            this.lbl_ServerName.TabIndex = 5;
            this.lbl_ServerName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ServerName.Size = new System.Drawing.Size(100, 23);
            this.lbl_ServerName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServerName.Text = @"* Server Name";
            this.toolTip1.SetToolTip(this.lbl_ServerName, @"");

            this.lbl_ServerSMTP.AutoSize = false;
            this.lbl_ServerSMTP.Location = new System.Drawing.Point(6, 50);
            this.lbl_ServerSMTP.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ServerSMTP.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ServerSMTP.Name = "lbl_ServerSMTP";
            this.lbl_ServerSMTP.Enabled = true;
            this.lbl_ServerSMTP.Visible = true;
            this.lbl_ServerSMTP.TabIndex = 7;
            this.lbl_ServerSMTP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ServerSMTP.Size = new System.Drawing.Size(100, 23);
            this.lbl_ServerSMTP.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServerSMTP.Text = @"* SMTP Name";
            this.toolTip1.SetToolTip(this.lbl_ServerSMTP, @"");

            this.lbl_ServerSMTPPort.AutoSize = false;
            this.lbl_ServerSMTPPort.Location = new System.Drawing.Point(6, 80);
            this.lbl_ServerSMTPPort.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ServerSMTPPort.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ServerSMTPPort.Name = "lbl_ServerSMTPPort";
            this.lbl_ServerSMTPPort.Enabled = true;
            this.lbl_ServerSMTPPort.Visible = true;
            this.lbl_ServerSMTPPort.TabIndex = 9;
            this.lbl_ServerSMTPPort.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ServerSMTPPort.Size = new System.Drawing.Size(100, 23);
            this.lbl_ServerSMTPPort.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServerSMTPPort.Text = @"* Port Number";
            this.toolTip1.SetToolTip(this.lbl_ServerSMTPPort, @"");

            this.lblSSL.AutoSize = false;
            this.lblSSL.Location = new System.Drawing.Point(6, 112);
            this.lblSSL.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblSSL.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblSSL.Name = "lblSSL";
            this.lblSSL.Enabled = true;
            this.lblSSL.Visible = true;
            this.lblSSL.TabIndex = 0;
            this.lblSSL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSSL.Size = new System.Drawing.Size(100, 23);
            this.lblSSL.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSSL.Text = @"* SSL";
            this.toolTip1.SetToolTip(this.lblSSL, @"");

            this.lbl_ServerID.AutoSize = false;
            this.lbl_ServerID.Location = new System.Drawing.Point(37, 147);
            this.lbl_ServerID.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ServerID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ServerID.Name = "lbl_ServerID";
            this.lbl_ServerID.Enabled = true;
            this.lbl_ServerID.Visible = true;
            this.lbl_ServerID.TabIndex = 3;
            this.lbl_ServerID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ServerID.Size = new System.Drawing.Size(100, 23);
            this.lbl_ServerID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServerID.Text = @"Serverid";
            this.toolTip1.SetToolTip(this.lbl_ServerID, @"");

            this.txt_ServerID.Location = new System.Drawing.Point(137, 147);
            this.txt_ServerID.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_ServerID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ServerID.Name = "txt_ServerID";
            this.txt_ServerID.DefaultValue = null;
            this.txt_ServerID.FriendlyName = "";
            this.txt_ServerID.Enabled = true;
            this.txt_ServerID.Visible = true;
            this.txt_ServerID.ReadOnly = false;
            this.txt_ServerID.TabIndex = 2;
            this.txt_ServerID.MaxValue = 2147483647;
            this.txt_ServerID.MinValue = -2147483648;
            this.txt_ServerID.ValidationMessage = "";
            this.txt_ServerID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServerID.Size = new System.Drawing.Size(100, 20);
            this.txt_ServerID.SelectAllOnFocus = true;
            this.txt_ServerID.DoValidation = false;
            this.txt_ServerID.AllowNull = false;
            this.txt_ServerID.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_ServerID, @"");

            this.pnlSSL.Location = new System.Drawing.Point(120, 107);
            this.pnlSSL.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.pnlSSL.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.pnlSSL.Name = "pnlSSL";
            this.pnlSSL.AllowNull = true;
            this.pnlSSL.FriendlyName = "";
            this.pnlSSL.Enabled = true;
            this.pnlSSL.Visible = true;
            this.pnlSSL.Size = new System.Drawing.Size(231, 32);
            this.pnlSSL.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlSSL.SendToBack();

            this.rbTrue.AutoSize = true;
            this.rbTrue.Location = new System.Drawing.Point(2, 1);
            this.rbTrue.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.rbTrue.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.rbTrue.Name = "rbTrue";
            this.rbTrue.Enabled = true;
            this.rbTrue.Visible = true;
            this.rbTrue.TabIndex = 0;
            this.rbTrue.Size = new System.Drawing.Size(60, 27);
            this.rbTrue.Text = @"True";
            this.rbTrue.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTrue.UseVisualStyleBackColor = true;
            this.rbTrue.Value = 1;
            this.toolTip1.SetToolTip(this.rbTrue, @"");

            this.rbFalse.AutoSize = true;
            this.rbFalse.Location = new System.Drawing.Point(68, 1);
            this.rbFalse.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.rbFalse.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.rbFalse.Name = "rbFalse";
            this.rbFalse.Enabled = true;
            this.rbFalse.Visible = true;
            this.rbFalse.TabIndex = 0;
            this.rbFalse.Size = new System.Drawing.Size(62, 29);
            this.rbFalse.Text = @"False";
            this.rbFalse.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbFalse.UseVisualStyleBackColor = true;
            this.rbFalse.Value = 0;
            this.toolTip1.SetToolTip(this.rbFalse, @"");

            this.txt_ServerName.Location = new System.Drawing.Point(120, 17);
            this.txt_ServerName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_ServerName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ServerName.Multiline = false;
            this.txt_ServerName.MaxLength = 100;
            this.txt_ServerName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_ServerName.Name = "txt_ServerName";
            this.txt_ServerName.Text = @"";
            
            this.txt_ServerName.AllowNull = false;
            this.txt_ServerName.DefaultValue = "";
            this.txt_ServerName.FriendlyName = "";
            this.txt_ServerName.ValidationType = TextValidation.None;
            this.txt_ServerName.ValidationExpression = @"";
            this.txt_ServerName.ValidationMessage = @"";
            this.txt_ServerName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ServerName.Enabled = true;
            this.txt_ServerName.ReadOnly = false;
            this.txt_ServerName.Visible = true;
            this.txt_ServerName.TabIndex = 4;
            this.txt_ServerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ServerName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServerName.Size = new System.Drawing.Size(231, 27);
            this.toolTip1.SetToolTip(this.txt_ServerName, @"");

            this.txt_ServerSMTP.Location = new System.Drawing.Point(120, 47);
            this.txt_ServerSMTP.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_ServerSMTP.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ServerSMTP.Multiline = false;
            this.txt_ServerSMTP.MaxLength = 20;
            this.txt_ServerSMTP.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_ServerSMTP.Name = "txt_ServerSMTP";
            this.txt_ServerSMTP.Text = @"";
            
            this.txt_ServerSMTP.AllowNull = false;
            this.txt_ServerSMTP.DefaultValue = "";
            this.txt_ServerSMTP.FriendlyName = "";
            this.txt_ServerSMTP.ValidationType = TextValidation.None;
            this.txt_ServerSMTP.ValidationExpression = @"";
            this.txt_ServerSMTP.ValidationMessage = @"";
            this.txt_ServerSMTP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ServerSMTP.Enabled = true;
            this.txt_ServerSMTP.ReadOnly = false;
            this.txt_ServerSMTP.Visible = true;
            this.txt_ServerSMTP.TabIndex = 6;
            this.txt_ServerSMTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ServerSMTP.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServerSMTP.Size = new System.Drawing.Size(231, 27);
            this.toolTip1.SetToolTip(this.txt_ServerSMTP, @"");

            this.txt_ServerSMTPPort.Location = new System.Drawing.Point(120, 77);
            this.txt_ServerSMTPPort.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_ServerSMTPPort.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ServerSMTPPort.Multiline = false;
            this.txt_ServerSMTPPort.MaxLength = 20;
            this.txt_ServerSMTPPort.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_ServerSMTPPort.Name = "txt_ServerSMTPPort";
            this.txt_ServerSMTPPort.Text = @"";
            
            this.txt_ServerSMTPPort.AllowNull = true;
            this.txt_ServerSMTPPort.DefaultValue = "";
            this.txt_ServerSMTPPort.FriendlyName = "";
            this.txt_ServerSMTPPort.ValidationType = TextValidation.None;
            this.txt_ServerSMTPPort.ValidationExpression = @"";
            this.txt_ServerSMTPPort.ValidationMessage = @"";
            this.txt_ServerSMTPPort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ServerSMTPPort.Enabled = true;
            this.txt_ServerSMTPPort.ReadOnly = false;
            this.txt_ServerSMTPPort.Visible = true;
            this.txt_ServerSMTPPort.TabIndex = 8;
            this.txt_ServerSMTPPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ServerSMTPPort.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServerSMTPPort.Size = new System.Drawing.Size(231, 27);
            this.toolTip1.SetToolTip(this.txt_ServerSMTPPort, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(8, 188);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(362, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnServerID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnServerID.HeaderText = "Serverid";
            this.dgrDataColumnServerID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnServerID.Name = "dgrDataColumnServerID";
            this.dgrDataColumnServerID.DataPropertyName = "ServerID";
            this.dgrDataColumnServerID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnServerID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnServerID.Width = 100;
            this.dgrDataColumnServerID.Visible = false;
            this.dgrDataColumnServerID.DisplayIndex = 0;
            this.dgrDataColumnServerID.ReadOnly = false;
            this.dgrDataColumnServerID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnServerID);

            this.dgrDataColumnServerName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnServerName.HeaderText = "Server Name";
            this.dgrDataColumnServerName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnServerName.Name = "dgrDataColumnServerName";
            this.dgrDataColumnServerName.DataPropertyName = "ServerName";
            this.dgrDataColumnServerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnServerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnServerName.Width = 100;
            this.dgrDataColumnServerName.Visible = true;
            this.dgrDataColumnServerName.DisplayIndex = 1;
            this.dgrDataColumnServerName.ReadOnly = false;
            this.dgrDataColumnServerName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnServerName);

            this.dgrDataColumnServerSMTP.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnServerSMTP.HeaderText = "SMTP";
            this.dgrDataColumnServerSMTP.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnServerSMTP.Name = "dgrDataColumnServerSMTP";
            this.dgrDataColumnServerSMTP.DataPropertyName = "ServerSMTP";
            this.dgrDataColumnServerSMTP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnServerSMTP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnServerSMTP.Width = 100;
            this.dgrDataColumnServerSMTP.Visible = true;
            this.dgrDataColumnServerSMTP.DisplayIndex = 2;
            this.dgrDataColumnServerSMTP.ReadOnly = false;
            this.dgrDataColumnServerSMTP.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnServerSMTP);

            this.dgrDataColumnServerSMTPPort.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnServerSMTPPort.HeaderText = "SMTP Port";
            this.dgrDataColumnServerSMTPPort.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnServerSMTPPort.Name = "dgrDataColumnServerSMTPPort";
            this.dgrDataColumnServerSMTPPort.DataPropertyName = "ServerSMTPPort";
            this.dgrDataColumnServerSMTPPort.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnServerSMTPPort.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnServerSMTPPort.Width = 100;
            this.dgrDataColumnServerSMTPPort.Visible = true;
            this.dgrDataColumnServerSMTPPort.DisplayIndex = 3;
            this.dgrDataColumnServerSMTPPort.ReadOnly = false;
            this.dgrDataColumnServerSMTPPort.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnServerSMTPPort);

            this.dgrDataColumnServerSSL.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnServerSSL.HeaderText = "SSL";
            this.dgrDataColumnServerSSL.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnServerSSL.Name = "dgrDataColumnServerSSL";
            this.dgrDataColumnServerSSL.DataPropertyName = "ServerSSL";
            this.dgrDataColumnServerSSL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnServerSSL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnServerSSL.Width = 100;
            this.dgrDataColumnServerSSL.Visible = true;
            this.dgrDataColumnServerSSL.DisplayIndex = 4;
            this.dgrDataColumnServerSSL.ReadOnly = false;
            this.dgrDataColumnServerSSL.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnServerSSL);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpEmailserver);
            this.grpEmailserver.Controls.Add(this.lbl_ServerName);
            this.grpEmailserver.Controls.Add(this.lbl_ServerSMTP);
            this.grpEmailserver.Controls.Add(this.lbl_ServerSMTPPort);
            this.grpEmailserver.Controls.Add(this.lblSSL);
            this.grpEmailserver.Controls.Add(this.lbl_ServerID);
            this.grpEmailserver.Controls.Add(this.txt_ServerID);
            this.grpEmailserver.Controls.Add(this.pnlSSL);
            this.pnlSSL.Controls.Add(this.rbTrue);
            this.pnlSSL.Controls.Add(this.rbFalse);
            this.grpEmailserver.Controls.Add(this.txt_ServerName);
            this.grpEmailserver.Controls.Add(this.txt_ServerSMTP);
            this.grpEmailserver.Controls.Add(this.txt_ServerSMTPPort);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "EmailServer";
            this.Text = "Server Master";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(403, 566);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpEmailserver;
        private Kushal.Controls.KushalLabel lbl_ServerName;
        private Kushal.Controls.KushalLabel lbl_ServerSMTP;
        private Kushal.Controls.KushalLabel lbl_ServerSMTPPort;
        private Kushal.Controls.KushalLabel lblSSL;
        private Kushal.Controls.KushalLabel lbl_ServerID;
        private NumericTextBox txt_ServerID;
        private Kushal.Controls.RadioButtonPanel pnlSSL;
        private Kushal.Controls.KushalRadioButton rbTrue;
        private Kushal.Controls.KushalRadioButton rbFalse;
        private Kushal.Controls.KushalTextBox txt_ServerName;
        private Kushal.Controls.KushalTextBox txt_ServerSMTP;
        private Kushal.Controls.KushalTextBox txt_ServerSMTPPort;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnServerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnServerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnServerSMTP;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnServerSMTPPort;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnServerSSL;
    }
}