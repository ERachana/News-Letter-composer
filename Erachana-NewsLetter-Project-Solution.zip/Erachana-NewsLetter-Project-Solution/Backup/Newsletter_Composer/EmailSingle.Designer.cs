using Kushal.Controls;
namespace Newsletter_Composer {
    partial class EmailSingle {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnSend = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.grpDetails = new Kushal.Controls.KushalGroupBox();
            this.btnAttachment = new Kushal.Controls.KushalButton();
            this.btnRemove = new Kushal.Controls.KushalButton();
            this.btnOpen = new Kushal.Controls.KushalButton();
            this.btnConfigure = new Kushal.Controls.KushalButton();
            this.txt_From = new Kushal.Controls.KushalComboBox();
            this.lblTo = new Kushal.Controls.KushalLabel();
            this.lblBCC = new Kushal.Controls.KushalLabel();
            this.lblCC = new Kushal.Controls.KushalLabel();
            this.lblSubject = new Kushal.Controls.KushalLabel();
            this.lblMessage = new Kushal.Controls.KushalLabel();
            this.lblFrom = new Kushal.Controls.KushalLabel();
            this.lblAttachments = new Kushal.Controls.KushalLabel();
            this.txt_To = new Kushal.Controls.KushalTextBox();
            this.txt_BCC = new Kushal.Controls.KushalTextBox();
            this.txt_CC = new Kushal.Controls.KushalTextBox();
            this.txt_Subject = new Kushal.Controls.KushalTextBox();
            this.txt_Message = new Kushal.Controls.KushalTextBox();
            this.dgrAttachment = new System.Windows.Forms.DataGridView();
            this.dgrAttachmentColumnfile_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrAttachmentColumnfile_path = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnSend.Location = new System.Drawing.Point(109, 570);
            this.btnSend.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSend.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSend.Name = "btnSend";
            this.btnSend.Enabled = true;
            this.btnSend.Visible = true;
            this.btnSend.TabIndex = 7;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSend.Size = new System.Drawing.Size(80, 29);
            this.btnSend.Text = @"Send";
            this.btnSend.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSend, @"Send Email");
            
            

            this.btnClose.Location = new System.Drawing.Point(835, 570);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 11;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.grpDetails.Location = new System.Drawing.Point(6, 1);
            this.grpDetails.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpDetails.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpDetails.Name = "grpDetails";
            this.grpDetails.Enabled = true;
            this.grpDetails.Visible = true;
            this.grpDetails.TabIndex = 0;
            this.grpDetails.TabStop = false;
            this.grpDetails.Size = new System.Drawing.Size(913, 560);
            this.grpDetails.Text = @"";
            this.grpDetails.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDetails.SendToBack();
            this.toolTip1.SetToolTip(this.grpDetails, @"");

            this.btnAttachment.Location = new System.Drawing.Point(546, 523);
            this.btnAttachment.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnAttachment.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnAttachment.Name = "btnAttachment";
            this.btnAttachment.Enabled = true;
            this.btnAttachment.Visible = true;
            this.btnAttachment.TabIndex = 8;
            this.btnAttachment.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnAttachment.Size = new System.Drawing.Size(70, 30);
            this.btnAttachment.Text = @"Add";
            this.btnAttachment.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttachment.UseVisualStyleBackColor = false;
            this.btnAttachment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnAttachment, @"Add Attachments");
            
            

            this.btnRemove.Location = new System.Drawing.Point(836, 524);
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnRemove.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Enabled = true;
            this.btnRemove.Visible = true;
            this.btnRemove.TabIndex = 10;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnRemove.Size = new System.Drawing.Size(70, 30);
            this.btnRemove.Text = @"Remove";
            this.btnRemove.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnRemove, @"Delete File");
            
            

            this.btnOpen.Location = new System.Drawing.Point(691, 524);
            this.btnOpen.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnOpen.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Enabled = true;
            this.btnOpen.Visible = true;
            this.btnOpen.TabIndex = 9;
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnOpen.Size = new System.Drawing.Size(70, 30);
            this.btnOpen.Text = @"Open";
            this.btnOpen.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpen.UseVisualStyleBackColor = false;
            this.btnOpen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnOpen, @"Open File");
            
            

            this.btnConfigure.Location = new System.Drawing.Point(509, 17);
            this.btnConfigure.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnConfigure.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnConfigure.Name = "btnConfigure";
            this.btnConfigure.Enabled = true;
            this.btnConfigure.Visible = true;
            this.btnConfigure.TabIndex = 0;
            this.btnConfigure.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnConfigure.Size = new System.Drawing.Size(30, 30);
            this.btnConfigure.Text = @"...";
            this.btnConfigure.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfigure.UseVisualStyleBackColor = false;
            this.btnConfigure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnConfigure, @"Configure Email");
            
            

            this.txt_From.Location = new System.Drawing.Point(89, 17);
            this.txt_From.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_From.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_From.MaxDropDownItems = 10;
            this.txt_From.IntegralHeight = false;
            this.txt_From.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_From.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_From.FormattingEnabled = true;
            this.txt_From.Name = "txt_From";
            this.txt_From.AllowNull = false;
            this.txt_From.FriendlyName = "";
            this.txt_From.Enabled = true;
            this.txt_From.Visible = true;
            this.txt_From.TabIndex = 1;
            this.txt_From.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_From.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_From.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_From.Size = new System.Drawing.Size(416, 30);
            this.txt_From.Tag = "select ID,EmailID from EmailList";
            this.toolTip1.SetToolTip(this.txt_From, @"Select Email");
            

            this.lblTo.AutoSize = false;
            this.lblTo.Location = new System.Drawing.Point(12, 52);
            this.lblTo.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblTo.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblTo.Name = "lblTo";
            this.lblTo.Enabled = true;
            this.lblTo.Visible = true;
            this.lblTo.TabIndex = 0;
            this.lblTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTo.Size = new System.Drawing.Size(73, 23);
            this.lblTo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTo.Text = @"To :";
            this.toolTip1.SetToolTip(this.lblTo, @"");

            this.lblBCC.AutoSize = false;
            this.lblBCC.Location = new System.Drawing.Point(12, 109);
            this.lblBCC.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblBCC.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblBCC.Name = "lblBCC";
            this.lblBCC.Enabled = true;
            this.lblBCC.Visible = true;
            this.lblBCC.TabIndex = 0;
            this.lblBCC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBCC.Size = new System.Drawing.Size(73, 23);
            this.lblBCC.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBCC.Text = @"BCC : ";
            this.toolTip1.SetToolTip(this.lblBCC, @"");

            this.lblCC.AutoSize = false;
            this.lblCC.Location = new System.Drawing.Point(12, 154);
            this.lblCC.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblCC.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblCC.Name = "lblCC";
            this.lblCC.Enabled = true;
            this.lblCC.Visible = true;
            this.lblCC.TabIndex = 0;
            this.lblCC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCC.Size = new System.Drawing.Size(73, 23);
            this.lblCC.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCC.Text = @"CC :";
            this.toolTip1.SetToolTip(this.lblCC, @"");

            this.lblSubject.AutoSize = false;
            this.lblSubject.Location = new System.Drawing.Point(12, 206);
            this.lblSubject.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblSubject.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblSubject.Name = "lblSubject";
            this.lblSubject.Enabled = true;
            this.lblSubject.Visible = true;
            this.lblSubject.TabIndex = 0;
            this.lblSubject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSubject.Size = new System.Drawing.Size(73, 23);
            this.lblSubject.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubject.Text = @"Subject :";
            this.toolTip1.SetToolTip(this.lblSubject, @"");

            this.lblMessage.AutoSize = false;
            this.lblMessage.Location = new System.Drawing.Point(12, 234);
            this.lblMessage.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblMessage.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Enabled = true;
            this.lblMessage.Visible = true;
            this.lblMessage.TabIndex = 0;
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblMessage.Size = new System.Drawing.Size(73, 23);
            this.lblMessage.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Text = @"Message : ";
            this.toolTip1.SetToolTip(this.lblMessage, @"");

            this.lblFrom.AutoSize = false;
            this.lblFrom.Location = new System.Drawing.Point(12, 18);
            this.lblFrom.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblFrom.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.Enabled = true;
            this.lblFrom.Visible = true;
            this.lblFrom.TabIndex = 0;
            this.lblFrom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFrom.Size = new System.Drawing.Size(73, 23);
            this.lblFrom.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrom.Text = @"From :";
            this.toolTip1.SetToolTip(this.lblFrom, @"");

            this.lblAttachments.AutoSize = false;
            this.lblAttachments.Location = new System.Drawing.Point(548, 207);
            this.lblAttachments.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblAttachments.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblAttachments.Name = "lblAttachments";
            this.lblAttachments.Enabled = true;
            this.lblAttachments.Visible = true;
            this.lblAttachments.TabIndex = 0;
            this.lblAttachments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAttachments.Size = new System.Drawing.Size(211, 23);
            this.lblAttachments.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAttachments.Text = @"Attachments";
            this.toolTip1.SetToolTip(this.lblAttachments, @"");

            this.txt_To.Location = new System.Drawing.Point(89, 49);
            this.txt_To.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_To.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_To.Multiline = true;
            this.txt_To.MaxLength = 2147483647;
            this.txt_To.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_To.Name = "txt_To";
            this.txt_To.Text = @"";
            
            this.txt_To.AllowNull = false;
            this.txt_To.DefaultValue = "";
            this.txt_To.FriendlyName = "txtNewText1";
            this.txt_To.ValidationType = TextValidation.None;
            this.txt_To.ValidationExpression = @"";
            this.txt_To.ValidationMessage = @"";
            this.txt_To.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_To.Enabled = true;
            this.txt_To.ReadOnly = false;
            this.txt_To.Visible = true;
            this.txt_To.TabIndex = 2;
            this.txt_To.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_To.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_To.Size = new System.Drawing.Size(450, 50);
            this.toolTip1.SetToolTip(this.txt_To, @"Email To");

            this.txt_BCC.Location = new System.Drawing.Point(89, 101);
            this.txt_BCC.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_BCC.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_BCC.Multiline = true;
            this.txt_BCC.MaxLength = 2147483647;
            this.txt_BCC.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_BCC.Name = "txt_BCC";
            this.txt_BCC.Text = @"";
            
            this.txt_BCC.AllowNull = false;
            this.txt_BCC.DefaultValue = "";
            this.txt_BCC.FriendlyName = "txtNewText2";
            this.txt_BCC.ValidationType = TextValidation.None;
            this.txt_BCC.ValidationExpression = @"";
            this.txt_BCC.ValidationMessage = @"";
            this.txt_BCC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_BCC.Enabled = true;
            this.txt_BCC.ReadOnly = false;
            this.txt_BCC.Visible = true;
            this.txt_BCC.TabIndex = 3;
            this.txt_BCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_BCC.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_BCC.Size = new System.Drawing.Size(450, 50);
            this.toolTip1.SetToolTip(this.txt_BCC, @"Before Carbon Copy");

            this.txt_CC.Location = new System.Drawing.Point(89, 153);
            this.txt_CC.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_CC.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_CC.Multiline = true;
            this.txt_CC.MaxLength = 2147483647;
            this.txt_CC.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_CC.Name = "txt_CC";
            this.txt_CC.Text = @"";
            
            this.txt_CC.AllowNull = false;
            this.txt_CC.DefaultValue = "";
            this.txt_CC.FriendlyName = "txtNewText3";
            this.txt_CC.ValidationType = TextValidation.None;
            this.txt_CC.ValidationExpression = @"";
            this.txt_CC.ValidationMessage = @"";
            this.txt_CC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_CC.Enabled = true;
            this.txt_CC.ReadOnly = false;
            this.txt_CC.Visible = true;
            this.txt_CC.TabIndex = 4;
            this.txt_CC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_CC.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CC.Size = new System.Drawing.Size(450, 50);
            this.toolTip1.SetToolTip(this.txt_CC, @"Carbon Copy");

            this.txt_Subject.Location = new System.Drawing.Point(89, 205);
            this.txt_Subject.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_Subject.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Subject.Multiline = false;
            this.txt_Subject.MaxLength = 2147483647;
            this.txt_Subject.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Subject.Name = "txt_Subject";
            this.txt_Subject.Text = @"";
            
            this.txt_Subject.AllowNull = false;
            this.txt_Subject.DefaultValue = "";
            this.txt_Subject.FriendlyName = "txtNewText4";
            this.txt_Subject.ValidationType = TextValidation.None;
            this.txt_Subject.ValidationExpression = @"";
            this.txt_Subject.ValidationMessage = @"";
            this.txt_Subject.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Subject.Enabled = true;
            this.txt_Subject.ReadOnly = false;
            this.txt_Subject.Visible = true;
            this.txt_Subject.TabIndex = 5;
            this.txt_Subject.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Subject.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Subject.Size = new System.Drawing.Size(450, 27);
            this.toolTip1.SetToolTip(this.txt_Subject, @"Subject of Email");

            this.txt_Message.Location = new System.Drawing.Point(89, 234);
            this.txt_Message.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_Message.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Message.Multiline = true;
            this.txt_Message.MaxLength = 2147483647;
            this.txt_Message.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_Message.Name = "txt_Message";
            this.txt_Message.Text = @"";
            
            this.txt_Message.AllowNull = false;
            this.txt_Message.DefaultValue = "";
            this.txt_Message.FriendlyName = "txtNewText5";
            this.txt_Message.ValidationType = TextValidation.None;
            this.txt_Message.ValidationExpression = @"";
            this.txt_Message.ValidationMessage = @"";
            this.txt_Message.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Message.Enabled = true;
            this.txt_Message.ReadOnly = false;
            this.txt_Message.Visible = true;
            this.txt_Message.TabIndex = 6;
            this.txt_Message.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Message.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Message.Size = new System.Drawing.Size(450, 320);
            this.toolTip1.SetToolTip(this.txt_Message, @"Email Content");

            this.dgrAttachment.AllowUserToAddRows = false;
            this.dgrAttachment.AllowUserToDeleteRows = false;
            this.dgrAttachment.ColumnHeadersHeight = 25;
            this.dgrAttachment.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrAttachment.Location = new System.Drawing.Point(545, 235);
            this.dgrAttachment.Name = "dgrAttachment";
            this.dgrAttachment.Enabled = true;
            this.dgrAttachment.Visible = true;
            this.dgrAttachment.MultiSelect = false;
            this.dgrAttachment.ReadOnly = true;
            this.dgrAttachment.ShowRowErrors = false;
            this.dgrAttachment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrAttachment.Size = new System.Drawing.Size(361, 283);
            this.dgrAttachment.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrAttachment.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrAttachment.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrAttachment.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrAttachment.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrAttachment.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrAttachment.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrAttachment.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrAttachment.TabIndex = 0;
            this.dgrAttachment.Tag = @"select '' as file_name, '' as file_path from emaillist";
            this.toolTip1.SetToolTip(this.dgrAttachment, @"");
            
            
            

            this.dgrAttachmentColumnfile_name.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrAttachmentColumnfile_name.HeaderText = "File Name";
            this.dgrAttachmentColumnfile_name.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrAttachmentColumnfile_name.Name = "dgrAttachmentColumnfile_name";
            this.dgrAttachmentColumnfile_name.DataPropertyName = "file_name";
            this.dgrAttachmentColumnfile_name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrAttachmentColumnfile_name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrAttachmentColumnfile_name.Width = 300;
            this.dgrAttachmentColumnfile_name.Visible = true;
            this.dgrAttachmentColumnfile_name.DisplayIndex = 0;
            this.dgrAttachmentColumnfile_name.ReadOnly = false;
            this.dgrAttachmentColumnfile_name.Tag = "";
            
            
            
            this.dgrAttachment.Columns.Add(this.dgrAttachmentColumnfile_name);

            this.dgrAttachmentColumnfile_path.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrAttachmentColumnfile_path.HeaderText = "File Path";
            this.dgrAttachmentColumnfile_path.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrAttachmentColumnfile_path.Name = "dgrAttachmentColumnfile_path";
            this.dgrAttachmentColumnfile_path.DataPropertyName = "file_path";
            this.dgrAttachmentColumnfile_path.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrAttachmentColumnfile_path.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrAttachmentColumnfile_path.Width = 150;
            this.dgrAttachmentColumnfile_path.Visible = false;
            this.dgrAttachmentColumnfile_path.DisplayIndex = 1;
            this.dgrAttachmentColumnfile_path.ReadOnly = false;
            this.dgrAttachmentColumnfile_path.Tag = "";
            
            
            
            this.dgrAttachment.Columns.Add(this.dgrAttachmentColumnfile_path);


            
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpDetails);
            this.grpDetails.Controls.Add(this.btnAttachment);
            this.grpDetails.Controls.Add(this.btnRemove);
            this.grpDetails.Controls.Add(this.btnOpen);
            this.grpDetails.Controls.Add(this.btnConfigure);
            this.grpDetails.Controls.Add(this.txt_From);
            this.grpDetails.Controls.Add(this.lblTo);
            this.grpDetails.Controls.Add(this.lblBCC);
            this.grpDetails.Controls.Add(this.lblCC);
            this.grpDetails.Controls.Add(this.lblSubject);
            this.grpDetails.Controls.Add(this.lblMessage);
            this.grpDetails.Controls.Add(this.lblFrom);
            this.grpDetails.Controls.Add(this.lblAttachments);
            this.grpDetails.Controls.Add(this.txt_To);
            this.grpDetails.Controls.Add(this.txt_BCC);
            this.grpDetails.Controls.Add(this.txt_CC);
            this.grpDetails.Controls.Add(this.txt_Subject);
            this.grpDetails.Controls.Add(this.txt_Message);
            this.grpDetails.Controls.Add(this.dgrAttachment);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "EmailSingle";
            this.Text = "Send Email";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(935, 639);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnSend;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalGroupBox grpDetails;
        private Kushal.Controls.KushalButton btnAttachment;
        private Kushal.Controls.KushalButton btnRemove;
        private Kushal.Controls.KushalButton btnOpen;
        private Kushal.Controls.KushalButton btnConfigure;
        private Kushal.Controls.KushalComboBox txt_From;
        private Kushal.Controls.KushalLabel lblTo;
        private Kushal.Controls.KushalLabel lblBCC;
        private Kushal.Controls.KushalLabel lblCC;
        private Kushal.Controls.KushalLabel lblSubject;
        private Kushal.Controls.KushalLabel lblMessage;
        private Kushal.Controls.KushalLabel lblFrom;
        private Kushal.Controls.KushalLabel lblAttachments;
        private Kushal.Controls.KushalTextBox txt_To;
        private Kushal.Controls.KushalTextBox txt_BCC;
        private Kushal.Controls.KushalTextBox txt_CC;
        private Kushal.Controls.KushalTextBox txt_Subject;
        private Kushal.Controls.KushalTextBox txt_Message;
        private System.Windows.Forms.DataGridView dgrAttachment;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrAttachmentColumnfile_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrAttachmentColumnfile_path;
    }
}