using Kushal.Controls;
namespace Newsletter_Composer {
    partial class EmailTemplate {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.btnAdd = new Kushal.Controls.KushalButton();
            this.btnUpdate = new Kushal.Controls.KushalButton();
            this.btnRemove = new Kushal.Controls.KushalButton();
            this.grpEmailtemplate_Emailtemplateattachment = new Kushal.Controls.KushalGroupBox();
            this.btnContentHeader = new Kushal.Controls.KushalButton();
            this.btnContentBody = new Kushal.Controls.KushalButton();
            this.btnContentFooter = new Kushal.Controls.KushalButton();
            this.btnGenarate = new Kushal.Controls.KushalButton();
            this.btnpreview = new Kushal.Controls.KushalButton();
            this.btn_EditHtml = new Kushal.Controls.KushalButton();
            this.cmbContentHeader = new Kushal.Controls.KushalComboBox();
            this.cmbContentBody = new Kushal.Controls.KushalComboBox();
            this.cmbContentFooter = new Kushal.Controls.KushalComboBox();
            this.cmbSelectMonth = new Kushal.Controls.KushalComboBox();
            this.lbl_TemplateID = new Kushal.Controls.KushalLabel();
            this.lbl_TemplateName = new Kushal.Controls.KushalLabel();
            this.lbl_Subject = new Kushal.Controls.KushalLabel();
            this.lbl_ContentHeader = new Kushal.Controls.KushalLabel();
            this.lbl_ContentBody = new Kushal.Controls.KushalLabel();
            this.lbl_ID = new Kushal.Controls.KushalLabel();
            this.lbl_TemplateID_child = new Kushal.Controls.KushalLabel();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.txt_TemplateID = new NumericTextBox();
            this.txt_ID_Child = new NumericTextBox();
            this.txt_TemplateID_Child = new NumericTextBox();
            this.txt_TemplateName = new Kushal.Controls.KushalTextBox();
            this.txt_Subject = new Kushal.Controls.KushalTextBox();
            this.txt_ContentHeader = new Kushal.Controls.KushalTextBox();
            this.txt_ContentBody = new Kushal.Controls.KushalTextBox();
            this.txt_ContentFooter = new Kushal.Controls.KushalTextBox();
            this.grpEmailtemplate_EmailtemplateattachmentChild = new Kushal.Controls.KushalGroupBox();
            this.lbl_AttachmentPath = new Kushal.Controls.KushalLabel();
            this.txt_AttachmentPath = new Kushal.Controls.KushalTextBox();
            this.dgr1 = new System.Windows.Forms.DataGridView();
            this.dgr1ColumnTemplateID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr1ColumnTemplateName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr1ColumnSubject = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr1ColumnContentHeader = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr1ColumnContentBody = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr1ColumnContentFooter = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2 = new System.Windows.Forms.DataGridView();
            this.dgr2ColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnTemplateID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgr2ColumnAttachmentPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(10, 480);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 14;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 28);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(183, 480);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 15;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 28);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(356, 480);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 16;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 28);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(529, 480);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 19;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 28);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.btnAdd.Location = new System.Drawing.Point(620, 88);
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Enabled = true;
            this.btnAdd.Visible = true;
            this.btnAdd.TabIndex = 28;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnAdd.Size = new System.Drawing.Size(80, 30);
            this.btnAdd.Text = @"&Add";
            this.btnAdd.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnAdd, @"");
            
            

            this.btnUpdate.Location = new System.Drawing.Point(713, 88);
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Enabled = true;
            this.btnUpdate.Visible = true;
            this.btnUpdate.TabIndex = 29;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnUpdate.Size = new System.Drawing.Size(80, 30);
            this.btnUpdate.Text = @"&Update";
            this.btnUpdate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnUpdate, @"");
            
            

            this.btnRemove.Location = new System.Drawing.Point(806, 88);
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnRemove.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Enabled = true;
            this.btnRemove.Visible = true;
            this.btnRemove.TabIndex = 30;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnRemove.Size = new System.Drawing.Size(80, 30);
            this.btnRemove.Text = @"&Remove";
            this.btnRemove.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnRemove, @"");
            
            

            this.grpEmailtemplate_Emailtemplateattachment.Location = new System.Drawing.Point(9, 3);
            this.grpEmailtemplate_Emailtemplateattachment.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpEmailtemplate_Emailtemplateattachment.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpEmailtemplate_Emailtemplateattachment.Name = "grpEmailtemplate_Emailtemplateattachment";
            this.grpEmailtemplate_Emailtemplateattachment.Enabled = true;
            this.grpEmailtemplate_Emailtemplateattachment.Visible = true;
            this.grpEmailtemplate_Emailtemplateattachment.TabIndex = 1;
            this.grpEmailtemplate_Emailtemplateattachment.TabStop = false;
            this.grpEmailtemplate_Emailtemplateattachment.Size = new System.Drawing.Size(600, 471);
            this.grpEmailtemplate_Emailtemplateattachment.Text = @"Template Details";
            this.grpEmailtemplate_Emailtemplateattachment.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEmailtemplate_Emailtemplateattachment.SendToBack();
            this.toolTip1.SetToolTip(this.grpEmailtemplate_Emailtemplateattachment, @"");

            this.btnContentHeader.Location = new System.Drawing.Point(776, 260);
            this.btnContentHeader.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnContentHeader.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnContentHeader.Name = "btnContentHeader";
            this.btnContentHeader.Enabled = true;
            this.btnContentHeader.Visible = false;
            this.btnContentHeader.TabIndex = 0;
            this.btnContentHeader.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnContentHeader.Size = new System.Drawing.Size(38, 29);
            this.btnContentHeader.Text = @"<<";
            this.btnContentHeader.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContentHeader.UseVisualStyleBackColor = false;
            this.btnContentHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnContentHeader, @"");
            
            

            this.btnContentBody.Location = new System.Drawing.Point(776, 318);
            this.btnContentBody.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnContentBody.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnContentBody.Name = "btnContentBody";
            this.btnContentBody.Enabled = true;
            this.btnContentBody.Visible = false;
            this.btnContentBody.TabIndex = 0;
            this.btnContentBody.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnContentBody.Size = new System.Drawing.Size(38, 29);
            this.btnContentBody.Text = @"<<";
            this.btnContentBody.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContentBody.UseVisualStyleBackColor = false;
            this.btnContentBody.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnContentBody, @"");
            
            

            this.btnContentFooter.Location = new System.Drawing.Point(775, 381);
            this.btnContentFooter.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnContentFooter.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnContentFooter.Name = "btnContentFooter";
            this.btnContentFooter.Enabled = true;
            this.btnContentFooter.Visible = false;
            this.btnContentFooter.TabIndex = 0;
            this.btnContentFooter.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnContentFooter.Size = new System.Drawing.Size(38, 29);
            this.btnContentFooter.Text = @"<<";
            this.btnContentFooter.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContentFooter.UseVisualStyleBackColor = false;
            this.btnContentFooter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnContentFooter, @"");
            
            

            this.btnGenarate.Location = new System.Drawing.Point(326, 152);
            this.btnGenarate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnGenarate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnGenarate.Name = "btnGenarate";
            this.btnGenarate.Enabled = true;
            this.btnGenarate.Visible = true;
            this.btnGenarate.TabIndex = 0;
            this.btnGenarate.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnGenarate.Size = new System.Drawing.Size(80, 30);
            this.btnGenarate.Text = @"Generate";
            this.btnGenarate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenarate.UseVisualStyleBackColor = false;
            this.btnGenarate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnGenarate, @"");
            
            

            this.btnpreview.Location = new System.Drawing.Point(514, 372);
            this.btnpreview.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnpreview.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnpreview.Name = "btnpreview";
            this.btnpreview.Enabled = true;
            this.btnpreview.Visible = true;
            this.btnpreview.TabIndex = 0;
            this.btnpreview.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnpreview.Size = new System.Drawing.Size(80, 28);
            this.btnpreview.Text = @"Preview";
            this.btnpreview.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpreview.UseVisualStyleBackColor = false;
            this.btnpreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnpreview, @"");
            
            

            this.btn_EditHtml.Location = new System.Drawing.Point(416, 372);
            this.btn_EditHtml.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btn_EditHtml.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btn_EditHtml.Name = "btn_EditHtml";
            this.btn_EditHtml.Enabled = true;
            this.btn_EditHtml.Visible = true;
            this.btn_EditHtml.TabIndex = 0;
            this.btn_EditHtml.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btn_EditHtml.Size = new System.Drawing.Size(80, 28);
            this.btn_EditHtml.Text = @"Edit Html";
            this.btn_EditHtml.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditHtml.UseVisualStyleBackColor = false;
            this.btn_EditHtml.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btn_EditHtml, @"");
            
            

            this.cmbContentHeader.Location = new System.Drawing.Point(736, 230);
            this.cmbContentHeader.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbContentHeader.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbContentHeader.MaxDropDownItems = 10;
            this.cmbContentHeader.IntegralHeight = false;
            this.cmbContentHeader.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmbContentHeader.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbContentHeader.FormattingEnabled = true;
            this.cmbContentHeader.Name = "cmbContentHeader";
            this.cmbContentHeader.AllowNull = true;
            this.cmbContentHeader.FriendlyName = "";
            this.cmbContentHeader.Enabled = true;
            this.cmbContentHeader.Visible = false;
            this.cmbContentHeader.TabIndex = 0;
            this.cmbContentHeader.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContentHeader.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbContentHeader.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbContentHeader.Size = new System.Drawing.Size(120, 30);
            this.cmbContentHeader.Tag = "select ID,FieldName from EmailTemplateFields";
            this.toolTip1.SetToolTip(this.cmbContentHeader, @"");
            

            this.cmbContentBody.Location = new System.Drawing.Point(736, 287);
            this.cmbContentBody.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbContentBody.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbContentBody.MaxDropDownItems = 10;
            this.cmbContentBody.IntegralHeight = false;
            this.cmbContentBody.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmbContentBody.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbContentBody.FormattingEnabled = true;
            this.cmbContentBody.Name = "cmbContentBody";
            this.cmbContentBody.AllowNull = true;
            this.cmbContentBody.FriendlyName = "";
            this.cmbContentBody.Enabled = true;
            this.cmbContentBody.Visible = false;
            this.cmbContentBody.TabIndex = 0;
            this.cmbContentBody.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContentBody.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbContentBody.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbContentBody.Size = new System.Drawing.Size(120, 30);
            this.cmbContentBody.Tag = "select ID,FieldName from EmailTemplateFields";
            this.toolTip1.SetToolTip(this.cmbContentBody, @"");
            

            this.cmbContentFooter.Location = new System.Drawing.Point(737, 349);
            this.cmbContentFooter.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbContentFooter.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbContentFooter.MaxDropDownItems = 10;
            this.cmbContentFooter.IntegralHeight = false;
            this.cmbContentFooter.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmbContentFooter.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbContentFooter.FormattingEnabled = true;
            this.cmbContentFooter.Name = "cmbContentFooter";
            this.cmbContentFooter.AllowNull = true;
            this.cmbContentFooter.FriendlyName = "";
            this.cmbContentFooter.Enabled = true;
            this.cmbContentFooter.Visible = false;
            this.cmbContentFooter.TabIndex = 0;
            this.cmbContentFooter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContentFooter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbContentFooter.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbContentFooter.Size = new System.Drawing.Size(120, 30);
            this.cmbContentFooter.Tag = "select ID,FieldName from EmailTemplateFields";
            this.toolTip1.SetToolTip(this.cmbContentFooter, @"");
            

            this.cmbSelectMonth.Location = new System.Drawing.Point(123, 153);
            this.cmbSelectMonth.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectMonth.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectMonth.MaxDropDownItems = 10;
            this.cmbSelectMonth.IntegralHeight = false;
            this.cmbSelectMonth.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmbSelectMonth.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbSelectMonth.FormattingEnabled = true;
            this.cmbSelectMonth.Name = "cmbSelectMonth";
            this.cmbSelectMonth.AllowNull = true;
            this.cmbSelectMonth.FriendlyName = "cmbNewDropDown1";
            this.cmbSelectMonth.Enabled = true;
            this.cmbSelectMonth.Visible = true;
            this.cmbSelectMonth.TabIndex = 0;
            this.cmbSelectMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSelectMonth.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectMonth.Size = new System.Drawing.Size(194, 29);
            this.cmbSelectMonth.Tag = "select monthmaster.id, cast(monthmaster.year as nvarchar(4)) + '-' + cast(listmaster.listcode as nvarchar(15)) as expr1, listmaster.listid AS Month, monthmaster.year from monthmaster inner join listmaster on monthmaster.month = listmaster.listid where listmaster.listtypeid = 1";
            this.toolTip1.SetToolTip(this.cmbSelectMonth, @"");
            

            this.lbl_TemplateID.AutoSize = false;
            this.lbl_TemplateID.Location = new System.Drawing.Point(15, 309);
            this.lbl_TemplateID.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_TemplateID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_TemplateID.Name = "lbl_TemplateID";
            this.lbl_TemplateID.Enabled = true;
            this.lbl_TemplateID.Visible = false;
            this.lbl_TemplateID.TabIndex = 3;
            this.lbl_TemplateID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_TemplateID.Size = new System.Drawing.Size(100, 23);
            this.lbl_TemplateID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TemplateID.Text = @"Templateid";
            this.toolTip1.SetToolTip(this.lbl_TemplateID, @"");

            this.lbl_TemplateName.AutoSize = false;
            this.lbl_TemplateName.Location = new System.Drawing.Point(8, 17);
            this.lbl_TemplateName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_TemplateName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_TemplateName.Name = "lbl_TemplateName";
            this.lbl_TemplateName.Enabled = true;
            this.lbl_TemplateName.Visible = true;
            this.lbl_TemplateName.TabIndex = 5;
            this.lbl_TemplateName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_TemplateName.Size = new System.Drawing.Size(113, 23);
            this.lbl_TemplateName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TemplateName.Text = @"* Template Name";
            this.toolTip1.SetToolTip(this.lbl_TemplateName, @"");

            this.lbl_Subject.AutoSize = false;
            this.lbl_Subject.Location = new System.Drawing.Point(8, 48);
            this.lbl_Subject.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Subject.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Enabled = true;
            this.lbl_Subject.Visible = true;
            this.lbl_Subject.TabIndex = 7;
            this.lbl_Subject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Subject.Size = new System.Drawing.Size(113, 23);
            this.lbl_Subject.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subject.Text = @"* Subject";
            this.toolTip1.SetToolTip(this.lbl_Subject, @"");

            this.lbl_ContentHeader.AutoSize = false;
            this.lbl_ContentHeader.Location = new System.Drawing.Point(8, 98);
            this.lbl_ContentHeader.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ContentHeader.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ContentHeader.Name = "lbl_ContentHeader";
            this.lbl_ContentHeader.Enabled = true;
            this.lbl_ContentHeader.Visible = true;
            this.lbl_ContentHeader.TabIndex = 9;
            this.lbl_ContentHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ContentHeader.Size = new System.Drawing.Size(113, 23);
            this.lbl_ContentHeader.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ContentHeader.Text = @"  Content Header";
            this.toolTip1.SetToolTip(this.lbl_ContentHeader, @"");

            this.lbl_ContentBody.AutoSize = false;
            this.lbl_ContentBody.Location = new System.Drawing.Point(10, 190);
            this.lbl_ContentBody.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ContentBody.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ContentBody.Name = "lbl_ContentBody";
            this.lbl_ContentBody.Enabled = true;
            this.lbl_ContentBody.Visible = true;
            this.lbl_ContentBody.TabIndex = 11;
            this.lbl_ContentBody.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ContentBody.Size = new System.Drawing.Size(113, 23);
            this.lbl_ContentBody.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ContentBody.Text = @"  Content  Body";
            this.toolTip1.SetToolTip(this.lbl_ContentBody, @"");

            this.lbl_ID.AutoSize = false;
            this.lbl_ID.Location = new System.Drawing.Point(17, 284);
            this.lbl_ID.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Enabled = true;
            this.lbl_ID.Visible = false;
            this.lbl_ID.TabIndex = 23;
            this.lbl_ID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ID.Size = new System.Drawing.Size(100, 23);
            this.lbl_ID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Text = @"Id";
            this.toolTip1.SetToolTip(this.lbl_ID, @"");

            this.lbl_TemplateID_child.AutoSize = false;
            this.lbl_TemplateID_child.Location = new System.Drawing.Point(13, 401);
            this.lbl_TemplateID_child.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_TemplateID_child.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_TemplateID_child.Name = "lbl_TemplateID_child";
            this.lbl_TemplateID_child.Enabled = true;
            this.lbl_TemplateID_child.Visible = true;
            this.lbl_TemplateID_child.TabIndex = 25;
            this.lbl_TemplateID_child.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_TemplateID_child.Size = new System.Drawing.Size(100, 23);
            this.lbl_TemplateID_child.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TemplateID_child.Text = @"Content Footer";
            this.toolTip1.SetToolTip(this.lbl_TemplateID_child, @"");

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(421, 156);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(172, 23);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"(If Month Report Template)";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(8, 156);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(100, 23);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @"  Select Month";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.txt_TemplateID.Location = new System.Drawing.Point(14, 258);
            this.txt_TemplateID.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_TemplateID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_TemplateID.Name = "txt_TemplateID";
            this.txt_TemplateID.DefaultValue = null;
            this.txt_TemplateID.FriendlyName = "";
            this.txt_TemplateID.Enabled = true;
            this.txt_TemplateID.Visible = false;
            this.txt_TemplateID.ReadOnly = false;
            this.txt_TemplateID.TabIndex = 2;
            this.txt_TemplateID.MaxValue = 2147483647;
            this.txt_TemplateID.MinValue = -2147483648;
            this.txt_TemplateID.ValidationMessage = "";
            this.txt_TemplateID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TemplateID.Size = new System.Drawing.Size(100, 20);
            this.txt_TemplateID.SelectAllOnFocus = true;
            this.txt_TemplateID.DoValidation = false;
            this.txt_TemplateID.AllowNull = false;
            this.txt_TemplateID.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_TemplateID, @"");

            this.txt_ID_Child.Location = new System.Drawing.Point(14, 334);
            this.txt_ID_Child.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_ID_Child.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ID_Child.Name = "txt_ID_Child";
            this.txt_ID_Child.DefaultValue = null;
            this.txt_ID_Child.FriendlyName = "";
            this.txt_ID_Child.Enabled = true;
            this.txt_ID_Child.Visible = false;
            this.txt_ID_Child.ReadOnly = false;
            this.txt_ID_Child.TabIndex = 22;
            this.txt_ID_Child.MaxValue = 2147483647;
            this.txt_ID_Child.MinValue = -2147483648;
            this.txt_ID_Child.ValidationMessage = "";
            this.txt_ID_Child.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ID_Child.Size = new System.Drawing.Size(100, 20);
            this.txt_ID_Child.SelectAllOnFocus = true;
            this.txt_ID_Child.DoValidation = false;
            this.txt_ID_Child.AllowNull = false;
            this.txt_ID_Child.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_ID_Child, @"");

            this.txt_TemplateID_Child.Location = new System.Drawing.Point(14, 231);
            this.txt_TemplateID_Child.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_TemplateID_Child.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_TemplateID_Child.Name = "txt_TemplateID_Child";
            this.txt_TemplateID_Child.DefaultValue = null;
            this.txt_TemplateID_Child.FriendlyName = "";
            this.txt_TemplateID_Child.Enabled = true;
            this.txt_TemplateID_Child.Visible = false;
            this.txt_TemplateID_Child.ReadOnly = false;
            this.txt_TemplateID_Child.TabIndex = 24;
            this.txt_TemplateID_Child.MaxValue = 2147483647;
            this.txt_TemplateID_Child.MinValue = -2147483648;
            this.txt_TemplateID_Child.ValidationMessage = "";
            this.txt_TemplateID_Child.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TemplateID_Child.Size = new System.Drawing.Size(100, 20);
            this.txt_TemplateID_Child.SelectAllOnFocus = true;
            this.txt_TemplateID_Child.DoValidation = false;
            this.txt_TemplateID_Child.AllowNull = false;
            this.txt_TemplateID_Child.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_TemplateID_Child, @"");

            this.txt_TemplateName.Location = new System.Drawing.Point(123, 13);
            this.txt_TemplateName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_TemplateName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_TemplateName.Multiline = false;
            this.txt_TemplateName.MaxLength = 100;
            this.txt_TemplateName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_TemplateName.Name = "txt_TemplateName";
            this.txt_TemplateName.Text = @"";
            
            this.txt_TemplateName.AllowNull = false;
            this.txt_TemplateName.DefaultValue = "";
            this.txt_TemplateName.FriendlyName = "";
            this.txt_TemplateName.ValidationType = TextValidation.None;
            this.txt_TemplateName.ValidationExpression = @"";
            this.txt_TemplateName.ValidationMessage = @"";
            this.txt_TemplateName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_TemplateName.Enabled = true;
            this.txt_TemplateName.ReadOnly = false;
            this.txt_TemplateName.Visible = true;
            this.txt_TemplateName.TabIndex = 4;
            this.txt_TemplateName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_TemplateName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TemplateName.Size = new System.Drawing.Size(469, 27);
            this.toolTip1.SetToolTip(this.txt_TemplateName, @"");

            this.txt_Subject.Location = new System.Drawing.Point(123, 45);
            this.txt_Subject.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_Subject.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Subject.Multiline = true;
            this.txt_Subject.MaxLength = 255;
            this.txt_Subject.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_Subject.Name = "txt_Subject";
            this.txt_Subject.Text = @"";
            
            this.txt_Subject.AllowNull = false;
            this.txt_Subject.DefaultValue = "";
            this.txt_Subject.FriendlyName = "";
            this.txt_Subject.ValidationType = TextValidation.None;
            this.txt_Subject.ValidationExpression = @"";
            this.txt_Subject.ValidationMessage = @"";
            this.txt_Subject.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Subject.Enabled = true;
            this.txt_Subject.ReadOnly = false;
            this.txt_Subject.Visible = true;
            this.txt_Subject.TabIndex = 6;
            this.txt_Subject.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Subject.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Subject.Size = new System.Drawing.Size(469, 50);
            this.toolTip1.SetToolTip(this.txt_Subject, @"");

            this.txt_ContentHeader.Location = new System.Drawing.Point(123, 98);
            this.txt_ContentHeader.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_ContentHeader.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ContentHeader.Multiline = true;
            this.txt_ContentHeader.MaxLength = 255;
            this.txt_ContentHeader.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_ContentHeader.Name = "txt_ContentHeader";
            this.txt_ContentHeader.Text = @"";
            
            this.txt_ContentHeader.AllowNull = true;
            this.txt_ContentHeader.DefaultValue = "";
            this.txt_ContentHeader.FriendlyName = "";
            this.txt_ContentHeader.ValidationType = TextValidation.None;
            this.txt_ContentHeader.ValidationExpression = @"";
            this.txt_ContentHeader.ValidationMessage = @"";
            this.txt_ContentHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ContentHeader.Enabled = true;
            this.txt_ContentHeader.ReadOnly = false;
            this.txt_ContentHeader.Visible = true;
            this.txt_ContentHeader.TabIndex = 8;
            this.txt_ContentHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ContentHeader.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContentHeader.Size = new System.Drawing.Size(469, 51);
            this.toolTip1.SetToolTip(this.txt_ContentHeader, @"");

            this.txt_ContentBody.Location = new System.Drawing.Point(125, 189);
            this.txt_ContentBody.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_ContentBody.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ContentBody.Multiline = true;
            this.txt_ContentBody.MaxLength = 1000;
            this.txt_ContentBody.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_ContentBody.Name = "txt_ContentBody";
            this.txt_ContentBody.Text = @"";
            
            this.txt_ContentBody.AllowNull = true;
            this.txt_ContentBody.DefaultValue = "";
            this.txt_ContentBody.FriendlyName = "";
            this.txt_ContentBody.ValidationType = TextValidation.None;
            this.txt_ContentBody.ValidationExpression = @"";
            this.txt_ContentBody.ValidationMessage = @"";
            this.txt_ContentBody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ContentBody.Enabled = true;
            this.txt_ContentBody.ReadOnly = false;
            this.txt_ContentBody.Visible = true;
            this.txt_ContentBody.TabIndex = 10;
            this.txt_ContentBody.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ContentBody.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContentBody.Size = new System.Drawing.Size(469, 182);
            this.toolTip1.SetToolTip(this.txt_ContentBody, @"");

            this.txt_ContentFooter.Location = new System.Drawing.Point(123, 401);
            this.txt_ContentFooter.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_ContentFooter.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ContentFooter.Multiline = true;
            this.txt_ContentFooter.MaxLength = 255;
            this.txt_ContentFooter.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_ContentFooter.Name = "txt_ContentFooter";
            this.txt_ContentFooter.Text = @"";
            
            this.txt_ContentFooter.AllowNull = true;
            this.txt_ContentFooter.DefaultValue = "";
            this.txt_ContentFooter.FriendlyName = "";
            this.txt_ContentFooter.ValidationType = TextValidation.None;
            this.txt_ContentFooter.ValidationExpression = @"";
            this.txt_ContentFooter.ValidationMessage = @"";
            this.txt_ContentFooter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ContentFooter.Enabled = true;
            this.txt_ContentFooter.ReadOnly = false;
            this.txt_ContentFooter.Visible = true;
            this.txt_ContentFooter.TabIndex = 12;
            this.txt_ContentFooter.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ContentFooter.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ContentFooter.Size = new System.Drawing.Size(469, 59);
            this.toolTip1.SetToolTip(this.txt_ContentFooter, @"");

            this.grpEmailtemplate_EmailtemplateattachmentChild.Location = new System.Drawing.Point(616, 11);
            this.grpEmailtemplate_EmailtemplateattachmentChild.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpEmailtemplate_EmailtemplateattachmentChild.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpEmailtemplate_EmailtemplateattachmentChild.Name = "grpEmailtemplate_EmailtemplateattachmentChild";
            this.grpEmailtemplate_EmailtemplateattachmentChild.Enabled = true;
            this.grpEmailtemplate_EmailtemplateattachmentChild.Visible = true;
            this.grpEmailtemplate_EmailtemplateattachmentChild.TabIndex = 21;
            this.grpEmailtemplate_EmailtemplateattachmentChild.TabStop = false;
            this.grpEmailtemplate_EmailtemplateattachmentChild.Size = new System.Drawing.Size(273, 69);
            this.grpEmailtemplate_EmailtemplateattachmentChild.Text = @"";
            this.grpEmailtemplate_EmailtemplateattachmentChild.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEmailtemplate_EmailtemplateattachmentChild.SendToBack();
            this.toolTip1.SetToolTip(this.grpEmailtemplate_EmailtemplateattachmentChild, @"");

            this.lbl_AttachmentPath.AutoSize = false;
            this.lbl_AttachmentPath.Location = new System.Drawing.Point(5, 14);
            this.lbl_AttachmentPath.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_AttachmentPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_AttachmentPath.Name = "lbl_AttachmentPath";
            this.lbl_AttachmentPath.Enabled = true;
            this.lbl_AttachmentPath.Visible = true;
            this.lbl_AttachmentPath.TabIndex = 27;
            this.lbl_AttachmentPath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_AttachmentPath.Size = new System.Drawing.Size(100, 23);
            this.lbl_AttachmentPath.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AttachmentPath.Text = @"Attachment";
            this.toolTip1.SetToolTip(this.lbl_AttachmentPath, @"");

            this.txt_AttachmentPath.Location = new System.Drawing.Point(3, 39);
            this.txt_AttachmentPath.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_AttachmentPath.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_AttachmentPath.Multiline = false;
            this.txt_AttachmentPath.MaxLength = 500;
            this.txt_AttachmentPath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_AttachmentPath.Name = "txt_AttachmentPath";
            this.txt_AttachmentPath.Text = @"";
            
            this.txt_AttachmentPath.AllowNull = false;
            this.txt_AttachmentPath.DefaultValue = "";
            this.txt_AttachmentPath.FriendlyName = "";
            this.txt_AttachmentPath.ValidationType = TextValidation.None;
            this.txt_AttachmentPath.ValidationExpression = @"";
            this.txt_AttachmentPath.ValidationMessage = @"";
            this.txt_AttachmentPath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_AttachmentPath.Enabled = true;
            this.txt_AttachmentPath.ReadOnly = true;
            this.txt_AttachmentPath.Visible = true;
            this.txt_AttachmentPath.TabIndex = 26;
            this.txt_AttachmentPath.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_AttachmentPath.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AttachmentPath.Size = new System.Drawing.Size(265, 29);
            this.toolTip1.SetToolTip(this.txt_AttachmentPath, @"");

            this.dgr1.AllowUserToAddRows = false;
            this.dgr1.AllowUserToDeleteRows = false;
            this.dgr1.ColumnHeadersHeight = 25;
            this.dgr1.Dock = System.Windows.Forms.DockStyle.None;
            this.dgr1.Location = new System.Drawing.Point(8, 513);
            this.dgr1.Name = "dgr1";
            this.dgr1.Enabled = true;
            this.dgr1.Visible = true;
            this.dgr1.MultiSelect = false;
            this.dgr1.ReadOnly = true;
            this.dgr1.ShowRowErrors = false;
            this.dgr1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgr1.Size = new System.Drawing.Size(600, 113);
            this.dgr1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgr1.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr1.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgr1.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgr1.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgr1.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgr1.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgr1.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgr1.TabIndex = 0;
            this.dgr1.Tag = @"";
            this.toolTip1.SetToolTip(this.dgr1, @"");
            this.dgr1.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgr1_DataError);
            this.dgr1.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgr1_RowStateChanged);
            

            this.dgr1ColumnTemplateID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgr1ColumnTemplateID.HeaderText = "Templateid";
            this.dgr1ColumnTemplateID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr1ColumnTemplateID.Name = "dgr1ColumnTemplateID";
            this.dgr1ColumnTemplateID.DataPropertyName = "TemplateID";
            this.dgr1ColumnTemplateID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr1ColumnTemplateID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr1ColumnTemplateID.Width = 100;
            this.dgr1ColumnTemplateID.Visible = false;
            this.dgr1ColumnTemplateID.DisplayIndex = 0;
            this.dgr1ColumnTemplateID.ReadOnly = false;
            this.dgr1ColumnTemplateID.Tag = "";
            
            
            
            this.dgr1.Columns.Add(this.dgr1ColumnTemplateID);

            this.dgr1ColumnTemplateName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr1ColumnTemplateName.HeaderText = "Template Name";
            this.dgr1ColumnTemplateName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr1ColumnTemplateName.Name = "dgr1ColumnTemplateName";
            this.dgr1ColumnTemplateName.DataPropertyName = "TemplateName";
            this.dgr1ColumnTemplateName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr1ColumnTemplateName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr1ColumnTemplateName.Width = 120;
            this.dgr1ColumnTemplateName.Visible = true;
            this.dgr1ColumnTemplateName.DisplayIndex = 1;
            this.dgr1ColumnTemplateName.ReadOnly = false;
            this.dgr1ColumnTemplateName.Tag = "";
            
            
            
            this.dgr1.Columns.Add(this.dgr1ColumnTemplateName);

            this.dgr1ColumnSubject.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr1ColumnSubject.HeaderText = "Subject";
            this.dgr1ColumnSubject.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr1ColumnSubject.Name = "dgr1ColumnSubject";
            this.dgr1ColumnSubject.DataPropertyName = "Subject";
            this.dgr1ColumnSubject.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr1ColumnSubject.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr1ColumnSubject.Width = 150;
            this.dgr1ColumnSubject.Visible = true;
            this.dgr1ColumnSubject.DisplayIndex = 2;
            this.dgr1ColumnSubject.ReadOnly = false;
            this.dgr1ColumnSubject.Tag = "";
            
            
            
            this.dgr1.Columns.Add(this.dgr1ColumnSubject);

            this.dgr1ColumnContentHeader.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr1ColumnContentHeader.HeaderText = "Content Header";
            this.dgr1ColumnContentHeader.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr1ColumnContentHeader.Name = "dgr1ColumnContentHeader";
            this.dgr1ColumnContentHeader.DataPropertyName = "ContentHeader";
            this.dgr1ColumnContentHeader.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr1ColumnContentHeader.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr1ColumnContentHeader.Width = 180;
            this.dgr1ColumnContentHeader.Visible = true;
            this.dgr1ColumnContentHeader.DisplayIndex = 3;
            this.dgr1ColumnContentHeader.ReadOnly = false;
            this.dgr1ColumnContentHeader.Tag = "";
            
            
            
            this.dgr1.Columns.Add(this.dgr1ColumnContentHeader);

            this.dgr1ColumnContentBody.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr1ColumnContentBody.HeaderText = "Content Body";
            this.dgr1ColumnContentBody.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr1ColumnContentBody.Name = "dgr1ColumnContentBody";
            this.dgr1ColumnContentBody.DataPropertyName = "ContentBody";
            this.dgr1ColumnContentBody.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr1ColumnContentBody.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr1ColumnContentBody.Width = 180;
            this.dgr1ColumnContentBody.Visible = true;
            this.dgr1ColumnContentBody.DisplayIndex = 4;
            this.dgr1ColumnContentBody.ReadOnly = false;
            this.dgr1ColumnContentBody.Tag = "";
            
            
            
            this.dgr1.Columns.Add(this.dgr1ColumnContentBody);

            this.dgr1ColumnContentFooter.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr1ColumnContentFooter.HeaderText = "Content Footer";
            this.dgr1ColumnContentFooter.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr1ColumnContentFooter.Name = "dgr1ColumnContentFooter";
            this.dgr1ColumnContentFooter.DataPropertyName = "ContentFooter";
            this.dgr1ColumnContentFooter.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr1ColumnContentFooter.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr1ColumnContentFooter.Width = 160;
            this.dgr1ColumnContentFooter.Visible = true;
            this.dgr1ColumnContentFooter.DisplayIndex = 5;
            this.dgr1ColumnContentFooter.ReadOnly = false;
            this.dgr1ColumnContentFooter.Tag = "";
            
            
            
            this.dgr1.Columns.Add(this.dgr1ColumnContentFooter);

            this.dgr2.AllowUserToAddRows = false;
            this.dgr2.AllowUserToDeleteRows = false;
            this.dgr2.ColumnHeadersHeight = 25;
            this.dgr2.Dock = System.Windows.Forms.DockStyle.None;
            this.dgr2.Location = new System.Drawing.Point(620, 129);
            this.dgr2.Name = "dgr2";
            this.dgr2.Enabled = true;
            this.dgr2.Visible = true;
            this.dgr2.MultiSelect = false;
            this.dgr2.ReadOnly = true;
            this.dgr2.ShowRowErrors = false;
            this.dgr2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgr2.Size = new System.Drawing.Size(270, 498);
            this.dgr2.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgr2.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgr2.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgr2.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgr2.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgr2.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgr2.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgr2.TabIndex = 20;
            this.dgr2.Tag = @"";
            this.toolTip1.SetToolTip(this.dgr2, @"");
            this.dgr2.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgr2_DataError);
            this.dgr2.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgr2_RowStateChanged);
            

            this.dgr2ColumnID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgr2ColumnID.HeaderText = "Id";
            this.dgr2ColumnID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnID.Name = "dgr2ColumnID";
            this.dgr2ColumnID.DataPropertyName = "ID";
            this.dgr2ColumnID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnID.Width = 100;
            this.dgr2ColumnID.Visible = false;
            this.dgr2ColumnID.DisplayIndex = 0;
            this.dgr2ColumnID.ReadOnly = false;
            this.dgr2ColumnID.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnID);

            this.dgr2ColumnTemplateID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgr2ColumnTemplateID.HeaderText = "Templateid";
            this.dgr2ColumnTemplateID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnTemplateID.Name = "dgr2ColumnTemplateID";
            this.dgr2ColumnTemplateID.DataPropertyName = "TemplateID";
            this.dgr2ColumnTemplateID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgr2ColumnTemplateID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnTemplateID.Width = 100;
            this.dgr2ColumnTemplateID.Visible = false;
            this.dgr2ColumnTemplateID.DisplayIndex = 1;
            this.dgr2ColumnTemplateID.ReadOnly = false;
            this.dgr2ColumnTemplateID.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnTemplateID);

            this.dgr2ColumnAttachmentPath.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgr2ColumnAttachmentPath.HeaderText = "Attachment";
            this.dgr2ColumnAttachmentPath.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgr2ColumnAttachmentPath.Name = "dgr2ColumnAttachmentPath";
            this.dgr2ColumnAttachmentPath.DataPropertyName = "AttachmentPath";
            this.dgr2ColumnAttachmentPath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgr2ColumnAttachmentPath.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgr2ColumnAttachmentPath.Width = 200;
            this.dgr2ColumnAttachmentPath.Visible = true;
            this.dgr2ColumnAttachmentPath.DisplayIndex = 2;
            this.dgr2ColumnAttachmentPath.ReadOnly = false;
            this.dgr2ColumnAttachmentPath.Tag = "";
            
            
            
            this.dgr2.Columns.Add(this.dgr2ColumnAttachmentPath);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.grpEmailtemplate_Emailtemplateattachment);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.btnContentHeader);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.btnContentBody);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.btnContentFooter);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.btnGenarate);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.btnpreview);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.btn_EditHtml);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.cmbContentHeader);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.cmbContentBody);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.cmbContentFooter);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.cmbSelectMonth);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_TemplateID);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_TemplateName);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_Subject);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_ContentHeader);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_ContentBody);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_ID);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lbl_TemplateID_child);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lblNewLabel1);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.lblNewLabel2);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_TemplateID);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_ID_Child);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_TemplateID_Child);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_TemplateName);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_Subject);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_ContentHeader);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_ContentBody);
            this.grpEmailtemplate_Emailtemplateattachment.Controls.Add(this.txt_ContentFooter);
            this.Controls.Add(this.grpEmailtemplate_EmailtemplateattachmentChild);
            this.grpEmailtemplate_EmailtemplateattachmentChild.Controls.Add(this.lbl_AttachmentPath);
            this.grpEmailtemplate_EmailtemplateattachmentChild.Controls.Add(this.txt_AttachmentPath);
            this.Controls.Add(this.dgr1);
            this.Controls.Add(this.dgr2);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "EmailTemplate";
            this.Text = "Email Template Creation";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(914, 674);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalButton btnAdd;
        private Kushal.Controls.KushalButton btnUpdate;
        private Kushal.Controls.KushalButton btnRemove;
        private Kushal.Controls.KushalGroupBox grpEmailtemplate_Emailtemplateattachment;
        private Kushal.Controls.KushalButton btnContentHeader;
        private Kushal.Controls.KushalButton btnContentBody;
        private Kushal.Controls.KushalButton btnContentFooter;
        private Kushal.Controls.KushalButton btnGenarate;
        private Kushal.Controls.KushalButton btnpreview;
        private Kushal.Controls.KushalButton btn_EditHtml;
        private Kushal.Controls.KushalComboBox cmbContentHeader;
        private Kushal.Controls.KushalComboBox cmbContentBody;
        private Kushal.Controls.KushalComboBox cmbContentFooter;
        private Kushal.Controls.KushalComboBox cmbSelectMonth;
        private Kushal.Controls.KushalLabel lbl_TemplateID;
        private Kushal.Controls.KushalLabel lbl_TemplateName;
        private Kushal.Controls.KushalLabel lbl_Subject;
        private Kushal.Controls.KushalLabel lbl_ContentHeader;
        private Kushal.Controls.KushalLabel lbl_ContentBody;
        private Kushal.Controls.KushalLabel lbl_ID;
        private Kushal.Controls.KushalLabel lbl_TemplateID_child;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private NumericTextBox txt_TemplateID;
        private NumericTextBox txt_ID_Child;
        private NumericTextBox txt_TemplateID_Child;
        private Kushal.Controls.KushalTextBox txt_TemplateName;
        private Kushal.Controls.KushalTextBox txt_Subject;
        private Kushal.Controls.KushalTextBox txt_ContentHeader;
        private Kushal.Controls.KushalTextBox txt_ContentBody;
        private Kushal.Controls.KushalTextBox txt_ContentFooter;
        private Kushal.Controls.KushalGroupBox grpEmailtemplate_EmailtemplateattachmentChild;
        private Kushal.Controls.KushalLabel lbl_AttachmentPath;
        private Kushal.Controls.KushalTextBox txt_AttachmentPath;
        private System.Windows.Forms.DataGridView dgr1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr1ColumnTemplateID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr1ColumnTemplateName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr1ColumnSubject;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr1ColumnContentHeader;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr1ColumnContentBody;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr1ColumnContentFooter;
        private System.Windows.Forms.DataGridView dgr2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnTemplateID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgr2ColumnAttachmentPath;
    }
}