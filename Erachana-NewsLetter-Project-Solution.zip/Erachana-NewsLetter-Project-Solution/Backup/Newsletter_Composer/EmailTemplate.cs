using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class EmailTemplate : Form {
        private DataAdapter dataAdapter;
        private AdminDetails adminDetails = Settings.GetDatabaseAdminDetails();
        private Dictionary<string, string> fieldSqls = new Dictionary<string, string>();
        private string keyField = "TemplateID";
        private string keyFieldChild = "ID";
        private string childTableForeignKey = "TemplateID";
        private List<string> additionalKeys = new List<string>() { };
        private List<string> additionalChildKeys = new List<string>() { "TemplateID" };
        private Dictionary<string, Control> associatedParentControls = new Dictionary<string, Control>();
        private Dictionary<string, Control> associatedChildControls = new Dictionary<string, Control>();
        private Dictionary<string, Control> associatedControls = new Dictionary<string, Control>();
        private Dictionary<string, Control> uniqueControls = new Dictionary<string, Control>();
        private List<string> uniqueColumns = new List<string>() { };
        private Dictionary<string, ColumnValidationInfo> colValidations = new Dictionary<string, ColumnValidationInfo>();
        private bool newRecord = false;
        private bool updateParent = true;
        private bool updatingGrid = false;
        private bool skipIdValueProcessing = false;
        private bool formActivated = false;
        private bool autoIncrementMultiIndex = true;
        private List<string> ExportableColumnNames = new List<string>() { };
        private long dgr_ErrorCount = 0;

        public EmailTemplate() {
            InitializeComponent();
            this.Load += new System.EventHandler(this.EmailTemplate_PreLoad);
            this.Load += new System.EventHandler(this.EmailTemplate_Load);
            this.Load += new System.EventHandler(this.EmailTemplate_PostLoad);
            this.Activated += new System.EventHandler(this.EmailTemplate_Activated);
            DoEventSubscriptions();
            
            associatedControls.Add("EmailTemplateTemplateID", txt_TemplateID);
            associatedControls.Add("EmailTemplateAttachmentID", txt_ID_Child);
            associatedControls.Add("EmailTemplateAttachmentTemplateID", txt_TemplateID_Child);
            associatedControls.Add("EmailTemplateTemplateName", txt_TemplateName);
            associatedControls.Add("EmailTemplateSubject", txt_Subject);
            associatedControls.Add("EmailTemplateContentHeader", txt_ContentHeader);
            associatedControls.Add("EmailTemplateContentBody", txt_ContentBody);
            associatedControls.Add("EmailTemplateContentFooter", txt_ContentFooter);
            associatedControls.Add("EmailTemplateAttachmentAttachmentPath", txt_AttachmentPath);
            
            associatedParentControls.Add("EmailTemplateTemplateID", txt_TemplateID);
            associatedParentControls.Add("EmailTemplateTemplateName", txt_TemplateName);
            associatedParentControls.Add("EmailTemplateSubject", txt_Subject);
            associatedParentControls.Add("EmailTemplateContentHeader", txt_ContentHeader);
            associatedParentControls.Add("EmailTemplateContentBody", txt_ContentBody);
            associatedParentControls.Add("EmailTemplateContentFooter", txt_ContentFooter);
            
            associatedChildControls.Add("EmailTemplateAttachmentID", txt_ID_Child);
            associatedChildControls.Add("EmailTemplateAttachmentTemplateID", txt_TemplateID_Child);
            associatedChildControls.Add("EmailTemplateAttachmentAttachmentPath", txt_AttachmentPath);
            
            uniqueControls.Add("EmailTemplateTemplateID", txt_TemplateID);
            uniqueControls.Add("EmailTemplateAttachmentID", txt_ID_Child);
            
            fieldSqls.Add("cmbContentHeader", "select ID,FieldName from EmailTemplateFields");
            fieldSqls.Add("cmbContentBody", "select ID,FieldName from EmailTemplateFields");
            fieldSqls.Add("cmbContentFooter", "select ID,FieldName from EmailTemplateFields");
            fieldSqls.Add("cmbSelectMonth", "select monthmaster.id, cast(monthmaster.year as nvarchar(4)) + '-' + cast(listmaster.listcode as nvarchar(15)) as expr1, listmaster.listid AS Month, monthmaster.year from monthmaster inner join listmaster on monthmaster.month = listmaster.listid where listmaster.listtypeid = 1");
            
            ControlAdapter.LoadControlDataSource(this.Controls.Cast<Control>().ToList(), fieldSqls);
            ControlAdapter.ProcessDropdownColumns(this.Controls.Cast<Control>().ToList());
            
            
            ControlAdapter.ProcessColumnValidation(this.Controls.Cast<Control>().ToList(), colValidations);
            
            ControlAdapter.DoColumnDuplicatesValidation(dgr1, "dgr1ColumnTemplateID");
            ControlAdapter.DoColumnDuplicatesValidation(dgr2, "dgr2ColumnID");
            ExportableColumnNames = getExportableColumnNames();
        }

        private List<string> getExportableColumnNames() {
            List<string> ExportableColumnList = new List<string>();
            
            ExportableColumnList.Add("dgr1ColumnTemplateID");
            ExportableColumnList.Add("dgr1ColumnTemplateName");
            ExportableColumnList.Add("dgr1ColumnSubject");
            ExportableColumnList.Add("dgr1ColumnContentHeader");
            ExportableColumnList.Add("dgr1ColumnContentBody");
            ExportableColumnList.Add("dgr1ColumnContentFooter");
            ExportableColumnList.Add("dgr2ColumnID");
            ExportableColumnList.Add("dgr2ColumnTemplateID");
            ExportableColumnList.Add("dgr2ColumnAttachmentPath");
            return ExportableColumnList;
        }

        private void printErrorOnlyOnce() {
            if (dgr_ErrorCount > 0) { //DataGridViewComboBoxCell value is not valid
                MessageBox.Show("Some of the columns in the Grid could have problem with it's SQL statement.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dgr_ErrorCount = 0;
            }
        }
        
        

        public object gFilePath { get; set; }
        public object gIsfile { get; set; }
        private void EmailTemplate_PreLoad(object sender, EventArgs e) {
            
        }

        private void EmailTemplate_Load(object sender, EventArgs e) {
            LoadData();
        }

        private void EmailTemplate_PostLoad(object sender, EventArgs e) {
            Load_Fun();
        }

        private void EmailTemplate_Activated(object sender, EventArgs e) {
            if (formActivated == false) {
                ControlAdapter.RaiseClick(btnNew);
                ControlAdapter.RaiseClick(btnAdd);
            }
            formActivated = true;
        }

        private void DoEventSubscriptions() {
            
            this.btnNew.Click += this.btnNew_Click;
            this.btnSave.Click += this.btnSave_Click;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Evaluate_Click);
            this.btnDelete.Click += this.btnDelete_Click;
            this.btnClose.Click += this.btnClose_Click;
            this.btnAdd.Click += this.btnAdd_Click;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Evaluate_Click);
            this.btnUpdate.Click += this.btnUpdate_Click;
            this.btnRemove.Click += this.btnRemove_Click;
            this.btnContentHeader.Click += new System.EventHandler(this.btnContentHeader_Evaluate_Click);
            this.btnContentBody.Click += new System.EventHandler(this.btnContentBody_Evaluate_Click);
            this.btnContentFooter.Click += new System.EventHandler(this.btnContentFooter_Evaluate_Click);
            this.btnGenarate.Click += new System.EventHandler(this.btnGenarate_Evaluate_Click);
            this.btnpreview.Click += new System.EventHandler(this.btnpreview_Evaluate_Click);
            this.btn_EditHtml.Click += new System.EventHandler(this.btn_EditHtml_Evaluate_Click);
            this.txt_TemplateID.TextChanged += this.txt_TemplateID_TextChanged;
        }
        #region Event Handers
        
        private void btnSave_Evaluate_Click(Object sender, EventArgs e) {
            PostSave_Update();
        }
        private void btnAdd_Evaluate_Click(Object sender, EventArgs e) {
            Add_File();
        }
        private void btnContentHeader_Evaluate_Click(Object sender, EventArgs e) {
            AppendContentHeader();
        }
        private void btnContentBody_Evaluate_Click(Object sender, EventArgs e) {
            AppendContentBody();
        }
        private void btnContentFooter_Evaluate_Click(Object sender, EventArgs e) {
            AppendContentFooter();
        }
        private void btnGenarate_Evaluate_Click(Object sender, EventArgs e) {
            Month_Validate();
            Generate_Report();
        }
        private void btnpreview_Evaluate_Click(Object sender, EventArgs e) {
            Preview_Function();
        }
        private void btn_EditHtml_Evaluate_Click(Object sender, EventArgs e) {
            Edit_Html();
        }
        private void EmailTemplate_Evaluate_Load(Object sender, EventArgs e) {
            Load_Fun();
        }
        private void btnNew_Click(object sender, EventArgs e) {
            
            ControlAdapter.BeginNewItem_Id(associatedControls, "EmailTemplate" + keyField, additionalKeys, "EmailTemplate", true, dataAdapter);
            this.newRecord = true;
            dgr1.ClearSelection();
            dataAdapter.Clear("EmailTemplateAttachment");
            DataTable dt1 = dataAdapter.LoadData("select * from [EmailTemplateAttachment] WHERE 0=1", "EmailTemplateAttachment");
            if (dt1 != null) {
                dgr2.DataSource = dt1;
            }
            
        }
        private void btnSave_Click(object sender, EventArgs e) {
            
            bool result = Save_btnSave();
            if (result) {
                AutoClosingMessageBox.Show("Data saved successfully", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information, 2000);
            }
        }

        private bool Save_btnSave() {
            bool result = true;
            updatingGrid = true;
            try {
                
            result = result && PreSaveValidation();
                result = result && ValidateParentInput();
                
                
                result = result && Save();
                
            } finally {
                updatingGrid = false;
            }
            return result;
        }
        private void btnDelete_Click(object sender, EventArgs e) {
            
            Delete_btnDelete();
        }

        private bool Delete_btnDelete() {
            bool result = true;
            
            result = result && PreDelete();
            result = result && Delete();
            
            return result;
        }
        private void btnClose_Click(object sender, EventArgs e) {
            if (newRecord && ControlAdapter.IsControlValueSet(associatedControls, keyField, keyFieldChild)) {
                if (MessageBox.Show("Some of the controls in the form have their value set. Do you want to save values ?", "Save", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) {
                    return;
                }
            }
            if (newRecord == false && dgr1.SelectedRows.Count > 0) {
                object rowView = dgr1.SelectedRows[0].DataBoundItem;
                if (rowView != null && rowView is DataRowView) {
                    if (ControlAdapter.IsControlValueChanged(associatedControls, ((DataRowView)rowView).Row, true)) {
                        if (MessageBox.Show("Some of the controls in the form have their value set. Do you want to save values ?", "Save", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) {
                            return;
                        }
                    }
                }
            }
            if (newRecord == false && dgr2.SelectedRows.Count > 0) {
                object rowView = dgr2.SelectedRows[0].DataBoundItem;
                if (rowView != null && rowView is DataRowView) {
                    if (ControlAdapter.IsControlValueChanged(associatedControls, ((DataRowView)rowView).Row, true)) {
                        if (MessageBox.Show("Some of the controls in the form have their value set. Do you want to save values ?", "Save", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) {
                            return;
                        }
                    }
                }
            }
            this.Close();
        }
        private void btnAdd_Click(object sender, EventArgs e) {
            object val = ControlAdapter.GetValue(associatedControls["EmailTemplate" + keyField]);
            dgr2.ClearSelection();
            ControlAdapter.SetValue(associatedControls["EmailTemplateAttachment" + childTableForeignKey], val);
            ControlAdapter.BeginNewItemChild_Id(associatedControls, "EmailTemplateAttachment" + keyFieldChild, additionalChildKeys, "EmailTemplateAttachment", true, dataAdapter);
            ControlAdapter.SetValue(associatedControls["EmailTemplateAttachment" + childTableForeignKey], val);
        }
        private void btnUpdate_Click(object sender, EventArgs e) {
            bool result = Update_btnUpdate();
            if (result) {
                AutoClosingMessageBox.Show("Data saved successfully", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information, 2000);
            }
        }

        private bool Update_btnUpdate() {
            bool result = true;
            updatingGrid = true;
            try {
                
            result = result && PreSaveValidation();
            result = result && PreUpdateValidation();
                result = result && ValidateParentInput();
                result = result && ValidateChildInput();
                
                
                result = result && UpdateChildGrid();
                
            } finally {
                updatingGrid = false;
            }
            return result;
        }
        private void btnRemove_Click(object sender, EventArgs e) {
            Remove_btnRemove();
        }

        private bool Remove_btnRemove() {
            bool result = true;
            
            result = result && PreRemove();
            result = result && Remove();
            
            return result;
        }
        private void dgr1_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e) {
            if (e.StateChanged != DataGridViewElementStates.Selected)
                return;
            if (updatingGrid)
                return;
            DataTable parentTable = (DataTable)dgr1.DataSource;
            string idVal = ControlAdapter.GetTextValue(associatedControls[parentTable.TableName + keyField]);
            if (dgr1.SelectedRows != null && dgr1.SelectedRows.Count > 0) {
                this.newRecord = false;
                // Set input values
                int rowIndex = dgr1.SelectedRows[0].Index;
                ControlAdapter.SetRowValuesToControls(associatedControls, dgr1, parentTable.TableName);
                idVal = Convert.ToString(dgr1["dgr1ColumnTemplateID", rowIndex].Value);
                printErrorOnlyOnce();
            }
            
            
            dataAdapter.Clear("EmailTemplateAttachment");
            DataTable dt1 = dataAdapter.LoadData(String.Format("select * from [EmailTemplateAttachment] WHERE TemplateID={0}", idVal), "EmailTemplateAttachment");
            if (dt1 != null) {
                dgr2.DataSource = dt1;
            }
        }


        private void dgr1_DataError(object sender, DataGridViewDataErrorEventArgs e) {
            if (!e.Exception.Message.Contains("DataGridViewComboBoxCell value is not valid")) {
                MessageBox.Show(e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                dgr_ErrorCount++;
            }
            e.Cancel = true;
        }
        private void dgr2_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e) {
            if (e.StateChanged != DataGridViewElementStates.Selected)
                return;
            if (updatingGrid)
                return;
            DataTable parentTable = (DataTable)dgr2.DataSource;
            string idVal = ControlAdapter.GetTextValue(associatedControls[parentTable.TableName + keyFieldChild]);
            if (dgr2.SelectedRows != null && dgr2.SelectedRows.Count > 0) {
                this.newRecord = false;
                // Set input values
                int rowIndex = dgr2.SelectedRows[0].Index;
                ControlAdapter.SetRowValuesToControls(associatedControls, dgr2, parentTable.TableName);
                
                printErrorOnlyOnce();
            }
            else {
                ClearChildControls(parentTable);
            }
            
        }
        private void ClearChildControls(DataTable parentTable) {
            foreach (DataGridViewColumn col in dgr2.Columns) {
                if (associatedControls.ContainsKey(parentTable.TableName + col.DataPropertyName)) {
                    ControlAdapter.ResetControl(associatedControls[parentTable.TableName + col.DataPropertyName]);
                }
            }
        }

        private void dgr2_DataError(object sender, DataGridViewDataErrorEventArgs e) {
            if (!e.Exception.Message.Contains("DataGridViewComboBoxCell value is not valid")) {
                MessageBox.Show(e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                dgr_ErrorCount++;
            }
            e.Cancel = true;
        }

        private void txt_TemplateID_TextChanged(object sender, EventArgs e) {
            ProcessIdValueChange(sender);
        }
        #endregion
        private bool LoadData() {
            return LoadData(true);
        }
        private bool LoadData(bool showMessage) {
            try {
                
                dataAdapter = DataAdapter.Current;
                DataTable dt0 = dataAdapter.LoadData("select * from [EmailTemplate]", "EmailTemplate");
                if (dt0 != null) {
                    dgr1.DataSource = dt0;
                }

                dataAdapter = DataAdapter.Current;
                DataTable dt1 = dataAdapter.LoadData("select * from [EmailTemplateAttachment]", "EmailTemplateAttachment");
                if (dt1 != null) {
                    dgr2.DataSource = dt1;
                }

            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private bool Save() {
            return Save(true);
        }
        private bool Save(bool showMessage) {
            bool status = true;
            dgr1.RowStateChanged -= new DataGridViewRowStateChangedEventHandler(dgr1_RowStateChanged);
            try {
                if (newRecord) {
                    int rowcount = dgr1.Rows.Count;
                    status = AddNewRecord(showMessage);
                    
                    if (status) {
                        newRecord = false;
                    }
                } else {
                    status = UpdateSelectedParentRecord();
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                status = false;
            }
            dgr1.RowStateChanged += new DataGridViewRowStateChangedEventHandler(dgr1_RowStateChanged);
            return status;
        }

        private bool ValidateParentInput() {
            bool isValid = ControlAdapter.ValidateInput(true, newRecord, associatedParentControls, uniqueControls, additionalKeys, "EmailTemplate", dataAdapter, dgr1);
            if (isValid == false)
                return false;
            return true;
        }

        private bool ValidateChildInput() {
            bool isValid = ControlAdapter.ValidateInput(true, newRecord, associatedChildControls, uniqueControls, additionalKeys, "EmailTemplateAttachment", dataAdapter, dgr2);
            if (isValid == false)
                return false;
            return true;
        }

        private bool AddNewRecord(bool showMessage) {
            DataTable table = (DataTable)dgr1.DataSource;
            if (autoIncrementMultiIndex) {
                if (associatedControls.ContainsKey(table.TableName + keyField) && associatedControls[table.TableName + keyField] is NumericTextBox) {
                    NumericTextBox txt = (NumericTextBox)associatedControls[table.TableName + keyField];
                    bool exists = ControlAdapter.IsIdValueExists(txt.Value.Value, keyField, table.TableName, dataAdapter);
                    if (exists) {
                        int max = ControlAdapter.GetMaxValue(associatedControls, keyField, additionalKeys, table.TableName, false, dataAdapter);
                        if (txt.Value.Value <= max) {
                            skipIdValueProcessing = true;
                            txt.Value = max + 1;
                            MessageBox.Show("Same or greater value found for " + keyField + ". Hence it is automatically set to " + (max + 1), "New value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            skipIdValueProcessing = false;
                        }
                    }
                }
            }
            List<object> vals = new List<object>();
            foreach (DataColumn col in table.Columns) {
                object val = null;
                if (associatedControls.ContainsKey(table.TableName + col.ColumnName)) {
                    val = ControlAdapter.GetValue(associatedControls[table.TableName + col.ColumnName]);
                }
                vals.Add(val);
            }
            DataRow newRow = table.Rows.Add(vals.ToArray());
            // Update database
            try {
                int result = dataAdapter.Update(table.TableName);
                if (result < 0) {
                    table.RejectChanges();
                    return false;
                }
                foreach (DataGridViewRow gridRow in dgr1.Rows) {
                    DataRowView dataRowView = (DataRowView)gridRow.DataBoundItem;
                    DataRow row = dataRowView.Row;
                    if (row == newRow) {
                        gridRow.Selected = true;
                        break;
                    }
                }
            } catch (Exception e) {
                if (showMessage)
                    MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                table.RejectChanges();
                return false;
            }
            return true;
        }

        private bool UpdateSelectedParentRecord() {
            return UpdateSelectedParentRecord(true);
        }

        private bool UpdateSelectedParentRecord(bool showMessage) {
            try {
                if (dgr1.SelectedRows != null && dgr1.SelectedRows.Count > 0) {
                    DataTable table = (DataTable)dgr1.DataSource;
                    // Assign data source values
					int selectedIndex = dgr1.SelectedRows[0].Index;
                    DataRow row = (dgr1.SelectedRows[0].DataBoundItem as DataRowView).Row;
                    int rowIndex = table.Rows.IndexOf(row);
                    foreach (DataColumn col in table.Columns) {
                        object val = null;
                        if (associatedControls.ContainsKey(table.TableName + col.ColumnName)) {
                            val = ControlAdapter.GetValue(associatedControls[table.TableName + col.ColumnName]);
                        }
                        table.Rows[rowIndex][col.ColumnName] = (val == null ? DBNull.Value : val);
                    }
                    // Update database
                    int rowsUpdated = dataAdapter.Update(table.TableName);
                    dgr1.Rows[selectedIndex].Selected = true;
                    if (rowsUpdated < 0) {
                        table.RejectChanges();
                        return false;
                    }
                } else {
                    if (showMessage)
                        MessageBox.Show("No rows found selected to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool UpdateChildRecord(bool showMessage) {
            try {
                DataTable childTable = (DataTable)dgr2.DataSource;
                object idValue = ControlAdapter.GetIdFieldValue(associatedControls, "EmailTemplate" + keyField);
                // Set parent Id values
                foreach (DataColumn column in childTable.Columns) {
                    if (column.ColumnName == childTableForeignKey) {
                        // last row is added automatically
                        for (int i = 0; i < childTable.Rows.Count; i++ ) {
                            DataRow row = childTable.Rows[i];
                            row[column.ColumnName] = idValue;
                        }
                        break;
                    }
                }
                int selectedIndex = dgr2.SelectedRows[0].Index;
                int rowsUpdated = dataAdapter.Update(childTable.TableName);
                dgr2.Rows[selectedIndex].Selected = true;
                if (rowsUpdated < 0) {
                    return false;
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Errpr", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        public bool UpdateChildGrid() {
            bool status = true;
            if (newRecord && updateParent) {
                status = AddNewRecord(true);
                if (status) {
                    newRecord = false;
                }
            }
            status = status && UpdateChild();
            if (status && newRecord == false && updateParent) {
                status = UpdateParent();
            }
            return status;
        }

        public bool UpdateChild() {
            return UpdateChild(true);
        }

        public bool UpdateChild(bool showMessage) {
            try {
                int rowIndex = 0;
                if (dgr2.SelectedRows != null && dgr2.SelectedRows.Count > 0) {
                    rowIndex = dgr2.SelectedRows[0].Index;
                    bool success = SaveSelectedChildRecord(showMessage);
                    if (success == false)
                        return false;
                } else {
                    bool success = AddNewChildRecord(showMessage);
                    if (success == false)
                        return false;
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        public bool UpdateParent() {
            return UpdateParent(true);
        }

        public bool UpdateParent(bool showMessage) {
            bool status = true;
            try {
                status = status && UpdateSelectedParentRecord();
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return status;
        }

        private bool AddNewChildRecord() {
            return AddNewChildRecord(true);
        }

        private bool AddNewChildRecord(bool showMessage) {
            DataTable table = (DataTable)dgr2.DataSource;
            object parentKeyVal = ControlAdapter.GetValue(associatedControls["EmailTemplate" + keyField]);
            ControlAdapter.SetValue(associatedControls["EmailTemplateAttachment" + childTableForeignKey], parentKeyVal);
            // Assign data source values
            dgr2.RowStateChanged -= new DataGridViewRowStateChangedEventHandler(dgr2_RowStateChanged);
            DataRow row = table.Rows.Add();
            dgr2.RowStateChanged += new DataGridViewRowStateChangedEventHandler(dgr2_RowStateChanged);
            foreach (DataColumn col in table.Columns) {
                object val = null;
                if (associatedControls.ContainsKey(table.TableName + col.ColumnName)) {
                    val = ControlAdapter.GetValue(associatedControls[table.TableName + col.ColumnName]);
                }
                row[col.ColumnName] = (val == null ? DBNull.Value : val);
            }
            // Update database
            try {
                int result = dataAdapter.Update(table.TableName);
                if (result < 0) {
                    table.RejectChanges();
                    return false;
                }
                dgr2.DataSource = table;
                foreach (DataGridViewRow gridRow in dgr2.Rows) {
                    DataRowView dataRowView = (DataRowView)gridRow.DataBoundItem;
                    DataRow r = dataRowView.Row;
                    if (r == row) {
                        gridRow.Selected = true;
                        break;
                    }
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool SaveSelectedChildRecord() {
            return SaveSelectedChildRecord(true);
        }

        private bool SaveSelectedChildRecord(bool showMessage) {
            DataTable table = (DataTable)dgr2.DataSource;
            // Assign data source values
            DataRow row = (dgr2.SelectedRows[0].DataBoundItem as DataRowView).Row;
            int rowIndex = table.Rows.IndexOf(row);
            foreach (DataColumn col in table.Columns) {
                object val = null;
                if (associatedControls.ContainsKey(table.TableName + col.ColumnName)) {
                    val = ControlAdapter.GetValue(associatedControls[table.TableName + col.ColumnName]);
                }
                table.Rows[rowIndex][col.ColumnName] = (val == null ? DBNull.Value : val);
            }

            // Update database
            try {
                int rowsUpdated = dataAdapter.Update(table.TableName);
                if (rowsUpdated < 0) {
                    table.RejectChanges();
                    return false;
                }
                foreach (DataGridViewRow gridRow in dgr2.Rows) {
                    DataRowView dataRowView = (DataRowView)gridRow.DataBoundItem;
                    DataRow r = dataRowView.Row;
                    if (r == row) {
                        gridRow.Selected = true;
                        break;
                    }
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool Delete() {
            return Delete(true);
        }

        private bool Delete(bool showMessage) {
            try {
                if (dgr1.SelectedRows != null && dgr1.SelectedRows.Count > 0) {
                    DialogResult dialogResult = DialogResult.OK;
                    if (showMessage) {
                        dialogResult = MessageBox.Show("Do you really want to delete this row?", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                        if (dialogResult != DialogResult.OK)
                            return false;
                    }
                    if (dialogResult == DialogResult.OK) {
                        DeleteChildGridValues(showMessage);
                        DeleteParentGridValues(showMessage);
                        // Clear child grid if there are not parent rows
                        if (dgr1.Rows.Count == 0) {
                            dataAdapter.Clear("EmailTemplateAttachment");
                            DataTable dt1 = dataAdapter.LoadData("select * from [EmailTemplateAttachment] WHERE TemplateID=2147483647", "EmailTemplateAttachment");
                            if (dt1 != null) {
                                dgr2.DataSource = dt1;
                            }
                        }
                    }
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool DeleteChildGridValues(bool showMessages) {
            try {
                DataTable childTable = (DataTable)dgr2.DataSource;
                foreach (DataGridViewColumn column in dgr2.Columns) {
                    if (column.DataPropertyName == childTableForeignKey) {
                        if (dgr2.Rows.Count > 0) {
                            foreach (DataGridViewRow row in dgr2.Rows) {
                                if (row.Cells[column.Name].Value != null && row.Cells[column.Name].Value != DBNull.Value) {
                                    dataAdapter.DeleteRow(childTable, Convert.ToString(row.Cells[column.Name].Value), childTableForeignKey);
                                }
                            }
                            childTable.AcceptChanges();
                        }
                        break;
                    }
                }
            } catch (Exception exc) {
                if (showMessages)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool DeleteParentGridValues(bool showMessage) {
            try {
                DataTable table = (DataTable)dgr1.DataSource;
                foreach (DataGridViewColumn column in dgr1.Columns) {
                    if (column.DataPropertyName == keyField) {
                        dataAdapter.DeleteRow(table, Convert.ToString(dgr1.SelectedRows[0].Cells[column.Name].Value), keyField);
                        dgr1.Rows.RemoveAt(dgr1.SelectedRows[0].Index);
                        table.AcceptChanges();
                        break;
                    }
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool Remove() {
            return Remove(true);
        }

        private bool Remove(bool showMessage) {
            bool status = true;
            DataTable table = (DataTable)dgr2.DataSource;
            if (dgr2.SelectedCells != null && dgr2.SelectedCells.Count > 0) {
                DialogResult dialogResult = DialogResult.OK;
                if (showMessage) {
                    dialogResult = MessageBox.Show("Do you really want to remove this row ?", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    if (dialogResult != DialogResult.OK)
                        return false;
                }
                if (dialogResult == DialogResult.OK) {
                    try {
                        Dictionary<string, string> values = new Dictionary<string, string>();
                        DataGridViewRow row = dgr2.Rows[dgr2.SelectedCells[0].RowIndex];
                        string col1 = ControlAdapter.GetColumnName(dgr2, keyFieldChild);
                        if (String.IsNullOrEmpty(col1) == false) {
                            values.Add(keyFieldChild, Convert.ToString(row.Cells[col1].Value));
                        }
                        string col2 = ControlAdapter.GetColumnName(dgr2, childTableForeignKey);
                        if (String.IsNullOrEmpty(col2) == false) {
                            values.Add(childTableForeignKey, Convert.ToString(row.Cells[col2].Value));
                        }
                        dataAdapter.DeleteRow(table, values, new List<string>() { keyFieldChild, childTableForeignKey });
                        int rowIndex = dgr2.SelectedCells[0].RowIndex;
                        dgr2.Rows.RemoveAt(rowIndex);
                        table.AcceptChanges();
                        if (newRecord == false && updateParent) {
                            
                            status = status && UpdateSelectedParentRecord();
                        }
                        if (dgr2.Rows.Count > rowIndex) {
                            dgr2.Rows[rowIndex].Selected = true;
                        }
                    } catch (Exception exc) {
                        if (showMessage)
                            MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            return status;
        }

        private bool ProcessIdValueChange(object control) {
            return ProcessIdValueChange(control, true);
        }

        private bool ProcessIdValueChange(object control, bool showMessage) {
            try {
                if (skipIdValueProcessing)
                    return true;
                string text = ((TextBox)control).Text;
                if (String.IsNullOrEmpty(text))
                    return false;
                int val = Convert.ToInt32(text);
                DataTable table = (DataTable)dgr1.DataSource;
                foreach (DataGridViewRow row in dgr1.Rows) {
                    foreach (DataGridViewCell cell in row.Cells) {
                        if ((dgr1.Columns[cell.ColumnIndex].DataPropertyName == keyField) && Convert.ToInt32(cell.Value) == val) {
                            row.Selected = true;
                            return true;
                        }
                    }
                }
                newRecord = true;
                dgr1.ClearSelection();
                ControlAdapter.ResetControls(associatedControls, "EmailTemplate" + keyField);
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void ReloadData(ListControl listControl) {
            if (fieldSqls.ContainsKey(listControl.Name)) {
                DataTable dt = DataAdapter.Current.LoadData(fieldSqls[listControl.Name], "datasource" + listControl.Name);
                if (dt != null) {
                    listControl.ValueMember = dt.Columns[0].ColumnName;
                    listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    listControl.DataSource = dt;
                }
            }
        }
    }
}
