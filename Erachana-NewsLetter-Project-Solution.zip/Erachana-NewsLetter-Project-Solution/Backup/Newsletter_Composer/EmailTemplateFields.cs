using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class EmailTemplateFields : Form {
        private DataAdapter dataAdapter;
        private AdminDetails adminDetails = Settings.GetDatabaseAdminDetails();
        private Dictionary<string, string> fieldSqls = new Dictionary<string, string>();
        private string keyField = "ID";
        private string keyFieldChild = "";
        private string childTableForeignKey = "";
        private List<string> additionalKeys = new List<string>() { };
        private Dictionary<string, Control> associatedControls = new Dictionary<string, Control>();
        private Dictionary<string, Control> uniqueControls = new Dictionary<string, Control>();
        private List<string> uniqueColumns = new List<string>() { };
        private Dictionary<string, ColumnValidationInfo> colValidations = new Dictionary<string, ColumnValidationInfo>();
        private bool newRecord = false;
        private bool updateParent = true;
        private bool deleteChildNodes = false;
        private bool skipIdValueProcessing = false;
        private bool formActivated = false;
        private bool autoIncrementMultiIndex = true;
        private List<string> ExportableColumnNames = new List<string>() { };
        private long dgr_ErrorCount = 0;

        public EmailTemplateFields() {
            InitializeComponent();
            this.Load += new System.EventHandler(this.EmailTemplateFields_PreLoad);
            this.Load += new System.EventHandler(this.EmailTemplateFields_Load);
            this.Load += new System.EventHandler(this.EmailTemplateFields_PostLoad);
            this.Activated += new System.EventHandler(this.EmailTemplateFields_Activated);
            DoEventSubscriptions();
            
            associatedControls.Add("ID", txt_Id);
            associatedControls.Add("FieldName", txt_FieldName);
            
            uniqueControls.Add("EmailTemplateFieldsID", txt_Id);
            
            ControlAdapter.DoColumnDuplicatesValidation(dgrData, "dgrDataColumnId");
            
            
            ControlAdapter.LoadControlDataSource(this.Controls.Cast<Control>().ToList(), fieldSqls);
            ControlAdapter.ProcessDropdownColumns(this.Controls.Cast<Control>().ToList());
            
            
            ControlAdapter.ProcessColumnValidation(this.Controls.Cast<Control>().ToList(), colValidations);
            ExportableColumnNames = getExportableColumnNames();
        }

        private List<string> getExportableColumnNames() {
            List<string> ExportableColumnList = new List<string>();
            
            ExportableColumnList.Add("dgrDataColumnId");
            ExportableColumnList.Add("dgrDataColumnFieldName");
            return ExportableColumnList;
        }

        private void printErrorOnlyOnce() {
            if (dgr_ErrorCount > 0) { //DataGridViewComboBoxCell value is not valid
                MessageBox.Show("Some of the columns in the Grid could have problem with it's SQL statement.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dgr_ErrorCount = 0;
            }
        }
        
        

        private void EmailTemplateFields_PreLoad(object sender, EventArgs e) {
            
        }
        private void EmailTemplateFields_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void EmailTemplateFields_PostLoad(object sender, EventArgs e) {
            
        }
        private void EmailTemplateFields_Activated(object sender, EventArgs e) {
            if (formActivated == false) {
                ControlAdapter.RaiseClick(btnNew);
            }
            formActivated = true;
        }
        private void DoEventSubscriptions() {
            
            this.btnNew.Click += this.btnNew_Click;
            this.btnSave.Click += this.btnSave_Click;
            this.btnDelete.Click += this.btnDelete_Click;
            this.btnClose.Click += this.btnClose_Click;
            this.txt_Id.TextChanged += this.txt_Id_TextChanged;
        }
        #region Event Handers
        
        private void btnNew_Click(object sender, EventArgs e) {
            
            ControlAdapter.BeginNewItem_Id(associatedControls, keyField, additionalKeys, "EmailTemplateFields", false, dataAdapter);
            this.newRecord = true;
            dgrData.ClearSelection();
        }
        private void btnSave_Click(object sender, EventArgs e) {
            
            bool result = Save_btnSave();
            if (result) {
                AutoClosingMessageBox.Show("Data saved successfully", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information, 2000);
            }
        }

        private bool Save_btnSave() {
            bool result = true;
            
            result = result && ValidateInput();
            
            
            result = result && Save(null);
            
            return result;
        }
        private void btnDelete_Click(object sender, EventArgs e) {
            Delete_btnDelete();
        }

        private bool Delete_btnDelete() {
            bool result = true;
            
            result = result && Delete(null);
            
            return result;
        }
        private void btnClose_Click(object sender, EventArgs e) {
            if (newRecord && ControlAdapter.IsControlValueSet(associatedControls, keyField, keyFieldChild)) {
                if (MessageBox.Show("Some of the controls in the form have their value set. Do you want to save values ?", "Save", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) {
                    return;
                }
            }

            if (newRecord == false && dgrData.SelectedRows.Count > 0) {
                object rowView = dgrData.SelectedRows[0].DataBoundItem;
                if (rowView != null && rowView is DataRowView) {
                    if (ControlAdapter.IsControlValueChanged(associatedControls, ((DataRowView)rowView).Row)) {
                        if (MessageBox.Show("Some of the controls in the form have their value set. Do you want to save values ?", "Save", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) {
                            return;
                        }
                    }
                }
            }

            this.Close();
        }
        private void dgrData_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e) {
            if (e.StateChanged != DataGridViewElementStates.Selected)
                return;
            if (dgrData.SelectedRows != null && dgrData.SelectedRows.Count > 0) {
                this.newRecord = false;
                // Set input values
                ControlAdapter.SetRowValuesToControls(associatedControls, dgrData, "");
            }
            printErrorOnlyOnce();
        }
        private void dgrData_DataError(object sender, DataGridViewDataErrorEventArgs e) {
            if (!e.Exception.Message.Contains("DataGridViewComboBoxCell value is not valid")) {
                MessageBox.Show(e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                dgr_ErrorCount++;
            }
            e.Cancel = true;
        }
        private void txt_Id_TextChanged(object sender, EventArgs e) {
            ProcessIdValueChange(sender);
        }
        
        #endregion

        private bool LoadData() {
            return LoadData(true);
        }

        private bool LoadData(bool showMessage) {
            try {
                
                dataAdapter = DataAdapter.Current;
                DataTable dt = dataAdapter.LoadData("select * from [EmailTemplateFields]", "EmailTemplateFields");
                if (dt != null) {
                    dgrData.DataSource = dt;
                }

            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        
        #region Save
        private bool Save(TreeLoadInfo loadInfo) {
            return Save(loadInfo, true);
        }

        private bool Save(TreeLoadInfo loadInfo, bool showMessage) {
            try {
                if (newRecord) {
                    int rowcount = dgrData.Rows.Count;
                    bool success = AddNewRecord(loadInfo);
                    if (success == false && rowcount < dgrData.Rows.Count) {
                        dgrData.Rows.RemoveAt(dgrData.Rows.Count - 1);
                    }
                    if (success == false)
                        return false;
                } else {
                    bool success = UpdateSelectedRecord(showMessage);
                    if (success == false)
                        return false;
                }
                if (loadInfo != null) {
                    ControlAdapter.LoadTreeView(loadInfo.TreeView, loadInfo.TableName, loadInfo.IdField, loadInfo.KeyField, loadInfo.ParentKeyField, loadInfo.DisplayTextField);
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool ValidateInput() {
            bool isValid = ControlAdapter.ValidateInput(true, newRecord, associatedControls, uniqueControls, additionalKeys, "EmailTemplateFields", dataAdapter, dgrData);
            if (isValid == false)
                return false;
            return true;
        }

        private bool AddNewRecord(TreeLoadInfo loadInfo) {
            DataTable dt = (DataTable)dgrData.DataSource;
            DataTable table = dataAdapter.GetTable(dt.TableName);
            if (table == null)
                return false;
            if (autoIncrementMultiIndex) {
                if (associatedControls.ContainsKey(keyField) && associatedControls[keyField] is NumericTextBox) {
                    NumericTextBox txt = (NumericTextBox)associatedControls[keyField];
                    bool exists = ControlAdapter.IsIdValueExists(txt.Value.Value, keyField, table.TableName, dataAdapter);
                    if (exists) {
                        int max = ControlAdapter.GetMaxValue(associatedControls, keyField, additionalKeys, table.TableName, false, dataAdapter);
                        if (txt.Value.Value <= max) {
                            skipIdValueProcessing = true;
                            txt.Value = max + 1;
                            MessageBox.Show("Same or greater value found for " + keyField + ". Hence it is automatically set to " + (max + 1), "New value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            skipIdValueProcessing = false;
                        }
                    }
                }
            }
            if (loadInfo != null) {
                SetKeyField(loadInfo);
            }
            List<object> vals = new List<object>();
            foreach (DataColumn column in table.Columns) {
                object val = null;
                if (associatedControls.ContainsKey(column.ColumnName)) {
                    val = ControlAdapter.GetValue(associatedControls[column.ColumnName]);
                }
                vals.Add(val);
            }
            DataRow newRow = table.Rows.Add(vals.ToArray());

            // Update database
            try {
                int result = dataAdapter.Update(table.TableName);
                if (result < 0) {
                    return false;
                }
                dgrData.DataSource = table;
                foreach (DataGridViewRow gridRow in dgrData.Rows) {
                    DataRowView dataRowView = (DataRowView)gridRow.DataBoundItem;
                    DataRow row = dataRowView.Row;
                    if (row == newRow) {
                        gridRow.Selected = true;
                        break;
                    }
                }
            } catch (Exception e) {
                MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void SetKeyField(TreeLoadInfo loadInfo) {
            string parentKeyFieldValue = (string)ControlAdapter.GetValue(loadInfo.ParentKeyFieldControl);
            object value = GetNextKeyValue(loadInfo.KeyField, parentKeyFieldValue);
            ControlAdapter.SetValue(loadInfo.KeyFieldControl, value);
        }

        private string GetNextKeyValue(string keyField, string parentKeyField) {
            if (parentKeyField == null) {
                parentKeyField = string.Empty;
            }
            int maxVal = 0;
            List<string> keys = new List<string>();
            DataAdapter.Current.Clear("GetNextKeyValue");
            DataTable dt = DataAdapter.Current.LoadData("select * from [EmailTemplateFields]", "GetNextKeyValue");
            if (dt != null) {
                foreach (DataRow row in dt.Rows) {
                    string key = (string)row[keyField];
                    if (String.IsNullOrEmpty(parentKeyField) || key.StartsWith(parentKeyField)) {
                        keys.Add(key);
                    }
                }
            }
            if (keys.Count > 0) {
                List<int> existingVals = new List<int>();
                int index = parentKeyField.Trim("|".ToCharArray()).Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Length;
                foreach (string key in keys) {
                    string[] vals = key.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    if (vals.Length > index) {
                        existingVals.Add(Convert.ToInt32(vals[index]));
                    }
                }
                if (existingVals.Count > 0) {
                    maxVal = existingVals.Max() + 1;
                }
            }
            string nextId = maxVal.ToString().PadLeft(3, '0');
            if (String.IsNullOrEmpty(parentKeyField) == false) {
                nextId = parentKeyField + "|" + nextId;
            }
            return nextId;
        }

        private bool UpdateSelectedRecord(bool showMessage) {
            try {
                if (dgrData.SelectedRows != null && dgrData.SelectedRows.Count > 0) {
                    DataTable table = (DataTable)dgrData.DataSource;
                    // Assign data source values
                    DataRow row = (dgrData.SelectedRows[0].DataBoundItem as DataRowView).Row;
                    int rowIndex = table.Rows.IndexOf(row);
                    foreach (DataColumn column in table.Columns) {
                        object val = null;
                        if (associatedControls.ContainsKey(column.ColumnName)) {
                            val = ControlAdapter.GetValue(associatedControls[column.ColumnName]);
                        }
                        table.Rows[rowIndex][column.ColumnName] = (val == null ? DBNull.Value : val);
                    }
                    // Update database
                    int rowsUpdated = dataAdapter.Update(table.TableName);
                    if (rowsUpdated < 0) {
                        table.RejectChanges();
                        return false;
                    }
                    dgrData.DataSource = table;
                    foreach (DataGridViewRow gridRow in dgrData.Rows) {
                        DataRowView dataRowView = (DataRowView)gridRow.DataBoundItem;
                        DataRow r = dataRowView.Row;
                        if (row == r) {
                            gridRow.Selected = true;
                            break;
                        }
                    }
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion

        #region Delete
        private bool Delete(TreeLoadInfo loadInfo) {
            return Delete(loadInfo, true);
        }

        private bool Delete(TreeLoadInfo loadInfo, bool showMessage) {
            try {
                if (loadInfo != null && loadInfo.TreeView.SelectedNode == null) {
                    MessageBox.Show("Please select a tree node", "Delete nodes", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                if (loadInfo != null && loadInfo.TreeView.SelectedNode.Nodes.Count > 0 && deleteChildNodes == false) {
                    MessageBox.Show("Selected node cannot be deleted as it contains child nodes. Configure using Kushal to allow deleting child nodes", "Delete nodes", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                if (loadInfo != null && loadInfo.TreeView.SelectedNode.Nodes.Count > 0 && deleteChildNodes) {
                    if (MessageBox.Show("Deleting this node removes all its child nodes. Do you want to continue ?", "Delete nodes", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) != DialogResult.OK) {
                        return false;
                    }
                }
                DataTable table = (DataTable)dgrData.DataSource;
                if (dgrData.SelectedRows != null && dgrData.SelectedRows.Count > 0) {
                    string message = "Do you really want to delete this row?";
                    if (loadInfo != null && loadInfo.TreeView.SelectedNode.Nodes.Count == 0) {
                        message = "Do you want to delete selected node";
                    } else if (loadInfo != null && loadInfo.TreeView.SelectedNode.Nodes.Count > 0) {
                        message = string.Empty;
                    }
                    if (String.IsNullOrEmpty(message) || (MessageBox.Show(message, "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)) {
                        foreach (DataGridViewColumn column in dgrData.Columns) {
                            if (column.DataPropertyName == keyField) {
                                // Following variables used for deleting all child nodes in case of treeview
                                string treeKeyFieldVal = string.Empty;
                                string keyColumnName = string.Empty;
                                if (loadInfo != null) {
                                    foreach (DataGridViewColumn col in dgrData.Columns) {
                                        if (col.DataPropertyName == loadInfo.KeyField) {
                                            treeKeyFieldVal = Convert.ToString(dgrData.SelectedRows[0].Cells[col.Name].Value);
                                            keyColumnName = col.Name;
                                            break;
                                        }
                                    }
                                }
                                dataAdapter.DeleteRow(table, Convert.ToString(dgrData.SelectedRows[0].Cells[column.Name].Value), keyField);
                                dgrData.Rows.RemoveAt(dgrData.SelectedRows[0].Index);
                                table.AcceptChanges();
                                if (loadInfo != null) {
                                    // Delete child nodes
                                    if (String.IsNullOrEmpty(treeKeyFieldVal) == false) {
                                        for (int i = dgrData.Rows.Count - 1; i >= 0; i--) {
                                            DataGridViewRow row = dgrData.Rows[i];
                                            string keyVal = Convert.ToString(row.Cells[keyColumnName].Value);
                                            if (keyVal.StartsWith(treeKeyFieldVal)) {
                                                dataAdapter.DeleteRow(table, Convert.ToString(row.Cells[column.Name].Value), keyField);
                                                dgrData.Rows.RemoveAt(row.Index);
                                                table.AcceptChanges();
                                            }
                                        }
                                    }
                                    ControlAdapter.LoadTreeView(loadInfo.TreeView, loadInfo.TableName, loadInfo.IdField, loadInfo.KeyField, loadInfo.ParentKeyField, loadInfo.DisplayTextField);
                                }
                                break;
                            }
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion
        
        private bool ProcessIdValueChange(object control) {
            return ProcessIdValueChange(control, true);
        }

        private bool ProcessIdValueChange(object control, bool showMessage) {
            try {
                if (skipIdValueProcessing)
                    return true;
                string text = ((TextBox)control).Text;
                if (String.IsNullOrEmpty(text))
                    return false;
                int val = Convert.ToInt32(text);
                DataTable table = (DataTable)dgrData.DataSource;
                foreach (DataGridViewRow row in dgrData.Rows) {
                    foreach (DataGridViewCell cell in row.Cells) {
                        if ((dgrData.Columns[cell.ColumnIndex].DataPropertyName == keyField) && Convert.ToInt32(cell.Value) == val) {
                            row.Selected = true;
                            return true;
                        }
                    }
                }
                newRecord = true;
                dgrData.ClearSelection();
                ControlAdapter.ResetControls(associatedControls, keyField);
            } catch (Exception exc) {
                if (showMessage)
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void ReloadData(ListControl listControl) {
            if (fieldSqls.ContainsKey(listControl.Name)) {
                DataTable dt = DataAdapter.Current.LoadData(fieldSqls[listControl.Name], "datasource" + listControl.Name);
                if (dt != null) {
                    listControl.ValueMember = dt.Columns[0].ColumnName;
                    listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    listControl.DataSource = dt;
                }
            }
        }
    }
}
