using Kushal.Controls;
namespace Newsletter_Composer {
    partial class EmailTemplateSelector {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnProceed = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.cmbSelectedTemplate = new Kushal.Controls.KushalComboBox();
            this.lblTemplate = new Kushal.Controls.KushalLabel();
            this.SuspendLayout();
            
            
            this.btnProceed.Location = new System.Drawing.Point(125, 48);
            this.btnProceed.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnProceed.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnProceed.Name = "btnProceed";
            this.btnProceed.Enabled = true;
            this.btnProceed.Visible = true;
            this.btnProceed.TabIndex = 0;
            this.btnProceed.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnProceed.Size = new System.Drawing.Size(100, 30);
            this.btnProceed.Text = @"Select";
            this.btnProceed.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProceed.UseVisualStyleBackColor = false;
            this.btnProceed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnProceed, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(297, 48);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(100, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.cmbSelectedTemplate.Location = new System.Drawing.Point(89, 11);
            this.cmbSelectedTemplate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectedTemplate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectedTemplate.MaxDropDownItems = 10;
            this.cmbSelectedTemplate.IntegralHeight = false;
            this.cmbSelectedTemplate.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmbSelectedTemplate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbSelectedTemplate.FormattingEnabled = true;
            this.cmbSelectedTemplate.Name = "cmbSelectedTemplate";
            this.cmbSelectedTemplate.AllowNull = true;
            this.cmbSelectedTemplate.FriendlyName = "SelectedTemplate";
            this.cmbSelectedTemplate.Enabled = true;
            this.cmbSelectedTemplate.Visible = true;
            this.cmbSelectedTemplate.TabIndex = 0;
            this.cmbSelectedTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectedTemplate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSelectedTemplate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectedTemplate.Size = new System.Drawing.Size(411, 30);
            this.cmbSelectedTemplate.Tag = "select TemplateID, TemplateName from EmailTemplate";
            this.toolTip1.SetToolTip(this.cmbSelectedTemplate, @"");
            

            this.lblTemplate.AutoSize = false;
            this.lblTemplate.Location = new System.Drawing.Point(8, 15);
            this.lblTemplate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblTemplate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblTemplate.Name = "lblTemplate";
            this.lblTemplate.Enabled = true;
            this.lblTemplate.Visible = true;
            this.lblTemplate.TabIndex = 0;
            this.lblTemplate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTemplate.Size = new System.Drawing.Size(71, 22);
            this.lblTemplate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemplate.Text = @"Template";
            this.toolTip1.SetToolTip(this.lblTemplate, @"");


            
            this.Controls.Add(this.btnProceed);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.cmbSelectedTemplate);
            this.Controls.Add(this.lblTemplate);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "EmailTemplateSelector";
            this.Text = "Select a Template";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(520, 121);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnProceed;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalComboBox cmbSelectedTemplate;
        private Kushal.Controls.KushalLabel lblTemplate;
    }
}