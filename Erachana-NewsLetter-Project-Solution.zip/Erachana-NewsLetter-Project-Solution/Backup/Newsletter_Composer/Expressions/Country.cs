using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class Country {
                public void Count_Expr() {
                try {                    lbl_Count.Text = "Count : " + dgrData.Rows.Count;                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }
        public bool PreSaveValidation() {
                			try {                				if(txt_CountryName.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter Country", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_CountryName.Focus();                					return false;                				}                				if(txt_CountryName.Text.Trim() == "India")                				{                					MessageBox.Show("India already entered", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_CountryName.Focus();                					return false;	                				}                                				                				DataTable dt = (DataTable) dgrData.DataSource;                				DataRow[] dr = dt.Select("CountryName='" + txt_CountryName.Text.Trim() + "' and CountryId<>" + txt_CountryId.Text);                				if (dr.Count() > 0)                				{                					MessageBox.Show("Given Country already entered", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_CountryName.Focus();                					return false;	                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public bool Pre_Delete_Fun() {
                			try {                				if(!newRecord)                				{                					if(txt_CountryName.Text.Trim() == "India")                					{                						MessageBox.Show("Not possible to delete 'India'", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                						txt_CountryName.Focus();                						return false;	                					}                					                					string sql = "select State.CountryId from State where State.CountryId = " + txt_CountryId.Text;                					DataTable data = (DataTable) SqlInterpreter.GetData(sql);                					if(data.Rows.Count > 0)					                					{                 						MessageBox.Show("Selected Country is used in State list", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                						return false;                					}                					else                						return true;		                				}                				else                					return true;                			} catch (Exception exc) {                                				                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }

    }
}