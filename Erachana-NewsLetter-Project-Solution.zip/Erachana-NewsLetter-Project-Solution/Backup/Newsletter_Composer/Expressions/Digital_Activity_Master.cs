using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class Digital_Activity_Master {
                public void Count_Expression() {
                try {                    lbl_Count.Text = "Count : " + dgrData.Rows.Count;                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }
        public bool PreSave() {
                			try {                				if(txt_SocialMediaMaster_ActivityName.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter Activity Name", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_SocialMediaMaster_ActivityName.Focus();                					return false;                				}                				DataTable dt = (DataTable) dgrData.DataSource;                				DataRow[] dr = dt.Select("ActivityName='" + txt_SocialMediaMaster_ActivityName.Text.Trim() + "'and Id<>" + txt_SocialMediaMaster_Id.Text.Trim());                				if (dr.Count() > 0)                				{                					MessageBox.Show("Entered Activity Name already present", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_SocialMediaMaster_ActivityName.Focus();                					return false;	                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public bool Pre_Delete() {
                			try {                				                				if(!newRecord)                				{                					DataTable dt1 = SqlInterpreter.GetData("SELECT  * FROM  SocialMedia WHERE  MasterName = " + txt_SocialMediaMaster_Id.Text);                					if(dt1.Rows.Count != 0 )                					{                						MessageBox.Show("Its Already in Use Not Possible to Delete", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                						return false;                					}                					return true;	                				}                				return true;                                    			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }

    }
}