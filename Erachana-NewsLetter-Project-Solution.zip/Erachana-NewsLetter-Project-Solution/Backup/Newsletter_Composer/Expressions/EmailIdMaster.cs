using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class EmailIdMaster {
                public void Load_Data() {
                try {                			/*	int user_id = TypeConverter.ConvertToInt(GlobalVariables.GetValue("$$UserId"));                                                				DataTable dt_emp = SqlInterpreter.GetData("select tremplin_user.isadmin from tremplin_user where tremplin_user.isadmin=0 and tremplin_user.id = " + user_id);                				if(dt_emp.Rows.Count > 0 )                				{                					if(cmb_USER_ID.DataSource != null)                						ControlAdapter.Filter(cmb_USER_ID, "emp_id=" + user_id, fieldSqls);                                				                					if(dgrData.DataSource != null )                					{                						ControlAdapter.Filter(dgrData, "USER_ID=" + user_id);                					}                				}*/                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }
        public bool PreSaveValidation() {
                			try {                				if(txt_SERVER_ID.SelectedIndex < 0)                				{                					MessageBox.Show("Select Server", "Eamil Server", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_SERVER_ID.Focus();                					return false;                				}                				if(txt_EMAIL_ID.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter your Email Id", "Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_EMAIL_ID.Focus();                					return false;                				}                				                				System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"^([A-Za-z0-9_\.-]+)@([\dA-Za-z\.-]+)\.([A-Za-z\.]{2,6})$");                				if (!string.IsNullOrEmpty(txt_EMAIL_ID.Text) && !regex.IsMatch(txt_EMAIL_ID.Text.ToString()))                				{                					MessageBox.Show("Invalid Email Id", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_EMAIL_ID.Focus();                					return false;                				}                				if(txt_PASSWORD.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter Email Password", "Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_PASSWORD.Focus();                					return false;                				}                				DataTable dt = (DataTable) dgrData.DataSource;                				DataRow[] dr = dt.Select("EmailID='" + txt_EMAIL_ID.Text.Trim() + "' and ID<>" + txt_ID.Text);                				if (dr.Count() > 0)                				{                					MessageBox.Show("This Email Id already configured", "Duplicate Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_EMAIL_ID.Focus();                					return false;	                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public void CountExpr() {
                try {                				lbl_Count.Text = "Count : " + dgrData.Rows.Count;                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }

    }
}