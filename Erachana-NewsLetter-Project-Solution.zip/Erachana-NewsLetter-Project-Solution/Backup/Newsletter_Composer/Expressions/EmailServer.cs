using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class EmailServer {
                public void Count_Expr() {
                			try {                				lbl_Count.Text = "Count : " + dgrData.Rows.Count;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }
        public bool PreSaveValidation() {
                			try {                				if(txt_ServerName.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter Server Name", "Server Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_ServerName.Focus();                					return false;                				}                				if(txt_ServerSMTP.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter SMTP of Server", "SMTP", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_ServerSMTP.Focus();                					return false;                				}                				if(txt_ServerSMTPPort.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter SMTP Port of Server", "SMTP Port Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_ServerSMTPPort.Focus();                					return false;                				}                				return true;                				DataTable dt = (DataTable) dgrData.DataSource;                				DataRow[] dr = dt.Select("ServerSMTP='" + txt_ServerSMTP.Text.Trim() + "' and ServerID <>" + txt_ServerID.Text);                				if (dr.Count() > 0)                				{                					MessageBox.Show("This Server alredy entered", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_ServerName.Focus();                					return false;	                				}                                                    			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public bool PreDeleteValidation() {
                			try {                				if(!newRecord)                				{                					DataTable dt = SqlInterpreter.GetData("select ID from EmailList where ServerID=" + txt_ServerID.Text);                					if(dt.Rows.Count > 0 )                					{                						MessageBox.Show("Selected sever configured with email", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                						return false;                					}                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public void New_Data() {
                			try {                				rbFalse.Checked = true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }

    }
}