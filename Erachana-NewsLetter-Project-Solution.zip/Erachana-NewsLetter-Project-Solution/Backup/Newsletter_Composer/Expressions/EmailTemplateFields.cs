using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class EmailTemplateFields {
        
    }
}