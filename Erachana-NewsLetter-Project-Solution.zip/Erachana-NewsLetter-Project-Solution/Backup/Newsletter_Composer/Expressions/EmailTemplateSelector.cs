using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class EmailTemplateSelector {
                public void SetSelectedTemplateID() {
                			try {                				if(cmbSelectedTemplate.SelectedIndex < 0){                					MessageBox.Show("Select Template or Create", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                				}                				else                				{                					gTemplateID = cmbSelectedTemplate.SelectedValue.ToString();                					//	MessageBox.Show(gTemplateID.ToString());                					this.Close();                				}                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }
        public void Validate_select() {
                try {                				if(cmbSelectedTemplate.SelectedIndex < 0){                				 MessageBox.Show("Select Templet or Create", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                				}                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }

    }
}