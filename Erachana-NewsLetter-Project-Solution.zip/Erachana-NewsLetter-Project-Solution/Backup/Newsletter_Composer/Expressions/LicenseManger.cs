using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class LicenseManger {
                public void OpenLicense() {
                			try {                				string licenseManagerPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles) + @"\ERachana\License_Manager.exe";                				                					try                					{                						string args = "NL" + " " + "\"News Letter Composer\"" + " " + "\"" + Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\"+this.ProductName+"\"";                						System.Diagnostics.Process.Start(@""+licenseManagerPath, args).WaitForExit();                						//	return false;                						this.Close();                					}                					catch (Exception ex)                					{                						MessageBox.Show("License Manager not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);                						//return false;                						this.Close();                					}                				                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }

    }
}