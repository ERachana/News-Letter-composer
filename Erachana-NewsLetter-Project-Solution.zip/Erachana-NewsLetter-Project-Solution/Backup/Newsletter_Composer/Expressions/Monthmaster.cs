using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class Monthmaster {
                public void Count_Exp() {
                			try {                				lbl_Count.Text = "Count : " + dgrData.Rows.Count;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }
        public bool PreSave() {
                			try {                				if(txt_MonthMaster_Year.Text.Trim().Length <= 0 || TypeConverter.ConvertToInt(txt_MonthMaster_Year.Text)<2017)                				{                					MessageBox.Show("Missed to Enter Year or Improper data", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_MonthMaster_Year.Focus();                					return false;                				}                				if(txt_MonthMaster_Month.SelectedIndex < 0)                				{                					MessageBox.Show(" Select Month", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_MonthMaster_Month.Focus();                					return false;                				}                				DataTable dt = (DataTable) dgrData.DataSource;                				DataRow[] dr = dt.Select("Year='" + txt_MonthMaster_Year.Text.Trim() + "' and Month=" + txt_MonthMaster_Month.SelectedValue + " and Id<>" + txt_MonthMaster_Id.Text);                				if (dr.Count() > 0)                				{                					MessageBox.Show("Entered Month with Year already present", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_MonthMaster_Month.Focus();                					return false;	                				}                				                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public bool Pre_Delete() {
                			try {                				if(!newRecord)                				{DataTable dt3 = SqlInterpreter.GetData("SELECT  * FROM  SocialMedia WHERE Month =" + txt_MonthMaster_Id.Text);                					if( dt3.Rows.Count != 0)                					{                						MessageBox.Show("Data Is there for this month", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                						return false;                					}                					return true;                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }

    }
}