using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class Producttypemaster {
                public void Count_Exp() {
                			try {                				lbl_Count.Text = "Count : " + dgrData.Rows.Count;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }
        public bool PreSave_Validation() {
                			try {                				if(txt_ProductTypeMaster_ProductName.Text.Trim().Length <= 0)                				{                					MessageBox.Show("Enter Product Type", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_ProductTypeMaster_ProductName.Focus();                					return false;                				}                				DataTable dt = (DataTable) dgrData.DataSource;                				DataRow[] dr = dt.Select("CategoryName='" + txt_ProductTypeMaster_ProductName.Text.Trim() + "'and Id<>" + txt_ProductTypeMaster_Id.Text.Trim());                				if (dr.Count() > 0)                				{                					MessageBox.Show("Entered App Type already present", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					txt_ProductTypeMaster_ProductName.Focus();                					return false;	                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }
        public bool Pre_Delete() {
                			try {                				if(!newRecord)                				{DataTable dt2 = SqlInterpreter.GetData("SELECT  * FROM  AppDetails where  CategoryId = " + txt_ProductTypeMaster_Id.Text);                					//DataTable dt3 = SqlInterpreter.GetData("SELECT  * FROM  AppDetails where  CategoryId = " + txt_ProductTypeMaster_Id.Text);                					if( dt2.Rows.Count!=0)                					{                						MessageBox.Show("Applications are there for selected Type", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                						return false;                					}                					return true;                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }

    }
}