using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer {
    partial class Socialmedia {
                public void Count_Exp() {
                			try {                				lbl_Count.Text = "Count : " + dgrData.Rows.Count;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                			}
        }
        public void Form_DigitalActivity() {
                try {                				Form frm = ControlAdapter.CreateForm("Digital_Activity_Master");                				frm.ShowDialog();                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }
        public void NewData() {
                try {                				dtp_SocialMedia_StatusDate.Value = DateTime.Now;                } catch (Exception exc) {                    MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                }
        }
        public bool PreSave() {
                			try {                				if(txt_SocialMedia_MasterName.SelectedIndex < 0)                				{                					MessageBox.Show("Please select month", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					return false;                				}                				if(txt_SocialMedia_Month.SelectedIndex < 0)                				{                					MessageBox.Show("Please select month", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					return false;                				}                				return true;                			} catch (Exception exc) {                				MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                				return false;                			}
        }

    }
}