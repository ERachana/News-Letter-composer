using Kushal.Controls;
namespace Newsletter_Composer {
    partial class FilterEmails {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnSelect = new Kushal.Controls.KushalButton();
            this.btnCancel = new Kushal.Controls.KushalButton();
            this.grpFilter = new Kushal.Controls.KushalGroupBox();
            this.chkRelation = new Kushal.Controls.KushalCheckBox();
            this.chkHandledBy = new Kushal.Controls.KushalCheckBox();
            this.chk = new Kushal.Controls.KushalCheckBox();
            this.lbltitle1 = new Kushal.Controls.KushalLabel();
            this.lbltitle2 = new Kushal.Controls.KushalLabel();
            this.lbltitle3 = new Kushal.Controls.KushalLabel();
            this.lstRelation = new Kushal.Controls.KushalCheckedListBox();
            this.lstHandledby = new Kushal.Controls.KushalCheckedListBox();
            this.lstPlace = new Kushal.Controls.KushalCheckedListBox();
            this.SuspendLayout();
            
            
            this.btnSelect.Location = new System.Drawing.Point(145, 290);
            this.btnSelect.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSelect.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Enabled = true;
            this.btnSelect.Visible = true;
            this.btnSelect.TabIndex = 0;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSelect.Size = new System.Drawing.Size(133, 30);
            this.btnSelect.Text = @"Select";
            this.btnSelect.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSelect, @"");
            
            

            this.btnCancel.Location = new System.Drawing.Point(400, 290);
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Enabled = true;
            this.btnCancel.Visible = true;
            this.btnCancel.TabIndex = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnCancel.Size = new System.Drawing.Size(133, 30);
            this.btnCancel.Text = @"Cancel";
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnCancel, @"");
            
            

            this.grpFilter.Location = new System.Drawing.Point(9, 4);
            this.grpFilter.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpFilter.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpFilter.Name = "grpFilter";
            this.grpFilter.Enabled = true;
            this.grpFilter.Visible = true;
            this.grpFilter.TabIndex = 0;
            this.grpFilter.TabStop = false;
            this.grpFilter.Size = new System.Drawing.Size(684, 271);
            this.grpFilter.Text = @"Subscriber Email Filter";
            this.grpFilter.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpFilter.SendToBack();
            this.toolTip1.SetToolTip(this.grpFilter, @"");

            this.chkRelation.AutoSize = true;
            this.chkRelation.Location = new System.Drawing.Point(15, 242);
            this.chkRelation.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.chkRelation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chkRelation.Name = "chkRelation";
            this.chkRelation.DefaultChecked = false;
            this.chkRelation.FriendlyName = "";
            this.chkRelation.Enabled = true;
            this.chkRelation.Visible = true;
            this.chkRelation.TabIndex = 0;
            this.chkRelation.Size = new System.Drawing.Size(100, 25);
            this.chkRelation.Text = @"Select All";
            this.chkRelation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRelation.UseVisualStyleBackColor = true;
            this.toolTip1.SetToolTip(this.chkRelation, @"");

            this.chkHandledBy.AutoSize = true;
            this.chkHandledBy.Location = new System.Drawing.Point(236, 242);
            this.chkHandledBy.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.chkHandledBy.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chkHandledBy.Name = "chkHandledBy";
            this.chkHandledBy.DefaultChecked = false;
            this.chkHandledBy.FriendlyName = "";
            this.chkHandledBy.Enabled = true;
            this.chkHandledBy.Visible = true;
            this.chkHandledBy.TabIndex = 0;
            this.chkHandledBy.Size = new System.Drawing.Size(100, 25);
            this.chkHandledBy.Text = @"Select All";
            this.chkHandledBy.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHandledBy.UseVisualStyleBackColor = true;
            this.toolTip1.SetToolTip(this.chkHandledBy, @"");

            this.chk.AutoSize = true;
            this.chk.Location = new System.Drawing.Point(459, 242);
            this.chk.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.chk.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chk.Name = "chk";
            this.chk.DefaultChecked = false;
            this.chk.FriendlyName = "";
            this.chk.Enabled = true;
            this.chk.Visible = true;
            this.chk.TabIndex = 0;
            this.chk.Size = new System.Drawing.Size(100, 25);
            this.chk.Text = @"Select All";
            this.chk.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk.UseVisualStyleBackColor = true;
            this.toolTip1.SetToolTip(this.chk, @"");

            this.lbltitle1.AutoSize = false;
            this.lbltitle1.Location = new System.Drawing.Point(13, 21);
            this.lbltitle1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbltitle1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbltitle1.Name = "lbltitle1";
            this.lbltitle1.Enabled = true;
            this.lbltitle1.Visible = true;
            this.lbltitle1.TabIndex = 0;
            this.lbltitle1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbltitle1.Size = new System.Drawing.Size(66, 23);
            this.lbltitle1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle1.Text = @"Relation";
            this.toolTip1.SetToolTip(this.lbltitle1, @"");

            this.lbltitle2.AutoSize = false;
            this.lbltitle2.Location = new System.Drawing.Point(236, 21);
            this.lbltitle2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbltitle2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbltitle2.Name = "lbltitle2";
            this.lbltitle2.Enabled = true;
            this.lbltitle2.Visible = true;
            this.lbltitle2.TabIndex = 0;
            this.lbltitle2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbltitle2.Size = new System.Drawing.Size(100, 23);
            this.lbltitle2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle2.Text = @"Handled By";
            this.toolTip1.SetToolTip(this.lbltitle2, @"");

            this.lbltitle3.AutoSize = false;
            this.lbltitle3.Location = new System.Drawing.Point(459, 21);
            this.lbltitle3.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbltitle3.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbltitle3.Name = "lbltitle3";
            this.lbltitle3.Enabled = true;
            this.lbltitle3.Visible = true;
            this.lbltitle3.TabIndex = 0;
            this.lbltitle3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbltitle3.Size = new System.Drawing.Size(100, 23);
            this.lbltitle3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle3.Text = @"Place";
            this.toolTip1.SetToolTip(this.lbltitle3, @"");

            this.lstRelation.Location = new System.Drawing.Point(14, 46);
            this.lstRelation.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lstRelation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lstRelation.FormattingEnabled = true;
            this.lstRelation.Name = "lstRelation";
            this.lstRelation.Enabled = true;
            this.lstRelation.Visible = true;
            this.lstRelation.TabIndex = 0;
            this.lstRelation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstRelation.Size = new System.Drawing.Size(212, 195);
            this.lstRelation.Tag = "Select RelationId,Relation from Relations";
            this.toolTip1.SetToolTip(this.lstRelation, @"");
            

            this.lstHandledby.Location = new System.Drawing.Point(236, 46);
            this.lstHandledby.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lstHandledby.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lstHandledby.FormattingEnabled = true;
            this.lstHandledby.Name = "lstHandledby";
            this.lstHandledby.Enabled = true;
            this.lstHandledby.Visible = true;
            this.lstHandledby.TabIndex = 0;
            this.lstHandledby.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstHandledby.Size = new System.Drawing.Size(212, 195);
            this.lstHandledby.Tag = "select  Id , Name from HandeledBy";
            this.toolTip1.SetToolTip(this.lstHandledby, @"");
            

            this.lstPlace.Location = new System.Drawing.Point(459, 46);
            this.lstPlace.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lstPlace.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lstPlace.FormattingEnabled = true;
            this.lstPlace.Name = "lstPlace";
            this.lstPlace.Enabled = true;
            this.lstPlace.Visible = true;
            this.lstPlace.TabIndex = 0;
            this.lstPlace.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPlace.Size = new System.Drawing.Size(212, 195);
            this.lstPlace.Tag = "select PlaceId,PlaceName from Place";
            this.toolTip1.SetToolTip(this.lstPlace, @"");
            


            
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.grpFilter);
            this.grpFilter.Controls.Add(this.chkRelation);
            this.grpFilter.Controls.Add(this.chkHandledBy);
            this.grpFilter.Controls.Add(this.chk);
            this.grpFilter.Controls.Add(this.lbltitle1);
            this.grpFilter.Controls.Add(this.lbltitle2);
            this.grpFilter.Controls.Add(this.lbltitle3);
            this.grpFilter.Controls.Add(this.lstRelation);
            this.grpFilter.Controls.Add(this.lstHandledby);
            this.grpFilter.Controls.Add(this.lstPlace);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "FilterEmails";
            this.Text = "Email Filter";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(717, 370);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnSelect;
        private Kushal.Controls.KushalButton btnCancel;
        private Kushal.Controls.KushalGroupBox grpFilter;
        private Kushal.Controls.KushalCheckBox chkRelation;
        private Kushal.Controls.KushalCheckBox chkHandledBy;
        private Kushal.Controls.KushalCheckBox chk;
        private Kushal.Controls.KushalLabel lbltitle1;
        private Kushal.Controls.KushalLabel lbltitle2;
        private Kushal.Controls.KushalLabel lbltitle3;
        private Kushal.Controls.KushalCheckedListBox lstRelation;
        private Kushal.Controls.KushalCheckedListBox lstHandledby;
        private Kushal.Controls.KushalCheckedListBox lstPlace;
    }
}