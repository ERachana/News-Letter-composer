using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Frm_AboutUs {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.grpContactDetails = new Kushal.Controls.KushalGroupBox();
            this.lnkEmail1 = new Kushal.Controls.KushalEmailLabel();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel9 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel10 = new Kushal.Controls.KushalLabel();
            this.lnkWebsite = new Kushal.Controls.KushalLinkLabel();
            this.grpRegisteration = new Kushal.Controls.KushalGroupBox();
            this.lblUserName = new Kushal.Controls.KushalLabel();
            this.lblCompanyName = new Kushal.Controls.KushalLabel();
            this.lblEmail = new Kushal.Controls.KushalLabel();
            this.lblLicenseType = new Kushal.Controls.KushalLabel();
            this.lblCardNo = new Kushal.Controls.KushalLabel();
            this.lblExpiryDate = new Kushal.Controls.KushalLabel();
            this.SuspendLayout();
            
            
            this.grpContactDetails.Location = new System.Drawing.Point(367, 311);
            this.grpContactDetails.BackColor = System.Drawing.Color.FromArgb(-1);
            this.grpContactDetails.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpContactDetails.Name = "grpContactDetails";
            this.grpContactDetails.Enabled = true;
            this.grpContactDetails.Visible = true;
            this.grpContactDetails.TabIndex = 0;
            this.grpContactDetails.TabStop = false;
            this.grpContactDetails.Size = new System.Drawing.Size(231, 154);
            this.grpContactDetails.Text = @"Contact Us";
            this.grpContactDetails.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpContactDetails.SendToBack();
            this.toolTip1.SetToolTip(this.grpContactDetails, @"");

            this.lnkEmail1.AutoSize = false;
            this.lnkEmail1.Location = new System.Drawing.Point(91, 41);
            this.lnkEmail1.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lnkEmail1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lnkEmail1.Name = "lnkEmail1";
            this.lnkEmail1.Enabled = true;
            this.lnkEmail1.Visible = true;
            this.lnkEmail1.TabIndex = 0;
            this.lnkEmail1.Size = new System.Drawing.Size(132, 20);
            this.lnkEmail1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkEmail1.Text = @"info@erachana.net";
            this.toolTip1.SetToolTip(this.lnkEmail1, @"");
            this.lnkEmail1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEmail1_LinkClicked);

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(7, 65);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(211, 59);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"Telephone : +91 80 - 23199709
                  +91 80 - 23194545
                  +91 80 - 23192323";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(7, 126);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(209, 23);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @" Mobile     : +91 - 9964077688";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.lblNewLabel9.AutoSize = false;
            this.lblNewLabel9.Location = new System.Drawing.Point(7, 15);
            this.lblNewLabel9.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblNewLabel9.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.lblNewLabel9.Name = "lblNewLabel9";
            this.lblNewLabel9.Enabled = true;
            this.lblNewLabel9.Visible = true;
            this.lblNewLabel9.TabIndex = 0;
            this.lblNewLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel9.Size = new System.Drawing.Size(81, 23);
            this.lblNewLabel9.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel9.Text = @"Website    :";
            this.toolTip1.SetToolTip(this.lblNewLabel9, @"");

            this.lblNewLabel10.AutoSize = false;
            this.lblNewLabel10.Location = new System.Drawing.Point(7, 40);
            this.lblNewLabel10.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblNewLabel10.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.lblNewLabel10.Name = "lblNewLabel10";
            this.lblNewLabel10.Enabled = true;
            this.lblNewLabel10.Visible = true;
            this.lblNewLabel10.TabIndex = 0;
            this.lblNewLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel10.Size = new System.Drawing.Size(81, 23);
            this.lblNewLabel10.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel10.Text = @"Email        :";
            this.toolTip1.SetToolTip(this.lblNewLabel10, @"");

            this.lnkWebsite.AutoSize = false;
            this.lnkWebsite.Location = new System.Drawing.Point(89, 15);
            this.lnkWebsite.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lnkWebsite.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lnkWebsite.Name = "lnkWebsite";
            this.lnkWebsite.Enabled = true;
            this.lnkWebsite.Visible = true;
            this.lnkWebsite.TabIndex = 0;
            this.lnkWebsite.Size = new System.Drawing.Size(132, 22);
            this.lnkWebsite.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkWebsite.Text = @"www.erachana.net";
            this.toolTip1.SetToolTip(this.lnkWebsite, @"");
            this.lnkWebsite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkWebsite_LinkClicked);
            this.lnkWebsite.Click += new System.EventHandler(this.lnkWebsite_Evaluate_Click);

            this.grpRegisteration.Location = new System.Drawing.Point(-2, 288);
            this.grpRegisteration.BackColor = System.Drawing.Color.FromArgb(-1);
            this.grpRegisteration.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpRegisteration.Name = "grpRegisteration";
            this.grpRegisteration.Enabled = true;
            this.grpRegisteration.Visible = true;
            this.grpRegisteration.TabIndex = 0;
            this.grpRegisteration.TabStop = false;
            this.grpRegisteration.Size = new System.Drawing.Size(299, 177);
            this.grpRegisteration.Text = @"Registerd To";
            this.grpRegisteration.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRegisteration.SendToBack();
            this.toolTip1.SetToolTip(this.grpRegisteration, @"");

            this.lblUserName.AutoSize = false;
            this.lblUserName.Location = new System.Drawing.Point(9, 17);
            this.lblUserName.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblUserName.ForeColor = System.Drawing.Color.FromArgb(-16777024);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Enabled = true;
            this.lblUserName.Visible = true;
            this.lblUserName.TabIndex = 0;
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserName.Size = new System.Drawing.Size(283, 24);
            this.lblUserName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Text = @"Name                 :";
            this.toolTip1.SetToolTip(this.lblUserName, @"");

            this.lblCompanyName.AutoSize = false;
            this.lblCompanyName.Location = new System.Drawing.Point(9, 44);
            this.lblCompanyName.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblCompanyName.ForeColor = System.Drawing.Color.FromArgb(-16777024);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Enabled = true;
            this.lblCompanyName.Visible = true;
            this.lblCompanyName.TabIndex = 0;
            this.lblCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCompanyName.Size = new System.Drawing.Size(283, 23);
            this.lblCompanyName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.Text = @"Company Name   :";
            this.toolTip1.SetToolTip(this.lblCompanyName, @"");

            this.lblEmail.AutoSize = false;
            this.lblEmail.Location = new System.Drawing.Point(9, 70);
            this.lblEmail.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblEmail.ForeColor = System.Drawing.Color.FromArgb(-16777024);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Enabled = true;
            this.lblEmail.Visible = true;
            this.lblEmail.TabIndex = 0;
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblEmail.Size = new System.Drawing.Size(283, 23);
            this.lblEmail.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Text = @"Email                  :";
            this.toolTip1.SetToolTip(this.lblEmail, @"");

            this.lblLicenseType.AutoSize = false;
            this.lblLicenseType.Location = new System.Drawing.Point(9, 96);
            this.lblLicenseType.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblLicenseType.ForeColor = System.Drawing.Color.FromArgb(-16777024);
            this.lblLicenseType.Name = "lblLicenseType";
            this.lblLicenseType.Enabled = true;
            this.lblLicenseType.Visible = true;
            this.lblLicenseType.TabIndex = 0;
            this.lblLicenseType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblLicenseType.Size = new System.Drawing.Size(283, 23);
            this.lblLicenseType.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLicenseType.Text = @"License Type       :";
            this.toolTip1.SetToolTip(this.lblLicenseType, @"");

            this.lblCardNo.AutoSize = false;
            this.lblCardNo.Location = new System.Drawing.Point(9, 122);
            this.lblCardNo.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblCardNo.ForeColor = System.Drawing.Color.FromArgb(-16777024);
            this.lblCardNo.Name = "lblCardNo";
            this.lblCardNo.Enabled = true;
            this.lblCardNo.Visible = true;
            this.lblCardNo.TabIndex = 0;
            this.lblCardNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCardNo.Size = new System.Drawing.Size(283, 23);
            this.lblCardNo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardNo.Text = @"Card No              :";
            this.toolTip1.SetToolTip(this.lblCardNo, @"");

            this.lblExpiryDate.AutoSize = false;
            this.lblExpiryDate.Location = new System.Drawing.Point(9, 148);
            this.lblExpiryDate.BackColor = System.Drawing.Color.FromArgb(-1);
            this.lblExpiryDate.ForeColor = System.Drawing.Color.FromArgb(-16777024);
            this.lblExpiryDate.Name = "lblExpiryDate";
            this.lblExpiryDate.Enabled = true;
            this.lblExpiryDate.Visible = true;
            this.lblExpiryDate.TabIndex = 0;
            this.lblExpiryDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblExpiryDate.Size = new System.Drawing.Size(283, 23);
            this.lblExpiryDate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpiryDate.Text = @"Expiry Date         :";
            this.toolTip1.SetToolTip(this.lblExpiryDate, @"");


            
            this.Controls.Add(this.grpContactDetails);
            this.grpContactDetails.Controls.Add(this.lnkEmail1);
            this.grpContactDetails.Controls.Add(this.lblNewLabel1);
            this.grpContactDetails.Controls.Add(this.lblNewLabel2);
            this.grpContactDetails.Controls.Add(this.lblNewLabel9);
            this.grpContactDetails.Controls.Add(this.lblNewLabel10);
            this.grpContactDetails.Controls.Add(this.lnkWebsite);
            this.Controls.Add(this.grpRegisteration);
            this.grpRegisteration.Controls.Add(this.lblUserName);
            this.grpRegisteration.Controls.Add(this.lblCompanyName);
            this.grpRegisteration.Controls.Add(this.lblEmail);
            this.grpRegisteration.Controls.Add(this.lblLicenseType);
            this.grpRegisteration.Controls.Add(this.lblCardNo);
            this.grpRegisteration.Controls.Add(this.lblExpiryDate);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-2039584);
            this.BackgroundImage = global::Newsletter_Composer.Properties.Resources.Frm_AboutUs_3ef;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Frm_AboutUs";
            this.Text = "About Us";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(612, 503);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalGroupBox grpContactDetails;
        private Kushal.Controls.KushalEmailLabel lnkEmail1;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private Kushal.Controls.KushalLabel lblNewLabel9;
        private Kushal.Controls.KushalLabel lblNewLabel10;
        private Kushal.Controls.KushalLinkLabel lnkWebsite;
        private Kushal.Controls.KushalGroupBox grpRegisteration;
        private Kushal.Controls.KushalLabel lblUserName;
        private Kushal.Controls.KushalLabel lblCompanyName;
        private Kushal.Controls.KushalLabel lblEmail;
        private Kushal.Controls.KushalLabel lblLicenseType;
        private Kushal.Controls.KushalLabel lblCardNo;
        private Kushal.Controls.KushalLabel lblExpiryDate;
    }
}