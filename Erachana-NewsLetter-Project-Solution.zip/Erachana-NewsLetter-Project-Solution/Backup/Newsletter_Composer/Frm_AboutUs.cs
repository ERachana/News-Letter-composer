using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Web;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class Frm_AboutUs : Form {
        private AdminDetails adminDetails = Settings.GetDatabaseAdminDetails();
        private Dictionary<string, string> fieldSqls = new Dictionary<string, string>();
        private Dictionary<string, ColumnValidationInfo> colValidations = new Dictionary<string, ColumnValidationInfo>();
        private List<string> ExportableColumnNames = new List<string>() { };
        private long dgr_ErrorCount = 0;
        public Frm_AboutUs() {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Frm_AboutUs_PreLoad);
            this.Load += new System.EventHandler(this.Frm_AboutUs_PostLoad);
            this.Activated += new System.EventHandler(this.Frm_AboutUs_Activated);
            DoEventSubscriptions();
            
            ControlAdapter.LoadControlDataSource(this.Controls.Cast<Control>().ToList(), fieldSqls);
            ControlAdapter.ProcessDropdownColumns(this.Controls.Cast<Control>().ToList());
            
            
            ControlAdapter.ProcessColumnValidation(this.Controls.Cast<Control>().ToList(), colValidations);
            
            ExportableColumnNames = getExportableColumnNames();
        }

        private List<string> getExportableColumnNames() {
            List<string> ExportableColumnList = new List<string>();
            
            return ExportableColumnList;
        }

        private void printErrorOnlyOnce() {
            if (dgr_ErrorCount > 0) { //DataGridViewComboBoxCell value is not valid
                MessageBox.Show("Some of the columns in the Grid could have problem with it's SQL statement.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dgr_ErrorCount = 0;
            }
        }
        
        

        private void Frm_AboutUs_PreLoad(object sender, EventArgs e) {
            
        }
        private void Frm_AboutUs_PostLoad(object sender, EventArgs e) {
            Load_Data();
        }
        private void Frm_AboutUs_Activated(object sender, EventArgs e) {
        }
        private void DoEventSubscriptions() {
            
        }
        #region Event Handers
        
        private void lnkWebsite_Evaluate_Click(Object sender, EventArgs e) {
        }
        private void Frm_AboutUs_Evaluate_Load(Object sender, EventArgs e) {
            Load_Data();
        }
        private void lnkEmail1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            Process.Start("mailto:info@erachana.net");
        }
        private void lnkWebsite_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            if (String.IsNullOrEmpty("http://www.erachana.net") == false){
                 Process.Start("http://www.erachana.net");
            }
        }
        #endregion
        private void ReloadData(ListControl listControl) {
            if (fieldSqls.ContainsKey(listControl.Name)) {
                DataTable dt = DataAdapter.Current.LoadData(fieldSqls[listControl.Name], "datasource" + listControl.Name);
                if (dt != null) {
                    listControl.ValueMember = dt.Columns[0].ColumnName;
                    listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    listControl.DataSource = dt;
                }
            }
        }
    }
}
