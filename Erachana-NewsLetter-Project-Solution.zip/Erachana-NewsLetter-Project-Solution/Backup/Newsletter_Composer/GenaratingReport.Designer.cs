using Kushal.Controls;
namespace Newsletter_Composer {
    partial class GenaratingReport {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnGenarateReport = new Kushal.Controls.KushalButton();
            this.cmbSelectMonth = new Kushal.Controls.KushalComboBox();
            this.lblSelectMonth = new Kushal.Controls.KushalLabel();
            this.SuspendLayout();
            
            
            this.btnGenarateReport.Location = new System.Drawing.Point(350, 24);
            this.btnGenarateReport.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnGenarateReport.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnGenarateReport.Name = "btnGenarateReport";
            this.btnGenarateReport.Enabled = true;
            this.btnGenarateReport.Visible = true;
            this.btnGenarateReport.TabIndex = 0;
            this.btnGenarateReport.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnGenarateReport.Size = new System.Drawing.Size(136, 30);
            this.btnGenarateReport.Text = @"Generate Report";
            this.btnGenarateReport.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenarateReport.UseVisualStyleBackColor = false;
            this.btnGenarateReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnGenarateReport, @"");
            
            

            this.cmbSelectMonth.Location = new System.Drawing.Point(138, 25);
            this.cmbSelectMonth.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectMonth.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectMonth.MaxDropDownItems = 10;
            this.cmbSelectMonth.IntegralHeight = false;
            this.cmbSelectMonth.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.cmbSelectMonth.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbSelectMonth.FormattingEnabled = true;
            this.cmbSelectMonth.Name = "cmbSelectMonth";
            this.cmbSelectMonth.AllowNull = true;
            this.cmbSelectMonth.FriendlyName = "cmbNewDropDown1";
            this.cmbSelectMonth.Enabled = true;
            this.cmbSelectMonth.Visible = true;
            this.cmbSelectMonth.TabIndex = 0;
            this.cmbSelectMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSelectMonth.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectMonth.Size = new System.Drawing.Size(187, 29);
            this.cmbSelectMonth.Tag = "select monthmaster.id, cast(monthmaster.year as nvarchar(4)) + '-' + cast(listmaster.listcode as nvarchar(15)) as expr1, listmaster.listid AS Month, monthmaster.year from monthmaster inner join listmaster on monthmaster.month = listmaster.listid where listmaster.listtypeid = 1";
            this.toolTip1.SetToolTip(this.cmbSelectMonth, @"");
            

            this.lblSelectMonth.AutoSize = false;
            this.lblSelectMonth.Location = new System.Drawing.Point(26, 28);
            this.lblSelectMonth.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblSelectMonth.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblSelectMonth.Name = "lblSelectMonth";
            this.lblSelectMonth.Enabled = true;
            this.lblSelectMonth.Visible = true;
            this.lblSelectMonth.TabIndex = 0;
            this.lblSelectMonth.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSelectMonth.Size = new System.Drawing.Size(100, 23);
            this.lblSelectMonth.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectMonth.Text = @"* Select Month";
            this.toolTip1.SetToolTip(this.lblSelectMonth, @"");


            
            this.Controls.Add(this.btnGenarateReport);
            this.Controls.Add(this.cmbSelectMonth);
            this.Controls.Add(this.lblSelectMonth);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "GenaratingReport";
            this.Text = "Genarate Report";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(514, 120);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnGenarateReport;
        private Kushal.Controls.KushalComboBox cmbSelectMonth;
        private Kushal.Controls.KushalLabel lblSelectMonth;
    }
}