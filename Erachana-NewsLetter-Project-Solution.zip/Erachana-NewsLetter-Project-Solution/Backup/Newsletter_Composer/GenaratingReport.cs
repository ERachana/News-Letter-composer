using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Web;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class GenaratingReport : Form {
        private AdminDetails adminDetails = Settings.GetDatabaseAdminDetails();
        private Dictionary<string, string> fieldSqls = new Dictionary<string, string>();
        private Dictionary<string, ColumnValidationInfo> colValidations = new Dictionary<string, ColumnValidationInfo>();
        private List<string> ExportableColumnNames = new List<string>() { };
        private long dgr_ErrorCount = 0;
        public GenaratingReport() {
            InitializeComponent();
            this.Load += new System.EventHandler(this.GenaratingReport_PreLoad);
            this.Load += new System.EventHandler(this.GenaratingReport_PostLoad);
            this.Activated += new System.EventHandler(this.GenaratingReport_Activated);
            DoEventSubscriptions();
            
            fieldSqls.Add("cmbSelectMonth", "select monthmaster.id, cast(monthmaster.year as nvarchar(4)) + '-' + cast(listmaster.listcode as nvarchar(15)) as expr1, listmaster.listid AS Month, monthmaster.year from monthmaster inner join listmaster on monthmaster.month = listmaster.listid where listmaster.listtypeid = 1");
            ControlAdapter.LoadControlDataSource(this.Controls.Cast<Control>().ToList(), fieldSqls);
            ControlAdapter.ProcessDropdownColumns(this.Controls.Cast<Control>().ToList());
            
            
            ControlAdapter.ProcessColumnValidation(this.Controls.Cast<Control>().ToList(), colValidations);
            
            ExportableColumnNames = getExportableColumnNames();
        }

        private List<string> getExportableColumnNames() {
            List<string> ExportableColumnList = new List<string>();
            
            return ExportableColumnList;
        }

        private void printErrorOnlyOnce() {
            if (dgr_ErrorCount > 0) { //DataGridViewComboBoxCell value is not valid
                MessageBox.Show("Some of the columns in the Grid could have problem with it's SQL statement.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dgr_ErrorCount = 0;
            }
        }
        
        

        private void GenaratingReport_PreLoad(object sender, EventArgs e) {
            
        }
        private void GenaratingReport_PostLoad(object sender, EventArgs e) {
            
        }
        private void GenaratingReport_Activated(object sender, EventArgs e) {
        }
        private void DoEventSubscriptions() {
            
            this.btnGenarateReport.Click += new System.EventHandler(this.btnGenarateReport_Evaluate_Click);
        }
        #region Event Handers
        
        private void btnGenarateReport_Evaluate_Click(Object sender, EventArgs e) {
            Month_Validate();
            GenerateConsolidatedReportHTML();
        }
        #endregion
        private void ReloadData(ListControl listControl) {
            if (fieldSqls.ContainsKey(listControl.Name)) {
                DataTable dt = DataAdapter.Current.LoadData(fieldSqls[listControl.Name], "datasource" + listControl.Name);
                if (dt != null) {
                    listControl.ValueMember = dt.Columns[0].ColumnName;
                    listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    listControl.DataSource = dt;
                }
            }
        }
    }
}
