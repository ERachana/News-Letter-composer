using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Handeledby {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpHandeledby = new Kushal.Controls.KushalGroupBox();
            this.lbl_HandeledBy_Id = new Kushal.Controls.KushalLabel();
            this.lbl_HandeledBy_Name = new Kushal.Controls.KushalLabel();
            this.lbl_HandeledBy_Designation = new Kushal.Controls.KushalLabel();
            this.txt_HandeledBy_Id = new NumericTextBox();
            this.txt_HandeledBy_Name = new Kushal.Controls.KushalTextBox();
            this.txt_HandeledBy_Designation = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnDesignation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(9, 123);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 8;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(121, 123);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 9;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(233, 123);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 10;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(345, 123);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 13;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(322, 459);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpHandeledby.Location = new System.Drawing.Point(8, 1);
            this.grpHandeledby.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpHandeledby.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpHandeledby.Name = "grpHandeledby";
            this.grpHandeledby.Enabled = true;
            this.grpHandeledby.Visible = true;
            this.grpHandeledby.TabIndex = 1;
            this.grpHandeledby.TabStop = false;
            this.grpHandeledby.Size = new System.Drawing.Size(414, 115);
            this.grpHandeledby.Text = @"Employee Details";
            this.grpHandeledby.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpHandeledby.SendToBack();
            this.toolTip1.SetToolTip(this.grpHandeledby, @"");

            this.lbl_HandeledBy_Id.AutoSize = false;
            this.lbl_HandeledBy_Id.Location = new System.Drawing.Point(4, 21);
            this.lbl_HandeledBy_Id.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_HandeledBy_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_HandeledBy_Id.Name = "lbl_HandeledBy_Id";
            this.lbl_HandeledBy_Id.Enabled = true;
            this.lbl_HandeledBy_Id.Visible = true;
            this.lbl_HandeledBy_Id.TabIndex = 3;
            this.lbl_HandeledBy_Id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_HandeledBy_Id.Size = new System.Drawing.Size(100, 23);
            this.lbl_HandeledBy_Id.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HandeledBy_Id.Text = @"* ID";
            this.toolTip1.SetToolTip(this.lbl_HandeledBy_Id, @"");

            this.lbl_HandeledBy_Name.AutoSize = false;
            this.lbl_HandeledBy_Name.Location = new System.Drawing.Point(4, 51);
            this.lbl_HandeledBy_Name.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_HandeledBy_Name.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_HandeledBy_Name.Name = "lbl_HandeledBy_Name";
            this.lbl_HandeledBy_Name.Enabled = true;
            this.lbl_HandeledBy_Name.Visible = true;
            this.lbl_HandeledBy_Name.TabIndex = 5;
            this.lbl_HandeledBy_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_HandeledBy_Name.Size = new System.Drawing.Size(100, 23);
            this.lbl_HandeledBy_Name.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HandeledBy_Name.Text = @"* Name";
            this.toolTip1.SetToolTip(this.lbl_HandeledBy_Name, @"");

            this.lbl_HandeledBy_Designation.AutoSize = false;
            this.lbl_HandeledBy_Designation.Location = new System.Drawing.Point(4, 81);
            this.lbl_HandeledBy_Designation.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_HandeledBy_Designation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_HandeledBy_Designation.Name = "lbl_HandeledBy_Designation";
            this.lbl_HandeledBy_Designation.Enabled = true;
            this.lbl_HandeledBy_Designation.Visible = true;
            this.lbl_HandeledBy_Designation.TabIndex = 7;
            this.lbl_HandeledBy_Designation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_HandeledBy_Designation.Size = new System.Drawing.Size(100, 23);
            this.lbl_HandeledBy_Designation.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HandeledBy_Designation.Text = @"  Designation";
            this.toolTip1.SetToolTip(this.lbl_HandeledBy_Designation, @"");

            this.txt_HandeledBy_Id.Location = new System.Drawing.Point(104, 21);
            this.txt_HandeledBy_Id.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_HandeledBy_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_HandeledBy_Id.Name = "txt_HandeledBy_Id";
            this.txt_HandeledBy_Id.DefaultValue = null;
            this.txt_HandeledBy_Id.FriendlyName = "";
            this.txt_HandeledBy_Id.Enabled = true;
            this.txt_HandeledBy_Id.Visible = true;
            this.txt_HandeledBy_Id.ReadOnly = false;
            this.txt_HandeledBy_Id.TabIndex = 2;
            this.txt_HandeledBy_Id.MaxValue = 2147483647;
            this.txt_HandeledBy_Id.MinValue = -2147483648;
            this.txt_HandeledBy_Id.ValidationMessage = "";
            this.txt_HandeledBy_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_HandeledBy_Id.Size = new System.Drawing.Size(100, 20);
            this.txt_HandeledBy_Id.SelectAllOnFocus = true;
            this.txt_HandeledBy_Id.DoValidation = false;
            this.txt_HandeledBy_Id.AllowNull = false;
            this.txt_HandeledBy_Id.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_HandeledBy_Id, @"");

            this.txt_HandeledBy_Name.Location = new System.Drawing.Point(104, 51);
            this.txt_HandeledBy_Name.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_HandeledBy_Name.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_HandeledBy_Name.Multiline = false;
            this.txt_HandeledBy_Name.MaxLength = 100;
            this.txt_HandeledBy_Name.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_HandeledBy_Name.Name = "txt_HandeledBy_Name";
            this.txt_HandeledBy_Name.Text = @"";
            
            this.txt_HandeledBy_Name.AllowNull = false;
            this.txt_HandeledBy_Name.DefaultValue = "";
            this.txt_HandeledBy_Name.FriendlyName = "";
            this.txt_HandeledBy_Name.ValidationType = TextValidation.None;
            this.txt_HandeledBy_Name.ValidationExpression = @"";
            this.txt_HandeledBy_Name.ValidationMessage = @"";
            this.txt_HandeledBy_Name.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_HandeledBy_Name.Enabled = true;
            this.txt_HandeledBy_Name.ReadOnly = false;
            this.txt_HandeledBy_Name.Visible = true;
            this.txt_HandeledBy_Name.TabIndex = 4;
            this.txt_HandeledBy_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_HandeledBy_Name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_HandeledBy_Name.Size = new System.Drawing.Size(303, 29);
            this.toolTip1.SetToolTip(this.txt_HandeledBy_Name, @"");

            this.txt_HandeledBy_Designation.Location = new System.Drawing.Point(104, 81);
            this.txt_HandeledBy_Designation.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_HandeledBy_Designation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_HandeledBy_Designation.Multiline = false;
            this.txt_HandeledBy_Designation.MaxLength = 100;
            this.txt_HandeledBy_Designation.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_HandeledBy_Designation.Name = "txt_HandeledBy_Designation";
            this.txt_HandeledBy_Designation.Text = @"";
            
            this.txt_HandeledBy_Designation.AllowNull = true;
            this.txt_HandeledBy_Designation.DefaultValue = "";
            this.txt_HandeledBy_Designation.FriendlyName = "";
            this.txt_HandeledBy_Designation.ValidationType = TextValidation.None;
            this.txt_HandeledBy_Designation.ValidationExpression = @"";
            this.txt_HandeledBy_Designation.ValidationMessage = @"";
            this.txt_HandeledBy_Designation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_HandeledBy_Designation.Enabled = true;
            this.txt_HandeledBy_Designation.ReadOnly = false;
            this.txt_HandeledBy_Designation.Visible = true;
            this.txt_HandeledBy_Designation.TabIndex = 6;
            this.txt_HandeledBy_Designation.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_HandeledBy_Designation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_HandeledBy_Designation.Size = new System.Drawing.Size(303, 29);
            this.toolTip1.SetToolTip(this.txt_HandeledBy_Designation, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(8, 158);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(414, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnId.HeaderText = "ID";
            this.dgrDataColumnId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnId.Name = "dgrDataColumnId";
            this.dgrDataColumnId.DataPropertyName = "Id";
            this.dgrDataColumnId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnId.Width = 50;
            this.dgrDataColumnId.Visible = true;
            this.dgrDataColumnId.DisplayIndex = 0;
            this.dgrDataColumnId.ReadOnly = false;
            this.dgrDataColumnId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnId);

            this.dgrDataColumnName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnName.HeaderText = "Name";
            this.dgrDataColumnName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnName.Name = "dgrDataColumnName";
            this.dgrDataColumnName.DataPropertyName = "Name";
            this.dgrDataColumnName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnName.Width = 150;
            this.dgrDataColumnName.Visible = true;
            this.dgrDataColumnName.DisplayIndex = 1;
            this.dgrDataColumnName.ReadOnly = false;
            this.dgrDataColumnName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnName);

            this.dgrDataColumnDesignation.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnDesignation.HeaderText = "Designation";
            this.dgrDataColumnDesignation.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnDesignation.Name = "dgrDataColumnDesignation";
            this.dgrDataColumnDesignation.DataPropertyName = "Designation";
            this.dgrDataColumnDesignation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnDesignation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnDesignation.Width = 150;
            this.dgrDataColumnDesignation.Visible = true;
            this.dgrDataColumnDesignation.DisplayIndex = 2;
            this.dgrDataColumnDesignation.ReadOnly = false;
            this.dgrDataColumnDesignation.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnDesignation);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpHandeledby);
            this.grpHandeledby.Controls.Add(this.lbl_HandeledBy_Id);
            this.grpHandeledby.Controls.Add(this.lbl_HandeledBy_Name);
            this.grpHandeledby.Controls.Add(this.lbl_HandeledBy_Designation);
            this.grpHandeledby.Controls.Add(this.txt_HandeledBy_Id);
            this.grpHandeledby.Controls.Add(this.txt_HandeledBy_Name);
            this.grpHandeledby.Controls.Add(this.txt_HandeledBy_Designation);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Handeledby";
            this.Text = "Handled By";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(445, 523);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpHandeledby;
        private Kushal.Controls.KushalLabel lbl_HandeledBy_Id;
        private Kushal.Controls.KushalLabel lbl_HandeledBy_Name;
        private Kushal.Controls.KushalLabel lbl_HandeledBy_Designation;
        private NumericTextBox txt_HandeledBy_Id;
        private Kushal.Controls.KushalTextBox txt_HandeledBy_Name;
        private Kushal.Controls.KushalTextBox txt_HandeledBy_Designation;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnDesignation;
    }
}