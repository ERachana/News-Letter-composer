using Kushal.Controls;
namespace Newsletter_Composer {
    partial class AboutUsForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.lnkEmail1 = new Kushal.Controls.KushalEmailLabel();
            this.lnkEmail2 = new Kushal.Controls.KushalEmailLabel();
            this.lnkWebsite = new Kushal.Controls.KushalLinkLabel();
            this.SuspendLayout();
            
            
            this.lnkEmail1.AutoSize = false;
            this.lnkEmail1.Location = new System.Drawing.Point(27, 332);
            this.lnkEmail1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lnkEmail1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lnkEmail1.Name = "lnkEmail1";
            this.lnkEmail1.Enabled = true;
            this.lnkEmail1.Visible = true;
            this.lnkEmail1.TabIndex = 0;
            this.lnkEmail1.Size = new System.Drawing.Size(182, 24);
            this.lnkEmail1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkEmail1.Text = @"Info : info@erachana.net";
            this.toolTip1.SetToolTip(this.lnkEmail1, @"");
            this.lnkEmail1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEmail1_LinkClicked);

            this.lnkEmail2.AutoSize = false;
            this.lnkEmail2.Location = new System.Drawing.Point(256, 350);
            this.lnkEmail2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lnkEmail2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lnkEmail2.Name = "lnkEmail2";
            this.lnkEmail2.Enabled = true;
            this.lnkEmail2.Visible = false;
            this.lnkEmail2.TabIndex = 0;
            this.lnkEmail2.Size = new System.Drawing.Size(182, 24);
            this.lnkEmail2.Font = new System.Drawing.Font("Trebuchet MS", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkEmail2.Text = @"Support : info@erachana.net";
            this.toolTip1.SetToolTip(this.lnkEmail2, @"");
            this.lnkEmail2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEmail2_LinkClicked);

            this.lnkWebsite.AutoSize = false;
            this.lnkWebsite.Location = new System.Drawing.Point(27, 281);
            this.lnkWebsite.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lnkWebsite.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lnkWebsite.Name = "lnkWebsite";
            this.lnkWebsite.Enabled = true;
            this.lnkWebsite.Visible = true;
            this.lnkWebsite.TabIndex = 0;
            this.lnkWebsite.Size = new System.Drawing.Size(182, 24);
            this.lnkWebsite.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkWebsite.Text = @"Website : www.erachana.net";
            this.toolTip1.SetToolTip(this.lnkWebsite, @"");
            this.lnkWebsite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkWebsite_LinkClicked);


            
            this.Controls.Add(this.lnkEmail1);
            this.Controls.Add(this.lnkEmail2);
            this.Controls.Add(this.lnkWebsite);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.BackgroundImage = global::Newsletter_Composer.Properties.Resources.AboutUsForm_744;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "AboutUsForm";
            this.Text = "About Us";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(515, 431);
            
                        this.Load += new System.EventHandler(this.AboutUsForm_Load);
            this.Activated += new System.EventHandler(this.AboutUsForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalEmailLabel lnkEmail1;
        private Kushal.Controls.KushalEmailLabel lnkEmail2;
        private Kushal.Controls.KushalLinkLabel lnkWebsite;
    }
}