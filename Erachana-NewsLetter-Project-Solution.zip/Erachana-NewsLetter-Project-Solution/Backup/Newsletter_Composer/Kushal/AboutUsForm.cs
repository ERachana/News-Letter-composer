using System;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class AboutUsForm : Form {
        Label lblUserName = new Label();

        public AboutUsForm() {
            InitializeComponent();

            CreateLabels();
        }

        private void AboutUsForm_Load(object sender, EventArgs e) {
            string userName = GlobalVariables.GetValue("$$UserName"); 
            if (String.IsNullOrEmpty(userName) == false) {
                lblUserName.Text = GlobalVariables.GetValue("$$UserName");
            } else {
                lblUserName.Visible = false;
            }
        }
        private void CreateLabels() {
            lblUserName.AutoSize = true;
            lblUserName.Location = new System.Drawing.Point(456, 357);
            lblUserName.Name = "lblUserName";
            lblUserName.Text = "User name";
            lblUserName.BackColor = System.Drawing.Color.FromArgb(-8000);
            lblUserName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            Controls.Add(lblUserName);
        }

		private void AboutUsForm_Activated(object sender, EventArgs e) { }
        void lnkEmail2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) { }
        void lnkEmail1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) { }
        void lnkWebsite_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) { }
    }
}
