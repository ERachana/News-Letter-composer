using System;
using System.Windows.Forms;

namespace Newsletter_Composer {
    internal class AggregateFunctionEvaluator {
        /// <summary>
        /// Calculate sum of values for the given grid column. Column is required to be a numeric column.
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>Sum of values in the given column</returns>
        public static decimal CalculateSum(DataGridView grid, string column) {
            decimal sum = 0;
            if (grid != null) {
                foreach (DataGridViewRow row in grid.Rows) {
                    if (row.Cells[column] != null && row.Cells[column].Value != DBNull.Value) {
                        sum += Convert.ToDecimal(row.Cells[column].Value);
                    }
                }
            }
            return sum;
        }

        /// <summary>
        /// Calculate average of values of the given column. Column is required to be numeric.
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>Average of values in the given column</returns>
        public static decimal CalculateAvg(DataGridView grid, string column) {
            decimal sum = 0, avg = 0;
            int count = 0;
            foreach (DataGridViewRow row in grid.Rows) {
                if (row.Cells[column] != null && row.Cells[column].Value != DBNull.Value) {
                    sum += Convert.ToDecimal(row.Cells[column].Value);
                }
                count++;
            }

            if (count > 0) {
                avg = (sum / count);
            }

            return avg;
        }
        
        /// <summary>
        /// Calculates number values in the given grid column. 
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>Number of values</returns>
        public static int CalculateCount(DataGridView grid, string column) {
            if (grid == null)
                return 0;

            int count = 0;
            foreach (DataGridViewRow row in grid.Rows) {
                count++;
            }

            return count;
        }

        /// <summary>
        /// Gets the minimum value from the given grid column
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>Minimum value</returns>
        internal static decimal CalculateMin(DataGridView grid, string column) {
            if (grid.Rows.Count == 0) {
                return 0;
            }

            decimal min = decimal.MaxValue;
            for (int i = 0; i < grid.Rows.Count; i++) {
                DataGridViewRow row = grid.Rows[i];

                decimal val = 0;
                if (row.Cells[column] != null && row.Cells[column].Value != DBNull.Value) {
                    val = Convert.ToDecimal(row.Cells[column].Value);
                }

                if (val < min) {
                    min = val;
                }
            }

            return min;
        }

        /// <summary>
        /// Gets the maximum value from the given grid column
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>Maximum value</returns>
        internal static decimal CalculateMax(DataGridView grid, string column) {
            if (grid.Rows.Count == 0) {
                return 0;
            }

            decimal max = decimal.MinValue;
            for (int i = 0; i < grid.Rows.Count; i++) {
                DataGridViewRow row = grid.Rows[i];

                decimal val = 0;
                if (row.Cells[column] != null && row.Cells[column].Value != DBNull.Value) {
                    val = Convert.ToDecimal(row.Cells[column].Value);
                }

                if (val > max) {
                    max = val;
                }
            }

            return max;
        }
        
        /// <summary>
        /// Gets first value from the given grid column
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>First value in thr grid column</returns>
        internal static object FirstValue(DataGridView grid, string column) {
            if (grid.Rows.Count > 0) {
                return grid[column, 0].Value;
            }

            return null;
        }

        /// <summary>
        /// Gets last value from the given grid column
        /// </summary>
        /// <param name="grid">Datagrid containing the column mentioned</param>
        /// <param name="column">Column name to consider</param>
        /// <returns>Last value in thr grid column</returns>
        internal static object LastValue(DataGridView grid, string column) {
            if (grid.Rows.Count > 0) {
                return grid[column, grid.Rows.Count - 1].Value;
            }

            return null;
        }
    }
}
