using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Timer = System.Threading.Timer;

namespace Newsletter_Composer {
    public class AutoClosingMessageBox {
        private const int WM_CLOSE = 0x0010;

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);

        Timer timeoutTimer;
        string caption;

        AutoClosingMessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, int timeout) {
            this.caption = caption;
            timeoutTimer = new Timer(OnTimerElapsed, null, timeout, Timeout.Infinite);
            MessageBox.Show(text, caption, buttons, icon);
        }

        /// <summary>
        /// Shows message window with given message, caption and closes window after the timeout specified.
        /// </summary>
        /// <param name="text">Message text to be displayed</param>
        /// <param name="caption">Caption of the message window</param>
        /// <param name="buttons">Buttons to be displayed. MessageBoxButtons lists default set of buttons supported.</param>
        /// <param name="icon">Icon to be displayed. MessageBoxIcon lists default set of icons supported.</param>
        /// <param name="timeout">Duration after which message box to be closed.</param>
        public static void Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, int timeout) {
            new AutoClosingMessageBox(text, caption, buttons, icon, timeout);
        }

        private void OnTimerElapsed(object state) {
            IntPtr mbWnd = FindWindow(null, caption);
            if (mbWnd != IntPtr.Zero) {
                SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            }

            timeoutTimer.Dispose();
        }
    }
}
