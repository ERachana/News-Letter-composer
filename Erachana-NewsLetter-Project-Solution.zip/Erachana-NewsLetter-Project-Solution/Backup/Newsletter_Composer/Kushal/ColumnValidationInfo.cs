namespace Newsletter_Composer {
    class ColumnValidationInfo {
        public ColumnValueType ValueType { get; set; }

        public decimal MinValue { get; set; }
        public decimal MaxValue { get; set; }
        
        public string ValidationMessage { get; set; }
        public string RegularExpression { get; set; }
    }

    public enum ColumnValueType {
        Text,
        Numeric
    }
}
