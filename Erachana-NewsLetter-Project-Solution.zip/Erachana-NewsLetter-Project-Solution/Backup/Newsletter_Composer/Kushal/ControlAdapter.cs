using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Threading;
using System.Reflection;
using System.IO;
using System.Net;
using System.Web;
using System.Drawing;
using System.Text.RegularExpressions;

namespace Newsletter_Composer {
    internal class ControlAdapter {

        /// <summary>
        /// Reset control to the default value
        /// </summary>
        /// <param name="ctrl">Control name</param>
        public static void ResetControl(Control ctrl) {
            if (ctrl.GetType() == typeof(KushalTextBox)) {
                KushalTextBox txt = (KushalTextBox)ctrl;
                txt.Text = txt.DefaultValue;
            } else if (ctrl.GetType() == typeof(NumericTextBox)) {
                ((NumericTextBox)ctrl).Reset();
            } else if (ctrl.GetType() == typeof(DecimalTextBox)) {
                ((DecimalTextBox)ctrl).Reset();
            } else if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                ((CurrencyTextBox)ctrl).Reset();
            } else if (ctrl.GetType() == typeof(DateTextBox)) {
                ((DateTextBox)ctrl).Reset();
            } else if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                ((FrameworkDateTime)ctrl).Value = DateTime.Now;
            } else if (ctrl.GetType() == typeof(KushalTextBox)) {
                KushalCheckBox chk = (KushalCheckBox)ctrl;
                chk.Checked = chk.DefaultChecked;
            } else if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                ((KushalCheckedListBox)ctrl).SelectedIndex = -1;
            } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                KushalComboBox cmb = (KushalComboBox)ctrl;

                if (cmb.DropDownStyle == ComboBoxStyle.DropDown) {
                    cmb.Text = string.Empty;
                } else if (cmb.DropDownStyle == ComboBoxStyle.DropDownList) {
                    ((KushalComboBox)ctrl).SelectedIndex = -1;
                }
            } else if (ctrl.GetType() == typeof(RadioButtonPanel)) {
                RadioButtonPanel pnl = (RadioButtonPanel)ctrl;
                foreach (Control control in pnl.Controls) {
                    if (control is KushalRadioButton) {
                        KushalRadioButton rb = (KushalRadioButton)control;
                        rb.Checked = false;
                    }
                }
            } else if (ctrl.GetType() == typeof(KushalPictureBox)) {
                KushalPictureBox pb = (KushalPictureBox)ctrl;
                pb.Image = pb.DefaultImage;
            }
        }

        /// <summary>
        /// It takes list of controls and reset all to default value, except key field control. Other multiple keys are ignored
        /// </summary>
        /// <param name="associatedControls">Set of associated controls. Each form contains its own set of associated controls</param>
        /// <param name="keyField">key field name</param>
        public static void ResetControls(Dictionary<string, Control> associatedControls, string keyField) {
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (keyField != key) {
                    ResetControl(ctrl);
                }
            }
        }

        /// <summary>
        /// Get value of the give control
        /// </summary>
        /// <param name="ctrl">Control name</param>
        /// <returns>Value</returns>
        public static object GetValue(Control ctrl) {
            object val = null;
            if (ctrl.GetType() == typeof(KushalTextBox)) {
                KushalTextBox txt = (KushalTextBox)ctrl;
                if (!txt.AllowNull || !String.IsNullOrEmpty(txt.Text))
                    val = txt.Text;
            } else if (ctrl.GetType() == typeof(NumericTextBox)) {
                val = ((NumericTextBox)ctrl).Value;
            } else if (ctrl.GetType() == typeof(DecimalTextBox)) {
                val = ((DecimalTextBox)ctrl).Value;
            } else if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                val = ((CurrencyTextBox)ctrl).Value;
            } else if (ctrl.GetType() == typeof(DateTextBox)) {
                val = ((DateTextBox)ctrl).Value;
            } else if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                val = ((FrameworkDateTime)ctrl).Text;
            } else if (ctrl.GetType() == typeof(DateTimePicker)) {
                DateTimePicker dtp = (DateTimePicker)ctrl;
                if (dtp.Format == DateTimePickerFormat.Time) {
                    TimeSpan timespan = new TimeSpan(dtp.Value.Hour, dtp.Value.Minute, dtp.Value.Second);
                    return timespan;
                }
            } else if (ctrl.GetType() == typeof(KushalCheckBox)) {
                val = ((KushalCheckBox)ctrl).Checked;
            } else if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                val = ((KushalCheckedListBox)ctrl).SelectedValue;
            } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                KushalComboBox cmb = (KushalComboBox)ctrl;
                bool nullable = cmb.AllowNull;
                if (cmb.DropDownStyle == ComboBoxStyle.DropDown) {
                    if (nullable && String.IsNullOrEmpty(cmb.Text)) {
                        val = null;
                    } else {
                        val = cmb.Text;
                    }
                } else if (cmb.DropDownStyle == ComboBoxStyle.DropDownList) {
                    if (nullable && cmb.SelectedIndex < 0) {
                        val = null;
                    } else {
                        if (cmb.DisplayMember == "") {
                            val = cmb.SelectedItem;
                        } else {
                            val = cmb.SelectedValue;
                        }
                    }
                }
            } else if (ctrl.GetType() == typeof(RadioButtonPanel)) {
                RadioButtonPanel pnl = (RadioButtonPanel)ctrl;
                foreach (Control control in pnl.Controls) {
                    if (control is KushalRadioButton) {
                        KushalRadioButton rb = (KushalRadioButton)control;
                        if (rb.Checked) {
                            val = rb.Value;
                            break;
                        }
                    }
                }
            } else if (ctrl.GetType() == typeof(KushalPictureBox)) {
                KushalPictureBox pb = (KushalPictureBox)ctrl;
                if (pb.Image != null) {
                    val = StringImageConverter.ImageToString(pb.Image);
                }
            }
            return val;
        }

        /// <summary>
        /// Get text value of the given control
        /// </summary>
        /// <param name="ctrl">Control name</param>
        /// <returns>Text value of the control</returns>
        public static string GetTextValue(Control ctrl) {
            string val = string.Empty;
            if (ctrl.GetType() == typeof(KushalTextBox)) {
                val = ((KushalTextBox)ctrl).Text;
            } else if (ctrl.GetType() == typeof(NumericTextBox)) {
                val = ((NumericTextBox)ctrl).Text;
            } else if (ctrl.GetType() == typeof(DecimalTextBox)) {
                val = ((DecimalTextBox)ctrl).Text;
            } else if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                val = ((CurrencyTextBox)ctrl).Text;
            } else if (ctrl.GetType() == typeof(DateTextBox)) {
                val = ((DateTextBox)ctrl).Text;
            } else if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                val = String.IsNullOrEmpty(((FrameworkDateTime)ctrl).Text.Trim()) ? ((FrameworkDateTime)ctrl).Text : ((FrameworkDateTime)ctrl).ToString();
            } else if (ctrl.GetType() == typeof(DateTimePicker)) {
                val = String.IsNullOrEmpty(((DateTimePicker)ctrl).Text.Trim()) ? ((DateTimePicker)ctrl).Text : ((DateTimePicker)ctrl).ToString();
            } else if (ctrl.GetType() == typeof(KushalCheckBox)) {
                val = ".";
            } else if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                val = Convert.ToString(((KushalCheckedListBox)ctrl).SelectedValue);
            } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                KushalComboBox cmb = (KushalComboBox)ctrl;
                if (cmb.DropDownStyle == ComboBoxStyle.DropDown) {
                    val = cmb.Text;
                } else if (cmb.DropDownStyle == ComboBoxStyle.DropDownList) {
                    val = Convert.ToString(cmb.DisplayMember == "" ? cmb.SelectedItem : cmb.SelectedValue);
                }
            }
            return val;
        }

        private static string GetDefaultTextValue(Control ctrl) {
            if (ctrl.GetType() == typeof(KushalTextBox)) {
                KushalTextBox txt = (KushalTextBox)ctrl;
                return txt.DefaultValue;
            }
            if (ctrl.GetType() == typeof(NumericTextBox)) {
                return "" + ((NumericTextBox)ctrl).DefaultValue;
            }
            if (ctrl.GetType() == typeof(DecimalTextBox)) {
                return "" + ((DecimalTextBox)ctrl).DefaultValue;
            }
            if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                return "" + ((CurrencyTextBox)ctrl).DefaultValue;
            }
            if (ctrl.GetType() == typeof(DateTextBox)) {
                return "" + ((DateTextBox)ctrl).DefaultValue;
            }
            if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                return "" + ((FrameworkDateTime)ctrl).DefaultValue;
            }
            if (ctrl.GetType() == typeof(DateTimePicker)) {
                //DateTimePicker dtp = (DateTimePicker)ctrl;
                //if (dateDefaultValues.ContainsKey(dtp.Name)) {
                //    return dateDefaultValues[dtp.Name].ToString();
                //} else {
                //    return string.Empty;
                //}
            } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                return string.Empty;
            }
            return string.Empty;
        }

        /// <summary>
        /// Set value to the given control
        /// </summary>
        /// <param name="ctrl">Control name</param>
        /// <param name="val">Value to be set to the control</param>
        public static void SetValue(Control ctrl, object val) {
            if (ctrl.GetType() == typeof(KushalTextBox)) {
                ((KushalTextBox)ctrl).Text = Convert.ToString(val);
            } else if (ctrl.GetType() == typeof(NumericTextBox)) {
                ((NumericTextBox)ctrl).Text = Convert.ToString(val);
            } else if (ctrl.GetType() == typeof(DecimalTextBox)) {
                ((DecimalTextBox)ctrl).Text = Convert.ToString(val);
            } else if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                ((CurrencyTextBox)ctrl).Text = Convert.ToString(val);
            } else if (ctrl.GetType() == typeof(DateTextBox)) {
                if (val == DBNull.Value) {
                    ((DateTextBox)ctrl).Value = null;
                } else {
                    ((DateTextBox)ctrl).Value = (DateTime)(val);
                }
            } else if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                FrameworkDateTime dtp = (FrameworkDateTime)ctrl;
                if (val == DBNull.Value) {
                    dtp.Value = dtp.DefaultValue;
                } else {
                    dtp.Value = (DateTime)(val);
                }
            } else if (ctrl.GetType() == typeof(DateTimePicker)) {
                DateTimePicker dtp = (DateTimePicker)ctrl;
                if (dtp.Format == DateTimePickerFormat.Time) {
                    if (val == DBNull.Value) {
                        ((DateTimePicker)ctrl).Value = DateTime.Now;
                    } else {
                        DateTime now = new DateTime(2000, 1, 1);
                        DateTime time = now.Add((TimeSpan)val);
                        ((DateTimePicker)ctrl).Value = time;
                    }
                }
            } else if (ctrl.GetType() == typeof(KushalCheckBox)) {
                ((KushalCheckBox)ctrl).Checked = val != DBNull.Value && Convert.ToBoolean(val);
            } else if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                ((KushalCheckedListBox)ctrl).SelectedValue = val;
            } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                KushalComboBox cmb = (KushalComboBox)ctrl;
                if (cmb.DropDownStyle == ComboBoxStyle.DropDown) {
                    cmb.Text = val == null ? string.Empty : Convert.ToString(val);
                } else if (cmb.DropDownStyle == ComboBoxStyle.DropDownList) {
                    if (cmb.DisplayMember == "") {
                        cmb.SelectedIndex = cmb.Items.IndexOf(Convert.ToString(val));
                        //cmb.SelectedItem = val;
                    } else if (cmb.Items.Count > 0 && val != null) {
                        cmb.SelectedValue = val;
                    }
                }
            } else if (ctrl.GetType() == typeof(RadioButtonPanel)) {
                RadioButtonPanel pnl = (RadioButtonPanel)ctrl;
                foreach (Control control in pnl.Controls) {
                    if (control is KushalRadioButton) {
                        KushalRadioButton rb = (KushalRadioButton)control;
                        if (rb.Value.ToString() == val.ToString()) {
                            rb.Checked = true;
                            break;
                        }
                    }
                }
            } else if (ctrl.GetType() == typeof(KushalPictureBox)) {
                KushalPictureBox pb = (KushalPictureBox)ctrl;
                if (val != null && val != DBNull.Value && String.IsNullOrEmpty((string)val) == false) {
                    pb.Image = StringImageConverter.StringToImage((string)val);
                } else {
                    pb.Image = null;
                }
            }
        }

        public static bool IsControlNullable(Control ctrl) {
            if (ctrl.GetType() == typeof(KushalTextBox)) {
                return ((KushalTextBox)ctrl).AllowNull;
            }
            if (ctrl.GetType() == typeof(NumericTextBox)) {
                return ((NumericTextBox)ctrl).AllowNull;
            }
            if (ctrl.GetType() == typeof(DecimalTextBox)) {
                return ((DecimalTextBox)ctrl).AllowNull;
            }
            if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                return ((CurrencyTextBox)ctrl).AllowNull;
            }
            if (ctrl.GetType() == typeof(DateTextBox)) {
                return ((DateTextBox)ctrl).AllowNull;
            }
            if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                return ((FrameworkDateTime)ctrl).AllowNull;
            }
            if (ctrl.GetType() == typeof(DateTimePicker)) {
                return false;
            }
            if (ctrl.GetType() == typeof(KushalCheckBox)) {
                return false;
            }
            if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                return true;
            }
            if (ctrl.GetType() == typeof(KushalComboBox)) {
                return ((KushalComboBox)ctrl).AllowNull;
            }
            return true;
        }

        /// <summary>
        /// Retrieves values from selected row and sets data row values to associated controls.
        /// </summary>
        /// <param name="associatedControls">Set of associated controls. Each form contains its own set of associated controls</param>
        /// <param name="grid">Datagrid view</param>
        /// <param name="tableName">Database table name</param>
        public static void SetRowValuesToControls(Dictionary<string, Control> associatedControls, DataGridView grid, string tableName) {
            int rowIndex = grid.SelectedRows[0].Index;
            Dictionary<string, Control> sortedControls = associatedControls.OrderBy(x => x.Value.TabIndex).ToDictionary(x => x.Key, x => x.Value);
            foreach (string key in sortedControls.Keys) {
                foreach (DataGridViewColumn col in grid.Columns) {
                    if (key == (tableName + col.DataPropertyName)) {
                        object val = grid[col.Index, rowIndex].Value;
                        SetValue(sortedControls[key], val);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Checks whether control value is set.
        /// </summary>
        /// <param name="associatedControls">Set of associated controls. Each form contains its own set of associated controls</param>
        /// <param name="dateDefaultValues">Date default values</param>
        /// <param name="textDefaultValues">Text control default values</param>
        /// <param name="keyField">Primary key field</param>
        /// <param name="keyFieldChild">Child table primary key</param>
        /// <returns>True if control value is set, else False</returns>
        public static bool IsControlValueSet(Dictionary<string, Control> associatedControls, string keyField, string keyFieldChild) {
            return false;
        }

        /// <summary>
        /// Checks whether controls associated with selected database row is changed
        /// </summary>
        /// <param name="associatedControls">Set of associated controls. Each form contains its own set of associated controls</param>
        /// <param name="row">Data row selected</param>
        /// <returns>True if control value is changed, else False</returns>
        public static bool IsControlValueChanged(Dictionary<string, Control> associatedControls, DataRow row) {
            return IsControlValueChanged(associatedControls, row, false);
        }

        /// <summary>
        /// Checks whether controls associated with selected database row is changed
        /// </summary>
        /// <param name="associatedControls">Set of associated controls. Each form contains its own set of associated controls</param>
        /// <param name="row">Dara row selected</param>
        /// <param name="isTableNameIncluded">Is table name included</param>
        /// <returns>True if control value is changed, else False</returns>
        public static bool IsControlValueChanged(Dictionary<string, Control> associatedControls, DataRow row, bool isTableNameIncluded) {
            return false;
        }

        /// <summary>
        /// Check whether the given control contains invalid value. Ex: Numeric control with text value
        /// </summary>
        /// <param name="ctrl">Control name</param>
        /// <param name="type">Type of the control</param>
        /// <returns>Return error message, if any</returns>
        public static string CheckForInvalidData(Control ctrl, Type type, string friendlyName) {
            string message = string.Empty;
            try {
                string val = string.Empty;
                if (ctrl.GetType() == typeof(KushalTextBox)) {
                    KushalTextBox txt = (KushalTextBox)ctrl;
                    IsInputValid(txt);
                    if (String.IsNullOrEmpty(ControlValidationMessage) == false) {
                        message = ControlValidationMessage; return message;
                    }
                    val = txt.Text;
                } else if (ctrl.GetType() == typeof(NumericTextBox)) {
                    NumericTextBox numericTextBox = (NumericTextBox)ctrl;
                    if (numericTextBox.IsValidInput == false && String.IsNullOrEmpty(numericTextBox.ValidationMessage) == false) {
                        message = numericTextBox.ValidationMessage; return message;
                    }
                    val = numericTextBox.AllowNull ? "0" : numericTextBox.Text;
                } else if (ctrl.GetType() == typeof(DecimalTextBox)) {
                    DecimalTextBox decimalTextBox = (DecimalTextBox)ctrl;
                    if (decimalTextBox.IsValidInput == false && String.IsNullOrEmpty(decimalTextBox.ValidationMessage) == false) {
                        message = decimalTextBox.ValidationMessage; return message;
                    }
                    val = decimalTextBox.AllowNull ? "0" : decimalTextBox.Text;
                } else if (ctrl.GetType() == typeof(CurrencyTextBox)) {
                    val = ((CurrencyTextBox)ctrl).Text;
                } else if (ctrl.GetType() == typeof(DateTextBox)) {
                    DateTextBox dateTextBox = (DateTextBox)ctrl;
                    if (dateTextBox.IsValidInput == false && String.IsNullOrEmpty(dateTextBox.ValidationMessage) == false) {
                        message = dateTextBox.ValidationMessage; return message;
                    }
                    val = dateTextBox.AllowNull ? DateTime.Now.ToString("yyyy-MM-dd") : ((DateTextBox)ctrl).Value.Value.ToString("yyyy-MM-dd");
                } else if (ctrl.GetType() == typeof(FrameworkDateTime)) {
                    FrameworkDateTime dtp = (FrameworkDateTime)ctrl;
                    IsInputValid(dtp);
                    if (dtp.IsValidInput == false && String.IsNullOrEmpty(dtp.ValidationMessage) == false) {
                        message = dtp.ValidationMessage; return message;
                    }
                    val = (((FrameworkDateTime)ctrl).Value) == null ? null : ((DateTime)((FrameworkDateTime)ctrl).Value).ToString("yyyy-MM-dd");
                } else if (ctrl.GetType() == typeof(KushalCheckedListBox)) {
                    val = Convert.ToString(((KushalCheckedListBox)ctrl).SelectedValue);
                } else if (ctrl.GetType() == typeof(KushalComboBox)) {
                    KushalComboBox cmb = (KushalComboBox)ctrl;
                    if (cmb.AllowNull && (cmb.SelectedIndex < 0 || String.IsNullOrEmpty(cmb.Text))) {
                        return message;
                    }
                    if (cmb.SelectedValue != null) {
                        val = Convert.ToString(cmb.SelectedValue);
                    } else if (String.IsNullOrEmpty(cmb.SelectedText) == false) {
                        val = cmb.SelectedText;
                    } else if (cmb.SelectedItem != null) {
                        val = Convert.ToString(cmb.SelectedItem);
                    } else if (String.IsNullOrEmpty(cmb.Text) == false) {
                        val = cmb.Text;
                    }
                    if (String.IsNullOrEmpty(val)) {
                        return String.IsNullOrEmpty(cmb.FriendlyName) ? "Combo box value is not selected." : "No value selected for " + cmb.FriendlyName;
                    }
                } else if (ctrl.GetType() == typeof(RadioButtonPanel)) {
                    RadioButtonPanel pnl = (RadioButtonPanel)ctrl;
                    foreach (Control control in pnl.Controls) {
                        if (control is KushalRadioButton) {
                            KushalRadioButton rb = (KushalRadioButton)control;
                            if (rb.Checked) {
                                val = rb.Value.ToString();
                                break;
                            }
                        }
                    }
                    if (pnl.AllowNull == false && String.IsNullOrEmpty(val)) {
                        return "No option selected in " + (String.IsNullOrEmpty(pnl.FriendlyName) ? pnl.Name : pnl.FriendlyName);
                    }
                    return string.Empty;
                } else if (ctrl.GetType() == typeof(KushalPictureBox)) {
                    KushalPictureBox pb = (KushalPictureBox)ctrl;
                    Image img = pb.Image;
                    if (pb.AllowNull == false && img == null) {
                        return "No image set to " + (String.IsNullOrEmpty(pb.FriendlyName) ? pb.Name : pb.FriendlyName);
                    }
                    return string.Empty;
                }

                switch (type.ToString()) {
                    case "System.UInt16":
                    case "System.UInt32":
                    case "System.UInt64":
                        ulong u = Convert.ToUInt64(val);
                        break;
                    case "System.Int16":
                    case "System.Int32":
                    case "System.Int64":
                        long l = Convert.ToInt64(val);
                        break;
                    case "System.Decimal":
                        decimal d = Convert.ToDecimal(val);
                        break;
                    case "System.Double":
                        double dd = Convert.ToDouble(val);
                        break;
                    case "System.DateTime":
                        DateTime datetime = Convert.ToDateTime(val);
                        break;
                }
            } catch (Exception exc) {
                message = String.IsNullOrEmpty(friendlyName) == false ? "Value entered for " + friendlyName + " is invalid" : exc.Message;
            }

            return message;
        }

        /// <summary>
        /// Indicates whether validation tooltip to be shown
        /// </summary>
        public static bool ShowValidationToolTip = true;
        public static string ControlValidationMessage = string.Empty;
        private static void IsInputValid(Control control) {
            ShowValidationToolTip = false;
            ControlValidationMessage = string.Empty;
            try {
                Type t = typeof(Control);
                MethodInfo mi = t.GetMethod("NotifyValidating", BindingFlags.Instance | BindingFlags.NonPublic);
                mi.Invoke(control, null);
            } finally {
                ShowValidationToolTip = true;
            }
        }

        /// <summary>
        /// Loads all data source controls.
        /// </summary>
        /// <param name="controls">List of controls</param>
        /// <param name="fieldSqls">Each form contains its own fieldSqls. Pass the same object.</param>
        public static void LoadControlDataSource(List<Control> controls, Dictionary<string, string> fieldSqls) {
            // Load list control data source
            foreach (Control ctrl in controls) {
                string sql = string.Empty;
                ListControl listControl = null;
                if (ctrl.GetType() == typeof(KushalComboBox) || ctrl.GetType() == typeof(ListBox) || ctrl.GetType() == typeof(KushalCheckedListBox)) {
                    listControl = (ListControl)ctrl;
                    sql = fieldSqls[listControl.Name];
                }
                if (String.IsNullOrEmpty(sql) == false && listControl != null) {
                    DataTable dt = DataAdapter.Current.LoadData(sql, "datasource");
                    if (dt != null) {
                        if (listControl is KushalCheckedListBox) {
                            listControl.DataSource = dt;
                            listControl.ValueMember = dt.Columns[0].ColumnName;
                            listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                        } else if (listControl is KushalComboBox || listControl is ListBox) {
                            listControl.ValueMember = dt.Columns[0].ColumnName;
                            listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                            listControl.DataSource = dt;
                        }
                    }
                }
            }

            // Load DataGrid data source
            foreach (Control ctrl in controls) {
                if (ctrl.GetType() == typeof(DataGridView)) {
                    DataGridView dgr = (DataGridView)ctrl;
                    if (fieldSqls.ContainsKey(dgr.Name)) {
                        string sql = fieldSqls[dgr.Name];
                        if (String.IsNullOrEmpty(sql) == false) {
                            DataTable dt = DataAdapter.Current.LoadData(sql, "GridSource");
                            dgr.DataSource = dt;
                        }
                    }

                    // Load DataGrid combobox column
                    foreach (DataGridViewColumn column in dgr.Columns) {
                        if (column is DataGridViewComboBoxColumn && fieldSqls.ContainsKey(column.Name)) {
                            DataGridViewComboBoxColumn cmbCol = (DataGridViewComboBoxColumn)column;
                            string sql = fieldSqls[cmbCol.Name];
                            if (String.IsNullOrEmpty(sql))
                                return;
                            DataTable dt = DataAdapter.Current.LoadData(sql, "ColumnSource" + column.Name);
                            cmbCol.ValueMember = dt.Columns[0].ColumnName;
                            cmbCol.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                            cmbCol.DataSource = dt;
                        }
                    }
                }
            }

            foreach (Control ctrl in controls) {
                if (ctrl.GetType() == typeof(KushalGroupBox)) {
                    List<Control> controlList = new List<Control>();
                    foreach (Control control in ((KushalGroupBox)ctrl).Controls) {
                        controlList.Add(control);
                    }
                    LoadControlDataSource(controlList, fieldSqls);
                } else if (ctrl.GetType() == typeof(KushalTabControl)) {
                    KushalTabControl tabControl = (KushalTabControl)ctrl;
                    List<Control> controlList = new List<Control>();
                    foreach (TabPage page in tabControl.TabPages) {
                        foreach (Control control in page.Controls) {
                            controlList.Add(control);
                        }
                    }
                    LoadControlDataSource(controlList, fieldSqls);
                }
            }
        }

        /// <summary>
        /// Reload dropdown column in a datagrid
        /// </summary>
        /// <param name="columnName">Dropdown column name</param>
        /// <param name="fieldSqls">Each form contains its own fieldSqls. Pass the same object.</param>
        public static void ReloadGridDropdown(DataGridView dgr, string columnName, Dictionary<string, string> fieldSqls) {
            foreach (DataGridViewColumn column in dgr.Columns) {
                if (columnName == column.Name) {
                    DataGridViewComboBoxColumn cmbCol = (DataGridViewComboBoxColumn)column;
                    string sql = fieldSqls[cmbCol.Name];
                    if (String.IsNullOrEmpty(sql))
                        return;
                    DataTable dt = DataAdapter.Current.LoadData(sql, "ColumnSource" + column.Name);
                    cmbCol.ValueMember = dt.Columns[0].ColumnName;
                    cmbCol.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    cmbCol.DataSource = dt;
                }
            }
        }

        /// <summary>
        /// Get value of the ID field control
        /// </summary>
        /// <param name="associatedControls">List of associated controls</param>
        /// <param name="keyField">Key field name. Table name is concatinated in case of parent child forms</param>
        /// <returns>Key field value</returns>
        public static object GetIdFieldValue(Dictionary<string, Control> associatedControls, string keyField) {
            object val = null;
            foreach (string key in associatedControls.Keys) {
                if (key == keyField) {
                    Control ctrl = associatedControls[key];
                    val = GetValue(ctrl);
                }
            }
            return val;
        }

        /// <summary>
        /// Set ID value where ID field is not numeric
        /// </summary>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="additionalKeys">List of additional keys</param>
        /// <param name="tableName">Table name</param>
        /// <param name="isTableNameIncluded">Indicate whether table name is included with key values</param>
        public static void BeginNewItem_None(Dictionary<string, Control> associatedControls, List<string> additionalKeys, string tableName, bool isTableNameIncluded) {
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (additionalKeys.Contains((isTableNameIncluded ? key.Substring(tableName.Length) : key)) == false)
                    ResetControl(ctrl);
            }
            FocusControl(associatedControls, string.Empty);
        }

        /// <summary>
        /// Set child ID value where ID field is not numeric
        /// </summary>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="additionalKeys">List of additional keys</param>
        /// <param name="tableName">Table name</param>
        /// <param name="isTableNameIncluded">Indicate whether table name is included with key values</param>
        public static void BeginNewItemChild_None(Dictionary<string, Control> associatedControls, List<string> additionalKeys, string tableName, bool isTableNameIncluded) {
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (key.StartsWith(tableName))
                    ResetControl(ctrl);
            }
            FocusControl(associatedControls, string.Empty);
        }

        /// <summary>
        /// Set ID value where ID field is numeric
        /// </summary>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="keyField">Key field name. Table name is concatinated in case of parent child forms</param>
        /// <param name="additionalKeys">List of additional keys</param>
        /// <param name="tableName">Table name</param>
        /// <param name="isTableNameIncluded">Indicate whether table name is included with key values</param>
        /// <param name="dataAdapter">Database adapter</param>
        public static void BeginNewItem_Id(Dictionary<string, Control> associatedControls, string keyField, List<string> additionalKeys, string tableName, bool isTableNameIncluded, DataAdapter dataAdapter) {
            if (String.IsNullOrEmpty(keyField))
                MessageBox.Show("Key field for this form is not set.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            int rowsCount = GetRowsCount(tableName, dataAdapter);
            // set additional key default values
            foreach (string key in associatedControls.Keys) {
                if (additionalKeys.Contains(key)) {
                    Control ctrl = associatedControls[key];
                    if ((ctrl is KushalComboBox) == false && (ctrl is RadioButtonPanel) == false)
                        ResetControl(ctrl);
                }
            }

            // check whether controls with additional keys associated value is set
            foreach (string key in associatedControls.Keys) {
                if (additionalKeys.Contains(key)) {
                    Control ctrl = associatedControls[key];
                    object val = GetValue(ctrl);
                    if (val == null && rowsCount > 0) {
                        MessageBox.Show("Value of control associated with primary key: " + key + " is not set.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    break;
                }
            }

            // Maintain additional key values
            Dictionary<string, object> additionalKeyValues = new Dictionary<string, object>();
            foreach (string key in associatedControls.Keys) {
                //if (additionalKeys.Count > 0) {
                    if (additionalKeys.Contains((isTableNameIncluded ? key.Substring(tableName.Length) : key))) {
                        Control ctrl = associatedControls[key];
                        object val = GetValue(ctrl);
                        additionalKeyValues.Add(key, val);
                    }
                //}
            }

            // Set key field control value
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (keyField == key)
                    ((TextBox)ctrl).Text = (GetAutoIncrementValue((isTableNameIncluded ? keyField.Substring(tableName.Length) : keyField), associatedControls, additionalKeys, tableName, isTableNameIncluded, rowsCount, dataAdapter) + 1).ToString();
            }

            // Reset control values and set new key value
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                //if (additionalKeys.Count > 0) {
                    if (keyField != key && additionalKeys.Contains((isTableNameIncluded ? key.Substring(tableName.Length) : key)) == false) {
                        ResetControl(ctrl);
                    }
                //}
            }

            // Set additional key values back again
            foreach (string key in associatedControls.Keys) {
                if (additionalKeyValues.ContainsKey(key)) {
                    Control ctrl = associatedControls[key];
                    SetValue(ctrl, additionalKeyValues[key]);
                }
            }
            FocusControl(associatedControls, string.Empty);
        }

        /// <summary>
        /// Set child ID value where ID field is numeric
        /// </summary>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="keyField">Key field name. Table name is concatinated in case of parent child forms</param>
        /// <param name="additionalKeys">List of additional keys</param>
        /// <param name="tableName">Table name</param>
        /// <param name="isTableNameIncluded">Indicate whether table name is included with key values</param>
        /// <param name="dataAdapter">Database adapter</param>
        public static void BeginNewItemChild_Id(Dictionary<string, Control> associatedControls, string keyField, List<string> additionalKeys, string tableName, bool isTableNameIncluded, DataAdapter dataAdapter) {
            if (String.IsNullOrEmpty(keyField)) {
                MessageBox.Show("Key field for this form is not set.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            int rowsCount = GetRowsCount(tableName, dataAdapter);

            // Reset control values and set new key value
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                string formattedKey = (isTableNameIncluded ? (key.Length > tableName.Length ? key.Substring(tableName.Length) : key) : key);
                if (keyField == key) {
                    ((TextBox)ctrl).Text = (GetAutoIncrementValue((isTableNameIncluded ? keyField.Substring(tableName.Length) : keyField), associatedControls, additionalKeys, tableName, isTableNameIncluded, rowsCount, dataAdapter) + 1).ToString();
                } else if (additionalKeys.Contains(formattedKey) == false && key.StartsWith(tableName)) {
                    ResetControl(ctrl);
                }
            }
            FocusControl(associatedControls, tableName);
        }

        /// <summary>
        /// Get next numeric value for the given field
        /// </summary>
        /// <param name="field">Field name</param>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="additionalKeys">List of additional keys</param>
        /// <param name="tableName">Table name</param>
        /// <param name="isTableNameIncluded">Indicate whether table name is included with key values</param>
        /// <param name="rowsCount">Number of rows</param>
        /// <param name="dataAdapter">Database adapter</param>
        /// <returns>Next numeric value</returns>
        public static long GetAutoIncrementValue(string field, Dictionary<string, Control> associatedControls, List<string> additionalKeys, string tableName, bool isTableNameIncluded, int rowsCount, DataAdapter dataAdapter) {
            long value = 0;
            if (String.IsNullOrEmpty(field) == false) {
                string condition = string.Empty;
                if (additionalKeys.Count > 0 && rowsCount > 0) {
                    List<string> conditions = new List<string>();
                    foreach (string key in additionalKeys) {
                        string formattedKey = (isTableNameIncluded ? tableName : "") + key;
                        if (associatedControls.ContainsKey(formattedKey)) {
                            Control ctrl = associatedControls[formattedKey];
                            object val = GetValue(ctrl);
                            if (val != null) {
                                conditions.Add(String.Format("{0} = {1}{2}{1}", key, (val is string ? "'" : ""), Convert.ToString(val)));
                            }
                        }
                    }
                    if (conditions.Count > 0) {
                        condition = " WHERE " + String.Join(" AND ", conditions.ToArray());
                    }
                }

                string sql = String.Format(@"SELECT MAX({0}) FROM [{1}]{2};", field, tableName, condition);
                DataTable dt1 = dataAdapter.LoadData(sql, Guid.NewGuid().ToString());
                if (dt1 != null && dt1.Rows.Count > 1 && dt1.Rows[1][0] != DBNull.Value) {
                    value = Convert.ToInt64(dt1.Rows[1][0]);
                } else if (dt1 != null && dt1.Rows.Count > 0 && dt1.Rows[0][0] != DBNull.Value) {
                    value = Convert.ToInt64(dt1.Rows[0][0]);
                }
            }
            return value;
        }

        private static int GetRowsCount(string tableName, DataAdapter dataAdapter) {
            string sql = "SELECT * FROM [" + tableName + "]";
            DataTable dt1 = dataAdapter.LoadData(sql, Guid.NewGuid().ToString());
            return dt1 == null ? 0 : dt1.Rows.Count;
        }

        internal static bool IsIdValueExists(int value, string columnName, string tableName, DataAdapter dataAdapter) {
            string sql = String.Format("select {0} as val from {1} where {0} = {2}", columnName, tableName, value);
            DataTable dt = dataAdapter.LoadData(sql, Guid.NewGuid().ToString());
            return dt != null && dt.Rows.Count > 0;
        }

        /// <summary>
        /// Gets maximum value for the given column
        /// </summary>
        /// <param name="associatedControls">Set of associated controls. Each form contains its own set of associated controls</param>
        /// <param name="columnName">Column name</param>
        /// <param name="additionalKeys">Multiple primary keys</param>
        /// <param name="tableName">Database table name</param>
        /// <param name="isTableNameIncluded">Indicates whether table name is included</param>
        /// <param name="dataAdapter">Database adapter</param>
        /// <returns>Maximum value</returns>
        internal static int GetMaxValue(Dictionary<string, Control> associatedControls, string columnName, List<string> additionalKeys, string tableName, bool isTableNameIncluded, DataAdapter dataAdapter) {
            string condition = string.Empty;
            if (additionalKeys.Count > 0) {
                List<string> conditions = new List<string>();
                foreach (string key in additionalKeys) {
                    string formattedKey = (isTableNameIncluded ? tableName : "") + key;
                    if (associatedControls.ContainsKey(formattedKey)) {
                        Control ctrl = associatedControls[formattedKey];
                        object val = GetValue(ctrl);
                        if (val != null) {
                            conditions.Add(String.Format("{0} = {1}{2}{1}", key, (val is string ? "'" : ""), Convert.ToString(val)));
                        }
                    }
                }
                if (conditions.Count > 0) {
                    condition = " WHERE " + String.Join(" AND ", conditions.ToArray());
                }
            }
            string sql = String.Format("SELECT Max({0}) FROM [{1}]", columnName, tableName);
            if (String.IsNullOrEmpty(condition) == false) {
                sql += condition;
            }
            DataTable dt = dataAdapter.LoadData(sql, Guid.NewGuid().ToString());
            if (dt != null && dt.Rows.Count > 0 && dt.Rows[0][0] != DBNull.Value) {
                return TypeConverter.ConvertToInt(dt.Rows[0][0]);
            }
            return 0;
        }

        /// <summary>
        /// Get associated column name for the given grid column
        /// </summary>
        /// <param name="grid">Data grid name</param>
        /// <param name="columnName">Column Name</param>
        /// <returns>Associated column name</returns>
        internal static string GetColumnName(DataGridView grid, string columnName) {
            string colName = string.Empty;
            foreach (DataGridViewColumn column in grid.Columns) {
                if (column.DataPropertyName == columnName) {
                    colName = column.Name;
                    break;
                }
            }

            return colName;
        }

        private static void FocusControl(Dictionary<string, Control> associatedControls, string childTableName) {
            int minIndex = Int32.MaxValue;
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (minIndex >= ctrl.TabIndex)
                    minIndex = ctrl.TabIndex;
            }
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                if (String.IsNullOrEmpty(childTableName) == false && key.StartsWith(childTableName) == false) {
                    continue;
                }
                if (ctrl.TabIndex == minIndex) {
                    ctrl.Focus();
                    break;
                }
            }
        }

        /// <summary>
        /// Validates input controls
        /// </summary>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="tableName">Table name</param>
        /// <param name="dataAdapter">Database adapter</param>
        /// <param name="dataTable">Data table (Data source)</param>
        /// <returns>True if validation is successful, False otherwise</returns>
        public static bool ValidateInput(Dictionary<string, Control> associatedControls, string tableName, DataAdapter dataAdapter, DataTable dataTable) {
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                // Unique or primary field, but value is empty
                bool valid = CheckForNull(key, ctrl);
                if (valid == false)
                    return false;

                // Invalid data type
                valid = CheckForInvalidData(ctrl, associatedControls, dataTable, dataAdapter);
                if (valid == false)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Validate input controls
        /// </summary>
        /// <param name="newRecord">Indicate whether it is a new record</param>
        /// <param name="associatedControls">Set of associated controls</param>
        /// <param name="uniqueControls">Set of controls defined</param>       
        /// <param name="additionalKeys">Set of additional keys</param>
        /// <param name="tableName">Table name</param>
        /// <param name="dataAdapter">Database adapter</param>
        /// <param name="dgrData">Data grid</param>
        /// <returns>True if validation is successful, False otherwise</returns>
        public static bool ValidateInput(bool showMessage, bool newRecord, Dictionary<string, Control> associatedControls, Dictionary<string, Control> uniqueControls, List<string> additionalKeys, string tableName, DataAdapter dataAdapter, DataGridView dgrData) {
            bool valid = true;
            foreach (string key in associatedControls.Keys) {
                Control ctrl = associatedControls[key];
                // Unique or primary field, but value is empty
                valid = CheckForNull(key, ctrl);
                if (valid == false)
                    return false;

                // Invalid data type
                valid = CheckForInvalidData(ctrl, associatedControls, dgrData, dataAdapter);
                if (valid == false)
                    return false;
            }

            // Duplicate values
            valid = CheckForDuplicateData(showMessage, tableName, dgrData, associatedControls, uniqueControls);
            if (valid == false)
                return false;

            // validate table with multiple keys
            List<string> multipleKeys = GetTableKeyColumns(tableName, dataAdapter);
            if (multipleKeys.Count > 1) {
                valid = CheckForMultipleKeyDuplicateData(showMessage, multipleKeys, tableName, dgrData, associatedControls, dataAdapter);
                if (valid == false)
                    return false;
            }
            return true;
        }

        private static List<string> GetTableKeyColumns(string tableName, DataAdapter dataAdapter) {
            List<string> columnNames = new List<string>();
            DataTable table = dataAdapter.GetSchemaTable("select * from " + tableName, CommandBehavior.KeyInfo);
            foreach (DataRow row in table.Rows) {
                if (row["IsKey"] != DBNull.Value && (bool)row["IsKey"]) {
                    columnNames.Add((string)row[0]);
                }
            }
            return columnNames;
        }

        private static bool CheckForMultipleKeyDuplicateData(bool showMessage, List<string> columnNames, string tableName, DataGridView dgrData, Dictionary<string, Control> associatedControls, DataAdapter dataAdapter) {
            DataTable table = new DataTable();
            foreach (string columnName in columnNames) {
                table.Columns.Add(columnName);
            }

            // set control values
            DataRow controlRow = table.NewRow();
            bool tableNameIncluded = IsTableNameIncluded(associatedControls, tableName, dataAdapter);
            foreach (string key in associatedControls.Keys) {
                string formattedKey = tableNameIncluded ? key.Replace(tableName, "") : key;
                if (columnNames.Contains(formattedKey)) {
                    Control ctrl = associatedControls[key];
                    string val = GetTextValue(ctrl);
                    controlRow[formattedKey] = val;
                }
            }

            table.Rows.Add(controlRow);

            // load all data grid values
            foreach (DataGridViewRow row in dgrData.Rows) {
                if (row.Selected || row.IsNewRow)
                    continue;
                DataRow r = table.NewRow();
                foreach (DataGridViewColumn column in dgrData.Columns) {
                    if (columnNames.Contains(column.DataPropertyName)) {
                        object val = row.Cells[column.Name].Value;
                        if (val != null) {
                            string value = Convert.ToString(val);
                            r[column.DataPropertyName] = value;
                        }
                    }
                }
                table.Rows.Add(r);
            }

            // check for duplicates in data table
            DataTable distinct = table.DefaultView.ToTable(true, columnNames.ToArray());
            bool valid = distinct.Rows.Count == table.Rows.Count;
            if (valid == false && showMessage)
                MessageBox.Show("Table " + tableName + " with multiple keys contains duplicate values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return valid;
        }

        private static bool IsTableNameIncluded(Dictionary<string, Control> associatedControls, string tableName, DataAdapter dataAdapter) {
            bool included = true;

            DataTable table = dataAdapter.GetSchemaTable("select * from [" + tableName + "]", CommandBehavior.KeyInfo);
            foreach (DataRow row in table.Rows) {
                string name = (string)row[0];

                included = associatedControls.ContainsKey(name) == false;
            }

            return included;
        }

        private static bool CheckForNull(string name, Control control) {
            bool allowNull = IsControlNullable(control);
            string friendlyName = GetFriendlyName(control);
            if (allowNull == false) {
                string val = GetTextValue(control);
                if (String.IsNullOrEmpty(val.Trim())) {
                    MessageBox.Show("Value of " + (String.IsNullOrEmpty(friendlyName) ? ("column " + name) : friendlyName) + " cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            return true;
        }

        private static bool CheckForNull(string name, string tableName, Control ctrl, DataAdapter dataAdapter) {
            DataTable table = dataAdapter.GetSchemaTable("select * from [" + tableName + "]");
            foreach (DataRow row in table.Rows) {
                if ((string)row[0] == name) {
                    if ((bool)row["AllowDBNull"] == false) {
                        string val = GetTextValue(ctrl);
                        if (String.IsNullOrEmpty(val.Trim())) {
                            MessageBox.Show("Value of column " + (string)row[0] + " cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        private static bool CheckForInvalidData(Control ctrl, Dictionary<string, Control> associatedControls, DataGridView dgrData, DataAdapter dataAdapter) {
            DataTable table = (DataTable)dgrData.DataSource;
            return CheckForInvalidData(ctrl, associatedControls, table, dataAdapter);
        }

        private static bool CheckForInvalidData(Control ctrl, Dictionary<string, Control> associatedControls, DataTable table, DataAdapter dataAdapter) {
            bool tableNameIncluded = IsTableNameIncluded(associatedControls, table.TableName, dataAdapter);
            foreach (DataColumn col in table.Columns) {
                if (associatedControls.ContainsKey((tableNameIncluded ? table.TableName : "") + col.ColumnName)) {
                    string friendlyName = GetFriendlyName(associatedControls[(tableNameIncluded ? table.TableName : "") + col.ColumnName]);
                    string message = CheckForInvalidData(associatedControls[(tableNameIncluded ? table.TableName : "") + col.ColumnName], col.DataType, friendlyName);
                    if (String.IsNullOrEmpty(message) == false) {
                        MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            return true;
        }

        private static bool CheckForDuplicateData(bool showMessage, string tableName, DataGridView dgrData, Dictionary<string, Control> associatedControls, Dictionary<string, Control> uniqueControls) {
            if (uniqueControls.Count > 0) {
                foreach (string key in uniqueControls.Keys) {
                    Control ctrl = uniqueControls[key];
                    string val = GetTextValue(ctrl);
                    List<string> values = new List<string> ();
                    values.Add(val);

                    // get respective column
                    DataGridViewColumn dataColumn = null;
                    foreach (DataGridViewColumn column in dgrData.Columns) {
                        if (tableName + column.DataPropertyName == key) {
                            dataColumn = column;
                            break;
                        }
                    }

                    // get all row values for the current column
                    if (dataColumn != null) {
                        foreach (DataGridViewRow row in dgrData.Rows) {
                            if (row.Selected == false) { // selected row value is already added to the list
                                object value = row.Cells[dataColumn.Name].Value;
                                if (value != null) {
                                    string cellValue = value.ToString();
                                    // empty value is ignored
                                    if (String.IsNullOrEmpty(cellValue) == false) {
                                        if (values.Contains(cellValue) == false) {
                                            values.Add(value.ToString());
                                        } else {
                                            if (showMessage)
                                                MessageBox.Show("Duplicate value: " + cellValue + " found in column " + dataColumn.HeaderText, "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Move selected tree view node left. This changes the level of selected tree node
        /// </summary>
        /// <param name="treeView">Treeview Control</param>
        internal static void MoveNodeLeft(TreeView treeView) {
            TreeNode parent = treeView.SelectedNode.Parent;
            if (parent == null)
                return;
            TreeNode grandParent = parent.Parent;
            TreeNodeCollection nodeCollection = null;
            nodeCollection = grandParent == null ? treeView.Nodes : grandParent.Nodes;
            int index = nodeCollection.IndexOf(parent);
            RearrageNode(treeView, nodeCollection, index + 1);
            SaveTreeView(treeView);
        }

        /// <summary>
        /// Move selected tree view node right. This changes the level of selected tree node
        /// </summary>
        /// <param name="treeView">Treeview Control</param>
        internal static void MoveNodeRight(TreeView treeView) {
            TreeNode parent = treeView.SelectedNode.Parent;
            TreeNodeCollection parentNodeCollection = null;
            parentNodeCollection = parent == null ? treeView.Nodes : parent.Nodes;

            int nodeIndex = parentNodeCollection.IndexOf(treeView.SelectedNode);
            if (nodeIndex == 0)
                return;
            TreeNode prevNode = parentNodeCollection[nodeIndex - 1];
            TreeNodeCollection nodeCollection = prevNode.Nodes;
            RearrageNode(treeView, nodeCollection, nodeCollection.Count);
            SaveTreeView(treeView);
        }

        /// <summary>
        /// Move selected tree view node upwards. 
        /// </summary>
        /// <param name="treeView">Treeview Control</param>
        internal static void MoveNodeUp(TreeView treeView) {
            TreeNode parent = treeView.SelectedNode.Parent;
            TreeNodeCollection nodeCollection = null;
            if (parent != null) {
                nodeCollection = parent.Nodes;
            } else {
                nodeCollection = treeView.Nodes;
            }
            int index = nodeCollection.IndexOf(treeView.SelectedNode);
            if (index == 0)
                return;
            RearrageNode(treeView, nodeCollection, index - 1);
            SaveTreeView(treeView);
        }

        /// <summary>
        /// Move selected tree view node downwards. 
        /// </summary>
        /// <param name="treeView">Treeview Control</param>
        internal static void MoveNodeDown(TreeView treeView) {
            TreeNode parent = treeView.SelectedNode.Parent;
            TreeNodeCollection nodeCollection = null;
            if (parent != null) {
                nodeCollection = parent.Nodes;
            } else {
                nodeCollection = treeView.Nodes;
            }
            int index = nodeCollection.IndexOf(treeView.SelectedNode);
            if (index == nodeCollection.Count - 1)
                return;
            RearrageNode(treeView, nodeCollection, index + 1);
            SaveTreeView(treeView);
        }

        /// <summary>
        /// Re-arrange given treeview control.
        /// </summary>
        /// <param name="treeView">Treeview control</param>
        /// <param name="nodeCollection">Tree node collection</param>
        /// <param name="index">Index of tree node collection</param>
        internal static void RearrageNode(TreeView treeView, TreeNodeCollection nodeCollection, int index) {
            string text = treeView.SelectedNode.Text;
            object tag = treeView.SelectedNode.Tag;
            List<TreeNode> nodes = new List<TreeNode>();
            foreach (TreeNode node in treeView.SelectedNode.Nodes) {
                nodes.Add(node);
            }
            treeView.SelectedNode.Remove();
            TreeNode newNode = new TreeNode(text, nodes.ToArray());
            newNode.Expand();
            newNode.Tag = tag;
            nodeCollection.Insert(index, newNode);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="treeView1"></param>
        /// <param name="tableName"></param>
        /// <param name="idField"></param>
        /// <param name="keyField"></param>
        /// <param name="parentKeyField"></param>
        /// <param name="displayText"></param>
        internal static void LoadTreeView(TreeView treeView1, string tableName, string idField, string keyField, string parentKeyField, string displayText) {
            treeView1.Nodes.Clear();
            // Load data from database table
            DataTable dt = DataAdapter.Current.LoadData("select * from " + tableName, tableName);
            if (dt != null) {
                for (int i = 0; ; i++) {
                    int nodesAdded = CreateNodes(treeView1, tableName, i, dt.Rows, idField, keyField, parentKeyField, displayText);
                    if (nodesAdded == 0) {
                        break;
                    }
                }
            }
        }

        private static int CreateNodes(TreeView treeview, string tableName, int level, DataRowCollection rows, string idField, string keyField, string parentKeyField, string displayText) {
            int nodesAdded = 0;
            foreach (DataRow row in rows) {
                int idVal = Convert.ToInt32(row[idField]);
                string key = (string)row[keyField];
                string text = (string)row[displayText];
                string id = GetLevel_N_Id(key, level, false);
                TreeNode existingNode = GetNodeForId(treeview.Nodes, id);
                if (existingNode != null && existingNode.Level == level) {
                    continue;
                }
                if (String.IsNullOrEmpty(id) == false) {
                    string parentId = GetLevel_N_Id(key, level - 1, true);
                    TreeNode node = null;
                    if (String.IsNullOrEmpty(parentId)) {
                        node = treeview.Nodes.Add(text);
                        nodesAdded++;
                    } else {
                        TreeNode parentNode = GetNodeForId(treeview.Nodes, parentId);
                        if (parentNode != null) {
                            node = parentNode.Nodes.Add(text);
                            nodesAdded++;
                        }
                    }
                    if (node != null) {
                        string keyVal = (parentId + "|" + id).Trim("|".ToCharArray());
                        node.Tag = new TreeNodeInfo { TableName = tableName, Key = keyVal, KeyFieldName = keyField, ParentKeyFieldName = parentKeyField, DisplayText = text, DisplayTextFieldName = displayText, SerialNumer = idVal, SerialNumerFieldName = idField, AltText = "" };
                    }
                }
            }
            return nodesAdded;
        }

        private static TreeNode GetNodeForId(TreeNodeCollection nodes, string parentId) {
            TreeNode treeNode = null;
            foreach (TreeNode node in nodes) {
                TreeNodeInfo info = (TreeNodeInfo)node.Tag;
                if (info.Key == parentId) {
                    treeNode = node;
                    break;
                }
                if (node.Nodes.Count > 0) {
                    treeNode = GetNodeForId(node.Nodes, parentId);
                    if (treeNode != null) {
                        break;
                    }
                }
            }
            return treeNode;
        }

        private static string GetLevel_N_Id(string key, int level, bool fullId) {
            if (level < 0)
                return "";
            string[] vals = key.Split("|".ToCharArray());
            if (fullId == false && vals.Length > (level + 1))
                return "";
            if (vals != null && vals.Length > level) {
                if (fullId) {
                    List<string> fullVal = new List<string>();
                    for (int i = 0; i <= level; i++) {
                        fullVal.Add(vals[i]);
                    }
                    return String.Join("|", fullVal.ToArray());
                }
                return vals[level];
            }
            return "";
        }

        /// <summary>
        /// Save given treeview control
        /// </summary>
        /// <param name="treeview">Name of treeview control</param>
        internal static void SaveTreeView(TreeView treeview) {// Recursively create nodes
            CreateNodeRecords(treeview.Nodes);
        }

        private static void CreateNodeRecords(TreeNodeCollection nodes) {
            foreach (TreeNode node in nodes) {
                TreeNodeInfo info = (TreeNodeInfo)node.Tag;
                string sql = "UPDATE " + info.TableName + " SET ###TreeKeyField = '###TreeKeyVal', ###ParentKeyField = '###ParentKeyVal', ###DisplayField = '###DisplayVal' WHERE ###IdField = ###IdVal";
                sql = sql.Replace("###IdField", info.SerialNumerFieldName);
                sql = sql.Replace("###TreeKeyField", info.KeyFieldName);
                sql = sql.Replace("###ParentKeyField", info.ParentKeyFieldName);
                sql = sql.Replace("###DisplayField", info.DisplayTextFieldName);
                sql = sql.Replace("###IdVal", info.SerialNumer.ToString());

                // Id next to its previous node
                SetTreeNodeKey(node);
                sql = sql.Replace("###TreeKeyVal", info.Key);
                string[] keyVals = info.Key.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                if (keyVals.Length == 1) {
                    sql = sql.Replace("###ParentKeyVal", "");
                } else if (keyVals.Length > 1) {
                    List<string> parentKeyVals = new List<string>();
                    for (int i = 0; i < keyVals.Length - 1; i++) {
                        parentKeyVals.Add(keyVals[i]);
                    }
                    sql = sql.Replace("###ParentKeyVal", String.Join("|", parentKeyVals.ToArray()));
                }
                sql = sql.Replace("###DisplayVal", info.DisplayText);
                DataAdapter.Current.ExecuteSql(sql);
                if (node.Nodes.Count > 0) {
                    CreateNodeRecords(node.Nodes);
                }
            }
        }

        private static void SetTreeNodeKey(TreeNode node) {
            TreeNodeInfo info = (TreeNodeInfo)node.Tag;
            string parentKey = string.Empty;
            if (node.Parent != null) {
                TreeNodeInfo parentInfo = (TreeNodeInfo)node.Parent.Tag;
                parentKey = parentInfo.Key;
            }
            string[] vals = null;
            if (node.PrevNode != null) {
                vals = ((TreeNodeInfo)node.PrevNode.Tag).Key.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            }
            string prevNodeIndex = "0";
            if (vals != null && vals.Length == 1) {
                prevNodeIndex = vals[0];
            } else if (vals != null && vals.Length > 1) {
                prevNodeIndex = vals[vals.Length - 1];
            } else {
                prevNodeIndex = "-1";
            }
            string currentNodeIndex = (Convert.ToInt32(prevNodeIndex) + 1).ToString().PadLeft(3, '0');
            info.Key = parentKey + "|" + currentNodeIndex;
            info.Key = info.Key.Trim("|".ToCharArray());
        }

        private static string GetTreeNodeFormattedKey(TreeNode node) {
            List<string> keys = new List<string>();
            TreeNodeInfo nodeInfo = (TreeNodeInfo)node.Tag;
            nodeInfo.Key = node.Index.ToString().PadLeft(3, '0');
            keys.Add(nodeInfo.Key);
            TreeNode parent = node.Parent;
            while (parent != null) {
                TreeNodeInfo info = (TreeNodeInfo)parent.Tag;
                keys.Add(info.Key);
                parent = parent.Parent;
            }
            keys.Reverse();
            return String.Join("|", keys.ToArray());
        }

        /// <summary>
        /// Filter ListBox or ComboBox control.
        /// </summary>
        /// <param name="listControl">Name of list box or combo box control</param>
        /// <param name="condition">Filter condition</param>
        /// <param name="fieldSqls">Set of fields and SQL statements. Each form contains fieldSqls. Pass the same object</param>
        internal static void Filter(ListControl listControl, string condition, Dictionary<string, string> fieldSqls) {
            if (fieldSqls.ContainsKey(listControl.Name) ) {
                string sql = fieldSqls[listControl.Name];
                DataTable dt = GetFilteredData(sql, condition, "datasource" + listControl.Name);
                if (dt != null) {
                    listControl.ValueMember = dt.Columns[0].ColumnName;
                    listControl.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    listControl.DataSource = dt;
                }
            }
        }

        /// <summary>
        /// Filter drop down column inside data grid control. This function is NOT suitable for filtering grid values
        /// </summary>
        /// <param name="dgr">Data grid</param>
        /// <param name="columnName">Name of the grid column</param>
        /// <param name="condition">Filter condition</param>
        /// <param name="fieldSqls">Set of fields and SQL statements. Each form contains fieldSqls. Pass the same object</param>
        internal static void Filter(DataGridView dgr, string columnName, string condition, Dictionary<string, string> fieldSqls) {
            if (fieldSqls.ContainsKey(columnName)) {
                string sql = fieldSqls[columnName];
                DataTable dt = GetFilteredData(sql, condition, "datasource" + columnName);
                if (dt != null) {
                    DataGridViewComboBoxColumn col = (DataGridViewComboBoxColumn)dgr.Columns[columnName];
                    col.ValueMember = dt.Columns[0].ColumnName;
                    col.DisplayMember = dt.Columns.Count > 1 ? dt.Columns[1].ColumnName : dt.Columns[0].ColumnName;
                    col.DataSource = dt;
                }
            }
        }

        private static DataTable GetFilteredData(string sql, string condition, string tablename) {
            DataTable table = DataAdapter.Current.LoadData(sql, tablename);
            DataTable dt = table.Clone();
            if (String.IsNullOrEmpty(condition) == false) {
                DataRow[] rows = table.Select(condition);
                foreach (DataRow row in rows) {
                    dt.ImportRow(row);
                }
            } else {
                return table;
            }
            return dt;
        }

        /// <summary>
        /// Filter data grid control
        /// </summary>
        /// <param name="grid">Name of data grid</param>
        /// <param name="condition">Filter condition</param>
        internal static void Filter(DataGridView grid, string condition) {
            if (grid.DataSource is BindingSource) {
                BindingSource bindingSource = (BindingSource)grid.DataSource;
                bindingSource.Filter = condition;
            } else {
                DataView dv = ((DataTable)grid.DataSource).DefaultView;
                dv.RowFilter = condition;
            }
        }

        /// <summary>
        /// Clears data grid view control rows
        /// </summary>
        /// <param name="grid">Data grid view control</param>
        internal static void ClearGridRows(DataGridView grid) {
            if (grid == null || grid.Rows.Count == 0)
                return;
            for (int i = grid.Rows.Count - 1; i >= 0; i--) {
                grid.Rows.RemoveAt(i);
            }
        }

        /// <summary>
        /// Automatically calculate column value based on the action set
        /// </summary>
        /// <param name="action">Action which defines how calculation is done</param>
        /// <param name="grid">Data grid</param>
        internal static void CalculatedColumn(Action<DataGridViewRow> action, DataGridView grid) {
            Thread thread = new Thread(CalculationThread) {IsBackground = true};
            thread.Start(new List<object> { action, grid });
        }

        private static void CalculationThread(object o) {
            List<object> os = (List<object>)o;
            Action<DataGridViewRow> action = (Action<DataGridViewRow>)os[0];
            DataGridView grid = (DataGridView)os[1];
            while (true) {
                lock (grid) {
                    int rowsCount = grid.Rows.Count;
                    Form form = grid.FindForm();
                    if (form == null)
                        return;
                    foreach (DataGridViewRow row in grid.Rows) {
                        if (rowsCount != grid.Rows.Count)
                            break;
                        InvokeRowAction(action, grid, row);
                    }
                }
                Thread.Sleep(1000);
            }
        }

        private delegate void RowActionDelegate(Action<DataGridViewRow> action, DataGridView grid, DataGridViewRow row);
        private static void InvokeRowAction(Action<DataGridViewRow> action, DataGridView grid, DataGridViewRow row) {
            if (grid.InvokeRequired) {
                grid.Invoke(new RowActionDelegate(InvokeRowAction), action, grid, row);
            } else {
                if (row.Index >= 0) {
                    action(row);
                }
            }
        }

        /// <summary>
        /// Create an instance of form for the given name
        /// </summary>
        /// <param name="formName">Name of the form</param>
        /// <returns>Form instance for the give form name</returns>
        internal static Form CreateForm(string formName) {
            Assembly assembly = Assembly.GetExecutingAssembly();
            Type[] types = assembly.GetTypes();
            foreach (Type type in types) {
                if (type.Name == formName) {
                    object o = Activator.CreateInstance(type);
                    if (o != null) {
                        return (Form)o;
                    }
                    break;
                }
            }
            return null;
        }

        /// <summary>
        /// Open pop-up form by its name
        /// </summary>
        /// <param name="formName">Form name</param>
        internal static Form ShowDialog(string formName) {
            Form form = CreateForm(formName);
            if (form != null) {
                form.ShowDialog();
            }
            return form;
        }

        /// <summary>
        /// Close a form by a control
        /// </summary>
        /// <param name="control">Any control inside form</param>
        internal static void CloseContainerForm(Control control) {
            Form form = control.FindForm();
            if (form != null && form.IsDisposed == false)
                form.Close();
        }

        /// <summary>
        /// Associate list box with a check box to handle Select All functionality
        /// </summary>
        /// <param name="checkBox">Check box control</param>
        /// <param name="listBox">Checked list box control</param>
        internal static void AssociateSelectAllListbox(CheckBox checkBox, KushalCheckedListBox listBox) {
            bool updatingListbox = false;
            bool listboxUpdating = false;
            checkBox.CheckedChanged += delegate {
                if (listboxUpdating)
                    return;
                bool allItemsSelcted = listBox.Items.Count == listBox.CheckedItems.Count;
                updatingListbox = true;
                if (allItemsSelcted == false && checkBox.Checked) {
                    for (int i = 0; i < listBox.Items.Count; i++) {
                        listBox.SetItemChecked(i, true);
                    }
                } else if (allItemsSelcted) {
                    // uncheck all items and uncheck checkbox
                    for (int i = 0; i < listBox.Items.Count; i++) {
                        listBox.SetItemChecked(i, false);
                    }
                    checkBox.Checked = false;
                }
                updatingListbox = false;
            };

            listBox.ItemCheck += delegate(object sender, ItemCheckEventArgs e) {
                listboxUpdating = true;

                if (updatingListbox == false) {
                    int checkedCount = 0;
                    for (int i = 0; i < listBox.Items.Count; i++) {
                        CheckState state = listBox.GetItemCheckState(i);
                        if (i == e.Index) {
                            if (e.NewValue == CheckState.Checked) {
                                checkedCount++;
                            }
                        } else {
                            if (state == CheckState.Checked) {
                                checkedCount++;
                            }
                        }
                    }
                    checkBox.Checked = checkedCount == listBox.Items.Count;
                }
                listboxUpdating = false;
            };
        }

        /// <summary>
        /// Show image in a picture box
        /// </summary>
        /// <param name="path">Full file location</param>
        /// <param name="pb">Picture box control</param>
        internal static void ShowImage(string path, PictureBox pb) {
            ShowImage(path, pb, true);
        }

        /// <summary>
        /// Show image in a picture box
        /// </summary>
        /// <param name="path">Full file location</param>
        /// <param name="pb">Picture box control</param>
        /// <param name="showMessage">Indicate whether to show messages</param>
        internal static void ShowImage(string path, PictureBox pb, bool showMessage) {
            if (File.Exists(path) == false) {
                if (showMessage)
                    MessageBox.Show("File: " + path + " does not exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (pb == null) {
                if (showMessage)
                    MessageBox.Show("Picture box cannot be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (File.Exists(path)) {
                Image img = Image.FromFile(path);
                pb.Image = img;
            } else {
                pb.Image = null;
            }
        }

        /// <summary>
        /// Processes drop down columns in the given set of data grid view controls
        /// </summary>
        /// <param name="controls">List of data grid controls</param>
        internal static void ProcessDropdownColumns(List<Control> controls) {
            foreach (Control control in controls) {
                if (control is DataGridView) {
                    DataGridView grid = (DataGridView)control;
                    foreach (DataGridViewColumn col in grid.Columns) {
                        if (col is DataGridViewComboBoxColumn) {
                            CustomSort(grid, col.Name);
                        }
                    }
                }
            }
        }

        private static Dictionary<string, bool> sortDropdownColumn = new Dictionary<string, bool>();
        private static void CustomSort(DataGridView grid, string columnName) {
            if (sortDropdownColumn.ContainsKey(columnName)) {
                sortDropdownColumn[columnName] = true;
            } else {
                sortDropdownColumn.Add(columnName, true);
            }

            grid.ColumnHeaderMouseClick += delegate(object sender, DataGridViewCellMouseEventArgs e) {
                if (grid.Columns[columnName].Index != e.ColumnIndex)
                    return;
                DataTable dt = null;
                if (grid.DataSource is BindingSource) {
                    BindingSource bindingSource = (BindingSource)grid.DataSource;
                    dt = (DataTable)bindingSource.DataSource;
                }else {
                    dt = (DataTable)grid.DataSource;
                }
                if (dt == null)
                    return;
                dt.DefaultView.Sort = string.Empty;
                string colName = "__" + Guid.NewGuid().ToString().Replace("-", "");
                DataColumn col = dt.Columns.Add(colName);
                for (int i = 0; i < dt.Rows.Count; i++) {
                    dt.Rows[i][col] = grid.Rows[i].Cells[columnName].FormattedValue;
                }
                dt.DefaultView.Sort = colName + " " + (sortDropdownColumn[columnName] ? "ASC" : "DESC");
                sortDropdownColumn[columnName] = !sortDropdownColumn[columnName];
                for (int i = grid.Columns.Count - 1; i >= 0; i--) {
                    if (grid.Columns[i].Name.StartsWith("__")) {
                        grid.Columns.Remove(grid.Columns[i]);
                    }
                }
                grid.Columns[columnName].HeaderCell.SortGlyphDirection = sortDropdownColumn[columnName] ? SortOrder.Ascending : SortOrder.Descending;
            };
        }

        /// <summary>
        /// Does multiple primary key validation for the editable grids.
        /// </summary>
        /// <param name="grid">Data grid</param>
        /// <param name="tableName">Database table name</param>
        /// <param name="dataAdapter">Data adapter</param>
        internal static void DoMultipleKeyDuplicatesValidation(DataGridView grid, string tableName, DataAdapter dataAdapter) {
            List<string> columns = GetTableKeyColumns(tableName, dataAdapter);
            if (columns.Count < 2)
                return;
            grid.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e) {
                string columnName = grid.Columns[e.ColumnIndex].DataPropertyName;
                if (columns.Contains(columnName)) {
                    bool valid = CheckForMultipleKeyDuplicateData(columns, tableName, grid);
                    if (valid == false) {
                        ShowGridTooltip("Grid associated with multiple keys contains duplicate data.", grid, e.RowIndex, e.ColumnIndex);
                    }
                }
            };
        }

        private static bool CheckForMultipleKeyDuplicateData(List<string> columnNames, string tableName, DataGridView dgrData) {
            DataTable table = new DataTable();
            foreach (string columnName in columnNames) {
                table.Columns.Add(columnName);
            }
            // load all data grid values
            foreach (DataGridViewRow row in dgrData.Rows) {
                if (row.Selected) continue;
                DataRow r = table.NewRow();
                foreach (DataGridViewColumn column in dgrData.Columns) {
                    if (columnNames.Contains(column.DataPropertyName)) {
                        object val = row.Cells[column.Name].Value;
                        if (val != null) {
                            string value = Convert.ToString(val);
                            r[column.DataPropertyName] = value;
                        }
                    }
                }
                table.Rows.Add(r);
            }
            // check for duplicates in data table
            DataTable distinct = table.DefaultView.ToTable(true, columnNames.ToArray());
            return distinct.Rows.Count == table.Rows.Count;
        }

        /// <summary>
        /// Checks for duplicate values entered in editable grids.
        /// </summary>
        /// <param name="grid">Data grid</param>
        /// <param name="columnName">Column name</param>
        internal static void DoColumnDuplicatesValidation(DataGridView grid, string columnName) {
            object oldValue = null;
            grid.CellBeginEdit += delegate(object sender, DataGridViewCellCancelEventArgs e) {
                oldValue = grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            };
            grid.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e) {
                if (grid.Columns[e.ColumnIndex].Name == columnName) {
                    List<string> values = new List<string>();
                    foreach (DataGridViewRow row in grid.Rows) {
                        object val = row.Cells[e.ColumnIndex].Value;
                        if (val != null) {
                            string value = val.ToString();
                            if (values.Contains(value)) {
                                ShowGridTooltip("Duplicate value", grid, e.RowIndex, e.ColumnIndex);
                                grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = oldValue;
                                break;
                            }
                            values.Add(value);
                        }
                    }
                }
            };
        }

        /// <summary>
        /// Does column validation for the given set of editable grids.
        /// </summary>
        /// <param name="controls">Set of editable grids</param>
        /// <param name="colValidations">Set of column validation configuration</param>
        internal static void ProcessColumnValidation(List<Control> controls, Dictionary<string, ColumnValidationInfo> colValidations) {
            foreach (Control control in controls) {
                if (control is DataGridView) {
                    ((DataGridView)control).CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e) {
                        DataGridView dgr = (DataGridView)sender;
                        dgr.ShowCellToolTips = false;

                        DataGridViewColumn column = dgr.Columns[e.ColumnIndex];
                        if (dgr.ReadOnly == false && column.ReadOnly == false && colValidations.ContainsKey(column.Name)) {
                            ColumnValidationInfo validationInfo = colValidations[column.Name];

                            if (validationInfo.ValueType == ColumnValueType.Numeric) {
                                try {
                                    decimal val = Convert.ToDecimal(dgr.Rows[e.RowIndex].Cells[e.ColumnIndex].FormattedValue);

                                    if (val > validationInfo.MaxValue || val < validationInfo.MinValue) {
                                        ShowGridTooltip(validationInfo.ValidationMessage, dgr, e.RowIndex, e.ColumnIndex);
                                        dgr.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = validationInfo.MinValue;
                                    }
                                } catch (Exception exc) {
                                    ShowGridTooltip(exc.Message, dgr, e.RowIndex, e.ColumnIndex);
                                    dgr.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = validationInfo.MinValue;
                                }
                            } else if (validationInfo.ValueType == ColumnValueType.Text) {
                                Regex regex = new Regex(validationInfo.RegularExpression, RegexOptions.Compiled);

                                string val = dgr.Rows[e.RowIndex].Cells[e.ColumnIndex].FormattedValue.ToString();

                                if (String.IsNullOrEmpty(val) == false) {
                                    bool isValid = regex.IsMatch(val);
                                    if (isValid == false) {
                                        ShowGridTooltip(validationInfo.ValidationMessage, dgr, e.RowIndex, e.ColumnIndex);
                                        dgr.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = string.Empty;
                                    }
                                }
                            }
                        }
                    };
                }
            }
        }

        /// <summary>
        /// Show tooltip message for the given control
        /// </summary>
        /// <param name="message">Message to be displayed</param>
        /// <param name="control">Associated control</param>
        internal static void ShowTooltip(string message, Control control) {
            ToolTip tooltip = new ToolTip {
                Active = true,
                IsBalloon = true,
                UseFading = true,
                UseAnimation = true,
                AutomaticDelay = 5000
            };
            tooltip.SetToolTip(control, message);
            tooltip.Show(message, control, 10, 10);
            Thread tooltipThread = new Thread(TooltipThread) {IsBackground = true};
            tooltipThread.Start(new List<object> { tooltip, control });
        }

        /// <summary>
        /// Show tooltip messages if validation fails after entering a value in editable grid.
        /// </summary>
        /// <param name="message">Message to be displayed</param>
        /// <param name="grid">Data grid</param>
        /// <param name="rowIndex">Selected row index</param>
        /// <param name="columnIndex">Index of the column to consider</param>
        internal static void ShowGridTooltip(string message, DataGridView grid, int rowIndex, int columnIndex) {
            ToolTip tooltip = new ToolTip {
                IsBalloon = true,
                UseFading = true,
                UseAnimation = true,
                AutomaticDelay = 5000
            };
            tooltip.SetToolTip(grid, message);
            var cell = grid.CurrentCell;
            var cellDisplayRect = grid.GetCellDisplayRectangle(columnIndex, rowIndex, false);
            tooltip.Show(message, grid, cellDisplayRect.X + cell.Size.Width / 2, cellDisplayRect.Y + cell.Size.Height / 2, 2000);
            Thread tooltipThread = new Thread(TooltipThread) {IsBackground = true};
            tooltipThread.Start(new List<object> { tooltip, grid });
        }

        private static void TooltipThread(object o) {
            ToolTip tooltip = (ToolTip)((List<object>)o)[0];
            Control control = (Control)((List<object>)o)[1];
            Thread.Sleep(5000);
            if (control.IsDisposed == false) {
                try {
                    tooltip.Hide(control);
                } catch { }
            }
        }

        /// <summary>
        /// Raises Click event for the given button instance
        /// </summary>
        /// <param name="instance">Button instance</param>
        internal static void RaiseClick(object instance) {
            object[] parameters = new object[1]; parameters[0] = EventArgs.Empty;
            MethodInfo methodInfo = instance.GetType().GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance);
            methodInfo.Invoke(instance, parameters);
        }
        private static string GetFriendlyName(Control ctrl) {
            PropertyInfo propertyInfo = ctrl.GetType().GetProperty("FriendlyName");
            if (propertyInfo != null) {
                object val = propertyInfo.GetValue(ctrl, null);
                if (val != null)
                    return (string)val;
            }
            return string.Empty;
        }
    }

    public static class FormExtensions {
        /// <summary>
        /// Extension method to retrieve form property value
        /// </summary>
        /// <param name="form">Form instance. This is not shown in intellisense as it is an extension method.</param>
        /// <param name="property">Property name whose value to be retrieved</param>
        /// <returns>Property value</returns>
        public static object GetPropertyValue(this Form form, string property) {
            PropertyInfo propertyInfo = form.GetType().GetProperty(property);
            if (propertyInfo != null)
                return propertyInfo.GetValue(form, null);
            return null;
        }

        /// <summary>
        /// Extension method to set property value
        /// </summary>
        /// <param name="form">Form instance. This is not shown in intellisense as it is an extension method.</param>
        /// <param name="property">Property name whose value to be assigned</param>
        /// <param name="value">Property value</param>
        public static void SetPropertyValue(this Form form, string property, object value) {
            PropertyInfo propertyInfo = form.GetType().GetProperty(property);
            if (propertyInfo != null)
                propertyInfo.SetValue(form, value, null);
        }
    } 
}
