using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Drawing;
using System.IO;

namespace Newsletter_Composer
{
    //internal enum ExcelAppType
    //{
    //    MicrosoftExcel,
    //    OpenOffice
    //}
    internal class ExcelImport
    {
        private object missing = Missing.Value;
        private object application;
        private object appManager;
        private object workbook;
        private ExcelAppType excelAppType;
        private object sheet;
        const int xlTemplate = 17;
        public ExcelImport(ExcelAppType appType)
        {
            excelAppType = appType;

            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                Type excelType = Type.GetTypeFromProgID("Excel.Application");
                application = Activator.CreateInstance(excelType);

                application.GetType().InvokeMember("Visible", System.Reflection.BindingFlags.SetProperty, null, application, new object[] { false });

                ////object workbooks = application.GetType().InvokeMember("Workbooks", System.Reflection.BindingFlags.GetProperty, null, application, null);

                ////workbook = workbooks.GetType().InvokeMember("Add", BindingFlags.InvokeMethod, null, workbooks, null);
            }
            else
            {
                Type excelType = Type.GetTypeFromProgID("com.sun.star.ServiceManager");

                appManager = Activator.CreateInstance(excelType);

                application = appManager.GetType().InvokeMember("createInstance", BindingFlags.InvokeMethod, null, appManager, new object[] { "com.sun.star.frame.Desktop" });

                ////object[] args = new object[2];
                ////args[0] = InitiateAPropertyValue();
                ////args[1] = InitiateAPropertyValue();

                ////workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { "private:factory/scalc", "_blank", 0, args });

            }
            //SetVisible(false);
        }
        public void NewWorkBook()
        {

            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {

                object workbooks = application.GetType().InvokeMember("Workbooks", System.Reflection.BindingFlags.GetProperty, null, application, null);

                workbook = workbooks.GetType().InvokeMember("Add", BindingFlags.InvokeMethod, null, workbooks, null);
            }
            else
            {

                object[] args = new object[2];
                args[0] = InitiateAPropertyValue();
                args[1] = InitiateAPropertyValue();

                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { "private:factory/scalc", "_blank", 0, args });

            }
        }
        public void SetVisible(bool value)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                application.GetType().InvokeMember("Visible", System.Reflection.BindingFlags.SetProperty, null, application, new object[] { value });
            }
            else
            {
                if (workbook != null)
                {
                    object controler = workbook.GetType().InvokeMember("CurrentController", System.Reflection.BindingFlags.GetProperty, null, workbook, null);
                    object frame = controler.GetType().InvokeMember("Frame", System.Reflection.BindingFlags.GetProperty, null, controler, null);
                    object container = frame.GetType().InvokeMember("ContainerWindow", System.Reflection.BindingFlags.GetProperty, null, frame, null);
                    container.GetType().InvokeMember("SetVisible", System.Reflection.BindingFlags.InvokeMethod, null, container, new object[] { value });
                }
            }

        }
        public void OpenWorkBook(string path)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = path;
                object workbooks = application.GetType().InvokeMember("Workbooks", System.Reflection.BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Open", BindingFlags.InvokeMethod, null, workbooks, args);
            }
            else
            {

                object[] args = new object[2];
                args[0] = InitiateAPropertyValue();
                args[1] = InitiateAPropertyValue();

                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { PathConverter(path), "_blank", 0, args });

            }
            sheet = GetActiveSheet();
        }

        public void OpenWorkBookTemplate(string path)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = path;
                object workbooks = application.GetType().InvokeMember("Workbooks", System.Reflection.BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Open", BindingFlags.InvokeMethod, null, workbooks, args);
            }
            else
            {

                object[] args = new object[2];

                args[0] = MakePropertyValue("Hidden", "true");
                args[1] = MakePropertyValue("AsTemplate", "true");
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { PathConverter(path), "_blank", 0, args });

            }
            sheet = GetActiveSheet();
        }
        public void SaveWorkbook(string strFileName)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[2];
                args[0] = strFileName;
                args[1] = xlTemplate;
                object objWorkBook = application.GetType().InvokeMember("ActiveWorkbook", System.Reflection.BindingFlags.GetProperty, null, application, null);
                objWorkBook.GetType().InvokeMember("SaveAs", System.Reflection.BindingFlags.GetProperty, null, objWorkBook, args);

            }
            else
            {
                //'Dim args() As Object
                //          objWorkBook.storeToURL ConvertToUrl(strFileName), Array(MakePropertyValue("FilterName", "MS Excel 97")) 'args()
            }
        }
        private string PathConverter(string file)
        {
            file = file.Replace(@"\", "/");
            file = file.Replace(" ", "%20");
            return "file:///" + file;
        }

        private Object InitiateAPropertyValue()
        {
            return appManager.GetType().InvokeMember("Bridge_GetStruct", BindingFlags.InvokeMethod, null, appManager, new object[] { "com.sun.star.beans.PropertyValue" });
        }

        private Object SetPropertyValues(Object popertyvalue, string name, string value)
        {
            popertyvalue.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, popertyvalue, new object[] { value });
            return popertyvalue;
        }

        private Object MakePropertyValue(string name, string value)
        {
            return SetPropertyValues(InitiateAPropertyValue(), name, value);
        }

        public object GetValue(long col, long row)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col, });
                return cell.GetType().InvokeMember("Value", BindingFlags.GetProperty, null, cell, null);
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                return cell.GetType().InvokeMember("String", BindingFlags.GetProperty, null, cell, null);

            }
        }

        public object SelectCell(long col, long row)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col, });
                return cell.GetType().InvokeMember("Select", BindingFlags.InvokeMethod, null, cell, null);
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                return cell.GetType().InvokeMember("String", BindingFlags.GetProperty, null, cell, null);

            }
        }
        ////public void Export(ExcelSheet sheet)
        ////{
        ////    SetExcelSheetName(sheet.Name);

        ////    ExportColumns(sheet.Columns);

        ////    ExportData(sheet.Data);
        ////}

        public void SetExcelSheetName(string name)
        {
            object sheet = GetActiveSheet();
            sheet.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, sheet, new object[] { name });
        }

        public object GetExcelSheetName()
        {
            object sheet = GetActiveSheet();
            return sheet.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, sheet, null);
        }

        public void SelectWorkSheet(int index)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", System.Reflection.BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Select", System.Reflection.BindingFlags.GetProperty, null, sheet, null);

            }
            else
            {
                object sheets;
                object[] args = new object[1];
                args[0] = index - 1;
                sheets = workbook.GetType().InvokeMember("getSheets", System.Reflection.BindingFlags.InvokeMethod, null, workbook, null);
                sheet = workbook.GetType().InvokeMember("getByIndex", System.Reflection.BindingFlags.InvokeMethod, null, sheets, args);
                object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                object[] args1 = new object[1];
                args1[0] = sheet;
                controler.GetType().InvokeMember("ActiveSheet", BindingFlags.SetProperty, null, controler, args1);

                //objWorkBook.CurrentController.ActiveSheet = objWorkBook.getSheets.getByIndex(intNo - 1)
            }

        }

        public void DeleteWorkSheet(int index)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", System.Reflection.BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Delete", System.Reflection.BindingFlags.GetProperty, null, sheet, null);

            }
            else
            {
                ////object sheets;
                ////object[] args = new object[1];
                ////args[0] = index - 1;
                ////sheets = workbook.GetType().InvokeMember("getSheets", System.Reflection.BindingFlags.InvokeMethod, null, workbook, null);
                ////sheet = workbook.GetType().InvokeMember("getByIndex", System.Reflection.BindingFlags.InvokeMethod, null, sheets, args);
                ////object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                ////object[] args1 = new object[1];
                ////args1[0] = sheet;
                ////controler.GetType().InvokeMember("ActiveSheet", BindingFlags.SetProperty, null, controler, args1);

                //objWorkBook.CurrentController.ActiveSheet = objWorkBook.getSheets.getByIndex(intNo - 1)
            }

        }
        public void SetRangeNumberFormat(string strRange, string strFormat)
        {

            object objRange;
            object sheet;
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                sheet = GetActiveSheet();
                objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                //objWorkSheet.Range(strRange).NumberFormat = strFormat
                objRange.GetType().InvokeMember("NumberFormat", BindingFlags.SetProperty, null, objRange, new object[] { strFormat });
            }
            else
            {
                ////long intNumFormat;
                ////intNumFormat = objWorkBook.getNumberFormats.queryKey(strFormat, objWorkBook.CharLocale, False)
                ////If intNumFormat = -1 Then   'Not yet defined
                ////    intNumFormat = objWorkBook.getNumberFormats.AddNew(strFormat, objWorkBook.CharLocale)
                ////End If
                ////objWorkSheet.getCellRangebyName(strRange).NumberFormat = intNumFormat
            }
        }
        public void SetMarkBorder(string strRange, bool blnLeft, bool blnRight, bool blnTop, bool blnBottom, bool blnHorizontal, bool blnVertical)
        {

            object objRange;
            object sheet, border;
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                sheet = GetActiveSheet();
                objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                if (blnLeft)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 7 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });

                }
                if (blnRight)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 10 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });

                }

                if (blnTop)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 9 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });

                }
                if (blnBottom)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 10 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });

                }

                if (blnHorizontal)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 12 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });

                }
                if (blnVertical)
                {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 11 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });

                }
            }
            else
            {
                ////long intNumFormat;
                ////intNumFormat = objWorkBook.getNumberFormats.queryKey(strFormat, objWorkBook.CharLocale, False)
                ////If intNumFormat = -1 Then   'Not yet defined
                ////    intNumFormat = objWorkBook.getNumberFormats.AddNew(strFormat, objWorkBook.CharLocale)
                ////End If
                ////objWorkSheet.getCellRangebyName(strRange).NumberFormat = intNumFormat
            }
        }

        public void SetRangeBackColor(string strRange, int intColorIndex)
        {
            //Dim strArray() As String
            object objRange;
            object sheet, interior;
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                sheet = GetActiveSheet();
                objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                //objWorkSheet.Range(strRange).NumberFormat = strFormat
                interior = objRange.GetType().InvokeMember("Interior", BindingFlags.GetProperty, null, objRange, null);
                interior.GetType().InvokeMember("ColorIndex", BindingFlags.SetProperty, null, interior, new object[] { intColorIndex });

                //objWorkSheet.Range(strRange).Interior.ColorIndex = intColorIndex
            }
            else
            {
                ////strArray = Split(getRGBFromIndex(intColorIndex), ",")
                ////If UBound(strArray) = 2 Then
                ////    objWorkSheet.getCellRangebyName(strRange).CellBackColor = RGB(strArray(0), strArray(1), strArray(2))
                ////End If
            }
        }

        public void HideColumnsFrom(int StartCol)
        {
            object sheet, columns, colcount, selection, entirecol;
            string strStartCol, strEndCol;

            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                sheet = GetActiveSheet();
                strStartCol = GetExcelColumnName(StartCol);
                int icolsCount;
                columns = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, null);
                colcount = sheet.GetType().InvokeMember("Count", BindingFlags.GetProperty, null, columns, null);
                icolsCount = (int)colcount;
                strEndCol = GetExcelColumnName(icolsCount);
                selection = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { strStartCol + ":" + strEndCol });

                entirecol = selection.GetType().InvokeMember("EntireColumn", BindingFlags.GetProperty, null, selection, null);
                entirecol.GetType().InvokeMember("Hidden", BindingFlags.SetProperty, null, entirecol, new object[] { true });


                //objWorkSheet.Range(strRange).Interior.ColorIndex = intColorIndex
            }
            else
            {
                ////strArray = Split(getRGBFromIndex(intColorIndex), ",")
                ////If UBound(strArray) = 2 Then
                ////    objWorkSheet.getCellRangebyName(strRange).CellBackColor = RGB(strArray(0), strArray(1), strArray(2))
                ////End If
            }

        }
        private object GetActiveSheet()
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
                return application.GetType().InvokeMember("ActiveSheet", BindingFlags.GetProperty, null, application, null);
            else
            {
                object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                return controler.GetType().InvokeMember("ActiveSheet", BindingFlags.GetProperty, null, controler, null);
            }
        }
        public object GetSheetCount()
        {
            object sheets;

            sheets = workbook.GetType().InvokeMember("Sheets", BindingFlags.GetProperty, null, workbook, null);
            return sheets.GetType().InvokeMember("Count", BindingFlags.GetProperty, null, sheets, null);

        }


        public void ColumnWidths(List<int> columns)
        {
            object sheet = GetActiveSheet();
            for (int i = 0; i < columns.Count; i++)
            {
                SetColWidth(sheet, i + 1, columns[i]);
            }
        }

        private void ExportColumns(List<string> columns)
        {
            object sheet = GetActiveSheet();
            for (int i = 0; i < columns.Count; i++)
            {
                string column = columns[i];
                SetValue(sheet, i + 1, 1, column);
            }
        }

        private void ExportData(List<List<string>> data)
        {
            object sheet = GetActiveSheet();

            for (int row = 0; row < data.Count; row++)
            {
                List<string> rowData = data[row];
                for (int column = 0; column < rowData.Count; column++)
                {
                    SetValue(sheet, column + 1, (row + 2), rowData[column]);
                }
            }
        }

        private void SetValue(object sheet, int col, int row, object value)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col, });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new object[] { value });
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new object[] { value });

            }
        }

        public void SetCellValue(int col, int row, object value)
        {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col, });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new object[] { value });
            }
            else
            {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new object[] { value });

            }
        }
        private void SetColWidth(object sheet, int index, int length)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object Colm = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { index, Missing.Value });

                Colm.GetType().InvokeMember("ColumnWidth", BindingFlags.SetProperty, null, Colm, new object[] { length });
            }
            else
            {
                object Colms = sheet.GetType().InvokeMember("getColumns", BindingFlags.InvokeMethod, null, sheet, null);
                object Colm = Colms.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, Colms, new object[] { index - 1 });

                object propValue = new object();
                propValue = MakePropertyValue("Width", Convert.ToString(length * 10));
                Colm.GetType().InvokeMember("setPropertyValue", BindingFlags.InvokeMethod, null, Colm, new object[] { "Width", Convert.ToInt32(length * 100 * 2.5) });
            }
        }
        public void SetColumnWidth(int index, int length)
        {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object Colm = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { index, Missing.Value });

                Colm.GetType().InvokeMember("ColumnWidth", BindingFlags.SetProperty, null, Colm, new object[] { length });
            }
            else
            {
                object Colms = sheet.GetType().InvokeMember("getColumns", BindingFlags.InvokeMethod, null, sheet, null);
                object Colm = Colms.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, Colms, new object[] { index - 1 });

                object propValue = new object();
                propValue = MakePropertyValue("Width", Convert.ToString(length * 10));
                Colm.GetType().InvokeMember("setPropertyValue", BindingFlags.InvokeMethod, null, Colm, new object[] { "Width", Convert.ToInt32(length * 100 * 2.5) });
            }
        }
        public void CloseWorkbook()
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                if (workbook != null)
                {
                    workbook.GetType().InvokeMember("Close", BindingFlags.InvokeMethod, null, workbook, new object[] { false });
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                    workbook = null;
                    sheet = null;
                }
            }
            else
            {
                if (workbook != null)
                {
                    workbook.GetType().InvokeMember("Dispose", BindingFlags.InvokeMethod, null, workbook, null);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                    workbook = null;
                    sheet = null;
                }

            }
        }

        public void CloseExcel()
        {
            if (workbook != null)
                CloseWorkbook();

            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                if (workbook == null)
                {
                    application.GetType().InvokeMember("Quit", System.Reflection.BindingFlags.InvokeMethod, null, application, null);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(application);
                }
                application = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            else
            {
                application.GetType().InvokeMember("terminate", System.Reflection.BindingFlags.InvokeMethod, null, application, null);
            }

        }
        private string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }
    }
}
