using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using System.Diagnostics;

namespace Newsletter_Composer
{
    class Suraksha
    {
        private static Suraksha instance;

        [DllImport("GetDiskSerial.dll", CharSet = CharSet.Ansi)]
        private static extern void SetLicenseKey(string regCode);

        [DllImport("GetDiskSerial.dll", CharSet = CharSet.Ansi)]
        private static extern string GetSerialNumber(byte driveIndex);
        private string licenseManagerPath = GetERachanaCommonPath() + "License_Manager.exe";
        string company = "ERachana Technologies";
        static string appName = string.Empty;
        static string appFullName = string.Empty;
        private string licPath = string.Empty;
        private string regPath = string.Empty;
        private string logpath = string.Empty;
        public string diskId = string.Empty;
        public string diskId2 = string.Empty;
        public string productCode = string.Empty;
        public string sfKey = string.Empty;
        public int licType = 0;
        public DateTime StartDate = new DateTime();
        public DateTime EndDate = new DateTime();
        public DateTime LastDate = new DateTime();
        public int counterVal = 0;
        public bool isCount = false;

        public static Suraksha Instance
        {
            get
            {
                if (instance == null) { instance = new Suraksha(); }
                return instance;
            }
        }

        public bool ValidateLic(string prdCode, string productName, string prdName, string path)
        {
            appName = prdName;
            appFullName = productName;
            licPath = GetDirectory() + "License.txt";
            regPath = GetDirectory() + "Register.txt";
            logpath = GetDirectory() + "Log.txt";

            if (!System.IO.Directory.Exists(GetDirectory()))
                System.IO.Directory.CreateDirectory(GetDirectory());

            if (System.IO.File.Exists(logpath))
            {
                double size = (new System.IO.FileInfo(logpath).Length / 1048576);
                if (size >= 5)
                    System.IO.File.Delete(logpath);
            }
            try
            {
                if (!ValidateLic(prdCode) == true)
                {
                    if (File.Exists(licPath))
                        File.Delete(licPath);
                    //if (File.Exists(regPath))
                    // File.Delete(regPath);
                    if (MessageBox.Show("Either License is not configured or License has Expired." + Environment.NewLine + Environment.NewLine + "Do you want to configure now?" + Environment.NewLine + "Click 'Yes' to Configure.", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly) == DialogResult.Yes)
                    {
                        try
                        {
                            string args = prdCode + " " + productName + " " + path;
                            Process.Start(@licenseManagerPath, args).WaitForExit();
                            return false;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("License Manager not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return false;
                        }
                    }
                    else
                        return false;
                }
                else
                    return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private bool ValidateLic(string prdCode)
        {
            try
            {
                LogWriter(logpath, Environment.NewLine + "Checking File License " + DateTime.Now);
                if (File.Exists(licPath))
                {
                    //Read Lic File.
                    string text = System.IO.File.ReadAllText(licPath);
                    char[] delim = new char[] { '\r', '\n' };
                    char[] delimeters = new char[] { ' ' };
                    string pCode = string.Empty;

                    string startDt = string.Empty;
                    string endDt = string.Empty;
                    string lastDt = string.Empty;
                    //string sfKey = string.Empty;
                    string[] lines = text.Split(delim, StringSplitOptions.RemoveEmptyEntries);
                    if (lines.Length > 0)
                    {
                        LogWriter(logpath, Environment.NewLine + "Licsense File Open " + DateTime.Now);
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (i == 0)
                            {
                                string[] vals = lines[i].Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
                                if (vals.Length > 0)
                                {
                                    LogWriter(logpath, Environment.NewLine + "Types of Disk " + DateTime.Now);
                                    if (vals.Length >= 1)
                                        licType = vals[0].Length > 0 ? Convert.ToInt32(vals[0]) : 0;
                                    if (vals.Length >= 2)
                                        diskId = vals[1].Length > 0 ? vals[1] : string.Empty;
                                }
                            }
                            else if (i > 0)
                            {
                                string[] vals = lines[i].Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
                                if (vals.Length > 0)
                                {
                                    LogWriter(logpath, Environment.NewLine + "Tracking data " + DateTime.Now);
                                    if (vals.Length >= 1)
                                        productCode = pCode = vals[0].Length > 0 ? vals[0] : string.Empty;
                                    if (vals.Length >= 2)
                                        startDt = vals[1].Length > 0 ? vals[1] : string.Empty;
                                    if (vals.Length >= 3)
                                        endDt = vals[2].Length > 0 ? vals[2] : string.Empty;
                                    if (vals.Length >= 4)
                                        sfKey = vals[3].Length > 0 ? vals[3] : string.Empty;
                                    if (vals.Length >= 5)
                                        lastDt = vals[4].Length > 0 ? vals[4] : string.Empty;
                                }
                                LogWriter(logpath, Environment.NewLine + "Checking File License " + DateTime.Now);
                            }

                        }

                        LogWriter(logpath, Environment.NewLine + "Checking File License " + DateTime.Now);
                        if (licType > 0 && !string.IsNullOrEmpty(pCode) && !string.IsNullOrEmpty(diskId) && !string.IsNullOrEmpty(endDt) && !string.IsNullOrEmpty(sfKey))
                        {
                            int trailCount = 5;
                            if (licType == 2)
                                trailCount = 10;

                            LogWriter(logpath, Environment.NewLine + "Validation of every data " + DateTime.Now);

                            if (chkDisk() && chkProduct(prdCode) && (endDt.Length == 8) && chkDate(endDt, lastDt, trailCount))
                            {
                                string tf = ValidateLic(licType, pCode, getDate(endDt), diskId, sfKey);
                                if (tf == "True")
                                {
                                    LogWriter(logpath, Environment.NewLine + "Valid License  " + DateTime.Now);
                                    return true;
                                }
                                else
                                {
                                    LogWriter(logpath, Environment.NewLine + "Invlid License File " + DateTime.Now);
                                    return false;
                                }
                            }
                            else
                                return false;
                        }
                        else
                            return false;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    LogWriter(logpath, Environment.NewLine + "License Not Found " + DateTime.Now);
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }
        private static string ValidateLic(int licType, string prdCode, DateTime validDate, string diskId, string sKey)
        {
            try
            {
                DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                //MessageBox.Show(dt.ToString());
                if (dt <= validDate)
                {
                    //MessageBox.Show(prdCode + Environment.NewLine + validDate + Environment.NewLine + sKey);
                    LicenseCheck.ValidateLicense ets = new LicenseCheck.ValidateLicense();
                    string key = sKey.Trim();
                    switch (licType)
                    {
                        case 1:
                            return ets.isTrialValid(ref prdCode, ref validDate, ref diskId, ref key);
                        case 2:
                            return ets.isLocalValid(ref prdCode, ref validDate, ref diskId, ref key);
                        case 3:
                            return ets.isServerValid(ref prdCode, ref validDate, ref  diskId, ref key);
                        case 4:
                            return ets.isClicentValid(ref prdCode, ref  validDate, ref  diskId, ref key);
                        case 5:
                            return ets.isDiskValid(ref diskId, ref key);
                        default: return "False";
                    }
                }
                else
                    return "False";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return "False";

            }
        }
        public string GetDiskId()
        {
            try
            {
                diskId2 = ReadHardDiskSerial();// read hard disk id
                if (string.IsNullOrEmpty(diskId2))// if fails read mac id;
                {
                    diskId2 = GetMacAddress();
                }
                return diskId2;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString(), "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                return null;
            }
        }
        private string ReadHardDiskSerial()
        {
            try
            {
                SetLicenseKey("992PC-6L4JT-3UJM7-QX44E-AVMG6");
                string serialNumber = GetSerialNumber(0);
                return serialNumber;

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString(), "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                return null;
            }
        }

        private string GetMacAddress()
        {
            string macAddresses = string.Empty;
            try
            {
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
                    {
                        macAddresses = nic.GetPhysicalAddress().ToString();
                        if (nic.OperationalStatus == OperationalStatus.Up)
                        {
                            macAddresses = nic.GetPhysicalAddress().ToString();
                        }
                    }
                }
                return macAddresses;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString(), "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                return null;
            }
        }
        private bool chkProduct(string prd)
        {
            try
            {
                //MessageBox.Show(productCode + Environment.NewLine + prd);
                if (productCode == prd)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private bool chkDisk()
        {
            try
            {
                string myDisk = GetDiskId();
                //  MessageBox.Show(myDisk + Environment.NewLine + diskId);
                if (diskId == myDisk)
                    return true;

                //In some system GetDiskId function will return id "BADC" (big endian / little endian), when it is running as non administrator mode.
                //Below loop will swap the value and checks 
                string newDisk = "";
                for (int z = 0; z < myDisk.Length - 1; z += 2)
                {
                    char[] chars = myDisk.Substring(z, 2).ToCharArray();
                    Array.Reverse(chars);
                    newDisk += new string(chars);
                }
                ///////
                if (diskId == newDisk)
                    return true;
                else
                {
                    MessageBox.Show("Invalid License.", "Invalid License", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (File.Exists(licPath))
                        File.Delete(licPath);
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private bool chkDate(string endDt, string lastVal, int trailCount)
        {
            try
            {
                //8 Digit End Date + 2 Digit Check for coutn r not + 2 Count of Open + 8 Digit Start Date + 00 differenceator + 8 Digit Last Used on 
                StartDate = getDate2(getStartDate(lastVal.Substring(12, 8)));
                EndDate = getDate2(getEndDate(lastVal.Substring(0, 8)));
                LastDate = getDate2(getLastDate(lastVal.Substring(22, 8)));
                //MessageBox.Show(StartDate + Environment.NewLine + EndDate + Environment.NewLine + LastDate);

                int checkCouter = Convert.ToInt32(lastVal.Substring(9, 1));
                counterVal = Convert.ToInt32(lastVal.Substring(10, 2));
                if (checkCouter == 1)
                {
                    isCount = true;
                    if (Convert.ToInt32(lastVal.Substring(11, 2)) > 0 && Convert.ToInt32(lastVal.Substring(11, 2)) < 65)
                        counterVal++;
                }

                if (isCount == true)
                {
                    if (counterVal <= trailCount)
                    {
                        MessageBox.Show("Your License has expired." + Environment.NewLine + "Please Contact " + company + " for further information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        reCreate();
                        return true;
                    }
                    else
                    {
                        if (File.Exists(licPath))
                            File.Delete(licPath);
                        MessageBox.Show("Your License has expired." + Environment.NewLine + "Please Contact " + company + " for further information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
                else
                {
                    DateTime today = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                    if (LastDate > today)//Start Counter
                    {
                        isCount = true;
                        counterVal++;
                        reCreate();
                    }
                    else
                    {
                        if (ping())
                        {
                            if (today != serverDate())
                                today = serverDate();
                        }
                        if (today >= StartDate && today <= EndDate)
                        {
                            reCreate();
                            TimeSpan sp = EndDate - today;
                            if ((sp.Days + 1) <= 7)
                            {
                                string dys = "Days";
                                if ((sp.Days + 1) == 1)
                                    dys = "Day";

                                MessageBox.Show("Your License will expire in " + (sp.Days + 1) + " " + dys + "." + Environment.NewLine + "Please Contact " + company + " for further information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            return true;
                        }
                        else
                        {
                            MessageBox.Show("Your License has expired." + Environment.NewLine + "Please Contact " + company + " for further information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            if (File.Exists(licPath))
                                File.Delete(licPath);
                            return false;
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private void reCreate()
        {
            try
            { // Rewrite the file
                if (File.Exists(licPath))
                    File.Delete(licPath);

                string key = "";
                key = licType + " " + diskId + Environment.NewLine + productCode + " " + StartDate.ToString("ddMMyyyy") + " " + EndDate.ToString("ddMMyyyy") + " " + sfKey + " " + dateParser();
                LogWriter(licPath, key);// Rewrite the file
            }
            catch (Exception ex)
            {
                if (File.Exists(licPath))
                    File.Delete(licPath);
            }
        }
        private static int getNumber(DateTime dt)
        {
            try
            {
                string retVal = dt.Year.ToString();

                if (dt.Month < 10)
                    retVal += "0" + dt.Month.ToString();
                else
                    retVal += dt.Month.ToString();

                if (dt.Day < 10)
                    retVal += "0" + dt.Day.ToString();
                else
                    retVal += dt.Day.ToString();
                return Convert.ToInt32(retVal);

            }
            catch
            {
                return 0;
            }
        }
        private string dateParser()
        {
            string sDate = (getStartDate(getNumber(StartDate).ToString())).ToString();
            string eDate = (getEndDate(getNumber(EndDate).ToString())).ToString();
            string usedDate = (getLastDate(getNumber(LastDate).ToString())).ToString();
            if (isCount)
                return eDate + "01" + counterVal.ToString("00") + sDate + "00" + usedDate;
            else
                return eDate + "0000" + sDate + "00" + usedDate;
        }


        private DateTime getDate(string endDt)
        {
            try
            {
                return new DateTime(Convert.ToInt32(endDt.Substring(4, 4)), Convert.ToInt32(endDt.Substring(2, 2)), Convert.ToInt32(endDt.Substring(0, 2)));
                //DateTime eDate = new DateTime(Convert.ToInt32(endDt.Substring(4, 4)), Convert.ToInt32(endDt.Substring(2, 2)), Convert.ToInt32(endDt.Substring(0, 2)));
                //DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                //if (eDate >= dt)
                //{
                //    return eDate;
                //}
                //else
                //    return new DateTime(1900,01,01);
            }
            catch (Exception ex)
            {
                return new DateTime(1900, 01, 01);
            }
        }

        private DateTime getDate2(string endDt)
        {
            try
            {
                return new DateTime(Convert.ToInt32(endDt.Substring(0, 4)), Convert.ToInt32(endDt.Substring(4, 2)), Convert.ToInt32(endDt.Substring(6, 2)));
            }
            catch (Exception ex)
            {
                return new DateTime(1900, 01, 01);
            }
        }
        public static string getStartDate(string val)
        {
            try // For Start date 96969696 - Value
            {
                return (96969696 - Convert.ToInt32(val)).ToString();
            }
            catch
            {
                return null;
            }
        }
        public static string getEndDate(string val)
        {
            try // For Start date 84848484 - Value
            {
                return (84848484 - Convert.ToInt32(val)).ToString();
            }
            catch
            {
                return null;
            }
        }
        public static string getLastDate(string val)
        {
            try // For Start date 72727272 - Value
            {
                return (72727272 - Convert.ToInt32(val)).ToString();
            }
            catch
            {
                return null;
            }
        }
        public bool licenseManager()
        {
            return true;
        }
        public static string GetERachanaCommonPath()
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles) + @"\ERachana\";
        }
        public static string GetDirectory()
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\" + appName + @"\";
        }

        public static bool ping()
        {
            try
            {
                System.Net.NetworkInformation.Ping pingSender = new System.Net.NetworkInformation.Ping();
                System.Net.NetworkInformation.PingReply reply = pingSender.Send("www.erachana.net");
                if (reply.Status == System.Net.NetworkInformation.IPStatus.Success)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public DateTime serverDate()
        {
            try
            {
                string retDate = new System.Net.WebClient().DownloadString("http://www.erachana.net/suraksha/server-datetime");
                DateTime sDate = getDate(retDate);
                return sDate;
            }
            catch (Exception ex)
            {
                return new DateTime();
            }
        }

        public void LogWriter(string filePath, string fileText)
        {
            try
            {
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    sw.WriteLine(fileText);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}

