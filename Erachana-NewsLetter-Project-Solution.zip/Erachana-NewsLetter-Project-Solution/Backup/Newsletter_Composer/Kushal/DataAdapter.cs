using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Reflection;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Specialized;
using System.Data.OleDb;
using System.Data.SqlServerCe;

namespace Newsletter_Composer {
    internal class DataAdapter {
        private static string appPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar;
        private Dictionary<string, SqlCeDataAdapter> dataAdapters;
        private string connectionString, filename;
        private DataSet ds = new DataSet();

        public DataAdapter(string filename, string password) {
            dataAdapters = new Dictionary<string, SqlCeDataAdapter>();
            connectionString = String.Format("Data Source={0};Encrypt Database=True;Password=admin;File Mode=Read Write;Persist Security Info=False;", filename);
            this.filename = filename;
        }

        public static DataAdapter Current { get; set; }
        public static string CurrentDatabase { get; set; }

        public static void LoadDataAdapter(string filenName) {
            CurrentDatabase = filenName;
            Current = new DataAdapter(filenName, string.Empty);
            GlobalVariables.SetValue("$$ConnectionString", String.Format("Data Source={0};Encrypt Database=True;Password=admin;File Mode=Read Write;Persist Security Info=False;", filenName));
        }

        public static void UnloadDataAdapter() {
            Current = null;
        }

        internal DataTable LoadData(string sql, string tableName) {
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            try {
                connection.Open();
                SqlCeDataAdapter dataAdapter = new SqlCeDataAdapter(sql, connection);
                SqlCeCommandBuilder commandBuilder = new SqlCeCommandBuilder(dataAdapter);
                if (dataAdapters.ContainsKey(tableName)) {
                    dataAdapters.Remove(tableName);
                }
                dataAdapters.Add(tableName, dataAdapter);
                if (ds.Tables.Contains(tableName)) {
                    ds.Tables.Remove(tableName);
                }
                dataAdapter.Fill(ds, tableName);
                if (ds.Tables.Contains(tableName)) {
                    return ds.Tables[tableName];
                }
            } finally {
                connection.Close();
            }
            return null;
        }

        internal int Update(string tableName) {
            UpdateType updateType = GetUpdateType(ds.Tables[tableName]);
            try {
                LoadSave.ShowProgress(ProgressType.Saving);
                int rowsUpdated = dataAdapters[tableName].Update(ds, tableName);
                ds.Tables[tableName].AcceptChanges();
                LoadSave.CloseProgress();
                return rowsUpdated;
            } catch (Exception exc) {
                if (exc.Message.Contains("foreign key")) {
                    MessageBox.Show(String.Format("{0} record(s) failed due to foreign key constraint", updateType.ToString()), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                } else {
                    throw exc;
                }
            }
        }

        internal int Update(string tableName, DataRow[] rows) {
            UpdateType updateType = GetUpdateType(ds.Tables[tableName]);
            try {
                LoadSave.ShowProgress(ProgressType.Saving);
                int rowsUpdated = dataAdapters[tableName].Update(rows);
                ds.Tables[tableName].AcceptChanges();
                LoadSave.CloseProgress();
                return rowsUpdated;
            } catch (Exception exc) {
                if (exc.Message.Contains("foreign key")) {
                    MessageBox.Show(String.Format("{0} record(s) failed due to foreign key constraint", updateType.ToString()), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                } else {
                    throw exc;
                }
            }
        }

        public IDbConnection GetConnection() {
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            connection.Open();
            return connection;
        }

        public DataTable GetTable(string tableName) {
            if (dataAdapters.ContainsKey(tableName) && ds.Tables.Contains(tableName)) {
                return ds.Tables[tableName];
            }
            return null;
        }

        private UpdateType GetUpdateType(DataTable dataTable) {
            UpdateType updateType = UpdateType.Update;
            DataTable dtAdded = dataTable.GetChanges(DataRowState.Added);
            DataTable dtDeleted = dataTable.GetChanges(DataRowState.Deleted);
            DataTable dtUpdated = dataTable.GetChanges(DataRowState.Modified);
            if (dtAdded != null && dtAdded.Rows.Count > 0) {
                updateType = UpdateType.Add;
            } else if (dtDeleted != null && dtDeleted.Rows.Count > 0) {
                updateType = UpdateType.Delete;
            } else if (dtUpdated != null && dtUpdated.Rows.Count > 0) {
                updateType = UpdateType.Update;
            }
            return updateType;
        }

        internal int DeleteRow(DataTable table, string value, string keyField) {
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            try {
                connection.Open();
                SqlCeCommand cmd = connection.CreateCommand();
                cmd.CommandText = GetDeleteSql(table, value, keyField);
                return cmd.ExecuteNonQuery();
            } finally {
                connection.Close();
            }
        }

        private string GetDeleteSql(DataTable table, string value, string keyField) {
            string sql = "DELETE FROM [" + table.TableName + "]";
            List<string> wheres = new List<string>();
            var numericTypes = new[] { typeof(Byte), typeof(Decimal), typeof(Double), typeof(Int16), typeof(Int32), typeof(Int64), typeof(SByte), typeof(Single), typeof(UInt16), typeof(UInt32), typeof(UInt64) };
            foreach (DataColumn col in table.Columns) {
                if (col.ColumnName == keyField) {
                    sql += " WHERE " + String.Format("{0} = {1}{2}{1}", col.ColumnName, (numericTypes.Contains(col.DataType) ? "" : "'"), value);
                    break;
                }
            }
            return sql;
        }

        internal int DeleteRow(DataTable table, Dictionary<string, string> values, List<string> fields) {
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            try {
                connection.Open();
                SqlCeCommand cmd = connection.CreateCommand();
                cmd.CommandText = GetDeleteSql(table, values, fields);
                return cmd.ExecuteNonQuery();
            } finally {
                connection.Close();
            }
        }

        private string GetDeleteSql(DataTable table, Dictionary<string, string> values, List<string> fields) {
            string sql = "DELETE FROM [" + table.TableName + "]";
            List<string> wheres = new List<string>();
            var numericTypes = new[] { typeof(Byte), typeof(Decimal), typeof(Double), typeof(Int16), typeof(Int32), typeof(Int64), typeof(SByte), typeof(Single), typeof(UInt16), typeof(UInt32), typeof(UInt64) };
            List<string> conditions = new List<string>();
            foreach (DataColumn col in table.Columns) {
                if (fields.Contains(col.ColumnName)) {
                    conditions.Add(String.Format("{0} = {1}{2}{1}", col.ColumnName, (numericTypes.Contains(col.DataType) ? "" : "'"), values[col.ColumnName]));
                }
            }
            if (conditions.Count > 0) {
                sql += " WHERE " + String.Join(" AND ", conditions.ToArray());
            }
            return sql;
        }

        internal void Clear(string tableName) {
            if (ds != null && ds.Tables.Contains(tableName)) {
                ds.Tables.Remove(tableName);
            }
        }

        internal DataTable Search(string sql) {
            return null;
        }

        internal string GetConnectionString() {
            return String.Format("Data Source={0};Encrypt Database=True;Password=admin;File Mode=Read Write;Persist Security Info=False;", filename);
        }

        internal int ExecuteSql(string sql) {
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            try {
                connection.Open();
                SqlCeCommand cmd = new SqlCeCommand(sql, connection);
                return cmd.ExecuteNonQuery();
            } finally {
                connection.Close();
            }
        }

        internal List<ProcedureResult> ExecuteStoredProcedure(string procedureName, List<SqlCeParameter> parameters) {
            List<ProcedureResult> values = new List<ProcedureResult>();
            using (SqlCeConnection connection = new SqlCeConnection(connectionString)) {
                using (SqlCeCommand cmd = new SqlCeCommand(procedureName, connection)) {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (parameters != null && parameters.Count > 0) {
                        foreach (SqlCeParameter parameter in parameters) {
                            cmd.Parameters.Add(parameter);
                        }
                    }
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (parameters != null && parameters.Count > 0) {
                        foreach (SqlCeParameter parameter in parameters) {
                            if (parameter.Direction == ParameterDirection.Output || parameter.Direction == ParameterDirection.InputOutput) {
                                values.Add(new ProcedureResult() { FieldName = parameter.ParameterName, Value = parameter.Value });
                            }
                        }
                    }
                }
            }
            return values;
        }

        internal DataTable ExecuteStoredProcedureReader(string procedureName, List<SqlCeParameter> parameters) {
            DataTable table = new DataTable();
            using (SqlCeConnection connection = new SqlCeConnection(connectionString)) {
                using (SqlCeCommand cmd = new SqlCeCommand(procedureName, connection)) {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (parameters != null && parameters.Count > 0) {
                        foreach (SqlCeParameter parameter in parameters) {
                            cmd.Parameters.Add(parameter);
                        }
                    }
                    connection.Open();
                    SqlCeDataReader reader = cmd.ExecuteReader();
                    // create table columns
                    for (int i = 0; i < reader.FieldCount; i++) {
                        table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
                    }
                    // Fill table values
                    while (reader.Read()) {
                        List<object> rowValues = new List<object>();
                        for (int i = 0; i < reader.FieldCount; i++) {
                            rowValues.Add(reader.GetValue(i));
                        }
                        table.Rows.Add(rowValues.ToArray());
                    }
                }
            }
            return table;
        }

        internal SqlCeParameter GetParameter(string name, DbType type, object value, ParameterDirection direction) {
            SqlCeParameter parameter = new SqlCeParameter(name, type);
            parameter.Value = value;
            parameter.Direction = direction;
            return parameter;
        }

        public DataTable GetSchemaTable(string sql) {
            return GetSchemaTable(sql, CommandBehavior.Default);
        }

        public DataTable GetSchemaTable(string sql, CommandBehavior behavior) {
            DataTable schema = null;
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            try {
                connection.Open();
                IDbCommand command = new SqlCeCommand(sql, connection);
                using (IDataReader reader = command.ExecuteReader()) {
                    schema = reader.GetSchemaTable();
                }
            } finally {
                connection.Close();
            }
            return schema;
        }

        internal string BackupData(string filename) {
            File.Copy(this.filename, filename, true);
            EncryptDecrypt.EncryptFile(filename);
            return string.Empty;
        }

        internal string RestoreData(string filename) {
            string status = string.Empty;
            if (File.Exists(filename)) {
                File.Copy(filename, this.filename, true);
                EncryptDecrypt.DecryptFile(this.filename);
            }
            return status;
        }
        
        public List<Table> ExtractTables() {
            List<Table> tables = new List<Table>();

            SqlCeConnection connection = new SqlCeConnection(connectionString);
            try {
                connection.Open();
                Dictionary<string, IDbCommand> commands = GetCommands(connection);
                foreach (string tableName in commands.Keys) {
                    IDbCommand command = commands[tableName];
                    using (IDataReader reader = command.ExecuteReader(CommandBehavior.KeyInfo)) {
                        DataTable schema = reader.GetSchemaTable();
                        Table table = new Table();
                        table.Name = tableName;
                        tables.Add(table);
                        foreach (DataRow row in schema.Rows) {
                            Column column = new Column();
                            foreach (DataColumn col in schema.Columns) {
                                SetProperty(column, col.ColumnName, row[col]);
                            }
                            table.Columns.Add(column);
                        }
                    }
                }
            } finally {
                connection.Close();
            }
            return tables;
        }

        private Dictionary<string, IDbCommand> GetCommands(SqlCeConnection connection) {
            Dictionary<string, IDbCommand> commands = new Dictionary<string, IDbCommand>();
            // Get list of table names
                        SqlCeCommand command = new SqlCeCommand("SELECT TABLE_NAME FROM information_schema.tables;", connection);
            SqlCeDataReader Reader = command.ExecuteReader();
            while (Reader.Read()) {
                for (int i = 0; i < Reader.FieldCount; i++) {
                    string tableName = Reader.GetValue(i).ToString();
                    string sql = "select * from [" + tableName + "]";
                    commands.Add(tableName, new SqlCeCommand(sql, connection));
                }
            }
            Reader.Close();
            return commands;
        }

        private void SetProperty(Column column, string columnName, object value) {
            if (value == DBNull.Value)
                return;
            switch (columnName) {
                case "ColumnName": column.Name = (string)value; break;
                case "ColumnSize": column.Size = Convert.ToInt32(value); break;
                case "NumericPrecision": column.NumericPrecision = Convert.ToInt32(value); break;
                case "NumericScale": column.NumericScale = Convert.ToInt32(value); break;
                case "IsUnique": column.IsUnique = (bool)value; break;
                case "IsKey": column.IsKey = (bool)value; break;
                case "DataType": column.DataType = value.ToString().Replace("System.", ""); break;
                case "AllowDBNull": column.AllowNull = (bool)value; break;
                case "IsAutoIncrement": column.IsAutoIncrement = (bool)value; break;
                case "IsReadOnly": column.IsReadOnly = (bool)value; break;
            }
        }

        internal static string GetAccessDriver() {
            List<string> stroledb = GetOLEDBDrivers();
            if (stroledb.Contains("Microsoft.ACE.OLEDB.12.0")) {
                return "Microsoft.ACE.OLEDB.12.0";
            } else {
                return "Microsoft.Jet.OLEDB.4.0";
            }
        }

        private static List<String> GetOLEDBDrivers() {
            List<string> names = new List<string>();
            OleDbEnumerator e = new OleDbEnumerator();
            DataTable tbl = e.GetElements();
            foreach (DataRow row in tbl.Rows) {
                names.Add((string)row[0]);
            }
            return names;
        }
    }

    public class ProcedureResult {
        public string FieldName { get; set; }
        public object Value { get; set; }
    }

    public enum UpdateType {
        Add,
        Delete,
        Update
    }

    public class Table {
        public string Name { get; set; }
        public List<Column> Columns { get; set; }
        public Table() {
            Columns = new List<Column>();
        }
    }

    public class Column {
        public string Name { get; set; }
        public string DataType { get; set; }
        public int Size { get; set; }
        public int NumericPrecision { get; set; }
        public int NumericScale { get; set; }
        public bool IsKey { get; set; }
        public bool IsUnique { get; set; }
        public bool AllowNull { get; set; }
        public bool IsAutoIncrement { get; set; }
        public bool IsReadOnly { get; set; }
    }
}