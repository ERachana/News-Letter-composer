using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class FileDatabaseLoginForm : Form {
        private List<DatabaseInfo> companies = new List<DatabaseInfo>();
        private DataAdapter dataAdapter;

        public FileDatabaseLoginForm() {
            InitializeComponent();
        }

        public string UserId {
            get { return txtUserName.Text; }
            set { txtUserName.Text = value; }
        }

        private void FileDatabaseLoginForm_Load(object sender, EventArgs e) {

        }

		private void FileDatabaseLoginForm_Activated(object sender, EventArgs e) {
		
		}

        public void LoadForm(string filename) {
            dataAdapter = new DataAdapter(filename, string.Empty);
        }

        private void btnLogin_Click(object sender, EventArgs e) {
            if (String.IsNullOrEmpty(txtUserName.Text)) {
                MessageBox.Show("User name cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (String.IsNullOrEmpty(txtPassword.Text)) {
                MessageBox.Show("Password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataTable dt = dataAdapter.LoadData(String.Format("SELECT * FROM kushal_user WHERE UserId = '{0}' AND Pass = '{1}'", txtUserName.Text, EncryptDecrypt.Encrypt(txtPassword.Text)), "User");
            if (dt != null && dt.Rows.Count > 0) {
                GlobalVariables.SetValue("$$UserId", Convert.ToString(dt.Rows[0]["Id"]));
                GlobalVariables.SetValue("$$UserName", Convert.ToString(dt.Rows[0]["UserId"]));
                GlobalVariables.SetValue("$$UserDisplayName", Convert.ToString(dt.Rows[0]["Name"]));

                this.DialogResult = DialogResult.OK;
            } else {
                MessageBox.Show("Login failed. Please check user ID and password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.No;
        }
    }

    internal class DatabaseInfo {
        public string Name { get; set; }
        public string Server { get; set; }
        public string Database { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
