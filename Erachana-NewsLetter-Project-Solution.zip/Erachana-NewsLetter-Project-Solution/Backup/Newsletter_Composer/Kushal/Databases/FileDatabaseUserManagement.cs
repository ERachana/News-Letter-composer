using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;

namespace Newsletter_Composer {
    internal class FileDatabaseUserManagement {
        private int moduleIndex = 0, moduleMapping = 0;

        internal void Configure(string databaseFile) {
            bool defaultTableExists = CheckDefaultTablesExists(databaseFile);
            if (defaultTableExists == false) {
                CreateDefaultTablesIfRequired(databaseFile);
                AddModules(databaseFile);
                AssociateFormAndModule(databaseFile);
            }
        }

        private bool CheckDefaultTablesExists(string databaseFile) {
            DataAdapter dataAdapter = new DataAdapter(databaseFile, string.Empty);

            List<Table> tables = dataAdapter.ExtractTables();
            List<string> tableNames = new List<string>();
            foreach (Table table in tables) {
                tableNames.Add(table.Name.ToLower());
            }

            return tableNames.Contains("kushal_user") && tableNames.Contains("module") && tableNames.Contains("module_user_mapping") && tableNames.Contains("form_module_mapping");
        }

        private void CreateDefaultTablesIfRequired(string databaseFile) {
            DataAdapter dataAdapter = new DataAdapter(databaseFile, string.Empty);
            string moduleSql = @"CREATE TABLE [module] (
  Id INTEGER  NOT NULL,
  Name NVARCHAR(45) NOT NULL,
  PRIMARY KEY (Id)
)";
            try {
                dataAdapter.ExecuteSql(moduleSql);
            } catch { }

            string usersSql = @"CREATE TABLE [kushal_user] (
  Id INTEGER  NOT NULL,
  Name NVARCHAR(128) NOT NULL,
  UserId NVARCHAR(45) NOT NULL,
  Pass NVARCHAR(45) NOT NULL,
  IsAdmin BIT NOT NULL,
  IsActive BIT NOT NULL,
  PRIMARY KEY (Id)
);";

            try {
                dataAdapter.ExecuteSql(usersSql);
            } catch { }

            string encryptedPassword = EncryptDecrypt.Encrypt("admin");
            string defaultUsersSql = String.Format(@"INSERT INTO [kushal_user] VALUES (1,'Administrator','admin','{0}', 1, 1);", encryptedPassword);

            try {
                dataAdapter.ExecuteSql(defaultUsersSql);
            } catch { }

            string userModuleMappingSql = @"CREATE TABLE [module_user_mapping] (
  _Module INTEGER  NOT NULL,
  _User INTEGER  NOT NULL,
  _New BIT NOT NULL,
  _Edit BIT NOT NULL,
  _Delete BIT NOT NULL,
  _View BIT NOT NULL,
  PRIMARY KEY (_Module, _User)
)";

            try {
                dataAdapter.ExecuteSql(userModuleMappingSql);
            } catch { }

            string formModuleMapping = @"CREATE TABLE [form_module_mapping] (
  Id INTEGER  NOT NULL,
  Form NVARCHAR(45) NOT NULL,
  _Module INTEGER  NOT NULL,
  PRIMARY KEY (Id)
);";
            try { dataAdapter.ExecuteSql(formModuleMapping); } catch { }
        }

        private void AddModules(string databaseFile) {
            List<string> modules = new List<string>() {  };
            DataAdapter adapter = new DataAdapter(databaseFile, string.Empty);
            foreach (string module in modules) {
                string sql = String.Format("INSERT INTO [module] VALUES({0}, '{1}')", moduleIndex++, module);
                adapter.ExecuteSql(sql);
            }
        }

        private int GetModuleId(string module, string databaseFile) {
            int id = 0;
            DataAdapter adapter = new DataAdapter(databaseFile, string.Empty);
            DataTable dt = adapter.LoadData(String.Format("SELECT Id FROM [module] WHERE Name = '{0}'", module), "module");
            if (dt != null) {
                id = Convert.ToInt32(dt.Rows[0][0]);
            }
            return id;
        }

        private void AssociateFormAndModule(string databaseFile) {
            Dictionary<string, List<int>> formModules = new Dictionary<string, List<int>>();
            
            DataAdapter adapter = new DataAdapter(databaseFile, string.Empty);
            foreach (string form in formModules.Keys) {
                foreach (int module in formModules[form]) {
                    string sql = String.Format("INSERT INTO [form_module_mapping] VALUES({0}, '{1}', {2})", moduleMapping++, form, module);
                    adapter.ExecuteSql(sql);
                }
            }
        }
    }
}