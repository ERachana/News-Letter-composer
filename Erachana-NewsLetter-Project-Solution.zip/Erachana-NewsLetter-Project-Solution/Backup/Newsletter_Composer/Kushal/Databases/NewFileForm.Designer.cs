using Kushal.Controls;
namespace Newsletter_Composer {
    partial class NewFileForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.grpNewGroupBox1 = new Kushal.Controls.KushalGroupBox();
            this.btnBrowse = new Kushal.Controls.KushalButton();
            this.btnSetAsDefault = new Kushal.Controls.KushalButton();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.txtFileName = new Kushal.Controls.KushalTextBox();
            this.txtDataDirectory = new Kushal.Controls.KushalTextBox();
            this.SuspendLayout();
            
            
            this.btnSave.Location = new System.Drawing.Point(244, 194);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            this.btnClose.Location = new System.Drawing.Point(344, 194);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.grpNewGroupBox1.Location = new System.Drawing.Point(12, 14);
            this.grpNewGroupBox1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpNewGroupBox1.Name = "grpNewGroupBox1";
            this.grpNewGroupBox1.Enabled = true;
            this.grpNewGroupBox1.Visible = true;
            this.grpNewGroupBox1.TabIndex = 0;
            this.grpNewGroupBox1.TabStop = false;
            this.grpNewGroupBox1.Size = new System.Drawing.Size(412, 168);
            this.grpNewGroupBox1.Text = @"";
            this.grpNewGroupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox1.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox1, @"");

            this.btnBrowse.Location = new System.Drawing.Point(14, 129);
            this.btnBrowse.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnBrowse.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Enabled = true;
            this.btnBrowse.Visible = true;
            this.btnBrowse.TabIndex = 0;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnBrowse.Size = new System.Drawing.Size(80, 30);
            this.btnBrowse.Text = @"Browse";
            this.btnBrowse.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnBrowse, @"");
            
            
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);

            this.btnSetAsDefault.Location = new System.Drawing.Point(103, 129);
            this.btnSetAsDefault.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSetAsDefault.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSetAsDefault.Name = "btnSetAsDefault";
            this.btnSetAsDefault.Enabled = true;
            this.btnSetAsDefault.Visible = true;
            this.btnSetAsDefault.TabIndex = 0;
            this.btnSetAsDefault.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSetAsDefault.Size = new System.Drawing.Size(106, 30);
            this.btnSetAsDefault.Text = @"Set As Default";
            this.btnSetAsDefault.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetAsDefault.UseVisualStyleBackColor = false;
            this.btnSetAsDefault.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSetAsDefault, @"");
            
            
            this.btnSetAsDefault.Click += new System.EventHandler(this.btnSetAsDefault_Click);

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(14, 10);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(100, 20);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"File Name";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(14, 67);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(100, 22);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @"Data Directory";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.txtFileName.Location = new System.Drawing.Point(14, 33);
            this.txtFileName.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtFileName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtFileName.Multiline = false;
            this.txtFileName.MaxLength = 256;
            this.txtFileName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Text = @"";
            
            this.txtFileName.AllowNull = false;
            this.txtFileName.DefaultValue = "";
            this.txtFileName.FriendlyName = "";
            this.txtFileName.ValidationType = TextValidation.None;
            this.txtFileName.ValidationExpression = @"";
            this.txtFileName.ValidationMessage = @"";
            this.txtFileName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtFileName.Enabled = true;
            this.txtFileName.ReadOnly = false;
            this.txtFileName.Visible = true;
            this.txtFileName.TabIndex = 0;
            this.txtFileName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtFileName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileName.Size = new System.Drawing.Size(381, 31);
            this.toolTip1.SetToolTip(this.txtFileName, @"");

            this.txtDataDirectory.Location = new System.Drawing.Point(14, 90);
            this.txtDataDirectory.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtDataDirectory.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtDataDirectory.Multiline = false;
            this.txtDataDirectory.MaxLength = 256;
            this.txtDataDirectory.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDataDirectory.Name = "txtDataDirectory";
            this.txtDataDirectory.Text = @"";
            
            this.txtDataDirectory.AllowNull = false;
            this.txtDataDirectory.DefaultValue = "";
            this.txtDataDirectory.FriendlyName = "";
            this.txtDataDirectory.ValidationType = TextValidation.None;
            this.txtDataDirectory.ValidationExpression = @"";
            this.txtDataDirectory.ValidationMessage = @"";
            this.txtDataDirectory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtDataDirectory.Enabled = true;
            this.txtDataDirectory.ReadOnly = false;
            this.txtDataDirectory.Visible = true;
            this.txtDataDirectory.TabIndex = 0;
            this.txtDataDirectory.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtDataDirectory.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataDirectory.Size = new System.Drawing.Size(381, 31);
            this.toolTip1.SetToolTip(this.txtDataDirectory, @"");


            
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpNewGroupBox1);
            this.grpNewGroupBox1.Controls.Add(this.btnBrowse);
            this.grpNewGroupBox1.Controls.Add(this.btnSetAsDefault);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel1);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel2);
            this.grpNewGroupBox1.Controls.Add(this.txtFileName);
            this.grpNewGroupBox1.Controls.Add(this.txtDataDirectory);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "NewFileForm";
            this.Text = "New File";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(451, 274);
            
                        this.Load += new System.EventHandler(this.NewFileForm_Load);
            this.Activated += new System.EventHandler(this.NewFileForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox1;
        private Kushal.Controls.KushalButton btnBrowse;
        private Kushal.Controls.KushalButton btnSetAsDefault;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private Kushal.Controls.KushalTextBox txtFileName;
        private Kushal.Controls.KushalTextBox txtDataDirectory;
    }
}