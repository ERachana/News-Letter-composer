using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class NewFileForm : Form {
        public NewFileForm() {
            InitializeComponent();
        }

        public string FileName {
            get { return txtDataDirectory.Text + @"\" + txtFileName.Text + ".ENL"; }
        }

        private void NewFileForm_Load(object sender, EventArgs e) {
            txtDataDirectory.Text = Settings.GetDataDirectoryPath();
        }

		private void NewFileForm_Activated(object sender, EventArgs e) {
		
		}

        private void btnSetAsDefault_Click(object sender, EventArgs e) {
            if (String.IsNullOrEmpty(txtDataDirectory.Text)) {
                MessageBox.Show("Data directory cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e) {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.ShowNewFolderButton = true;
            if (dlg.ShowDialog() == DialogResult.OK) {
                txtDataDirectory.Text = dlg.SelectedPath;

                Settings.SaveDataDirectoryPath(txtDataDirectory.Text);
            }
        }

        private void btnSave_Click(object sender, EventArgs e) {
            if (String.IsNullOrEmpty(txtDataDirectory.Text)) {
                MessageBox.Show("Data directory cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Directory.Exists(txtDataDirectory.Text) == false) {
                Directory.CreateDirectory(txtDataDirectory.Text);
            }

            // Copy blank database file 
            string destinationFile = txtDataDirectory.Text + @"\" + txtFileName.Text + ".ENL";
            CreateDatabase(destinationFile);

            this.DialogResult = DialogResult.OK;
        }

        internal static void CreateDatabase(string filepath) {
            string dir = Path.GetDirectoryName(filepath);
            if (Directory.Exists(dir) == false) {
                Directory.CreateDirectory(dir);
            }

            string appPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar;
            File.Copy(appPath + "InitialDB.sql", filepath, true);

            FileDatabaseUserManagement fileDatabaseUserManagement = new FileDatabaseUserManagement();
            fileDatabaseUserManagement.Configure(filepath);
        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.No;
        }
    }
}
