using Kushal.Controls;
namespace Newsletter_Composer {
    partial class DisclaimerForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.grpNewGroupBox1 = new Kushal.Controls.KushalGroupBox();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.SuspendLayout();
            
            
            this.btnClose.Location = new System.Drawing.Point(632, 294);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(10, 298);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(395, 23);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @"All disputes are subject to Bengaluru jurisdiction only.";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.grpNewGroupBox1.Location = new System.Drawing.Point(5, 7);
            this.grpNewGroupBox1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpNewGroupBox1.Name = "grpNewGroupBox1";
            this.grpNewGroupBox1.Enabled = true;
            this.grpNewGroupBox1.Visible = true;
            this.grpNewGroupBox1.TabIndex = 0;
            this.grpNewGroupBox1.TabStop = false;
            this.grpNewGroupBox1.Size = new System.Drawing.Size(713, 281);
            this.grpNewGroupBox1.Text = @"";
            this.grpNewGroupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox1.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox1, @"");

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(6, 11);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(698, 262);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"1. The license assumes full responsibility for the selection, installation and use of the program. ERachana Technologies assumes no responsibility for any direct/indirect damages ensuing from the use of its Product. 

2. ERachana Technologies does not warrant that the functions contained in the software will meet your requirements or that the operation of the Software will be Uninterrupted or error free.

3. This software package or program is provided as is, without warranty of any kind either expressed or implied, including but not limited to the implied warranties merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the product is with the user. Should the product prove defective, the user assumes the cost of all necessary servicing or error correction. 

4. Due care has been taken to avoid errors/omissions in this package. Despite sincere efforts, some errors might have occurred for which the firm shall not be responsible. Any mistakes, omissions, errors or discrepancies, noticed by users may kindly be brought to our notice, which shall be taken in care of subsequent versions. ";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");


            
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblNewLabel2);
            this.Controls.Add(this.grpNewGroupBox1);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel1);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "DisclaimerForm";
            this.Text = "Disclaimer";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(745, 369);
            
                        this.Load += new System.EventHandler(this.DisclaimerForm_Load);
            this.Activated += new System.EventHandler(this.DisclaimerForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox1;
        private Kushal.Controls.KushalLabel lblNewLabel1;
    }
}