using System;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class DisclaimerForm : Form {
        public DisclaimerForm() {
            InitializeComponent();
        }

        private void DisclaimerForm_Load(object sender, EventArgs e) { }

		private void DisclaimerForm_Activated(object sender, EventArgs e) { }

        private void btnClose_Click(object sender, EventArgs e) {
            Close();
        }
    }
}
