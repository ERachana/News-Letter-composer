using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Newsletter_Composer {
    internal enum ExcelAppType {
        MicrosoftExcel,
        OpenOffice
    }
    internal class ExcelExport : IDisposable {
        private object application;
        private object appManager;
        private object workbook;
        private object sheet;
        const int xlTemplate = 17;
        private ExcelAppType excelAppType;

        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing) {
            if (disposing) {
                application = null;
                appManager = null;
                workbook = null;
                sheet = null;
            }
        }

        /// <summary>
        /// Creates new instance of excel workbook
        /// </summary>
        /// <param name="appType">Indicate whether it is Microsoft Excel or Open Office</param>
        public ExcelExport(ExcelAppType appType) : this(appType, true) { }

        /// <summary>
        /// Creates new instance of excel workbook
        /// </summary>
        /// <param name="appType">Indicate whether it is Microsoft Excel or Open Office</param>
        /// <param name="createWorkBook">Indicate whether to create a new workbook</param>
        public ExcelExport(ExcelAppType appType, bool createWorkBook) {
            excelAppType = appType;

            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                Type excelType = Type.GetTypeFromProgID("Excel.Application");
                application = Activator.CreateInstance(excelType);
                application.GetType().InvokeMember("Visible", BindingFlags.SetProperty, null, application, new object[] { true });
            } else {
                Type excelType = Type.GetTypeFromProgID("com.sun.star.ServiceManager");
                appManager = Activator.CreateInstance(excelType);
                application = appManager.GetType().InvokeMember("createInstance", BindingFlags.InvokeMethod, null, appManager, new object[] { "com.sun.star.frame.Desktop" });
            }

            if (createWorkBook) {
                NewWorkBook();
            }
        }

        /// <summary>
        /// Creates new workbook
        /// </summary>
        public void NewWorkBook() {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object workbooks = application.GetType().InvokeMember("Workbooks", BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Add", BindingFlags.InvokeMethod, null, workbooks, null);
            } else {
                object[] args = new object[2];
                args[0] = InitiateAPropertyValue();
                args[1] = InitiateAPropertyValue();
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { "private:factory/scalc", "_blank", 0, args });
            }
        }

        /// <summary>
        /// Set excel workbook visibility
        /// </summary>
        /// <param name="value">True to make it visible, False otherwise</param>
        public void SetVisible(bool value) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                application.GetType().InvokeMember("Visible", BindingFlags.SetProperty, null, application, new object[] { value });
            } else {
                if (workbook != null) {
                    object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                    object frame = controler.GetType().InvokeMember("Frame", BindingFlags.GetProperty, null, controler, null);
                    object container = frame.GetType().InvokeMember("ContainerWindow", BindingFlags.GetProperty, null, frame, null);
                    container.GetType().InvokeMember("SetVisible", BindingFlags.InvokeMethod, null, container, new object[] { value });
                }
            }
        }

        /// <summary>
        /// Open the given workbook file
        /// </summary>
        /// <param name="path">Excel file path</param>
        public void OpenWorkBook(string path) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object[] args = new object[1];
                args[0] = path;
                object workbooks = application.GetType().InvokeMember("Workbooks", BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Open", BindingFlags.InvokeMethod, null, workbooks, args);
            } else {
                object[] args = new object[2];
                args[0] = InitiateAPropertyValue();
                args[1] = InitiateAPropertyValue();
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { PathConverter(path), "_blank", 0, args });
            }
            sheet = GetActiveSheet();
        }

        /// <summary>
        /// Open excel template file
        /// </summary>
        /// <param name="path">Template file path</param>
        public void OpenWorkBookTemplate(string path) {
            OpenWorkBookTemplate(path, true);
        }

        /// <summary>
        /// Open excel template file
        /// </summary>
        /// <param name="path">Template file path</param>
        /// <param name="isLocal">Indicate whether template file is in local directory</param>
        public void OpenWorkBookTemplate(string path, bool isLocal) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object[] args = new object[1];
                if (isLocal) {
                    args[0] = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar + path;
                } else {
                    args[0] = path;
                }
                object workbooks = application.GetType().InvokeMember("Workbooks", BindingFlags.GetProperty, null, application, null);
                workbook = workbooks.GetType().InvokeMember("Open", BindingFlags.InvokeMethod, null, workbooks, args);
            } else {
                object[] args = new object[2];
                args[0] = MakePropertyValue("Hidden", "true");
                args[1] = MakePropertyValue("AsTemplate", "true");
                workbook = application.GetType().InvokeMember("loadComponentFromURL", BindingFlags.InvokeMethod, null, application, new object[] { PathConverter(path), "_blank", 0, args });
            }
            sheet = GetActiveSheet();
        }

        /// <summary>
        /// Saves excel workbook file
        /// </summary>
        /// <param name="strFileName">Source file name</param>
        public void SaveWorkbook(string strFileName) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object[] args = new object[2];
                args[0] = strFileName;
                args[1] = xlTemplate;
                object objWorkBook = application.GetType().InvokeMember("ActiveWorkbook", BindingFlags.GetProperty, null, application, null);
                objWorkBook.GetType().InvokeMember("SaveAs", BindingFlags.GetProperty, null, objWorkBook, args);
            }
        }
		
		/// <summary>
        /// Saves excel  file
        /// </summary>
        /// <param name="strFileName">Source file name</param>
        public void SaveExcel(string strFileName)
        {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
            {
                object[] args = new object[1];
                args[0] = strFileName;
                //args[1] = xlTemplate;
                object objWorkBook = application.GetType().InvokeMember("ActiveWorkbook", BindingFlags.GetProperty, null, application, null);
                objWorkBook.GetType().InvokeMember("SaveAs", BindingFlags.GetProperty, null, objWorkBook, args);
            }
        }

        private string PathConverter(string file) {
            file = file.Replace(@"\", "/");
            file = file.Replace(" ", "%20");
            return "file:///" + file;
        }

        private Object InitiateAPropertyValue() {
            return appManager.GetType().InvokeMember("Bridge_GetStruct", BindingFlags.InvokeMethod, null, appManager, new object[] { "com.sun.star.beans.PropertyValue" });
        }

        private Object SetPropertyValues(Object popertyvalue, string name, string value) {
            popertyvalue.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, popertyvalue, new object[] { value });
            return popertyvalue;
        }

        private Object MakePropertyValue(string name, string value) {
            return SetPropertyValues(InitiateAPropertyValue(), name, value);
        }

        /// <summary>
        /// Get cell value in the active sheet
        /// </summary>
        /// <param name="col">Column index</param>
        /// <param name="row">Row index</param>
        /// <returns>Cell value</returns>
        public object GetValue(long col, long row) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                return cell.GetType().InvokeMember("Value", BindingFlags.GetProperty, null, cell, null);
            } else {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                return cell.GetType().InvokeMember("String", BindingFlags.GetProperty, null, cell, null);
            }
        }

        /// <summary>
        /// Selects a cell value in the active sheet
        /// </summary>
        /// <param name="col">Column index</param>
        /// <param name="row">Row index</param>
        /// <returns>Selected value</returns>
        public object SelectCell(long col, long row) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                return cell.GetType().InvokeMember("Select", BindingFlags.InvokeMethod, null, cell, null);
            } else {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                return cell.GetType().InvokeMember("String", BindingFlags.GetProperty, null, cell, null);
            }
        }

        /// <summary>
        /// Exports data table value to the active sheet from the specified start index
        /// </summary>
        /// <param name="data">Data table holding values</param>
        /// <param name="startIndex">Start index</param>
        public void Export(DataTable data, int startIndex) {
            object sheet = GetActiveSheet();
            for (int row = 0; row < data.Rows.Count; row++) {
                DataRow rowData = data.Rows[row];
                for (int column = 0; column < data.Columns.Count; column++) {
                    SetValue(sheet, column + 1, (row + startIndex), rowData[column]);
                }
            }
        }

        /// <summary>
        /// Exports data stored in excel sheet instance.
        /// </summary>
        /// <param name="sheet">Excel sheet instance holding data to be exported</param>
        public void Export(ExcelSheet sheet) {
            SetExcelSheetName(sheet.Name);
            ExportColumns(sheet.Columns);
            ExportData(sheet.Data);
        }

        public void SetExcelSheetName(string name) {
            object sheet = GetActiveSheet();
            sheet.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, sheet, new object[] { name });
        }

        public object GetActiveSheet() {
            if (excelAppType == ExcelAppType.MicrosoftExcel)
                return application.GetType().InvokeMember("ActiveSheet", BindingFlags.GetProperty, null, application, null);
            object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
            return controler.GetType().InvokeMember("ActiveSheet", BindingFlags.GetProperty, null, controler, null);
        }

        /// <summary>
        /// Gets active sheet name
        /// </summary>
        /// <returns></returns>
        public object GetExcelSheetName() {
            object sheet = GetActiveSheet();
            return sheet.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, sheet, null);
        }

        /// <summary>
        /// Selects worksheet at the given index
        /// </summary>
        /// <param name="index">Worksheet index</param>
        public void SelectWorkSheet(int index) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Select", BindingFlags.GetProperty, null, sheet, null);
            } else {
                object[] args = new object[1];
                args[0] = index - 1;
                var sheets = workbook.GetType().InvokeMember("getSheets", BindingFlags.InvokeMethod, null, workbook, null);
                sheet = workbook.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, sheets, args);
                object controler = workbook.GetType().InvokeMember("CurrentController", BindingFlags.GetProperty, null, workbook, null);
                object[] args1 = new object[1];
                args1[0] = sheet;
                controler.GetType().InvokeMember("ActiveSheet", BindingFlags.SetProperty, null, controler, args1);
            }
        }

        /// <summary>
        /// Remove worksheet at the given index
        /// </summary>
        /// <param name="index">Worksheet index</param>
        public void DeleteWorkSheet(int index) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object[] args = new object[1];
                args[0] = index;
                sheet = application.GetType().InvokeMember("WorkSheets", BindingFlags.GetProperty, null, application, args);
                sheet.GetType().InvokeMember("Delete", BindingFlags.GetProperty, null, sheet, null);
            }

        }

        /// <summary>
        /// Set number format for the given range
        /// </summary>
        /// <param name="strRange">Range in the active worksheet</param>
        /// <param name="strFormat">Number format to be applied</param>
        public void SetRangeNumberFormat(string strRange, string strFormat) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                objRange.GetType().InvokeMember("NumberFormat", BindingFlags.SetProperty, null, objRange, new object[] { strFormat });
            }
        }

        /// <summary>
        /// Sets border to the given cell
        /// </summary>
        /// <param name="strRange">Range indicator</param>
        /// <param name="blnLeft">Indidates whether left cell border to be set</param>
        /// <param name="blnRight">Indidates whether right cell border to be set</param>
        /// <param name="blnTop">Indidates whether top cell border to be set</param>
        /// <param name="blnBottom">Indidates whether bottom cell border to be set</param>
        /// <param name="blnHorizontal">Indidates whether horizontal line style to be set</param>
        /// <param name="blnVertical">Indidates whether vertical line style to be set</param>
        public void SetMarkBorder(string strRange, bool blnLeft, bool blnRight, bool blnTop, bool blnBottom, bool blnHorizontal, bool blnVertical) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                object border;
                if (blnLeft) {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 7 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnRight) {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 10 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }

                if (blnTop) {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 8 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnBottom) {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 9 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }

                if (blnHorizontal) {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 11 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
                if (blnVertical) {
                    border = objRange.GetType().InvokeMember("Borders", BindingFlags.GetProperty, null, objRange, new object[] { 12 });
                    border.GetType().InvokeMember("LineStyle", BindingFlags.SetProperty, null, border, new object[] { 1 });
                }
            }
        }

        /// <summary>
        /// Sets background color of the given range
        /// </summary>
        /// <param name="strRange">Range indicator</param>
        /// <param name="intColorIndex">Color index</param>
        public void SetRangeBackColor(string strRange, int intColorIndex) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                var sheet = GetActiveSheet();
                var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange });
                var interior = objRange.GetType().InvokeMember("Interior", BindingFlags.GetProperty, null, objRange, null);
                interior.GetType().InvokeMember("ColorIndex", BindingFlags.SetProperty, null, interior, new object[] { intColorIndex });
            }
        }

        /// <summary>
        /// Hides columns from the given index in the active worksheet
        /// </summary>
        /// <param name="StartCol">Start column index</param>
        public void HideColumnsFrom(int StartCol) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                var sheet = GetActiveSheet();
                var strStartCol = GetExcelColumnName(StartCol);
                int icolsCount;
                var columns = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, null);
                var colcount = sheet.GetType().InvokeMember("Count", BindingFlags.GetProperty, null, columns, null);
                icolsCount = (int)colcount;
                var strEndCol = GetExcelColumnName(icolsCount);
                var selection = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { strStartCol + ":" + strEndCol });
                var entirecol = selection.GetType().InvokeMember("EntireColumn", BindingFlags.GetProperty, null, selection, null);
                entirecol.GetType().InvokeMember("Hidden", BindingFlags.SetProperty, null, entirecol, new object[] { true });
            }
        }

        private string GetExcelColumnName(int columnNumber) {
            int dividend = columnNumber;
            string columnName = String.Empty;
            while (dividend > 0) {
                var modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo) + columnName;
                dividend = (dividend - modulo) / 26;
            }
            return columnName;
        }

        /// <summary>
        /// Updates column width of active worksheet
        /// </summary>
        /// <param name="columns">List of values to update worksheet column width.</param>
        public void ColumnWidths(List<int> columns) {
            object sheet = GetActiveSheet();
            for (int i = 0; i < columns.Count; i++) {
                SetColWidth(sheet, i + 1, columns[i]);
            }
        }

        /// <summary>
        /// Creates column in the worksheet
        /// </summary>
        /// <param name="columns">List of column names</param>
        public void ExportColumns(List<string> columns) {
            object sheet = GetActiveSheet();
            for (int i = 0; i < columns.Count; i++) {
                string column = columns[i];
                SetValue(sheet, i + 1, 1, column);
            }
        }

        /// <summary>
        /// Exports data to excel worksheet
        /// </summary>
        /// <param name="data">Set row row values to be exported</param>
        public void ExportData(List<List<string>> data) {
            object sheet = GetActiveSheet();
            for (int row = 0; row < data.Count; row++) {
                List<string> rowData = data[row];
                for (int column = 0; column < rowData.Count; column++) {
                    SetValue(sheet, column + 1, (row + 2), rowData[column]);
                }
            }
        }

        public void SetValue(object sheet, int col, int row, object value) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new[] { value });
            } else {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new[] { value });
            }
        }

        /// <summary>
        /// Set value to a cell in active worksheet
        /// </summary>
        /// <param name="col">Column index</param>
        /// <param name="row">Row index</param>
        /// <param name="value">Value to be assigned</param>
        public void SetCellValue(int col, int row, object value) {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object cell = sheet.GetType().InvokeMember("Cells", BindingFlags.GetProperty, null, sheet, new object[] { row, col });
                cell.GetType().InvokeMember("Value", BindingFlags.SetProperty, null, cell, new[] { value });
            } else {
                object cell = sheet.GetType().InvokeMember("getCellByPosition", BindingFlags.InvokeMethod, null, sheet, new object[] { col - 1, row - 1 });
                cell.GetType().InvokeMember("String", BindingFlags.SetProperty, null, cell, new[] { value });
            }
        }

        /// <summary>
        /// Set column width of an excel sheet
        /// </summary>
        /// <param name="sheet">Worksheet with the given column</param>
        /// <param name="index">Column index</param>
        /// <param name="length">Column width</param>
        public void SetColWidth(object sheet, int index, int length) {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object Colm = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { index, Missing.Value });

                Colm.GetType().InvokeMember("ColumnWidth", BindingFlags.SetProperty, null, Colm, new object[] { length });
            } else {
                object Colms = sheet.GetType().InvokeMember("getColumns", BindingFlags.InvokeMethod, null, sheet, null);
                object Colm = Colms.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, Colms, new object[] { index - 1 });

                object propValue = new object();
                propValue = MakePropertyValue("Width", Convert.ToString(length * 10));
                Colm.GetType().InvokeMember("setPropertyValue", BindingFlags.InvokeMethod, null, Colm, new object[] { "Width", Convert.ToInt32(length * 100 * 2.5) });
            }
        }

        /// <summary>
        /// Set width of column in the active sheet
        /// </summary>
        /// <param name="index">Column index</param>
        /// <param name="length">Column with</param>
        public void SetColumnWidth(int index, double length) {
            object sheet = GetActiveSheet();
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                object Colm = sheet.GetType().InvokeMember("Columns", BindingFlags.GetProperty, null, sheet, new object[] { index, Missing.Value });

                Colm.GetType().InvokeMember("ColumnWidth", BindingFlags.SetProperty, null, Colm, new object[] { length });
            } else {
                object Colms = sheet.GetType().InvokeMember("getColumns", BindingFlags.InvokeMethod, null, sheet, null);
                object Colm = Colms.GetType().InvokeMember("getByIndex", BindingFlags.InvokeMethod, null, Colms, new object[] { index - 1 });

                object propValue = new object();
                propValue = MakePropertyValue("Width", Convert.ToString(length * 10));
                Colm.GetType().InvokeMember("setPropertyValue", BindingFlags.InvokeMethod, null, Colm, new object[] { "Width", Convert.ToInt32(length * 100 * 2.5) });
            }
        }

        /// <summary>
        /// Close open workbook
        /// </summary>
        public void CloseWorkbook() {
            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                if (workbook != null) {
                    workbook.GetType().InvokeMember("Close", BindingFlags.InvokeMethod, null, workbook, new object[] { false });
                    Marshal.ReleaseComObject(workbook);
                    workbook = null;
                    sheet = null;
                }
            } else {
                if (workbook != null) {
                    workbook.GetType().InvokeMember("Dispose", BindingFlags.InvokeMethod, null, workbook, null);
                    Marshal.ReleaseComObject(workbook);
                    workbook = null;
                    sheet = null;
                }
            }
        }

        /// <summary>
        /// Close excel instance
        /// </summary>
        public void CloseExcel() {
            if (workbook != null)
                CloseWorkbook();

            if (excelAppType == ExcelAppType.MicrosoftExcel) {
                if (workbook == null) {
                    application.GetType().InvokeMember("Quit", BindingFlags.InvokeMethod, null, application, null);
                    Marshal.ReleaseComObject(application);
                }
                application = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            } else {
                application.GetType().InvokeMember("terminate", BindingFlags.InvokeMethod, null, application, null);
            }
        }

        public void CellsMearge(string strRange1, string strRange2) {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1, strRange2 });
            objRange.GetType().InvokeMember("MergeCells", BindingFlags.SetProperty, null, objRange, new object[] { true });
        }

        public void SetVerticalAlignment(string strRange1, int Alignment) {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("VerticalAlignment", BindingFlags.SetProperty, null, objRange, new object[] { Alignment });
        }


        public void SetHorisontalAlignment(string strRange1, int Alignment) {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("HorizontalAlignment", BindingFlags.SetProperty, null, objRange, new object[] { Alignment });
        }

        public void SetRowHeight(string strRange1, double Height) {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("RowHeight", BindingFlags.SetProperty, null, objRange, new object[] { Height });
        }
        public void SetWrapText(string strRange1) {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new object[] { strRange1 });
            objRange.GetType().InvokeMember("WrapText", BindingFlags.SetProperty, null, objRange, new object[] { true });
        }
        public void SetOrientation(int orientation) {
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("PageSetup", BindingFlags.GetProperty, null, sheet, null);
            objRange.GetType().InvokeMember("Orientation", BindingFlags.SetProperty, null, objRange, new object[] { orientation });
        }

        public void SetFont(string strRange1, string strRange2, object font) {
            Font newFont = (Font)(font);
            var sheet = GetActiveSheet();
            var objRange = sheet.GetType().InvokeMember("Range", BindingFlags.GetProperty, null, sheet, new Object[] { strRange1, strRange2 });
            var objFont = objRange.GetType().InvokeMember("Font", BindingFlags.GetProperty, null, objRange, null);

            objRange.GetType().InvokeMember("Name", BindingFlags.SetProperty, null, objFont, new Object[] { newFont.Name });
            objRange.GetType().InvokeMember("Size", BindingFlags.SetProperty, null, objFont, new Object[] { newFont.Size });
            objRange.GetType().InvokeMember("FontStyle", BindingFlags.SetProperty, null, objFont, new Object[] { newFont.Style });
        }
    }
}
