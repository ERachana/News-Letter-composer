using System.Collections.Generic;

namespace Newsletter_Composer {
    internal class ExcelSheet {
        /// <summary>
        /// Excel sheet name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// List of columns
        /// </summary>
        public List<string> Columns { get; set; }
        /// <summary>
        /// Excel sheet data
        /// </summary>
        public List<List<string>> Data { get; set; }

        internal ExcelSheet() {
            Columns = new List<string>();
            Data = new List<List<string>>();
        }
    }
}
