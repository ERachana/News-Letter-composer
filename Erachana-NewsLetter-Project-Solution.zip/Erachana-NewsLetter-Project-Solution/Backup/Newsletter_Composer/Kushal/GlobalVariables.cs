using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;

namespace Newsletter_Composer {
    internal class GlobalVariables {
        private static Dictionary<string, string> values = new Dictionary<string, string>();
        static GlobalVariables() {
            values.Add("$$ApplicationPath", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            
        }

        internal static string GetValue(string variableName) {
            if (values.ContainsKey(variableName)) {
                return values[variableName];
            }
            return string.Empty;
        }

        internal static void SetValue(string variableName, string value) {
            if (values.ContainsKey(variableName) == false) {
                values.Add(variableName, string.Empty);
            }
            values[variableName] = value;
        }
    }
}
