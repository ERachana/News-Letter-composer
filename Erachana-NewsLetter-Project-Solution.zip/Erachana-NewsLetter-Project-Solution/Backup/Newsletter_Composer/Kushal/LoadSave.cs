using System;
using System.Xml.Serialization;
using System.IO;

namespace Newsletter_Composer {
    internal class LoadSave {
        private static ProgressForm progressForm;

        /// <summary>
        /// Serialize the given instance and store it in the file specified.
        /// </summary>
        /// <param name="type">Instance Type</param>
        /// <param name="o">Instance</param>
        /// <param name="filename">File path</param>
        internal static void Save(Type type, object o, string filename) {
            Save(type, o, filename, true);
        }

        /// <summary>
        /// Serialize the given instance and store it in the file specified.
        /// </summary>
        /// <param name="type">Instance Type</param>
        /// <param name="o">Instance</param>
        /// <param name="filename">File path</param>
        /// <param name="emptyNamespaces">Namespaces are not included if set to false</param>
        internal static void Save(Type type, object o, string filename, bool emptyNamespaces) {
            try {
                ShowProgress(ProgressType.Saving);
                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                ns.Add(string.Empty, string.Empty);
                XmlSerializer serializer = XmlSerializer.FromTypes(new[] { type })[0];
                using (TextWriter textWriter = new StreamWriter(filename)) {
                    if (emptyNamespaces) {
                        serializer.Serialize(textWriter, o, ns);
                    } else {
                        serializer.Serialize(textWriter, o);
                    }
                }
            } finally {
                CloseProgress();
            }
        }

        /// <summary>
        /// Deserializes content in the file specified.
        /// </summary>
        /// <param name="type">Instance type</param>
        /// <param name="filename">File path</param>
        /// <returns>Instance created after deserializing file content</returns>
        internal static object Load(Type type, string filename) {
            object o = null;
            try {
                ShowProgress(ProgressType.Loading);
                if (File.Exists(filename)) {
                    XmlSerializer deserializer = XmlSerializer.FromTypes(new[] { type })[0];
                    using (TextReader textReader = new StreamReader(filename)) {
                        o = deserializer.Deserialize(textReader);
                    }
                }
            } finally {
                CloseProgress();
            }

            return o;
        }

        internal static void ShowProgress(ProgressType type) {
            //progressForm = new ProgressForm();
            //progressForm.Type = type;

            //Thread progressThread = new Thread(new ThreadStart(ProgressThread));
            //progressThread.IsBackground = true;
            //progressThread.Start();
        }

        internal static void CloseProgress() {
            //if (progressForm != null) {
            //    Thread.Sleep(1000);
            //    progressForm.Close();
            //}
        }

        private static void ProgressThread() {
            if (progressForm != null) {
                progressForm.ShowDialog();
            }
        }
    }
}
