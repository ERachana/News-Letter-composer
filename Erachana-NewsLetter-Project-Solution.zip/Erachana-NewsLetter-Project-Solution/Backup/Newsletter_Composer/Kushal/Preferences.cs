using System.Reflection;
using System.IO;

namespace Newsletter_Composer {
    public class Preferences {
        // Save preferences in preferences.xml
        private static string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar + "preferences.xml";

        public string DefaultDirectory { get; set; }

        /// <summary>
        /// Serializes preferences instance and stores serialized content in the local directory.
        /// </summary>
        public void Save() {
            LoadSave.Save(typeof(Preferences), this, path);
        }

        /// <summary>
        /// Loads preferences by deserializing the file stored in local directory.
        /// </summary>
        /// <returns>Preferences instance</returns>
        public static Preferences Load() {
            return (Preferences)LoadSave.Load(typeof(Preferences), path);
        }
    }
}
