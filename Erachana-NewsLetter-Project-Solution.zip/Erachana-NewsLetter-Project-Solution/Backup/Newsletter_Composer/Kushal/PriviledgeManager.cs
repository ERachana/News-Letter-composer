using System;
using System.Collections.Generic;
using System.Data;

namespace Newsletter_Composer {
    internal class PriviledgeManager {
        /// <summary>
        /// Gets priviledges available for the given user to access a form. 
        /// </summary>
        /// <param name="formName">Form to be accessed.</param>
        /// <param name="userId">User ID</param>
        /// <returns>Priviledges available</returns>
        public static PriviledgeType GetPriviledge(string formName, string userId) {
            DataAdapter adapter = DataAdapter.Current;
            // Get modules assigned to the form
            string sql = String.Format("SELECT * FROM form_module_mapping  WHERE Form = '{0}'", formName);
            DataTable dt = adapter.LoadData(sql, "form_module");

            List<string> modules = new List<string>();
            if (dt != null && dt.Rows.Count > 0) {
                foreach (DataRow row in dt.Rows) {
                    modules.Add("" + row["_Module"]);
                }
            }else{
                return PriviledgeType.None;
            }

            // Get priviledge given to the user per module
            sql = String.Format(@"SELECT m.[_New], m.[_Edit], m.[_Delete], m.[_View]
FROM module_user_mapping m
INNER JOIN kushal_user u ON u.Id = m.[_User]
WHERE u.UserId = '{0}' AND m.[_Module] IN ({1});", userId, String.Join(", ", modules.ToArray()));

            dt = adapter.LoadData(sql, "priviledge");
            
            bool newPriviledge = false, editPriviledge = false, deletePriviledge = false, viewPriviledge = false;
            if (dt != null && dt.Rows.Count > 0) {
                foreach (DataRow row in dt.Rows) {
                    newPriviledge = newPriviledge || (bool)row["_New"];
                    editPriviledge = editPriviledge || (bool)row["_Edit"];
                    deletePriviledge = deletePriviledge || (bool)row["_Delete"];
                    viewPriviledge = viewPriviledge || (bool)row["_View"];
                }
            }

            PriviledgeType priviledge = PriviledgeType.None;
            if (newPriviledge) { priviledge = priviledge | PriviledgeType.New; }
            if (editPriviledge) { priviledge = priviledge | PriviledgeType.Edit; }
            if (deletePriviledge) { priviledge = priviledge | PriviledgeType.Delete; }
            if (viewPriviledge) { priviledge = priviledge | PriviledgeType.View; }

            return priviledge;
        }
    }
}