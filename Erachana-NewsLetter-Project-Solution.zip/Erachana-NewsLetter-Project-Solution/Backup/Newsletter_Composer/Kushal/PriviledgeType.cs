namespace Newsletter_Composer {
    public enum PriviledgeType {
        None = 1,
        New = 2,
        Edit = 4,
        Delete = 8,
        View = 16,
    }
}
