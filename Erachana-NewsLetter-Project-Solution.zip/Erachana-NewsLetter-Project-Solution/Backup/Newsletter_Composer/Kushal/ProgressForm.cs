using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class ProgressForm : Form {
        public ProgressForm() {
            InitializeComponent();
        }

        public ProgressType Type {
            set {
                switch (value) {
                    case ProgressType.Executing: lblProgressMessage.Text = "Executing..."; break;
                    case ProgressType.Loading: lblProgressMessage.Text = "Loading..."; break;
                    case ProgressType.Saving: lblProgressMessage.Text = "Saving..."; break;
                }
            }
        }
    }

    public enum ProgressType {
        Loading,
        Saving,
        Executing
    }
}
