using System;
using System.Collections.Generic;
using System.IO;
using System.Data;
using System.Reflection;

namespace Newsletter_Composer {
    public partial class Project {
        private static Project instance;
        public string Password { get; set; }
        public string FileName { get; set; }

        public MainForm MainForm { get; set; }

        public Project() {
            // Create ProtectFile database if required
            CreateProtectFileTable();

            string password = GetPassword();
            if (String.IsNullOrEmpty(password)) {
                Password = "admin";

                SetPassword(Password);
            } else {
                Password = password;
            }

            IsLicensed = false;
            CardId = string.Empty;
        }

        public static bool IsLicensed { get; set; }

        public static string CardId { get; set; }

        /// <summary>
        /// Project instance. Each file based applications will have single instance of Project.
        /// </summary>
        public static Project Instance {
            get { return instance ?? (instance = new Project()); }
            set {
                instance = value;
            }
        }

        /// <summary>
        /// Executable path
        /// </summary>
        public static string ApplicationPath {
            get { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); }
        }

        /// <summary>
        /// Reports path
        /// </summary>
        public static string ReportsPath {
            get { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Reports\"; }
        }

        /// <summary>
        /// Creates project file database table to maintain application password.
        /// </summary>
        public void CreateProtectFileTable() {
            bool tableExists = false;

            if (DataAdapter.Current != null) {
                List<Table> tables = DataAdapter.Current.ExtractTables();
                foreach (Table table in tables) {
                    if (table.Name.Equals("ProtectFile", StringComparison.OrdinalIgnoreCase)) {
                        tableExists = true;
                    }
                }

                if (tableExists == false) {
                    string sql = "CREATE TABLE ProtectFile(FilePassword NVARCHAR(64))";
                    DataAdapter.Current.ExecuteSql(sql);
                }
            }
        }

        /// <summary>
        /// Retrieves application password.
        /// </summary>
        /// <returns>Password</returns>
        private string GetPassword() {
            string password = string.Empty;
            if (DataAdapter.Current != null) {
                DataTable dt = DataAdapter.Current.LoadData("select * from ProtectFile", "ProtectFile");
                if (dt != null && dt.Rows.Count > 0) {
                    string encryptedPassword = (string)dt.Rows[0][0];
                    if (String.IsNullOrEmpty(encryptedPassword) == false) {
                        password = EncryptDecrypt.Decrypt(encryptedPassword);
                    }
                }
            }

            return password;
        }

        /// <summary>
        /// Sets application password
        /// </summary>
        /// <param name="password">Password</param>
        public void SetPassword(string password) {
            Password = password;

            string encryptedPassword = EncryptDecrypt.Encrypt(password);

            if (DataAdapter.Current != null) {
                DataTable dt = DataAdapter.Current.LoadData("select * from ProtectFile", "ProtectFile");
                if (dt == null || dt.Rows.Count == 0) {
                    DataAdapter.Current.ExecuteSql(String.Format("INSERT INTO ProtectFile VALUES('{0}')", encryptedPassword));
                } else {
                    DataAdapter.Current.ExecuteSql(String.Format("update ProtectFile SET FilePassword = '{0}'", encryptedPassword));
                }
            }
        }

        public void NotifyProjectFileOpened() {
            ProjectFileOpened();
        }

        public void NotifyApplicationLaunched() {
            ApplicationLaunched();
        }

        partial void ProjectFileOpened();

        partial void ApplicationLaunched();
    }
}
