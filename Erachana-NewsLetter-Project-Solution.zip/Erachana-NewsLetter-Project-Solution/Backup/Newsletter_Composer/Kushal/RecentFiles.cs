using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Newsletter_Composer {
    public class RecentFiles {
        // Save list of recent files to recentfiles.xml
        private static string localPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Newsletter_Composer\";
        private static string path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Newsletter_Composer\recentfiles.xml";
        private const int MaxRecentFiles = 10;

        /// <summary>
        /// List of recent files opened by the application. Kushal maintains file path only with file based database is used.
        /// </summary>
        public List<string> Files { get; set; }

        public RecentFiles() {
            Files = new List<string>();

            if (Directory.Exists(localPath) == false) {
                Directory.CreateDirectory(localPath);
            }
        }

        /// <summary>
        /// Adds new file to recent files list.
        /// </summary>
        /// <param name="filename">File path</param>
        public void Add(string filename) {
            List<string> files = new List<string>();
            files.Add(filename);// recent first
            for (int i = 0; i < MaxRecentFiles - 1 && i < Files.Count; i++) {
                if (files.Contains(Files[i]) == false) {
                    files.Add(Files[i]);
                }
            }

            Files = files;

            Save();
        }

        /// <summary>
        /// Serializes recents files list and stores in local directory.
        /// </summary>
        public void Save() {
            LoadSave.Save(typeof(RecentFiles), this, path);
        }

        /// <summary>
        /// Deserializes local file to load recent files list
        /// </summary>
        /// <returns></returns>
        public static RecentFiles Load() {
            return (RecentFiles)LoadSave.Load(typeof(RecentFiles), path);
        }
    }
}
