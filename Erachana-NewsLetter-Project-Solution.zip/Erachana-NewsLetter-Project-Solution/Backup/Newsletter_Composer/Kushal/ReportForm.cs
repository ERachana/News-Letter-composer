using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using fyiReporting.RDL;
using fyiReporting.RDL.Utility;
using fyiReporting.RdlViewer;

namespace Newsletter_Composer {
    public partial class ReportForm : Form {
        public RdlViewer reportviewer;
        private Kushal.Controls.KushalGroupBox grpReport;
        public ViewerToolstrip reportStrip;
        public ReportForm() {
            InitializeComponent();
            
            this.grpReport = new Kushal.Controls.KushalGroupBox();
            this.grpReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.grpReport.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpReport.Location = new System.Drawing.Point(0, 0);
            this.grpReport.Name = "grpReport";
            this.grpReport.Size = new System.Drawing.Size(985, 670);
            this.grpReport.TabIndex = 0;
            this.grpReport.TabStop = false;
            this.Controls.Add(grpReport);
            try {
                reportviewer = new fyiReporting.RdlViewer.RdlViewer();
                reportviewer.Parent = grpReport;
            } catch (Exception exc) {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public List<DataTable> ReportData { get; set; }
        public string ReportPath { get; set; }

        private void ReportForm_Load(object sender, EventArgs e) {
            
            try {
                reportStrip = new ViewerToolstrip(reportviewer);
                reportStrip.Location = new System.Drawing.Point(0, 0);
                reportStrip.ShowItemToolTips = true;
                reportStrip.Stretch = false;
                reportStrip.Items.RemoveAt(0); // Remove Open Button
                this.grpReport.Controls.Add(reportStrip);

                //Remove  Run Report, Warnning Message button on viewer.
                reportviewer.Controls.RemoveAt(4); //  Run Report Button
                reportviewer.Controls.RemoveAt(2); //  Warnning Message Button  
                reportviewer.Dock = System.Windows.Forms.DockStyle.Fill;
                reportviewer.SourceFile = new Uri(ReportPath);

                // Tell the report to use this connection
                Report rpt = reportviewer.Report; // Get the report
                DataSource ds = rpt.DataSources["DS1"]; // get the data source

                long numberOfDataSets = this.ReportData.Count();
                if (numberOfDataSets == 0)
                    return;
                string dataX = "Data";
                for (int i = 0; i < numberOfDataSets; i++) {
                    string DataSetName = dataX;
                    if (i != 0)
                        DataSetName += Convert.ToString(i);
                    fyiReporting.RDL.DataSet dts = rpt.DataSets[DataSetName];
                    if (ReportData[i] != null)
                        dts.SetData(ReportData[i]);
                }

                reportviewer.Zoom = (float)(1); // setting initial zoom option
                reportviewer.Rebuild(); // force report to get rebuilt
            } catch (Exception exc) {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReportForm_Activated(object sender, EventArgs e) {
            this.Activate();
        }
    }
}
