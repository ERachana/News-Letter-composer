using System;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Windows.Forms;

namespace Newsletter_Composer {
    internal static class Settings {
        private static string settingsFile = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Newsletter_Composer\Settings.xml";

        /// <summary>
        /// Application password
        /// </summary>
        public static string AppPassword { get; set; }

        static Settings() {
            if (Directory.Exists(Path.GetDirectoryName(settingsFile)) == false) {
                Directory.CreateDirectory(Path.GetDirectoryName(settingsFile));
            }

            RemoveSettingsFileIfCorrupted();

            if (File.Exists(settingsFile) == false) {
                string settingsTemplate = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar + "Settings.xml";
                File.Copy(settingsTemplate, settingsFile);
            }

            try {
                ReadPassword();
            } catch {
                MessageBox.Show("Unexpected error occured. Application password is either missing or corrupted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                AppPassword = string.Empty;
            }
        }

        /// <summary>
        /// Removes settings file if it contains corrupted content.
        /// </summary>
        private static void RemoveSettingsFileIfCorrupted() {
            try {
                ReadPassword();
            } catch {
                if (File.Exists(settingsFile)) { File.Delete(settingsFile); }
            }
        }

        /// <summary>
        /// Reads application password from settings file
        /// </summary>
        public static void ReadPassword() {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            if (doc.DocumentElement.ChildNodes.Count > 0) {
                XmlNode node = doc.DocumentElement.ChildNodes[0];
                if (node != null && node.Attributes.Count > 0) {
                    string val = node.Attributes["val"].Value;
                    AppPassword = EncryptDecrypt.Decrypt(val);
                }
            }
        }

        /// <summary>
        /// Saves application password to settings file.
        /// </summary>
        public static void SavePassword() {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[0];
            node.Attributes["val"].Value = EncryptDecrypt.Encrypt(AppPassword);

            doc.Save(settingsFile);
        }

        /// <summary>
        /// Gets database admin details like server, database, user name and password. Admin details are required in RDBMS get initial database informations.
        /// </summary>
        /// <returns></returns>
        public static AdminDetails GetDatabaseAdminDetails() {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[1];
            string server = node.ChildNodes[0].Attributes["value"].Value;
            string database = node.ChildNodes[1].Attributes["value"].Value;
            string username = node.ChildNodes[2].Attributes["value"].Value;
            string password = node.ChildNodes[3].Attributes["value"].Value;

            if (String.IsNullOrEmpty(server) == false && String.IsNullOrEmpty(database) == false && String.IsNullOrEmpty(username) == false && String.IsNullOrEmpty(password) == false) {
                AdminDetails adminDetails = new AdminDetails {
                    Server = server,
                    Database = database,
                    Username = username,
                    Password = EncryptDecrypt.Decrypt(password)
                };

                return adminDetails;
            }

            return null;
        }

        /// <summary>
        /// Saves database administrator details.
        /// </summary>
        /// <param name="server">Server (name or IP address)</param>
        /// <param name="database">Database Name</param>
        /// <param name="username">User name</param>
        /// <param name="password">Password</param>
        public static void SaveAdminDetails(string server, string database, string username, string password) {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[1];
            node.ChildNodes[0].Attributes["value"].Value = server;
            node.ChildNodes[1].Attributes["value"].Value = database;
            node.ChildNodes[2].Attributes["value"].Value = username;
            node.ChildNodes[3].Attributes["value"].Value = EncryptDecrypt.Encrypt(password);

            doc.Save(settingsFile);
        }

        /// <summary>
        /// Retrieves data directory path. 
        /// </summary>
        /// <returns></returns>
        public static string GetDataDirectoryPath() {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[2];
            return node.Attributes["val"].Value;
        }

        /// <summary>
        /// Saves data directory path
        /// </summary>
        /// <param name="path">File path</param>
        public static void SaveDataDirectoryPath(string path) {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[2];
            node.Attributes["val"].Value = path;

            doc.Save(settingsFile);
        }

        /// <summary>
        /// Get database currently loaded
        /// </summary>
        /// <returns>Database name</returns>
        public static string GetDatabaseLoaded() {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[3];
            return node.Attributes["val"].Value;
        }

        /// <summary>
        /// Saves currently loaded database to settings file.
        /// </summary>
        /// <param name="database">Database name</param>
        public static void SaveDatabaseLoaded(string database) {
            XmlDocument doc = new XmlDocument();
            doc.Load(settingsFile);

            XmlNode node = doc.DocumentElement.ChildNodes[3];
            node.Attributes["val"].Value = database;

            doc.Save(settingsFile);
        }

        /// <summary>
        /// Copies settings file information to the file specified.
        /// </summary>
        /// <param name="path">Destination file</param>
        public static void Export(string path) {
            if (File.Exists(settingsFile)) {
                File.Copy(settingsFile, path + Path.DirectorySeparatorChar + Path.GetFileName(settingsFile), true);
            }
        }

        /// <summary>
        /// Imports settings information from the given file.
        /// </summary>
        /// <param name="filename">Source file location</param>
        public static void Import(string filename) {
            if (File.Exists(filename)) {
                File.Copy(filename, settingsFile, true);
            }
        }
    }

    internal class AdminDetails{
        public string Server { get; set; }
        public string Database { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
