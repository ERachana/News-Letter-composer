using System;
using System.Windows.Forms;
using System.Threading;

namespace Newsletter_Composer {
    public partial class SplashForm : Form {
        public SplashForm() {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.None;
            CheckForIllegalCrossThreadCalls = false;
        }

        private void SplashForm_Load(object sender, EventArgs e) {
            Thread closeThread = new Thread(CloseThread) {IsBackground = true};
            closeThread.Start();
        }

		private void SplashForm_Activated(object sender, EventArgs e) {
		
		}

        private void CloseThread() {
            Thread.Sleep(3000);
            Close();
        }
    }
}
