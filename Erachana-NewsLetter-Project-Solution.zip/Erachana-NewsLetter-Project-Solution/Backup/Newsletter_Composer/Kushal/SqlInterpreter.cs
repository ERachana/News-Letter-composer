using System;
using System.Collections.Generic;
using System.Data;

namespace Newsletter_Composer {
    public class SqlInterpreter {
        /// <summary>
        /// Executes given SQL query and gives single set of values by reading first row content.
        /// </summary>
        /// <param name="sql">SQL statement</param>
        /// <returns>First row values</returns>
        public static Dictionary<string, object> GetScalarData(string sql) {
            Dictionary<string, object> vars = new Dictionary<string, object>();

            DataTable table = DataAdapter.Current.LoadData(sql, Guid.NewGuid().ToString());

            if (table.Rows.Count < 1) return null;

            DataRow row = table.Rows[0];
            foreach (DataColumn column in table.Columns) {
                if (vars.ContainsKey(column.ColumnName) == false) {
                    vars.Add(column.ColumnName, row[column.ColumnName]);
                }
            }

            return vars;
        }

        /// <summary>
        /// Executes given SQL query and gives result generated.
        /// </summary>
        /// <param name="sql">SQL statement</param>
        /// <returns>Result data</returns>
        public static DataTable GetData(string sql) {
            return DataAdapter.Current.LoadData(sql, Guid.NewGuid().ToString());
        }

        /// <summary>
        /// Executes non query SQL statements like Update, Delete, Insert etc
        /// </summary>
        /// <param name="sql">SQL Statement</param>
        /// <returns>Number of rows affected</returns>
        public static int ExecuteSQL(string sql) {
            return DataAdapter.Current.ExecuteSql(sql);
        }
    }
}
