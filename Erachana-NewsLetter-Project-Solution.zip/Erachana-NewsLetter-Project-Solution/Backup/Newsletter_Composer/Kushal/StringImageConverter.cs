using System;
using System.IO;
using System.Drawing;

namespace Newsletter_Composer {
    internal class StringImageConverter {
        /// <summary>
        /// Converts image to base 64 string
        /// </summary>
        /// <param name="image">Image to be converted</param>
        /// <returns>Image in text format</returns>
        public static string ImageToString(Image image) {
            string imageStream = string.Empty;
            using (MemoryStream ms = new MemoryStream()) {
                image.Save(ms, image.RawFormat);
                byte[] imageBytes = ms.ToArray();

                imageStream = Convert.ToBase64String(imageBytes);
            }

            return imageStream;
        }

        /// <summary>
        /// Converts string to image
        /// </summary>
        /// <param name="imageStream">Text to be converted to image</param>
        /// <returns>Converted image</returns>
        public static Image StringToImage(string imageStream) {
            Image img = null;
            if (String.IsNullOrEmpty(imageStream) == false) {
                try {
                    byte[] imageBytes = Convert.FromBase64String(imageStream);
                    MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);

                    ms.Write(imageBytes, 0, imageBytes.Length);
                    img = Image.FromStream(ms, true);
                } catch { }
            }

            return img;
        }

        /// <summary>
        /// Converts binary file to base 64 string.
        /// </summary>
        /// <param name="filename">Source file to be converted.</param>
        /// <returns>Binary file in text format</returns>
        public static string BinaryFileToString(string filename) {
            using (FileStream stream = new FileStream(filename, FileMode.Open, FileAccess.Read)) {
                byte[] bytes = new byte[stream.Length];
                stream.Read(bytes, 0, Convert.ToInt32(stream.Length));
                return Convert.ToBase64String(bytes, Base64FormattingOptions.InsertLineBreaks);
            }
        }

        /// <summary>
        /// Converts text to binary file.
        /// </summary>
        /// <param name="filename">Destination file</param>
        /// <param name="imageStream">Image Stream</param>
        public static void StringToBinaryFile(string filename, string imageStream) {
            byte[] bytes = Convert.FromBase64String(imageStream);
            using (FileStream stream = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite)) {
                stream.Write(bytes, 0, bytes.Length);
            }
        }
    }
}
