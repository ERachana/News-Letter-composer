using Kushal.Controls;
namespace Newsletter_Composer {
    partial class PasswordCheckForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnOK = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.grpNewGroupBox1 = new Kushal.Controls.KushalGroupBox();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.txtPassword = new Kushal.Controls.KushalTextBox();
            this.SuspendLayout();
            
            
            this.btnOK.Location = new System.Drawing.Point(261, 89);
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnOK.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnOK.Name = "btnOK";
            this.btnOK.Enabled = true;
            this.btnOK.Visible = true;
            this.btnOK.TabIndex = 0;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnOK.Size = new System.Drawing.Size(80, 30);
            this.btnOK.Text = @"OK";
            this.btnOK.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnOK, @"");
            
            
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);

            this.btnClose.Location = new System.Drawing.Point(352, 89);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.grpNewGroupBox1.Location = new System.Drawing.Point(19, 9);
            this.grpNewGroupBox1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpNewGroupBox1.Name = "grpNewGroupBox1";
            this.grpNewGroupBox1.Enabled = true;
            this.grpNewGroupBox1.Visible = true;
            this.grpNewGroupBox1.TabIndex = 0;
            this.grpNewGroupBox1.TabStop = false;
            this.grpNewGroupBox1.Size = new System.Drawing.Size(413, 71);
            this.grpNewGroupBox1.Text = @"Specify Password";
            this.grpNewGroupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox1.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox1, @"");

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(13, 25);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(78, 20);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"Password";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.txtPassword.Location = new System.Drawing.Point(94, 25);
            this.txtPassword.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtPassword.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtPassword.Multiline = false;
            this.txtPassword.MaxLength = 256;
            this.txtPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Text = @"";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.AllowNull = false;
            this.txtPassword.DefaultValue = "";
            this.txtPassword.FriendlyName = "";
            this.txtPassword.ValidationType = TextValidation.None;
            this.txtPassword.ValidationExpression = @"";
            this.txtPassword.ValidationMessage = @"";
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtPassword.Enabled = true;
            this.txtPassword.ReadOnly = false;
            this.txtPassword.Visible = true;
            this.txtPassword.TabIndex = 0;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPassword.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Size = new System.Drawing.Size(303, 31);
            this.toolTip1.SetToolTip(this.txtPassword, @"");


            
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpNewGroupBox1);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel1);
            this.grpNewGroupBox1.Controls.Add(this.txtPassword);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "PasswordCheckForm";
            this.Text = "Password Check";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(465, 166);
            
                        this.Load += new System.EventHandler(this.PasswordCheckForm_Load);
            this.Activated += new System.EventHandler(this.PasswordCheckForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnOK;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox1;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalTextBox txtPassword;
    }
}