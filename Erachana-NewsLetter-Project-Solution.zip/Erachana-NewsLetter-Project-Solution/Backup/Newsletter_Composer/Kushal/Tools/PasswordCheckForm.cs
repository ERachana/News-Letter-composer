using System;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class PasswordCheckForm : Form {
        public PasswordCheckForm() {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
        }

        public string Password { get; set; }
        public ProtectionType Type { get; set; }

        private void PasswordCheckForm_Load(object sender, EventArgs e) { }
		private void PasswordCheckForm_Activated(object sender, EventArgs e) { }

        public void LoadForm() {
            switch (Type) {
                case ProtectionType.Application:
                    Text = "Specify application password.";
                    break;
                case ProtectionType.ProjectFile:
                    Text = "Specify project file password.";
                    break;
            }
        }

        private void btnOK_Click(object sender, EventArgs e) {
            if (String.IsNullOrEmpty(txtPassword.Text)) {
                MessageBox.Show("Please enter password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (txtPassword.Text != Password) {
                MessageBox.Show("Invalid password. Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DialogResult = DialogResult.OK;
        }

        private void btnClose_Click(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
        }
    }
}
