using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class PasswordProtectionForm : Form {
        public PasswordProtectionForm() {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        }

        public ProtectionType Type { get; set; }

        public string CurrentPassword { get; set; }
        
        public string NewPassword { get; set; }

        private void PasswordProtectionForm_Load(object sender, EventArgs e) {

        }

		private void PasswordProtectionForm_Activated(object sender, EventArgs e) {
		
		}

        public void LoadForm() {
            switch (Type) {
                case ProtectionType.Application:
                    this.Text = "Change password to protect program";
                    lblNote.Text = "Note: When software is installed 'Admin' will be the password, by setting password other than 'Admin', software will be password protected. To unset the protection, change the password back to 'Admin'.";
                    break;
                case ProtectionType.ProjectFile:
                    this.Text = "Change password to protect file";
                    lblNote.Text = "Note: When file is created 'Admin' will be the password, by setting password other than 'Admin', file will be password protected. To unset the protection, change password back to 'Admin'.";
                    break;
            }
        }

        private void btnOK_Click(object sender, EventArgs e) {
            bool isValid = ValidateInput();
            if (isValid) {
                NewPassword = txtNewPassword.Text;
                MessageBox.Show("Password updated successfully.", "Password update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK; 
            }
        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.No;
        }

        private bool ValidateInput() {
            if (String.IsNullOrEmpty( txtCurrentPassword.Text )) {
                MessageBox.Show("Current password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtCurrentPassword.Text.Equals(CurrentPassword, StringComparison.OrdinalIgnoreCase) == false) {
                MessageBox.Show("Invalid current password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (String.IsNullOrEmpty(txtNewPassword.Text)) {
                MessageBox.Show("New password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtNewPassword.Text.Equals(CurrentPassword, StringComparison.OrdinalIgnoreCase)) {
                MessageBox.Show("New password cannot be same as the current password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (String.IsNullOrEmpty(txtConfirmPassword.Text)) {
                MessageBox.Show("Confirm password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtNewPassword.Text != txtConfirmPassword.Text) {
                MessageBox.Show("New password and confirm password does not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
    }

    public enum ProtectionType {
        ProjectFile,
        Application
    }
}
