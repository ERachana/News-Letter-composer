using System.Windows.Forms;

namespace Newsletter_Composer {
    public class TreeNodeInfo {
        public string TableName { get; set; }

        public string Key { get; set; }
        public string KeyFieldName { get; set; }

        public string ParentKeyFieldName { get; set; }

        public int SerialNumer { get; set; }
        public string SerialNumerFieldName { get; set; }

        public string DisplayText { get; set; }
        public string DisplayTextFieldName { get; set; }

        public string AltText { get; set; }
        public string AltTextFielName { get; set; }
    }

    public class TreeLoadInfo {
        public TreeView TreeView { get; set; }
        public string TableName { get; set; }
        public string IdField { get; set; }
        public string KeyField { get; set; }
        public string ParentKeyField { get; set; }
        public string DisplayTextField { get; set; }

        public Control KeyFieldControl { get; set; }
        public Control ParentKeyFieldControl { get; set; }
    }
}
