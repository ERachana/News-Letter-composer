using System;

namespace Newsletter_Composer {
    public static class TypeConverter  {
        /// <summary>
        /// Converts given object to boolean value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to boolean, False if conversion fails</returns>
        public static bool ConvertToBool(object o) {
            return ConvertToBool(o, false);
        }

        /// <summary>
        /// Converts given object to boolean value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Value converted to boolean, default value if conversion fails</returns>
        public static bool ConvertToBool(object o, bool defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToBoolean(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to boolean value.
        /// </summary>
        /// <param name="s">string value to be converted</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Value converted to boolean, default value if conversion fails</returns>
        public static bool ConvertToBool(string s, bool defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            bool result = defaultValue;
            if (bool.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to Int16 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to Int16, 0 if conversion fails</returns>
        public static short ConvertToShort(object o) {
            return ConvertToShort(o, 0);
        }

        /// <summary>
        /// Converts given object to Int16 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Value converted to Int16, default value if conversion fails</returns>
        public static short ConvertToShort(object o, short defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToInt16(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to Int16 value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Value converted to Int16, default value if conversion fails</returns>
        public static short ConvertToShort(string s, short defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            short result = defaultValue;
            if (Int16.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to Int32 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to Int32, 0 if conversion fails</returns>
        public static int ConvertToInt(object o) {
            return ConvertToInt(o, 0);
        }

        /// <summary>
        /// Converts given object to Int32 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Value converted to Int32, default value if conversion fails</returns>
        public static int ConvertToInt(object o, int defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToInt32(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to Int32 value.
        /// </summary>
        /// <param name="s">string to be converted</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Value converted to Int32, default value if conversion fails</returns>
        public static int ConvertToInt(string s, int defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            int result = defaultValue;
            if (Int32.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to Long value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to Long, 0 if conversion fails</returns>
        public static long ConvertToLong(object o) {
            return ConvertToLong(o, 0);
        }

        /// <summary>
        /// Converts given object to Long value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Long, default value if conversion fails</returns>
        public static long ConvertToLong(object o, long defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToInt64(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to Long value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Long, default value if conversion fails</returns>
        public static long ConvertToLong(string s, long defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            long result = defaultValue;
            if (Int64.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to UInt16 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to UInt16, 0 if conversion fails</returns>
        public static ushort ConvertToUShort(object o) {
            return ConvertToUShort(o, 0);
        }

        /// <summary>
        /// Converts given object to UInt16 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to UInt16, default value if conversion fails</returns>
        public static ushort ConvertToUShort(object o, ushort defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToUInt16(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to UInt16 value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to UInt16, default value if conversion fails</returns>
        public static ushort ConvertToUShort(string s, ushort defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            ushort result = defaultValue;
            if (UInt16.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to UInt32 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to UInt32, 0 if conversion fails</returns>
        public static uint ConvertToUInt(object o) {
            return ConvertToUInt(o, 0);
        }

        /// <summary>
        /// Converts given object to UInt32 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to UInt32, default value if conversion fails</returns>
        public static uint ConvertToUInt(object o, uint defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToUInt32(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to UInt32 value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to UInt32, default value if conversion fails</returns>
        public static uint ConvertToUInt(string s, uint defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            uint result = defaultValue;
            if (UInt32.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to UInt64 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to UInt64, 0 if conversion fails</returns>
        public static ulong ConvertToULong(object o) {
            return ConvertToULong(o, 0);
        }

        /// <summary>
        /// Converts given object to UInt64 value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to UInt64, default value if conversion fails</returns>
        public static ulong ConvertToULong(object o, ulong defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToUInt64(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to UInt64 value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to UInt64, default value if conversion fails</returns>
        public static ulong ConvertToULong(string s, ulong defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            ulong result = defaultValue;
            if (UInt64.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to Decimal value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to Decimal, 0 if conversion fails</returns>
        public static decimal ConvertToDecimal(object o) {
            return ConvertToDecimal(o, 0);
        }

        /// <summary>
        /// Converts given object to Decimal value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Decimal, default value if conversion fails</returns>
        public static decimal ConvertToDecimal(object o, decimal defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToDecimal(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to Decimal value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Decimal, default value if conversion fails</returns>
        public static decimal ConvertToDecimal(string s, decimal defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            decimal result = defaultValue;
            if (Decimal.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to Float value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to Float, 0 if conversion fails</returns>
        public static float ConvertToSingle(object o) {
            return ConvertToSingle(o, 0);
        }

        /// <summary>
        /// Converts given object to Float value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Float, default value if conversion fails</returns>
        public static float ConvertToSingle(object o, float defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToSingle(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to Float value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Float, default value if conversion fails</returns>
        public static float ConvertToSingle(string s, float defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            float result = defaultValue;
            if (float.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to Double value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to Double, 0 if conversion fails</returns>
        public static double ConvertToDouble(object o) {
            return ConvertToDouble(o, 0);
        }

        /// <summary>
        /// Converts given object to Double value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Double, default value if conversion fails</returns>
        public static double ConvertToDouble(object o, double defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToDouble(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to Double value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to Double, default value if conversion fails</returns>
        public static double ConvertToDouble(string s, double defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            double result = defaultValue;
            if (double.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to DateTime value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to DateTime, default value if conversion fails</returns>
        public static DateTime ConvertToDateTime(object o, DateTime defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToDateTime(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given string to DateTime value.
        /// </summary>
        /// <param name="s">String to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to DateTime, default value if conversion fails</returns>
        public static DateTime ConvertToDateTime(string s, DateTime defaultValue) {
            if (String.IsNullOrEmpty(s)) return defaultValue;

            DateTime result = defaultValue;
            if (DateTime.TryParse(s, out result)) {
                return result;
            }

            return defaultValue;
        }

        /// <summary>
        /// Converts given object to String value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <returns>Value converted to String, empty string value if conversion fails</returns>
        public static string ConvertToString(object o) {
            return ConvertToString(o, string.Empty);
        }

        /// <summary>
        /// Converts given object to String value.
        /// </summary>
        /// <param name="o">Object to be converted</param>
        /// <param name="defaultValue">default value</param>
        /// <returns>Value converted to String, default value if conversion fails</returns>
        public static string ConvertToString(object o, string defaultValue) {
            if (o == null) { return defaultValue; }
            if (o == DBNull.Value) { return defaultValue; }

            try {
                return Convert.ToString(o);
            } catch {
                return defaultValue;
            }
        }

        /// <summary>
        /// Converts given number to descriptive text
        /// </summary>
        /// <param name="number">Number to be converted</param>
        /// <param name="indianSystem">True if number to be converted to India text representation, False otherwise</param>
        /// <returns>Words representing given number</returns>
        public static string ConvertToWords(double number, bool indianSystem) {
            return indianSystem ? NumberToWordsIndian(number) : NumberToWords(number);
        }

        private static string NumberToWordsIndian(double n) {
            int number = Convert.ToInt32(n);

            if (number == 0) { return "zero"; }
            if (number < 0) { return "minus " + NumberToWordsIndian(Math.Abs(number)); }
            string words = "";
            if ((number / 10000000) > 0) { words += NumberToWordsIndian(number / 10000000) + " Crore "; number %= 10000000; }
            if ((number / 100000) > 0) { words += NumberToWordsIndian(number / 100000) + " Lakh "; number %= 100000; }
            if ((number / 1000) > 0) { words += NumberToWordsIndian(number / 1000) + " Thousand "; number %= 1000; }
            if ((number / 100) > 0) { words += NumberToWordsIndian(number / 100) + " Hundred "; number %= 100; }
            if (number > 0) {
                if (words != "") { words += "and "; }
                var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
                var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "seventy", "Eighty", "Ninety" };
                if (number < 20) {
                    words += unitsMap[number];
                } else {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0) {
                        words += "-" + unitsMap[number % 10];
                    }
                }
            }
            return words;
        }

        private static String NumberToWords(double n) {
            int number = Convert.ToInt32(n);

            if (number == 0) { return "zero"; }
            if (number < 0) { return "minus " + NumberToWordsIndian(Math.Abs(number)); }
            string words = "";
            if ((number / 1000000000) > 0) { words += NumberToWordsIndian(number / 1000000000) + " Billion "; number %= 1000000000; }
            if ((number / 1000000) > 0) { words += NumberToWordsIndian(number / 1000000) + " Million "; number %= 1000000; }
            if ((number / 1000) > 0) { words += NumberToWordsIndian(number / 1000) + " Thousand "; number %= 1000; }
            if ((number / 100) > 0) { words += NumberToWordsIndian(number / 100) + " Hundred "; number %= 100; }
            if (number > 0) {
                if (words != "") { words += "and "; }
                var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
                var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "seventy", "Eighty", "Ninety" };
                if (number < 20) {
                    words += unitsMap[number];
                } else {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0) {
                        words += "-" + unitsMap[number % 10];
                    }
                }
            }
            return words;
        }
    }
}