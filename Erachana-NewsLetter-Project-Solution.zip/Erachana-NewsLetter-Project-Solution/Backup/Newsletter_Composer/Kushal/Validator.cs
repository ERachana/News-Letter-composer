using System.Text.RegularExpressions;

namespace Newsletter_Composer {
    class Validator {
        /// <summary>
        /// Matches input text against given regular expression given
        /// </summary>
        /// <param name="pattern">Regular expression pattern</param>
        /// <param name="input">Input text to be matched</param>
        /// <returns>True if text matches given regular expression pattern or False</returns>
        public static bool RegexMatch(string pattern, string input) {
            Regex regex = new Regex(pattern);
            return regex.IsMatch(input);
        }
    }
}