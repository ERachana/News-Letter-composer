using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace Newsletter_Composer {
    internal static class VersionController {
        private static List<Version> versions = new List<Version>();
        static VersionController() {
            Function1();

        }
        private static void Function1() {
            Version version = new Version();
            version.VersionNumber = 0.1;
            version.Statements.Add(@"ALTER TABLE EmailTemplate ADD IsFile int DEFAULT 0");
            versions.Add(version);
        }

        public static void Update() {
            Update(true);
        }
        // NOTE: Please dont change following function unless if really required
        public static void Update(bool isAdmin) {
            DataAdapter adapter = DataAdapter.Current;
            string sql = string.Empty;
            bool versionTableExists = false;
            List<Table> tables = adapter.ExtractTables();
            foreach (Table table in tables){
                if (table.Name == "version"){
                    versionTableExists = true;
                }
            }
            // Create version table if not found
            if (versionTableExists == false) {
                sql = "CREATE TABLE version (VersionNumber FLOAT NOT NULL)";
                adapter.ExecuteSql(sql);
                sql = "INSERT INTO version VALUES(0)";
                adapter.ExecuteSql(sql);
            }

            double currentVersion = 0;
            // Get current version in database
            sql = "SELECT MAX(VersionNumber) as maxNumber FROM version";
            DataTable dt = adapter.LoadData(sql, "current_version");
            if (dt != null && dt.Rows.Count > 0) {
                if (dt.Rows[0]["maxNumber"] != DBNull.Value) {
                    currentVersion = Convert.ToDouble(dt.Rows[0]["maxNumber"]);
                }
            }

            bool isNewVersionAvailable = false;
            foreach (Version version in versions) {
                if (version.VersionNumber > currentVersion) {
                    isNewVersionAvailable = true;
                    break;
                }
            }

            if (isNewVersionAvailable) {
                if (isAdmin) {
                    if (MessageBox.Show("Database update is required. Do you want to update your database ?", "Update", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) {
                        return;
                    }
                } else {
                    MessageBox.Show("Database update is required. Hence application may not work properly. Please contact administrator for more information. ?", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            // Execute all SQL statements above current version
            foreach (Version version in versions) {
                if (version.VersionNumber > currentVersion) {
                    foreach (string statement in version.Statements) {
                        adapter.ExecuteSql(statement);
                    }

                    // Add version in database
                    sql = String.Format("INSERT INTO version VALUES({0})", version.VersionNumber);
                    adapter.ExecuteSql(sql);
                }
            }
        }
    }

    internal class Version {
        public double VersionNumber { get; set; }
        public List<string> Statements { get; set; }

        public Version() {
            Statements = new List<string>();
        }
    }
}
