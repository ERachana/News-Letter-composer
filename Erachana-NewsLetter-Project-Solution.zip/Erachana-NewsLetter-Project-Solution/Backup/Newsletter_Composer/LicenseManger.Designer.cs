using Kushal.Controls;
namespace Newsletter_Composer {
    partial class LicenseManger {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnRegister = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.SuspendLayout();
            
            
            this.btnRegister.Location = new System.Drawing.Point(7, 65);
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnRegister.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Enabled = true;
            this.btnRegister.Visible = true;
            this.btnRegister.TabIndex = 3;
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnRegister.Size = new System.Drawing.Size(80, 30);
            this.btnRegister.Text = @"&Register";
            this.btnRegister.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnRegister, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(202, 65);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 4;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(72, 8);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblNewLabel1.Size = new System.Drawing.Size(149, 60);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"Newsletter Composer

Get Registered";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");


            
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblNewLabel1);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "LicenseManger";
            this.Text = "License Manager";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(305, 144);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnRegister;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lblNewLabel1;
    }
}