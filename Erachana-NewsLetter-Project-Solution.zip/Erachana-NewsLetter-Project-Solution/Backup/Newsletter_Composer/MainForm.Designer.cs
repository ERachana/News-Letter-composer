using System.Windows.Forms;
namespace Newsletter_Composer {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            menuStrip = new System.Windows.Forms.MenuStrip();
            FileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            FileNewFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            FileOpenFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            FileCloseFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            seperator0 = new System.Windows.Forms.ToolStripSeparator();
            FileRecentFilesMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            seperator1 = new System.Windows.Forms.ToolStripSeparator();
            FileExitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersHandledByMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersProductTypeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersDigitalActivityMasterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersMonthMasterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersRelationMasterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            seperator2 = new System.Windows.Forms.ToolStripSeparator();
            MastersCountryMasterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersStateMasterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            MastersPlaceMasterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            SubscribersMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ActivityDetailsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ActivityDetailsProjectDetailsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ActivityDetailsProductDetailsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ActivityDetailsDigitalActivityDetailsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ActivityDetailsReportMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            EmailMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            EmailSendMailMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            EmailSentMailMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            seperator3 = new System.Windows.Forms.ToolStripSeparator();
            EmailConfigureEmailMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            EmailConfigureEmailServerMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            EmailConfigureEmailTemplateMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ToolsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ToolsLicenseManagerMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ToolsBackupDatabaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ToolsRestoreDatabaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            seperator4 = new System.Windows.Forms.ToolStripSeparator();
            ToolsProtectFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ToolsProtectProgramMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            HelpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            HelpAboutNewsletterComposerMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            HelpDisclaimerMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            HelpAboutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            HelpAboutUsMenuItem = new System.Windows.Forms.ToolStripMenuItem();

            this.Controls.Add(menuStrip);
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            menuStrip.Items.Add(FileMenuItem);
            FileMenuItem.Name = "FileMenuItem";
            
            FileMenuItem.Size = new System.Drawing.Size(152, 22);
            FileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            FileMenuItem.Visible = true;
            FileMenuItem.Text = "File";


            FileMenuItem.DropDownItems.Add(FileNewFileMenuItem);
            FileNewFileMenuItem.Name = "FileNewFileMenuItem";
            
            FileNewFileMenuItem.Size = new System.Drawing.Size(152, 22);
            FileNewFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            FileNewFileMenuItem.Visible = true;
            FileNewFileMenuItem.Text = "New File";
            FileNewFileMenuItem.Click += new System.EventHandler(this.NewfileToolStripMenuItem_Click);

            FileMenuItem.DropDownItems.Add(FileOpenFileMenuItem);
            FileOpenFileMenuItem.Name = "FileOpenFileMenuItem";
            
            FileOpenFileMenuItem.Size = new System.Drawing.Size(152, 22);
            FileOpenFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            FileOpenFileMenuItem.Visible = true;
            FileOpenFileMenuItem.Text = "Open File";
            FileOpenFileMenuItem.Click += new System.EventHandler(this.OpenFileToolStripMenuItem_Click);

            FileMenuItem.DropDownItems.Add(FileCloseFileMenuItem);
            FileCloseFileMenuItem.Name = "FileCloseFileMenuItem";
            
            FileCloseFileMenuItem.Size = new System.Drawing.Size(152, 22);
            FileCloseFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            FileCloseFileMenuItem.Visible = true;
            FileCloseFileMenuItem.Text = "Close File";
            FileCloseFileMenuItem.Click += new System.EventHandler(this.CloseFileToolStripMenuItem_Click);

            FileMenuItem.DropDownItems.Add(seperator0);
            this.seperator0.Name = "seperator0";


            FileMenuItem.DropDownItems.Add(FileRecentFilesMenuItem);
            FileRecentFilesMenuItem.Name = "FileRecentFilesMenuItem";
            
            FileRecentFilesMenuItem.Size = new System.Drawing.Size(152, 22);
            FileRecentFilesMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            FileRecentFilesMenuItem.Visible = true;
            FileRecentFilesMenuItem.Text = "Recent Files";


            FileMenuItem.DropDownItems.Add(seperator1);
            this.seperator1.Name = "seperator1";


            FileMenuItem.DropDownItems.Add(FileExitMenuItem);
            FileExitMenuItem.Name = "FileExitMenuItem";
            
            FileExitMenuItem.Size = new System.Drawing.Size(152, 22);
            FileExitMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            FileExitMenuItem.Visible = true;
            FileExitMenuItem.Text = "Exit";
            FileExitMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);

            menuStrip.Items.Add(MastersMenuItem);
            MastersMenuItem.Name = "MastersMenuItem";
            
            MastersMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersMenuItem.Visible = true;
            MastersMenuItem.Text = "Masters";

            MastersMenuItem.DropDownItems.Add(MastersHandledByMenuItem);
            MastersHandledByMenuItem.Name = "MastersHandledByMenuItem";
            
            MastersHandledByMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersHandledByMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersHandledByMenuItem.Visible = true;
            MastersHandledByMenuItem.Text = "Handled By";
            MastersHandledByMenuItem.Click += new System.EventHandler(this.MastersHandledByMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(MastersProductTypeMenuItem);
            MastersProductTypeMenuItem.Name = "MastersProductTypeMenuItem";
            
            MastersProductTypeMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersProductTypeMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersProductTypeMenuItem.Visible = true;
            MastersProductTypeMenuItem.Text = "Product Type";
            MastersProductTypeMenuItem.Click += new System.EventHandler(this.MastersProductTypeMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(MastersDigitalActivityMasterMenuItem);
            MastersDigitalActivityMasterMenuItem.Name = "MastersDigitalActivityMasterMenuItem";
            
            MastersDigitalActivityMasterMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersDigitalActivityMasterMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersDigitalActivityMasterMenuItem.Visible = true;
            MastersDigitalActivityMasterMenuItem.Text = "Digital Activity Master";
            MastersDigitalActivityMasterMenuItem.Click += new System.EventHandler(this.MastersDigitalActivityMasterMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(MastersMonthMasterMenuItem);
            MastersMonthMasterMenuItem.Name = "MastersMonthMasterMenuItem";
            
            MastersMonthMasterMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersMonthMasterMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersMonthMasterMenuItem.Visible = true;
            MastersMonthMasterMenuItem.Text = "Month Master";
            MastersMonthMasterMenuItem.Click += new System.EventHandler(this.MastersMonthMasterMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(MastersRelationMasterMenuItem);
            MastersRelationMasterMenuItem.Name = "MastersRelationMasterMenuItem";
            
            MastersRelationMasterMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersRelationMasterMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersRelationMasterMenuItem.Visible = true;
            MastersRelationMasterMenuItem.Text = "Relation Master";
            MastersRelationMasterMenuItem.Click += new System.EventHandler(this.MastersRelationMasterMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(seperator2);
            this.seperator2.Name = "seperator2";

            MastersMenuItem.DropDownItems.Add(MastersCountryMasterMenuItem);
            MastersCountryMasterMenuItem.Name = "MastersCountryMasterMenuItem";
            
            MastersCountryMasterMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersCountryMasterMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersCountryMasterMenuItem.Visible = true;
            MastersCountryMasterMenuItem.Text = "Country Master";
            MastersCountryMasterMenuItem.Click += new System.EventHandler(this.MastersCountryMasterMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(MastersStateMasterMenuItem);
            MastersStateMasterMenuItem.Name = "MastersStateMasterMenuItem";
            
            MastersStateMasterMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersStateMasterMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersStateMasterMenuItem.Visible = true;
            MastersStateMasterMenuItem.Text = "State Master";
            MastersStateMasterMenuItem.Click += new System.EventHandler(this.MastersStateMasterMenuItem_Click);

            MastersMenuItem.DropDownItems.Add(MastersPlaceMasterMenuItem);
            MastersPlaceMasterMenuItem.Name = "MastersPlaceMasterMenuItem";
            
            MastersPlaceMasterMenuItem.Size = new System.Drawing.Size(152, 22);
            MastersPlaceMasterMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            MastersPlaceMasterMenuItem.Visible = true;
            MastersPlaceMasterMenuItem.Text = "Place Master";
            MastersPlaceMasterMenuItem.Click += new System.EventHandler(this.MastersPlaceMasterMenuItem_Click);

            menuStrip.Items.Add(SubscribersMenuItem);
            SubscribersMenuItem.Name = "SubscribersMenuItem";
            
            SubscribersMenuItem.Size = new System.Drawing.Size(152, 22);
            SubscribersMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            SubscribersMenuItem.Visible = true;
            SubscribersMenuItem.Text = "Subscribers";
            SubscribersMenuItem.Click += new System.EventHandler(this.SubscribersMenuItem_Click);

            menuStrip.Items.Add(ActivityDetailsMenuItem);
            ActivityDetailsMenuItem.Name = "ActivityDetailsMenuItem";
            
            ActivityDetailsMenuItem.Size = new System.Drawing.Size(152, 22);
            ActivityDetailsMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ActivityDetailsMenuItem.Visible = true;
            ActivityDetailsMenuItem.Text = "Activity Details";

            ActivityDetailsMenuItem.DropDownItems.Add(ActivityDetailsProjectDetailsMenuItem);
            ActivityDetailsProjectDetailsMenuItem.Name = "ActivityDetailsProjectDetailsMenuItem";
            
            ActivityDetailsProjectDetailsMenuItem.Size = new System.Drawing.Size(152, 22);
            ActivityDetailsProjectDetailsMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ActivityDetailsProjectDetailsMenuItem.Visible = true;
            ActivityDetailsProjectDetailsMenuItem.Text = "Project Details";
            ActivityDetailsProjectDetailsMenuItem.Click += new System.EventHandler(this.ActivityDetailsProjectDetailsMenuItem_Click);

            ActivityDetailsMenuItem.DropDownItems.Add(ActivityDetailsProductDetailsMenuItem);
            ActivityDetailsProductDetailsMenuItem.Name = "ActivityDetailsProductDetailsMenuItem";
            
            ActivityDetailsProductDetailsMenuItem.Size = new System.Drawing.Size(152, 22);
            ActivityDetailsProductDetailsMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ActivityDetailsProductDetailsMenuItem.Visible = true;
            ActivityDetailsProductDetailsMenuItem.Text = "Product Details";
            ActivityDetailsProductDetailsMenuItem.Click += new System.EventHandler(this.ActivityDetailsProductDetailsMenuItem_Click);

            ActivityDetailsMenuItem.DropDownItems.Add(ActivityDetailsDigitalActivityDetailsMenuItem);
            ActivityDetailsDigitalActivityDetailsMenuItem.Name = "ActivityDetailsDigitalActivityDetailsMenuItem";
            
            ActivityDetailsDigitalActivityDetailsMenuItem.Size = new System.Drawing.Size(152, 22);
            ActivityDetailsDigitalActivityDetailsMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ActivityDetailsDigitalActivityDetailsMenuItem.Visible = true;
            ActivityDetailsDigitalActivityDetailsMenuItem.Text = "Digital Activity Details";
            ActivityDetailsDigitalActivityDetailsMenuItem.Click += new System.EventHandler(this.ActivityDetailsDigitalActivityDetailsMenuItem_Click);

            ActivityDetailsMenuItem.DropDownItems.Add(ActivityDetailsReportMenuItem);
            ActivityDetailsReportMenuItem.Name = "ActivityDetailsReportMenuItem";
            
            ActivityDetailsReportMenuItem.Size = new System.Drawing.Size(152, 22);
            ActivityDetailsReportMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ActivityDetailsReportMenuItem.Visible = false;
            ActivityDetailsReportMenuItem.Text = "Report";
            ActivityDetailsReportMenuItem.Click += new System.EventHandler(this.ActivityDetailsReportMenuItem_Click);

            menuStrip.Items.Add(EmailMenuItem);
            EmailMenuItem.Name = "EmailMenuItem";
            
            EmailMenuItem.Size = new System.Drawing.Size(152, 22);
            EmailMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            EmailMenuItem.Visible = true;
            EmailMenuItem.Text = "Email";

            EmailMenuItem.DropDownItems.Add(EmailSendMailMenuItem);
            EmailSendMailMenuItem.Name = "EmailSendMailMenuItem";
            
            EmailSendMailMenuItem.Size = new System.Drawing.Size(152, 22);
            EmailSendMailMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            EmailSendMailMenuItem.Visible = true;
            EmailSendMailMenuItem.Text = "Send Mail";
            EmailSendMailMenuItem.Click += new System.EventHandler(this.EmailSendMailMenuItem_Click);

            EmailMenuItem.DropDownItems.Add(EmailSentMailMenuItem);
            EmailSentMailMenuItem.Name = "EmailSentMailMenuItem";
            
            EmailSentMailMenuItem.Size = new System.Drawing.Size(152, 22);
            EmailSentMailMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            EmailSentMailMenuItem.Visible = true;
            EmailSentMailMenuItem.Text = "Sent Mail";
            EmailSentMailMenuItem.Click += new System.EventHandler(this.EmailSentMailMenuItem_Click);

            EmailMenuItem.DropDownItems.Add(seperator3);
            this.seperator3.Name = "seperator3";

            EmailMenuItem.DropDownItems.Add(EmailConfigureEmailMenuItem);
            EmailConfigureEmailMenuItem.Name = "EmailConfigureEmailMenuItem";
            
            EmailConfigureEmailMenuItem.Size = new System.Drawing.Size(152, 22);
            EmailConfigureEmailMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            EmailConfigureEmailMenuItem.Visible = true;
            EmailConfigureEmailMenuItem.Text = "Configure Email";
            EmailConfigureEmailMenuItem.Click += new System.EventHandler(this.EmailConfigureEmailMenuItem_Click);

            EmailMenuItem.DropDownItems.Add(EmailConfigureEmailServerMenuItem);
            EmailConfigureEmailServerMenuItem.Name = "EmailConfigureEmailServerMenuItem";
            
            EmailConfigureEmailServerMenuItem.Size = new System.Drawing.Size(152, 22);
            EmailConfigureEmailServerMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            EmailConfigureEmailServerMenuItem.Visible = true;
            EmailConfigureEmailServerMenuItem.Text = "Configure Email Server";
            EmailConfigureEmailServerMenuItem.Click += new System.EventHandler(this.EmailConfigureEmailServerMenuItem_Click);

            EmailMenuItem.DropDownItems.Add(EmailConfigureEmailTemplateMenuItem);
            EmailConfigureEmailTemplateMenuItem.Name = "EmailConfigureEmailTemplateMenuItem";
            
            EmailConfigureEmailTemplateMenuItem.Size = new System.Drawing.Size(152, 22);
            EmailConfigureEmailTemplateMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            EmailConfigureEmailTemplateMenuItem.Visible = true;
            EmailConfigureEmailTemplateMenuItem.Text = "Configure Email Template";
            EmailConfigureEmailTemplateMenuItem.Click += new System.EventHandler(this.EmailConfigureEmailTemplateMenuItem_Click);

            menuStrip.Items.Add(ToolsMenuItem);
            ToolsMenuItem.Name = "ToolsMenuItem";
            
            ToolsMenuItem.Size = new System.Drawing.Size(152, 22);
            ToolsMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ToolsMenuItem.Visible = true;
            ToolsMenuItem.Text = "Tools";


            ToolsMenuItem.DropDownItems.Add(ToolsLicenseManagerMenuItem);
            ToolsLicenseManagerMenuItem.Name = "ToolsLicenseManagerMenuItem";
            
            ToolsLicenseManagerMenuItem.Size = new System.Drawing.Size(152, 22);
            ToolsLicenseManagerMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ToolsLicenseManagerMenuItem.Visible = true;
            ToolsLicenseManagerMenuItem.Text = "License Manager";
            ToolsLicenseManagerMenuItem.Click += new System.EventHandler(this.ToolsLicenseManagerMenuItem_Click);

            ToolsMenuItem.DropDownItems.Add(ToolsBackupDatabaseMenuItem);
            ToolsBackupDatabaseMenuItem.Name = "ToolsBackupDatabaseMenuItem";
            
            ToolsBackupDatabaseMenuItem.Size = new System.Drawing.Size(152, 22);
            ToolsBackupDatabaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ToolsBackupDatabaseMenuItem.Visible = true;
            ToolsBackupDatabaseMenuItem.Text = "Backup Database";
            ToolsBackupDatabaseMenuItem.Click += new System.EventHandler(this.DatabaseBackupToolStripMenuItem_Click);

            ToolsMenuItem.DropDownItems.Add(ToolsRestoreDatabaseMenuItem);
            ToolsRestoreDatabaseMenuItem.Name = "ToolsRestoreDatabaseMenuItem";
            
            ToolsRestoreDatabaseMenuItem.Size = new System.Drawing.Size(152, 22);
            ToolsRestoreDatabaseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ToolsRestoreDatabaseMenuItem.Visible = true;
            ToolsRestoreDatabaseMenuItem.Text = "Restore Database";
            ToolsRestoreDatabaseMenuItem.Click += new System.EventHandler(this.RestoreDatabaseToolStripMenuItem_Click);

            ToolsMenuItem.DropDownItems.Add(seperator4);
            this.seperator4.Name = "seperator4";

            ToolsMenuItem.DropDownItems.Add(ToolsProtectFileMenuItem);
            ToolsProtectFileMenuItem.Name = "ToolsProtectFileMenuItem";
            
            ToolsProtectFileMenuItem.Size = new System.Drawing.Size(152, 22);
            ToolsProtectFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ToolsProtectFileMenuItem.Visible = true;
            ToolsProtectFileMenuItem.Text = "Protect File";
            ToolsProtectFileMenuItem.Click += new System.EventHandler(this.ProtectFileToolStripMenuItem_Click);

            ToolsMenuItem.DropDownItems.Add(ToolsProtectProgramMenuItem);
            ToolsProtectProgramMenuItem.Name = "ToolsProtectProgramMenuItem";
            
            ToolsProtectProgramMenuItem.Size = new System.Drawing.Size(152, 22);
            ToolsProtectProgramMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            ToolsProtectProgramMenuItem.Visible = true;
            ToolsProtectProgramMenuItem.Text = "Protect Program";
            ToolsProtectProgramMenuItem.Click += new System.EventHandler(this.ProtectProgramToolStripMenuItem_Click);

            menuStrip.Items.Add(HelpMenuItem);
            HelpMenuItem.Name = "HelpMenuItem";
            
            HelpMenuItem.Size = new System.Drawing.Size(152, 22);
            HelpMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            HelpMenuItem.Visible = true;
            HelpMenuItem.Text = "Help";


            HelpMenuItem.DropDownItems.Add(HelpAboutNewsletterComposerMenuItem);
            HelpAboutNewsletterComposerMenuItem.Name = "HelpAboutNewsletterComposerMenuItem";
            
            HelpAboutNewsletterComposerMenuItem.Size = new System.Drawing.Size(152, 22);
            HelpAboutNewsletterComposerMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            HelpAboutNewsletterComposerMenuItem.Visible = true;
            HelpAboutNewsletterComposerMenuItem.Text = "About Newsletter Composer";
            HelpAboutNewsletterComposerMenuItem.Click += new System.EventHandler(this.HelpAboutNewsletterComposerMenuItem_Click);

            HelpMenuItem.DropDownItems.Add(HelpDisclaimerMenuItem);
            HelpDisclaimerMenuItem.Name = "HelpDisclaimerMenuItem";
            
            HelpDisclaimerMenuItem.Size = new System.Drawing.Size(152, 22);
            HelpDisclaimerMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            HelpDisclaimerMenuItem.Visible = true;
            HelpDisclaimerMenuItem.Text = "Disclaimer";
            HelpDisclaimerMenuItem.Click += new System.EventHandler(this.DisclaimerToolStripMenuItem_Click);

            HelpMenuItem.DropDownItems.Add(HelpAboutMenuItem);
            HelpAboutMenuItem.Name = "HelpAboutMenuItem";
            
            HelpAboutMenuItem.Size = new System.Drawing.Size(152, 22);
            HelpAboutMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            HelpAboutMenuItem.Visible = false;
            HelpAboutMenuItem.Text = "About";
            HelpAboutMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItem_Click);

            HelpMenuItem.DropDownItems.Add(HelpAboutUsMenuItem);
            HelpAboutUsMenuItem.Name = "HelpAboutUsMenuItem";
            
            HelpAboutUsMenuItem.Size = new System.Drawing.Size(152, 22);
            HelpAboutUsMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.None)));
            HelpAboutUsMenuItem.Visible = true;
            HelpAboutUsMenuItem.Text = "About Us";
            HelpAboutUsMenuItem.Click += new System.EventHandler(this.HelpAboutUsMenuItem_Click);

            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 303);
            this.IsMdiContainer = true;
            this.Name = "MainForm";
            this.Text = "Newsletter Composer";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackgroundImage = global::Newsletter_Composer.Properties.Resources.BackgroundNewsletterbackground;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Icon = global::Newsletter_Composer.Properties.Resources.News_Letter;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        MenuStrip menuStrip = new MenuStrip();
        ToolStripMenuItem FileMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem FileNewFileMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem FileOpenFileMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem FileCloseFileMenuItem = new ToolStripMenuItem();
        ToolStripSeparator seperator0 = new ToolStripSeparator();
        ToolStripMenuItem FileRecentFilesMenuItem = new ToolStripMenuItem();
        ToolStripSeparator seperator1 = new ToolStripSeparator();
        ToolStripMenuItem FileExitMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersHandledByMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersProductTypeMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersDigitalActivityMasterMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersMonthMasterMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersRelationMasterMenuItem = new ToolStripMenuItem();
        ToolStripSeparator seperator2 = new ToolStripSeparator();
        ToolStripMenuItem MastersCountryMasterMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersStateMasterMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem MastersPlaceMasterMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem SubscribersMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ActivityDetailsMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ActivityDetailsProjectDetailsMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ActivityDetailsProductDetailsMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ActivityDetailsDigitalActivityDetailsMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ActivityDetailsReportMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem EmailMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem EmailSendMailMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem EmailSentMailMenuItem = new ToolStripMenuItem();
        ToolStripSeparator seperator3 = new ToolStripSeparator();
        ToolStripMenuItem EmailConfigureEmailMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem EmailConfigureEmailServerMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem EmailConfigureEmailTemplateMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ToolsMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ToolsLicenseManagerMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ToolsBackupDatabaseMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ToolsRestoreDatabaseMenuItem = new ToolStripMenuItem();
        ToolStripSeparator seperator4 = new ToolStripSeparator();
        ToolStripMenuItem ToolsProtectFileMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem ToolsProtectProgramMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem HelpMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem HelpAboutNewsletterComposerMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem HelpDisclaimerMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem HelpAboutMenuItem = new ToolStripMenuItem();
        ToolStripMenuItem HelpAboutUsMenuItem = new ToolStripMenuItem();

    }
}