using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using Kushal.ImportTemplate;

namespace Newsletter_Composer {
    public partial class MainForm : Form {
        private string userId, companyName;
                private RecentFiles recentFiles;
        private const int maxRecentFiles = 5;
        private bool isDatabaseLoaded;
        private bool fixedDatabase = false;
        public MainForm() {
            InitializeComponent();
            foreach (Control control in this.Controls) {
                if (control is MdiClient) {
                    control.BackColor = System.Drawing.Color.FromArgb(255,160,160,160);
                    break;
                }
            }

            SetSqlCeDllDirectory();


        }

        [DllImport("kernel32.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern bool SetDllDirectory(string pathName);
        internal static bool SetSqlCeDllDirectory() {
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\References\sqlce\";
            path += (IntPtr.Size == 8 ? "x64" : "x86");
            return SetDllDirectory(path);
        }


        private void MainForm_Load(object sender, EventArgs e) {


            
            CheckApplicationPassword();
            LoadRecentFiles();
            string filepath = string.Empty;
            if (fixedDatabase) {
                string dir = Settings.GetDataDirectoryPath();
                filepath = dir + @"\.ENL";
                if (File.Exists(filepath) == false) {
                    NewFileForm.CreateDatabase(filepath);
                }
            } else {
                if (recentFiles.Files.Count > 0) {
                    filepath = recentFiles.Files[0];
                }
            }

            if (String.IsNullOrEmpty(filepath) == false) {
                OpenDatabaseFile(filepath);
            }
            
            Project.Instance.NotifyApplicationLaunched();
        }


                private void LoadRecentFiles() {
            recentFiles = RecentFiles.Load();

            ToolStripMenuItem recentFilesMenu = FileRecentFilesMenuItem;
            if (recentFiles != null && recentFiles.Files.Count > 0 && recentFilesMenu != null) {
                // Delete none existing directories
                foreach (string file in recentFiles.Files.ToArray()) {
                    if (File.Exists(file) == false) {
                        recentFiles.Files.Remove(file);
                    }
                }

                // Save updated list of recent files
                recentFiles.Save();
                
                recentFilesMenu.DropDownItems.Clear();

                for (int i = 0; i < recentFiles.Files.Count && i < maxRecentFiles; i++) {
                    string file = recentFiles.Files[i];

                    ToolStripMenuItem item = new ToolStripMenuItem();
                    if (file.Length > 80) {
                        item.Text = file.Substring(0, 40) + @"......\" + Path.GetFileName(file);
                    } else {
                        item.Text = file;
                    }

                    item.Tag = file;
                    item.Click += new EventHandler(RecentFileMenuItem_Clicked);
                    recentFilesMenu.DropDownItems.Add(item);
                }
            } else {
                // May be this application is running for the first time or somehow recent file is deleted
                if (recentFilesMenu != null) recentFilesMenu.DropDownItems.Clear();
                recentFiles = new RecentFiles();
                recentFiles.Save();
            }
        }

        private void RecentFileMenuItem_Clicked(object sender, EventArgs e) {
            ToolStripMenuItem item = (ToolStripMenuItem)sender;
            string filename = (string)item.Tag;

            OpenDatabaseFile(filename);
        }

                private void OpenDatabaseFile(string filename) {
            DataAdapter.LoadDataAdapter(filename);

            if (Project.Instance.Password.Equals("admin", StringComparison.OrdinalIgnoreCase) == false) {
                PasswordCheckForm passwordCheckForm = new PasswordCheckForm();
                passwordCheckForm.Type = ProtectionType.ProjectFile;
                passwordCheckForm.Password = Project.Instance.Password;
                passwordCheckForm.LoadForm();

                if (passwordCheckForm.ShowDialog() != DialogResult.OK) {
                    isDatabaseLoaded = false;
                    DataAdapter.UnloadDataAdapter();
                    this.Text = "Newsletter_Composer";

                    return;
                }
            }

            Project.Instance.MainForm = this;
            Project.Instance.NotifyProjectFileOpened();

            isDatabaseLoaded = true;
            this.Text = "Newsletter_Composer - " + filename;
            Project.Instance.FileName = filename;
            recentFiles.Add(filename);

            LoadRecentFiles();

            if (isDatabaseLoaded) {
                VersionController.Update();
            }
        }
        
        
        private void CheckApplicationPassword() {
            if (Settings.AppPassword.Equals("admin", StringComparison.OrdinalIgnoreCase) == false) {
                PasswordCheckForm passwordCheckForm = new PasswordCheckForm();
                passwordCheckForm.Type = ProtectionType.Application;
                passwordCheckForm.Password = Settings.AppPassword;
                passwordCheckForm.LoadForm();

                if (passwordCheckForm.ShowDialog() != DialogResult.OK) {
                    // TODO: disable few application functionalities if needed.
                }
            }
        }
        #region Menu Event Handers
        
        


        private void NewfileToolStripMenuItem_Click(object sender, EventArgs e) {

            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }

            NewFileForm newfileForm = new NewFileForm();
            if (newfileForm.ShowDialog() == DialogResult.OK) {
                OpenDatabaseFile(newfileForm.FileName);
            }
        }

        private void OpenFileToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "ENL files|*.ENL";
            dlg.Multiselect = false;
            dlg.InitialDirectory = Settings.GetDataDirectoryPath();
            if (dlg.ShowDialog() == DialogResult.OK) {
                OpenDatabaseFile(dlg.FileName);
            }
        }

        private void CloseFileToolStripMenuItem_Click(object sender, EventArgs e) {
            
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            isDatabaseLoaded = false;
            DataAdapter.UnloadDataAdapter();
            this.Text = "Newsletter_Composer";
        }



        private void ExitToolStripMenuItem_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void MastersHandledByMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Handeledby(), true, "");
        }

        private void MastersProductTypeMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Producttypemaster(), true, "");
        }

        private void MastersDigitalActivityMasterMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Digital_Activity_Master(), true, "");
        }

        private void MastersMonthMasterMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Monthmaster(), true, "");
        }

        private void MastersRelationMasterMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Relations(), true, "");
        }

        private void MastersCountryMasterMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Country(), true, "");
        }

        private void MastersStateMasterMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new State(), true, "");
        }

        private void MastersPlaceMasterMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Place(), true, "");
        }

        private void SubscribersMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Subscribers(), true, "");
        }

        private void ActivityDetailsProjectDetailsMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Appdetails(), true, "");
        }

        private void ActivityDetailsProductDetailsMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Appdetails_Partydetails(), true, "");
        }

        private void ActivityDetailsDigitalActivityDetailsMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Socialmedia(), true, "");
        }

        private void ActivityDetailsReportMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new GenaratingReport(), true, "");
        }

        private void EmailSendMailMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new EmailSingle(), true, "");
        }

        private void EmailSentMailMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new EmailSentSearch(), true, "");
        }

        private void EmailConfigureEmailMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new EmailIdMaster(), true, "");
        }

        private void EmailConfigureEmailServerMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new EmailServer(), true, "");
        }

        private void EmailConfigureEmailTemplateMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new EmailTemplate(), true, "");
        }



        private void ToolsLicenseManagerMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new LicenseManger(), true, "");
        }

        private void DatabaseBackupToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            
            DataAdapter adapter = DataAdapter.Current;
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.DefaultExt = "ENL";
            dlg.AddExtension = true;
            dlg.Filter = "ENL files|*.ENL";
            if (dlg.ShowDialog() == DialogResult.OK) {
                string status = adapter.BackupData(dlg.FileName);
                if (String.IsNullOrEmpty(status) == false) {
                    MessageBox.Show(status, "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else {
                    MessageBox.Show("Database backup succeeded", "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void RestoreDatabaseToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "ENL files|*.ENL";
            dlg.Multiselect = false;
            dlg.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            if (dlg.ShowDialog() == DialogResult.OK) {
                DataAdapter adapter = DataAdapter.Current;
                string status = adapter.RestoreData(dlg.FileName);
                if (String.IsNullOrEmpty(status) == false) {
                    MessageBox.Show(status, "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else {
                    MessageBox.Show("Database restore succeeded", "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void ProtectFileToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            PasswordProtectionForm passwordProtectionForm = new PasswordProtectionForm();
            passwordProtectionForm.Type = ProtectionType.ProjectFile;
            passwordProtectionForm.CurrentPassword = Project.Instance.Password;
            passwordProtectionForm.LoadForm();

            if (passwordProtectionForm.ShowDialog() == DialogResult.OK) {
                Project.Instance.SetPassword(passwordProtectionForm.NewPassword);
            }
        }

        private void ProtectProgramToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            PasswordProtectionForm passwordProtectionForm = new PasswordProtectionForm();
            passwordProtectionForm.Type = ProtectionType.Application;
            passwordProtectionForm.CurrentPassword = Settings.AppPassword;
            passwordProtectionForm.LoadForm();

            if (passwordProtectionForm.ShowDialog() == DialogResult.OK) {
                Settings.AppPassword = passwordProtectionForm.NewPassword;

                Settings.SavePassword();
            }
        }



        private void HelpAboutNewsletterComposerMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Process.Start(Environment.ExpandEnvironmentVariables(@"http://erachana.net/software/free-download-newsletter-composer-software"), Environment.ExpandEnvironmentVariables(@" "));
        }

        private void DisclaimerToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            DisclaimerForm disclaimerForm = new DisclaimerForm();
            disclaimerForm.ShowDialog();
        }

        private void AboutToolStripMenuItem_Click(object sender, EventArgs e) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            AboutUsForm aboutusForm = new AboutUsForm();
            aboutusForm.ShowDialog();
        }

        private void HelpAboutUsMenuItem_Click(object sender, EventArgs e) {
            if (!isDatabaseLoaded) {
                MessageBox.Show("Database not loaded. Please create database if required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowForm(new Frm_AboutUs(), true, "");
        }

        #endregion
        private void MainForm_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.F1) {
                ShowHelp();
            }
        }

        private void ShowHelp() {
            string helpPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\" + Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location) + "_Help.pdf";
            if (File.Exists(helpPath)) {
                Process.Start(helpPath);
            } else {
                MessageBox.Show("Help file: " + helpPath + " not found.");
            }
        }

        private void ShowForm(Form form, bool isMdiChild) {
            ShowForm(form, isMdiChild, string.Empty);
        }

        private void ShowForm(Form form, bool isMdiChild, string value) {
            if (IsMdiChildExists()) {
                foreach (Form child in this.MdiChildren) {
                    child.Close();
                }
            }
            if (String.IsNullOrEmpty(value) == false) {
                form.SetPropertyValue("Value", value);
            }
            if (isMdiChild) {
                form.MdiParent = this;
                form.Show();
                form.Activate();
            } else {
                form.ShowDialog();
            }
        }

        private bool IsMdiChildExists() {
            return this.MdiChildren.Length > 0;
        }

        public void ShowMenu(string menuName) {

            foreach (ToolStripMenuItem item in menuStrip.Items) {
                if (item.Name == menuName) {
                    item.Visible = true;
                    break;
                }
            }

        }

        public void HideMenu(string menuName) {

            foreach (ToolStripMenuItem item in menuStrip.Items) {
                if (item.Name == menuName) {
                    item.Visible = false;
                    break;
                }
            }

        }
    }
}