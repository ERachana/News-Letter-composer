using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Monthmaster {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpMonthmaster = new Kushal.Controls.KushalGroupBox();
            this.txt_MonthMaster_Month = new Kushal.Controls.KushalComboBox();
            this.lbl_MonthMaster_Id = new Kushal.Controls.KushalLabel();
            this.lbl_MonthMaster_Year = new Kushal.Controls.KushalLabel();
            this.lbl_MonthMaster_Month = new Kushal.Controls.KushalLabel();
            this.txt_MonthMaster_Id = new NumericTextBox();
            this.txt_MonthMaster_Year = new NumericTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnMonth = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(4, 98);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 8;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(118, 98);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 9;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(232, 98);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 10;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(346, 98);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 13;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(326, 438);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpMonthmaster.Location = new System.Drawing.Point(4, 6);
            this.grpMonthmaster.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpMonthmaster.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpMonthmaster.Name = "grpMonthmaster";
            this.grpMonthmaster.Enabled = true;
            this.grpMonthmaster.Visible = true;
            this.grpMonthmaster.TabIndex = 1;
            this.grpMonthmaster.TabStop = false;
            this.grpMonthmaster.Size = new System.Drawing.Size(422, 83);
            this.grpMonthmaster.Text = @"Month Details";
            this.grpMonthmaster.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMonthmaster.SendToBack();
            this.toolTip1.SetToolTip(this.grpMonthmaster, @"");

            this.txt_MonthMaster_Month.Location = new System.Drawing.Point(265, 47);
            this.txt_MonthMaster_Month.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_MonthMaster_Month.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_MonthMaster_Month.MaxDropDownItems = 10;
            this.txt_MonthMaster_Month.IntegralHeight = false;
            this.txt_MonthMaster_Month.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_MonthMaster_Month.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_MonthMaster_Month.FormattingEnabled = true;
            this.txt_MonthMaster_Month.Name = "txt_MonthMaster_Month";
            this.txt_MonthMaster_Month.AllowNull = false;
            this.txt_MonthMaster_Month.FriendlyName = "";
            this.txt_MonthMaster_Month.Enabled = true;
            this.txt_MonthMaster_Month.Visible = true;
            this.txt_MonthMaster_Month.TabIndex = 6;
            this.txt_MonthMaster_Month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_MonthMaster_Month.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_MonthMaster_Month.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MonthMaster_Month.Size = new System.Drawing.Size(152, 29);
            this.txt_MonthMaster_Month.Tag = "Select ListID,ListCode from ListMaster where ListTypeID = 1";
            this.toolTip1.SetToolTip(this.txt_MonthMaster_Month, @"");
            

            this.lbl_MonthMaster_Id.AutoSize = false;
            this.lbl_MonthMaster_Id.Location = new System.Drawing.Point(5, 20);
            this.lbl_MonthMaster_Id.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_MonthMaster_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_MonthMaster_Id.Name = "lbl_MonthMaster_Id";
            this.lbl_MonthMaster_Id.Enabled = true;
            this.lbl_MonthMaster_Id.Visible = true;
            this.lbl_MonthMaster_Id.TabIndex = 3;
            this.lbl_MonthMaster_Id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_MonthMaster_Id.Size = new System.Drawing.Size(70, 23);
            this.lbl_MonthMaster_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonthMaster_Id.Text = @"* ID";
            this.toolTip1.SetToolTip(this.lbl_MonthMaster_Id, @"");

            this.lbl_MonthMaster_Year.AutoSize = false;
            this.lbl_MonthMaster_Year.Location = new System.Drawing.Point(5, 50);
            this.lbl_MonthMaster_Year.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_MonthMaster_Year.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_MonthMaster_Year.Name = "lbl_MonthMaster_Year";
            this.lbl_MonthMaster_Year.Enabled = true;
            this.lbl_MonthMaster_Year.Visible = true;
            this.lbl_MonthMaster_Year.TabIndex = 5;
            this.lbl_MonthMaster_Year.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_MonthMaster_Year.Size = new System.Drawing.Size(70, 23);
            this.lbl_MonthMaster_Year.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonthMaster_Year.Text = @"* Year";
            this.toolTip1.SetToolTip(this.lbl_MonthMaster_Year, @"");

            this.lbl_MonthMaster_Month.AutoSize = false;
            this.lbl_MonthMaster_Month.Location = new System.Drawing.Point(180, 50);
            this.lbl_MonthMaster_Month.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_MonthMaster_Month.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_MonthMaster_Month.Name = "lbl_MonthMaster_Month";
            this.lbl_MonthMaster_Month.Enabled = true;
            this.lbl_MonthMaster_Month.Visible = true;
            this.lbl_MonthMaster_Month.TabIndex = 7;
            this.lbl_MonthMaster_Month.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_MonthMaster_Month.Size = new System.Drawing.Size(70, 23);
            this.lbl_MonthMaster_Month.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonthMaster_Month.Text = @"* Month";
            this.toolTip1.SetToolTip(this.lbl_MonthMaster_Month, @"");

            this.txt_MonthMaster_Id.Location = new System.Drawing.Point(81, 17);
            this.txt_MonthMaster_Id.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_MonthMaster_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_MonthMaster_Id.Name = "txt_MonthMaster_Id";
            this.txt_MonthMaster_Id.DefaultValue = null;
            this.txt_MonthMaster_Id.FriendlyName = "";
            this.txt_MonthMaster_Id.Enabled = true;
            this.txt_MonthMaster_Id.Visible = true;
            this.txt_MonthMaster_Id.ReadOnly = false;
            this.txt_MonthMaster_Id.TabIndex = 2;
            this.txt_MonthMaster_Id.MaxValue = 2147483647;
            this.txt_MonthMaster_Id.MinValue = -2147483648;
            this.txt_MonthMaster_Id.ValidationMessage = "";
            this.txt_MonthMaster_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MonthMaster_Id.Size = new System.Drawing.Size(92, 29);
            this.txt_MonthMaster_Id.SelectAllOnFocus = true;
            this.txt_MonthMaster_Id.DoValidation = false;
            this.txt_MonthMaster_Id.AllowNull = false;
            this.txt_MonthMaster_Id.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_MonthMaster_Id, @"");

            this.txt_MonthMaster_Year.Location = new System.Drawing.Point(81, 47);
            this.txt_MonthMaster_Year.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_MonthMaster_Year.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_MonthMaster_Year.Name = "txt_MonthMaster_Year";
            this.txt_MonthMaster_Year.DefaultValue = null;
            this.txt_MonthMaster_Year.FriendlyName = "";
            this.txt_MonthMaster_Year.Enabled = true;
            this.txt_MonthMaster_Year.Visible = true;
            this.txt_MonthMaster_Year.ReadOnly = false;
            this.txt_MonthMaster_Year.TabIndex = 4;
            this.txt_MonthMaster_Year.MaxValue = 2147483647;
            this.txt_MonthMaster_Year.MinValue = -2147483648;
            this.txt_MonthMaster_Year.ValidationMessage = "";
            this.txt_MonthMaster_Year.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MonthMaster_Year.Size = new System.Drawing.Size(92, 29);
            this.txt_MonthMaster_Year.SelectAllOnFocus = true;
            this.txt_MonthMaster_Year.DoValidation = false;
            this.txt_MonthMaster_Year.AllowNull = false;
            this.txt_MonthMaster_Year.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_MonthMaster_Year, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(4, 135);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(422, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnId.HeaderText = "ID";
            this.dgrDataColumnId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnId.Name = "dgrDataColumnId";
            this.dgrDataColumnId.DataPropertyName = "Id";
            this.dgrDataColumnId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnId.Width = 70;
            this.dgrDataColumnId.Visible = true;
            this.dgrDataColumnId.DisplayIndex = 0;
            this.dgrDataColumnId.ReadOnly = false;
            this.dgrDataColumnId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnId);

            this.dgrDataColumnYear.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnYear.HeaderText = "Year";
            this.dgrDataColumnYear.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnYear.Name = "dgrDataColumnYear";
            this.dgrDataColumnYear.DataPropertyName = "Year";
            this.dgrDataColumnYear.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnYear.Width = 100;
            this.dgrDataColumnYear.Visible = true;
            this.dgrDataColumnYear.DisplayIndex = 1;
            this.dgrDataColumnYear.ReadOnly = false;
            this.dgrDataColumnYear.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnYear);

            this.dgrDataColumnMonth.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnMonth.HeaderText = "Month";
            this.dgrDataColumnMonth.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnMonth.Name = "dgrDataColumnMonth";
            this.dgrDataColumnMonth.DataPropertyName = "Month";
            this.dgrDataColumnMonth.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnMonth.Width = 150;
            this.dgrDataColumnMonth.Visible = true;
            this.dgrDataColumnMonth.DisplayIndex = 2;
            this.dgrDataColumnMonth.ReadOnly = false;
            this.dgrDataColumnMonth.Tag = "Select ListID,ListCode from ListMaster where ListTypeID = 1";
            this.dgrDataColumnMonth.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnMonth);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpMonthmaster);
            this.grpMonthmaster.Controls.Add(this.txt_MonthMaster_Month);
            this.grpMonthmaster.Controls.Add(this.lbl_MonthMaster_Id);
            this.grpMonthmaster.Controls.Add(this.lbl_MonthMaster_Year);
            this.grpMonthmaster.Controls.Add(this.lbl_MonthMaster_Month);
            this.grpMonthmaster.Controls.Add(this.txt_MonthMaster_Id);
            this.grpMonthmaster.Controls.Add(this.txt_MonthMaster_Year);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Monthmaster";
            this.Text = "Month Master";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(448, 503);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpMonthmaster;
        private Kushal.Controls.KushalComboBox txt_MonthMaster_Month;
        private Kushal.Controls.KushalLabel lbl_MonthMaster_Id;
        private Kushal.Controls.KushalLabel lbl_MonthMaster_Year;
        private Kushal.Controls.KushalLabel lbl_MonthMaster_Month;
        private NumericTextBox txt_MonthMaster_Id;
        private NumericTextBox txt_MonthMaster_Year;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnYear;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnMonth;
    }
}