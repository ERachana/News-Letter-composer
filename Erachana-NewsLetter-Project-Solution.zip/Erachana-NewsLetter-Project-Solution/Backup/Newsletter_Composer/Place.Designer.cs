using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Place {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnSearch = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpCmnplace = new Kushal.Controls.KushalGroupBox();
            this.btnState = new Kushal.Controls.KushalButton();
            this.txt_StateId = new Kushal.Controls.KushalComboBox();
            this.lbl_PlaceId = new Kushal.Controls.KushalLabel();
            this.lbl_PlaceName = new Kushal.Controls.KushalLabel();
            this.lbl_StateId = new Kushal.Controls.KushalLabel();
            this.txt_PlaceId = new NumericTextBox();
            this.txt_PlaceName = new Kushal.Controls.KushalTextBox();
            this.grpImport = new Kushal.Controls.KushalGroupBox();
            this.btnImport = new Kushal.Controls.KushalButton();
            this.btnCreateTemplate = new Kushal.Controls.KushalButton();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnPlaceId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnStateId = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnPlaceName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(11, 87);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 12;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(118, 87);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 13;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(227, 87);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 14;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnSearch.Location = new System.Drawing.Point(13, 526);
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSearch.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Enabled = true;
            this.btnSearch.Visible = false;
            this.btnSearch.TabIndex = 15;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSearch.Size = new System.Drawing.Size(80, 30);
            this.btnSearch.Text = @"Search";
            this.btnSearch.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSearch, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(336, 87);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 17;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(317, 530);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpCmnplace.Location = new System.Drawing.Point(11, 2);
            this.grpCmnplace.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpCmnplace.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpCmnplace.Name = "grpCmnplace";
            this.grpCmnplace.Enabled = true;
            this.grpCmnplace.Visible = true;
            this.grpCmnplace.TabIndex = 1;
            this.grpCmnplace.TabStop = false;
            this.grpCmnplace.Size = new System.Drawing.Size(406, 76);
            this.grpCmnplace.Text = @"Place Details";
            this.grpCmnplace.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCmnplace.SendToBack();
            this.toolTip1.SetToolTip(this.grpCmnplace, @"");

            this.btnState.Location = new System.Drawing.Point(369, 14);
            this.btnState.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnState.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnState.Name = "btnState";
            this.btnState.Enabled = true;
            this.btnState.Visible = true;
            this.btnState.TabIndex = 11;
            this.btnState.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnState.Size = new System.Drawing.Size(30, 30);
            this.btnState.Text = @"...";
            this.btnState.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnState.UseVisualStyleBackColor = false;
            this.btnState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnState, @"Add State");
            
            

            this.txt_StateId.Location = new System.Drawing.Point(126, 14);
            this.txt_StateId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_StateId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_StateId.MaxDropDownItems = 10;
            this.txt_StateId.IntegralHeight = false;
            this.txt_StateId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_StateId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_StateId.FormattingEnabled = true;
            this.txt_StateId.Name = "txt_StateId";
            this.txt_StateId.AllowNull = true;
            this.txt_StateId.FriendlyName = "";
            this.txt_StateId.Enabled = true;
            this.txt_StateId.Visible = true;
            this.txt_StateId.TabIndex = 10;
            this.txt_StateId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_StateId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_StateId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_StateId.Size = new System.Drawing.Size(240, 30);
            this.txt_StateId.Tag = "select StateID, StateName from state";
            this.toolTip1.SetToolTip(this.txt_StateId, @"");
            

            this.lbl_PlaceId.AutoSize = false;
            this.lbl_PlaceId.Location = new System.Drawing.Point(18, 73);
            this.lbl_PlaceId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PlaceId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PlaceId.Name = "lbl_PlaceId";
            this.lbl_PlaceId.Enabled = true;
            this.lbl_PlaceId.Visible = false;
            this.lbl_PlaceId.TabIndex = 3;
            this.lbl_PlaceId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PlaceId.Size = new System.Drawing.Size(100, 23);
            this.lbl_PlaceId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PlaceId.Text = @"* Place Id";
            this.toolTip1.SetToolTip(this.lbl_PlaceId, @"");

            this.lbl_PlaceName.AutoSize = false;
            this.lbl_PlaceName.Location = new System.Drawing.Point(10, 47);
            this.lbl_PlaceName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PlaceName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PlaceName.Name = "lbl_PlaceName";
            this.lbl_PlaceName.Enabled = true;
            this.lbl_PlaceName.Visible = true;
            this.lbl_PlaceName.TabIndex = 5;
            this.lbl_PlaceName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PlaceName.Size = new System.Drawing.Size(100, 23);
            this.lbl_PlaceName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PlaceName.Text = @"* Place Name";
            this.toolTip1.SetToolTip(this.lbl_PlaceName, @"");

            this.lbl_StateId.AutoSize = false;
            this.lbl_StateId.Location = new System.Drawing.Point(10, 18);
            this.lbl_StateId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_StateId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_StateId.Name = "lbl_StateId";
            this.lbl_StateId.Enabled = true;
            this.lbl_StateId.Visible = true;
            this.lbl_StateId.TabIndex = 11;
            this.lbl_StateId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_StateId.Size = new System.Drawing.Size(100, 23);
            this.lbl_StateId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_StateId.Text = @"* State Name";
            this.toolTip1.SetToolTip(this.lbl_StateId, @"");

            this.txt_PlaceId.Location = new System.Drawing.Point(126, 73);
            this.txt_PlaceId.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_PlaceId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PlaceId.Name = "txt_PlaceId";
            this.txt_PlaceId.DefaultValue = null;
            this.txt_PlaceId.FriendlyName = "";
            this.txt_PlaceId.Enabled = true;
            this.txt_PlaceId.Visible = false;
            this.txt_PlaceId.ReadOnly = false;
            this.txt_PlaceId.TabIndex = 2;
            this.txt_PlaceId.MaxValue = 2147483647;
            this.txt_PlaceId.MinValue = -2147483648;
            this.txt_PlaceId.ValidationMessage = "";
            this.txt_PlaceId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PlaceId.Size = new System.Drawing.Size(100, 27);
            this.txt_PlaceId.SelectAllOnFocus = true;
            this.txt_PlaceId.DoValidation = false;
            this.txt_PlaceId.AllowNull = false;
            this.txt_PlaceId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_PlaceId, @"");

            this.txt_PlaceName.Location = new System.Drawing.Point(126, 45);
            this.txt_PlaceName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_PlaceName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PlaceName.Multiline = false;
            this.txt_PlaceName.MaxLength = 50;
            this.txt_PlaceName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_PlaceName.Name = "txt_PlaceName";
            this.txt_PlaceName.Text = @"";
            
            this.txt_PlaceName.AllowNull = false;
            this.txt_PlaceName.DefaultValue = "";
            this.txt_PlaceName.FriendlyName = "";
            this.txt_PlaceName.ValidationType = TextValidation.None;
            this.txt_PlaceName.ValidationExpression = @"";
            this.txt_PlaceName.ValidationMessage = @"";
            this.txt_PlaceName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_PlaceName.Enabled = true;
            this.txt_PlaceName.ReadOnly = false;
            this.txt_PlaceName.Visible = true;
            this.txt_PlaceName.TabIndex = 12;
            this.txt_PlaceName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_PlaceName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PlaceName.Size = new System.Drawing.Size(240, 27);
            this.toolTip1.SetToolTip(this.txt_PlaceName, @"");

            this.grpImport.Location = new System.Drawing.Point(11, 557);
            this.grpImport.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpImport.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpImport.Name = "grpImport";
            this.grpImport.Enabled = true;
            this.grpImport.Visible = false;
            this.grpImport.TabIndex = 0;
            this.grpImport.TabStop = false;
            this.grpImport.Size = new System.Drawing.Size(406, 59);
            this.grpImport.Text = @"Import Data";
            this.grpImport.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpImport.SendToBack();
            this.toolTip1.SetToolTip(this.grpImport, @"");

            this.btnImport.Location = new System.Drawing.Point(276, 22);
            this.btnImport.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnImport.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnImport.Name = "btnImport";
            this.btnImport.Enabled = true;
            this.btnImport.Visible = true;
            this.btnImport.TabIndex = 0;
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnImport.Size = new System.Drawing.Size(124, 30);
            this.btnImport.Text = @"Import Data";
            this.btnImport.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnImport, @"Insert Data to Database from Excel");
            
            

            this.btnCreateTemplate.Location = new System.Drawing.Point(4, 23);
            this.btnCreateTemplate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnCreateTemplate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnCreateTemplate.Name = "btnCreateTemplate";
            this.btnCreateTemplate.Enabled = true;
            this.btnCreateTemplate.Visible = true;
            this.btnCreateTemplate.TabIndex = 0;
            this.btnCreateTemplate.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnCreateTemplate.Size = new System.Drawing.Size(122, 30);
            this.btnCreateTemplate.Text = @"Create Template";
            this.btnCreateTemplate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateTemplate.UseVisualStyleBackColor = false;
            this.btnCreateTemplate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnCreateTemplate, @"");
            
            

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(11, 123);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(406, 400);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnPlaceId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnPlaceId.HeaderText = "Place Id";
            this.dgrDataColumnPlaceId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPlaceId.Name = "dgrDataColumnPlaceId";
            this.dgrDataColumnPlaceId.DataPropertyName = "PlaceID";
            this.dgrDataColumnPlaceId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnPlaceId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPlaceId.Width = 60;
            this.dgrDataColumnPlaceId.Visible = false;
            this.dgrDataColumnPlaceId.DisplayIndex = 0;
            this.dgrDataColumnPlaceId.ReadOnly = false;
            this.dgrDataColumnPlaceId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPlaceId);

            this.dgrDataColumnStateId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnStateId.HeaderText = "State Name";
            this.dgrDataColumnStateId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnStateId.Name = "dgrDataColumnStateId";
            this.dgrDataColumnStateId.DataPropertyName = "StateID";
            this.dgrDataColumnStateId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnStateId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnStateId.Width = 160;
            this.dgrDataColumnStateId.Visible = true;
            this.dgrDataColumnStateId.DisplayIndex = 1;
            this.dgrDataColumnStateId.ReadOnly = false;
            this.dgrDataColumnStateId.Tag = "select StateID, StateName from state";
            this.dgrDataColumnStateId.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnStateId);

            this.dgrDataColumnPlaceName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnPlaceName.HeaderText = "Place Name";
            this.dgrDataColumnPlaceName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPlaceName.Name = "dgrDataColumnPlaceName";
            this.dgrDataColumnPlaceName.DataPropertyName = "PlaceName";
            this.dgrDataColumnPlaceName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnPlaceName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPlaceName.Width = 160;
            this.dgrDataColumnPlaceName.Visible = true;
            this.dgrDataColumnPlaceName.DisplayIndex = 2;
            this.dgrDataColumnPlaceName.ReadOnly = false;
            this.dgrDataColumnPlaceName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPlaceName);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpCmnplace);
            this.grpCmnplace.Controls.Add(this.btnState);
            this.grpCmnplace.Controls.Add(this.txt_StateId);
            this.grpCmnplace.Controls.Add(this.lbl_PlaceId);
            this.grpCmnplace.Controls.Add(this.lbl_PlaceName);
            this.grpCmnplace.Controls.Add(this.lbl_StateId);
            this.grpCmnplace.Controls.Add(this.txt_PlaceId);
            this.grpCmnplace.Controls.Add(this.txt_PlaceName);
            this.Controls.Add(this.grpImport);
            this.grpImport.Controls.Add(this.btnImport);
            this.grpImport.Controls.Add(this.btnCreateTemplate);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Place";
            this.Text = "Place Master";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(439, 599);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnSearch;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpCmnplace;
        private Kushal.Controls.KushalButton btnState;
        private Kushal.Controls.KushalComboBox txt_StateId;
        private Kushal.Controls.KushalLabel lbl_PlaceId;
        private Kushal.Controls.KushalLabel lbl_PlaceName;
        private Kushal.Controls.KushalLabel lbl_StateId;
        private NumericTextBox txt_PlaceId;
        private Kushal.Controls.KushalTextBox txt_PlaceName;
        private Kushal.Controls.KushalGroupBox grpImport;
        private Kushal.Controls.KushalButton btnImport;
        private Kushal.Controls.KushalButton btnCreateTemplate;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPlaceId;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnStateId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPlaceName;
    }
}