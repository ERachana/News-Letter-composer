using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Producttypemaster {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpProducttypemaster = new Kushal.Controls.KushalGroupBox();
            this.lbl_ProductTypeMaster_Id = new Kushal.Controls.KushalLabel();
            this.lbl_ProductTypeMaster_ProductName = new Kushal.Controls.KushalLabel();
            this.txt_ProductTypeMaster_Id = new NumericTextBox();
            this.txt_ProductTypeMaster_ProductName = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(4, 85);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 6;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(116, 85);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 7;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(228, 85);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 8;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(340, 85);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 11;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(321, 420);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpProducttypemaster.Location = new System.Drawing.Point(4, 3);
            this.grpProducttypemaster.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpProducttypemaster.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpProducttypemaster.Name = "grpProducttypemaster";
            this.grpProducttypemaster.Enabled = true;
            this.grpProducttypemaster.Visible = true;
            this.grpProducttypemaster.TabIndex = 1;
            this.grpProducttypemaster.TabStop = false;
            this.grpProducttypemaster.Size = new System.Drawing.Size(416, 78);
            this.grpProducttypemaster.Text = @"Product Type";
            this.grpProducttypemaster.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpProducttypemaster.SendToBack();
            this.toolTip1.SetToolTip(this.grpProducttypemaster, @"");

            this.lbl_ProductTypeMaster_Id.AutoSize = false;
            this.lbl_ProductTypeMaster_Id.Location = new System.Drawing.Point(5, 17);
            this.lbl_ProductTypeMaster_Id.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ProductTypeMaster_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ProductTypeMaster_Id.Name = "lbl_ProductTypeMaster_Id";
            this.lbl_ProductTypeMaster_Id.Enabled = true;
            this.lbl_ProductTypeMaster_Id.Visible = true;
            this.lbl_ProductTypeMaster_Id.TabIndex = 3;
            this.lbl_ProductTypeMaster_Id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ProductTypeMaster_Id.Size = new System.Drawing.Size(120, 23);
            this.lbl_ProductTypeMaster_Id.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProductTypeMaster_Id.Text = @"* Category ID";
            this.toolTip1.SetToolTip(this.lbl_ProductTypeMaster_Id, @"");

            this.lbl_ProductTypeMaster_ProductName.AutoSize = false;
            this.lbl_ProductTypeMaster_ProductName.Location = new System.Drawing.Point(5, 47);
            this.lbl_ProductTypeMaster_ProductName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_ProductTypeMaster_ProductName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_ProductTypeMaster_ProductName.Name = "lbl_ProductTypeMaster_ProductName";
            this.lbl_ProductTypeMaster_ProductName.Enabled = true;
            this.lbl_ProductTypeMaster_ProductName.Visible = true;
            this.lbl_ProductTypeMaster_ProductName.TabIndex = 5;
            this.lbl_ProductTypeMaster_ProductName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_ProductTypeMaster_ProductName.Size = new System.Drawing.Size(120, 23);
            this.lbl_ProductTypeMaster_ProductName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProductTypeMaster_ProductName.Text = @"* Category Name";
            this.toolTip1.SetToolTip(this.lbl_ProductTypeMaster_ProductName, @"");

            this.txt_ProductTypeMaster_Id.Location = new System.Drawing.Point(127, 14);
            this.txt_ProductTypeMaster_Id.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_ProductTypeMaster_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ProductTypeMaster_Id.Name = "txt_ProductTypeMaster_Id";
            this.txt_ProductTypeMaster_Id.DefaultValue = null;
            this.txt_ProductTypeMaster_Id.FriendlyName = "";
            this.txt_ProductTypeMaster_Id.Enabled = true;
            this.txt_ProductTypeMaster_Id.Visible = true;
            this.txt_ProductTypeMaster_Id.ReadOnly = true;
            this.txt_ProductTypeMaster_Id.TabIndex = 2;
            this.txt_ProductTypeMaster_Id.MaxValue = 2147483647;
            this.txt_ProductTypeMaster_Id.MinValue = -2147483648;
            this.txt_ProductTypeMaster_Id.ValidationMessage = "";
            this.txt_ProductTypeMaster_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProductTypeMaster_Id.Size = new System.Drawing.Size(79, 29);
            this.txt_ProductTypeMaster_Id.SelectAllOnFocus = true;
            this.txt_ProductTypeMaster_Id.DoValidation = false;
            this.txt_ProductTypeMaster_Id.AllowNull = false;
            this.txt_ProductTypeMaster_Id.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_ProductTypeMaster_Id, @"");

            this.txt_ProductTypeMaster_ProductName.Location = new System.Drawing.Point(127, 44);
            this.txt_ProductTypeMaster_ProductName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_ProductTypeMaster_ProductName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_ProductTypeMaster_ProductName.Multiline = false;
            this.txt_ProductTypeMaster_ProductName.MaxLength = 100;
            this.txt_ProductTypeMaster_ProductName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_ProductTypeMaster_ProductName.Name = "txt_ProductTypeMaster_ProductName";
            this.txt_ProductTypeMaster_ProductName.Text = @"";
            
            this.txt_ProductTypeMaster_ProductName.AllowNull = true;
            this.txt_ProductTypeMaster_ProductName.DefaultValue = "";
            this.txt_ProductTypeMaster_ProductName.FriendlyName = "";
            this.txt_ProductTypeMaster_ProductName.ValidationType = TextValidation.None;
            this.txt_ProductTypeMaster_ProductName.ValidationExpression = @"";
            this.txt_ProductTypeMaster_ProductName.ValidationMessage = @"";
            this.txt_ProductTypeMaster_ProductName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_ProductTypeMaster_ProductName.Enabled = true;
            this.txt_ProductTypeMaster_ProductName.ReadOnly = false;
            this.txt_ProductTypeMaster_ProductName.Visible = true;
            this.txt_ProductTypeMaster_ProductName.TabIndex = 4;
            this.txt_ProductTypeMaster_ProductName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_ProductTypeMaster_ProductName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProductTypeMaster_ProductName.Size = new System.Drawing.Size(280, 29);
            this.toolTip1.SetToolTip(this.txt_ProductTypeMaster_ProductName, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(5, 118);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(416, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnId.HeaderText = "ID.";
            this.dgrDataColumnId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnId.Name = "dgrDataColumnId";
            this.dgrDataColumnId.DataPropertyName = "Id";
            this.dgrDataColumnId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnId.Width = 80;
            this.dgrDataColumnId.Visible = true;
            this.dgrDataColumnId.DisplayIndex = 0;
            this.dgrDataColumnId.ReadOnly = false;
            this.dgrDataColumnId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnId);

            this.dgrDataColumnProductName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnProductName.HeaderText = "Category Name";
            this.dgrDataColumnProductName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnProductName.Name = "dgrDataColumnProductName";
            this.dgrDataColumnProductName.DataPropertyName = "CategoryName";
            this.dgrDataColumnProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnProductName.Width = 270;
            this.dgrDataColumnProductName.Visible = true;
            this.dgrDataColumnProductName.DisplayIndex = 1;
            this.dgrDataColumnProductName.ReadOnly = false;
            this.dgrDataColumnProductName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnProductName);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpProducttypemaster);
            this.grpProducttypemaster.Controls.Add(this.lbl_ProductTypeMaster_Id);
            this.grpProducttypemaster.Controls.Add(this.lbl_ProductTypeMaster_ProductName);
            this.grpProducttypemaster.Controls.Add(this.txt_ProductTypeMaster_Id);
            this.grpProducttypemaster.Controls.Add(this.txt_ProductTypeMaster_ProductName);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Producttypemaster";
            this.Text = "Product Type Master";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(439, 484);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpProducttypemaster;
        private Kushal.Controls.KushalLabel lbl_ProductTypeMaster_Id;
        private Kushal.Controls.KushalLabel lbl_ProductTypeMaster_ProductName;
        private NumericTextBox txt_ProductTypeMaster_Id;
        private Kushal.Controls.KushalTextBox txt_ProductTypeMaster_ProductName;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnProductName;
    }
}