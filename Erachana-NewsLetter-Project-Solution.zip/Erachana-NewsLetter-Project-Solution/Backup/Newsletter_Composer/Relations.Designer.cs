using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Relations {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpRelations = new Kushal.Controls.KushalGroupBox();
            this.lbl_Relations_RelationId = new Kushal.Controls.KushalLabel();
            this.lbl_Relations_Relation = new Kushal.Controls.KushalLabel();
            this.txt_Relations_RelationId = new NumericTextBox();
            this.txt_Relations_Relation = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnRelationId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnRelation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(7, 107);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 6;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(118, 107);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 7;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(229, 107);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 8;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(340, 107);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 11;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(318, 446);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpRelations.Location = new System.Drawing.Point(7, 9);
            this.grpRelations.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpRelations.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpRelations.Name = "grpRelations";
            this.grpRelations.Enabled = true;
            this.grpRelations.Visible = true;
            this.grpRelations.TabIndex = 1;
            this.grpRelations.TabStop = false;
            this.grpRelations.Size = new System.Drawing.Size(411, 85);
            this.grpRelations.Text = @"Relation Details";
            this.grpRelations.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRelations.SendToBack();
            this.toolTip1.SetToolTip(this.grpRelations, @"");

            this.lbl_Relations_RelationId.AutoSize = false;
            this.lbl_Relations_RelationId.Location = new System.Drawing.Point(6, 17);
            this.lbl_Relations_RelationId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Relations_RelationId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Relations_RelationId.Name = "lbl_Relations_RelationId";
            this.lbl_Relations_RelationId.Enabled = true;
            this.lbl_Relations_RelationId.Visible = true;
            this.lbl_Relations_RelationId.TabIndex = 3;
            this.lbl_Relations_RelationId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Relations_RelationId.Size = new System.Drawing.Size(100, 23);
            this.lbl_Relations_RelationId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Relations_RelationId.Text = @"* ID";
            this.toolTip1.SetToolTip(this.lbl_Relations_RelationId, @"");

            this.lbl_Relations_Relation.AutoSize = false;
            this.lbl_Relations_Relation.Location = new System.Drawing.Point(6, 47);
            this.lbl_Relations_Relation.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Relations_Relation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Relations_Relation.Name = "lbl_Relations_Relation";
            this.lbl_Relations_Relation.Enabled = true;
            this.lbl_Relations_Relation.Visible = true;
            this.lbl_Relations_Relation.TabIndex = 5;
            this.lbl_Relations_Relation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Relations_Relation.Size = new System.Drawing.Size(100, 23);
            this.lbl_Relations_Relation.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Relations_Relation.Text = @"* Relation";
            this.toolTip1.SetToolTip(this.lbl_Relations_Relation, @"");

            this.txt_Relations_RelationId.Location = new System.Drawing.Point(106, 17);
            this.txt_Relations_RelationId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_Relations_RelationId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Relations_RelationId.Name = "txt_Relations_RelationId";
            this.txt_Relations_RelationId.DefaultValue = null;
            this.txt_Relations_RelationId.FriendlyName = "";
            this.txt_Relations_RelationId.Enabled = true;
            this.txt_Relations_RelationId.Visible = true;
            this.txt_Relations_RelationId.ReadOnly = false;
            this.txt_Relations_RelationId.TabIndex = 2;
            this.txt_Relations_RelationId.MaxValue = 2147483647;
            this.txt_Relations_RelationId.MinValue = -2147483648;
            this.txt_Relations_RelationId.ValidationMessage = "";
            this.txt_Relations_RelationId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Relations_RelationId.Size = new System.Drawing.Size(100, 20);
            this.txt_Relations_RelationId.SelectAllOnFocus = true;
            this.txt_Relations_RelationId.DoValidation = false;
            this.txt_Relations_RelationId.AllowNull = false;
            this.txt_Relations_RelationId.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_Relations_RelationId, @"");

            this.txt_Relations_Relation.Location = new System.Drawing.Point(106, 47);
            this.txt_Relations_Relation.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_Relations_Relation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Relations_Relation.Multiline = false;
            this.txt_Relations_Relation.MaxLength = 100;
            this.txt_Relations_Relation.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Relations_Relation.Name = "txt_Relations_Relation";
            this.txt_Relations_Relation.Text = @"";
            
            this.txt_Relations_Relation.AllowNull = true;
            this.txt_Relations_Relation.DefaultValue = "";
            this.txt_Relations_Relation.FriendlyName = "";
            this.txt_Relations_Relation.ValidationType = TextValidation.None;
            this.txt_Relations_Relation.ValidationExpression = @"";
            this.txt_Relations_Relation.ValidationMessage = @"";
            this.txt_Relations_Relation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Relations_Relation.Enabled = true;
            this.txt_Relations_Relation.ReadOnly = false;
            this.txt_Relations_Relation.Visible = true;
            this.txt_Relations_Relation.TabIndex = 4;
            this.txt_Relations_Relation.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Relations_Relation.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Relations_Relation.Size = new System.Drawing.Size(268, 29);
            this.toolTip1.SetToolTip(this.txt_Relations_Relation, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(7, 142);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(411, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnRelationId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnRelationId.HeaderText = "ID";
            this.dgrDataColumnRelationId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnRelationId.Name = "dgrDataColumnRelationId";
            this.dgrDataColumnRelationId.DataPropertyName = "RelationId";
            this.dgrDataColumnRelationId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnRelationId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnRelationId.Width = 100;
            this.dgrDataColumnRelationId.Visible = true;
            this.dgrDataColumnRelationId.DisplayIndex = 0;
            this.dgrDataColumnRelationId.ReadOnly = false;
            this.dgrDataColumnRelationId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnRelationId);

            this.dgrDataColumnRelation.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnRelation.HeaderText = "Relation";
            this.dgrDataColumnRelation.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnRelation.Name = "dgrDataColumnRelation";
            this.dgrDataColumnRelation.DataPropertyName = "Relation";
            this.dgrDataColumnRelation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnRelation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnRelation.Width = 200;
            this.dgrDataColumnRelation.Visible = true;
            this.dgrDataColumnRelation.DisplayIndex = 1;
            this.dgrDataColumnRelation.ReadOnly = false;
            this.dgrDataColumnRelation.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnRelation);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpRelations);
            this.grpRelations.Controls.Add(this.lbl_Relations_RelationId);
            this.grpRelations.Controls.Add(this.lbl_Relations_Relation);
            this.grpRelations.Controls.Add(this.txt_Relations_RelationId);
            this.grpRelations.Controls.Add(this.txt_Relations_Relation);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Relations";
            this.Text = "Relations";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(446, 511);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpRelations;
        private Kushal.Controls.KushalLabel lbl_Relations_RelationId;
        private Kushal.Controls.KushalLabel lbl_Relations_Relation;
        private NumericTextBox txt_Relations_RelationId;
        private Kushal.Controls.KushalTextBox txt_Relations_Relation;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnRelationId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnRelation;
    }
}