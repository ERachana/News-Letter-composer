using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Socialmedia {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.grpSocialmedia = new Kushal.Controls.KushalGroupBox();
            this.btnMaster = new Kushal.Controls.KushalButton();
            this.dtp_SocialMedia_StatusDate = new DateTextBox();
            this.txt_SocialMedia_MasterName = new Kushal.Controls.KushalComboBox();
            this.txt_SocialMedia_Month = new Kushal.Controls.KushalComboBox();
            this.lbl_SocialMedia_Id = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMedia_MasterName = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMedia_StatusDate = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMedia_Month = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMedia_Counts = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMedia_Link = new Kushal.Controls.KushalLabel();
            this.lbl_SocialMedia_Remarks = new Kushal.Controls.KushalLabel();
            this.txt_SocialMedia_Id = new NumericTextBox();
            this.txt_SocialMedia_Counts = new NumericTextBox();
            this.txt_SocialMedia_Link = new Kushal.Controls.KushalTextBox();
            this.txt_SocialMedia_Remarks = new Kushal.Controls.KushalTextBox();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnMasterName = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnStatusDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnMonth = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnCounts = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(4, 153);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 6;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(141, 153);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 7;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(278, 153);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 8;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(415, 153);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 9;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(395, 489);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.grpSocialmedia.Location = new System.Drawing.Point(4, 2);
            this.grpSocialmedia.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpSocialmedia.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpSocialmedia.Name = "grpSocialmedia";
            this.grpSocialmedia.Enabled = true;
            this.grpSocialmedia.Visible = true;
            this.grpSocialmedia.TabIndex = 1;
            this.grpSocialmedia.TabStop = false;
            this.grpSocialmedia.Size = new System.Drawing.Size(491, 145);
            this.grpSocialmedia.Text = @"Digital Activity Details";
            this.grpSocialmedia.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSocialmedia.SendToBack();
            this.toolTip1.SetToolTip(this.grpSocialmedia, @"");

            this.btnMaster.Location = new System.Drawing.Point(387, 48);
            this.btnMaster.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnMaster.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnMaster.Name = "btnMaster";
            this.btnMaster.Enabled = true;
            this.btnMaster.Visible = true;
            this.btnMaster.TabIndex = 2;
            this.btnMaster.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnMaster.Size = new System.Drawing.Size(30, 30);
            this.btnMaster.Text = @"...";
            this.btnMaster.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaster.UseVisualStyleBackColor = false;
            this.btnMaster.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnMaster, @"");
            
            

            this.dtp_SocialMedia_StatusDate.Location = new System.Drawing.Point(627, 41);
            this.dtp_SocialMedia_StatusDate.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.dtp_SocialMedia_StatusDate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.dtp_SocialMedia_StatusDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_SocialMedia_StatusDate.Name = "dtp_SocialMedia_StatusDate";
            this.dtp_SocialMedia_StatusDate.DefaultValue = null;
            this.dtp_SocialMedia_StatusDate.Text = "";
            this.dtp_SocialMedia_StatusDate.Value = null;
            this.dtp_SocialMedia_StatusDate.FriendlyName = "";
            this.dtp_SocialMedia_StatusDate.Enabled = true;
            this.dtp_SocialMedia_StatusDate.Visible = true;
            this.dtp_SocialMedia_StatusDate.TabIndex = 6;
            this.dtp_SocialMedia_StatusDate.MinValue = new System.DateTime(((long)(0)));
            this.dtp_SocialMedia_StatusDate.MaxValue = new System.DateTime(((long)(0)));
            this.dtp_SocialMedia_StatusDate.ValidationMessage = "";
            this.dtp_SocialMedia_StatusDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dtp_SocialMedia_StatusDate.Size = new System.Drawing.Size(93, 29);
            this.dtp_SocialMedia_StatusDate.SelectAllOnFocus = true;
            this.dtp_SocialMedia_StatusDate.DoValidation = false;
            this.dtp_SocialMedia_StatusDate.AllowNull = true;
            this.dtp_SocialMedia_StatusDate.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.dtp_SocialMedia_StatusDate, @"");

            this.txt_SocialMedia_MasterName.Location = new System.Drawing.Point(127, 49);
            this.txt_SocialMedia_MasterName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_SocialMedia_MasterName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_SocialMedia_MasterName.MaxDropDownItems = 10;
            this.txt_SocialMedia_MasterName.IntegralHeight = false;
            this.txt_SocialMedia_MasterName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_SocialMedia_MasterName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMedia_MasterName.FormattingEnabled = true;
            this.txt_SocialMedia_MasterName.Name = "txt_SocialMedia_MasterName";
            this.txt_SocialMedia_MasterName.AllowNull = false;
            this.txt_SocialMedia_MasterName.FriendlyName = "";
            this.txt_SocialMedia_MasterName.Enabled = true;
            this.txt_SocialMedia_MasterName.Visible = true;
            this.txt_SocialMedia_MasterName.TabIndex = 1;
            this.txt_SocialMedia_MasterName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_SocialMedia_MasterName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_SocialMedia_MasterName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMedia_MasterName.Size = new System.Drawing.Size(254, 29);
            this.txt_SocialMedia_MasterName.Tag = "select * from SocialMediaMaster";
            this.toolTip1.SetToolTip(this.txt_SocialMedia_MasterName, @"");
            

            this.txt_SocialMedia_Month.Location = new System.Drawing.Point(127, 80);
            this.txt_SocialMedia_Month.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_SocialMedia_Month.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_SocialMedia_Month.MaxDropDownItems = 10;
            this.txt_SocialMedia_Month.IntegralHeight = false;
            this.txt_SocialMedia_Month.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_SocialMedia_Month.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMedia_Month.FormattingEnabled = true;
            this.txt_SocialMedia_Month.Name = "txt_SocialMedia_Month";
            this.txt_SocialMedia_Month.AllowNull = true;
            this.txt_SocialMedia_Month.FriendlyName = "";
            this.txt_SocialMedia_Month.Enabled = true;
            this.txt_SocialMedia_Month.Visible = true;
            this.txt_SocialMedia_Month.TabIndex = 3;
            this.txt_SocialMedia_Month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_SocialMedia_Month.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_SocialMedia_Month.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMedia_Month.Size = new System.Drawing.Size(160, 29);
            this.txt_SocialMedia_Month.Tag = "SELECT MonthMaster.Id, CAST(MonthMaster.Year AS nvarchar(4)) + '-' + CAST(ListMaster.ListCode AS nvarchar(15)) AS Expr1 FROM MonthMaster INNER JOIN ListMaster ON MonthMaster.Month = ListMaster.ListID WHERE (ListMaster.ListTypeID = 1)";
            this.toolTip1.SetToolTip(this.txt_SocialMedia_Month, @"");
            

            this.lbl_SocialMedia_Id.AutoSize = false;
            this.lbl_SocialMedia_Id.Location = new System.Drawing.Point(9, 21);
            this.lbl_SocialMedia_Id.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_Id.Name = "lbl_SocialMedia_Id";
            this.lbl_SocialMedia_Id.Enabled = true;
            this.lbl_SocialMedia_Id.Visible = true;
            this.lbl_SocialMedia_Id.TabIndex = 3;
            this.lbl_SocialMedia_Id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_Id.Size = new System.Drawing.Size(100, 23);
            this.lbl_SocialMedia_Id.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_Id.Text = @"* ID";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_Id, @"");

            this.lbl_SocialMedia_MasterName.AutoSize = false;
            this.lbl_SocialMedia_MasterName.Location = new System.Drawing.Point(7, 50);
            this.lbl_SocialMedia_MasterName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_MasterName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_MasterName.Name = "lbl_SocialMedia_MasterName";
            this.lbl_SocialMedia_MasterName.Enabled = true;
            this.lbl_SocialMedia_MasterName.Visible = true;
            this.lbl_SocialMedia_MasterName.TabIndex = 5;
            this.lbl_SocialMedia_MasterName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_MasterName.Size = new System.Drawing.Size(108, 23);
            this.lbl_SocialMedia_MasterName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_MasterName.Text = @"* Digital Activity";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_MasterName, @"");

            this.lbl_SocialMedia_StatusDate.AutoSize = false;
            this.lbl_SocialMedia_StatusDate.Location = new System.Drawing.Point(626, 20);
            this.lbl_SocialMedia_StatusDate.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_StatusDate.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_StatusDate.Name = "lbl_SocialMedia_StatusDate";
            this.lbl_SocialMedia_StatusDate.Enabled = true;
            this.lbl_SocialMedia_StatusDate.Visible = true;
            this.lbl_SocialMedia_StatusDate.TabIndex = 7;
            this.lbl_SocialMedia_StatusDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_StatusDate.Size = new System.Drawing.Size(90, 23);
            this.lbl_SocialMedia_StatusDate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_StatusDate.Text = @"* Status Date";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_StatusDate, @"");

            this.lbl_SocialMedia_Month.AutoSize = false;
            this.lbl_SocialMedia_Month.Location = new System.Drawing.Point(7, 81);
            this.lbl_SocialMedia_Month.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_Month.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_Month.Name = "lbl_SocialMedia_Month";
            this.lbl_SocialMedia_Month.Enabled = true;
            this.lbl_SocialMedia_Month.Visible = true;
            this.lbl_SocialMedia_Month.TabIndex = 9;
            this.lbl_SocialMedia_Month.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_Month.Size = new System.Drawing.Size(90, 23);
            this.lbl_SocialMedia_Month.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_Month.Text = @"* Month";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_Month, @"");

            this.lbl_SocialMedia_Counts.AutoSize = false;
            this.lbl_SocialMedia_Counts.Location = new System.Drawing.Point(297, 81);
            this.lbl_SocialMedia_Counts.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_Counts.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_Counts.Name = "lbl_SocialMedia_Counts";
            this.lbl_SocialMedia_Counts.Enabled = true;
            this.lbl_SocialMedia_Counts.Visible = true;
            this.lbl_SocialMedia_Counts.TabIndex = 11;
            this.lbl_SocialMedia_Counts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_Counts.Size = new System.Drawing.Size(82, 23);
            this.lbl_SocialMedia_Counts.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_Counts.Text = @"  Counts";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_Counts, @"");

            this.lbl_SocialMedia_Link.AutoSize = false;
            this.lbl_SocialMedia_Link.Location = new System.Drawing.Point(629, 73);
            this.lbl_SocialMedia_Link.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_Link.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_Link.Name = "lbl_SocialMedia_Link";
            this.lbl_SocialMedia_Link.Enabled = true;
            this.lbl_SocialMedia_Link.Visible = false;
            this.lbl_SocialMedia_Link.TabIndex = 13;
            this.lbl_SocialMedia_Link.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_Link.Size = new System.Drawing.Size(90, 23);
            this.lbl_SocialMedia_Link.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_Link.Text = @"Media Link";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_Link, @"");

            this.lbl_SocialMedia_Remarks.AutoSize = false;
            this.lbl_SocialMedia_Remarks.Location = new System.Drawing.Point(7, 112);
            this.lbl_SocialMedia_Remarks.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_SocialMedia_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_SocialMedia_Remarks.Name = "lbl_SocialMedia_Remarks";
            this.lbl_SocialMedia_Remarks.Enabled = true;
            this.lbl_SocialMedia_Remarks.Visible = true;
            this.lbl_SocialMedia_Remarks.TabIndex = 15;
            this.lbl_SocialMedia_Remarks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_SocialMedia_Remarks.Size = new System.Drawing.Size(100, 23);
            this.lbl_SocialMedia_Remarks.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SocialMedia_Remarks.Text = @"  Remarks";
            this.toolTip1.SetToolTip(this.lbl_SocialMedia_Remarks, @"");

            this.txt_SocialMedia_Id.Location = new System.Drawing.Point(127, 18);
            this.txt_SocialMedia_Id.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_SocialMedia_Id.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMedia_Id.Name = "txt_SocialMedia_Id";
            this.txt_SocialMedia_Id.DefaultValue = null;
            this.txt_SocialMedia_Id.FriendlyName = "";
            this.txt_SocialMedia_Id.Enabled = true;
            this.txt_SocialMedia_Id.Visible = true;
            this.txt_SocialMedia_Id.ReadOnly = false;
            this.txt_SocialMedia_Id.TabIndex = 0;
            this.txt_SocialMedia_Id.MaxValue = 2147483647;
            this.txt_SocialMedia_Id.MinValue = -2147483648;
            this.txt_SocialMedia_Id.ValidationMessage = "";
            this.txt_SocialMedia_Id.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMedia_Id.Size = new System.Drawing.Size(100, 29);
            this.txt_SocialMedia_Id.SelectAllOnFocus = true;
            this.txt_SocialMedia_Id.DoValidation = false;
            this.txt_SocialMedia_Id.AllowNull = false;
            this.txt_SocialMedia_Id.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_SocialMedia_Id, @"");

            this.txt_SocialMedia_Counts.Location = new System.Drawing.Point(387, 80);
            this.txt_SocialMedia_Counts.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_SocialMedia_Counts.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMedia_Counts.Name = "txt_SocialMedia_Counts";
            this.txt_SocialMedia_Counts.DefaultValue = null;
            this.txt_SocialMedia_Counts.FriendlyName = "";
            this.txt_SocialMedia_Counts.Enabled = true;
            this.txt_SocialMedia_Counts.Visible = true;
            this.txt_SocialMedia_Counts.ReadOnly = false;
            this.txt_SocialMedia_Counts.TabIndex = 4;
            this.txt_SocialMedia_Counts.MaxValue = 2147483647;
            this.txt_SocialMedia_Counts.MinValue = -2147483648;
            this.txt_SocialMedia_Counts.ValidationMessage = "";
            this.txt_SocialMedia_Counts.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMedia_Counts.Size = new System.Drawing.Size(100, 29);
            this.txt_SocialMedia_Counts.SelectAllOnFocus = true;
            this.txt_SocialMedia_Counts.DoValidation = false;
            this.txt_SocialMedia_Counts.AllowNull = true;
            this.txt_SocialMedia_Counts.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_SocialMedia_Counts, @"");

            this.txt_SocialMedia_Link.Location = new System.Drawing.Point(626, 98);
            this.txt_SocialMedia_Link.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_SocialMedia_Link.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMedia_Link.Multiline = false;
            this.txt_SocialMedia_Link.MaxLength = 1000;
            this.txt_SocialMedia_Link.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_SocialMedia_Link.Name = "txt_SocialMedia_Link";
            this.txt_SocialMedia_Link.Text = @"";
            
            this.txt_SocialMedia_Link.AllowNull = true;
            this.txt_SocialMedia_Link.DefaultValue = "";
            this.txt_SocialMedia_Link.FriendlyName = "";
            this.txt_SocialMedia_Link.ValidationType = TextValidation.None;
            this.txt_SocialMedia_Link.ValidationExpression = @"";
            this.txt_SocialMedia_Link.ValidationMessage = @"";
            this.txt_SocialMedia_Link.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_SocialMedia_Link.Enabled = true;
            this.txt_SocialMedia_Link.ReadOnly = false;
            this.txt_SocialMedia_Link.Visible = false;
            this.txt_SocialMedia_Link.TabIndex = 12;
            this.txt_SocialMedia_Link.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_SocialMedia_Link.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMedia_Link.Size = new System.Drawing.Size(289, 29);
            this.toolTip1.SetToolTip(this.txt_SocialMedia_Link, @"");

            this.txt_SocialMedia_Remarks.Location = new System.Drawing.Point(127, 111);
            this.txt_SocialMedia_Remarks.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_SocialMedia_Remarks.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_SocialMedia_Remarks.Multiline = false;
            this.txt_SocialMedia_Remarks.MaxLength = 500;
            this.txt_SocialMedia_Remarks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_SocialMedia_Remarks.Name = "txt_SocialMedia_Remarks";
            this.txt_SocialMedia_Remarks.Text = @"";
            
            this.txt_SocialMedia_Remarks.AllowNull = true;
            this.txt_SocialMedia_Remarks.DefaultValue = "";
            this.txt_SocialMedia_Remarks.FriendlyName = "";
            this.txt_SocialMedia_Remarks.ValidationType = TextValidation.None;
            this.txt_SocialMedia_Remarks.ValidationExpression = @"";
            this.txt_SocialMedia_Remarks.ValidationMessage = @"";
            this.txt_SocialMedia_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_SocialMedia_Remarks.Enabled = true;
            this.txt_SocialMedia_Remarks.ReadOnly = false;
            this.txt_SocialMedia_Remarks.Visible = true;
            this.txt_SocialMedia_Remarks.TabIndex = 5;
            this.txt_SocialMedia_Remarks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_SocialMedia_Remarks.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SocialMedia_Remarks.Size = new System.Drawing.Size(360, 29);
            this.toolTip1.SetToolTip(this.txt_SocialMedia_Remarks, @"");

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(4, 187);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(491, 300);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnId.HeaderText = "ID";
            this.dgrDataColumnId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnId.Name = "dgrDataColumnId";
            this.dgrDataColumnId.DataPropertyName = "Id";
            this.dgrDataColumnId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnId.Width = 40;
            this.dgrDataColumnId.Visible = false;
            this.dgrDataColumnId.DisplayIndex = 0;
            this.dgrDataColumnId.ReadOnly = false;
            this.dgrDataColumnId.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnId);

            this.dgrDataColumnMasterName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnMasterName.HeaderText = "Digital Activity Name";
            this.dgrDataColumnMasterName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnMasterName.Name = "dgrDataColumnMasterName";
            this.dgrDataColumnMasterName.DataPropertyName = "MasterName";
            this.dgrDataColumnMasterName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnMasterName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnMasterName.Width = 200;
            this.dgrDataColumnMasterName.Visible = true;
            this.dgrDataColumnMasterName.DisplayIndex = 1;
            this.dgrDataColumnMasterName.ReadOnly = false;
            this.dgrDataColumnMasterName.Tag = "select * from SocialMediaMaster";
            this.dgrDataColumnMasterName.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnMasterName);

            this.dgrDataColumnStatusDate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnStatusDate.HeaderText = "Status Date";
            this.dgrDataColumnStatusDate.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnStatusDate.Name = "dgrDataColumnStatusDate";
            this.dgrDataColumnStatusDate.DataPropertyName = "StatusDate";
            this.dgrDataColumnStatusDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnStatusDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnStatusDate.Width = 80;
            this.dgrDataColumnStatusDate.Visible = false;
            this.dgrDataColumnStatusDate.DisplayIndex = 2;
            this.dgrDataColumnStatusDate.ReadOnly = false;
            this.dgrDataColumnStatusDate.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnStatusDate);

            this.dgrDataColumnMonth.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnMonth.HeaderText = "Month";
            this.dgrDataColumnMonth.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnMonth.Name = "dgrDataColumnMonth";
            this.dgrDataColumnMonth.DataPropertyName = "Month";
            this.dgrDataColumnMonth.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnMonth.Width = 150;
            this.dgrDataColumnMonth.Visible = true;
            this.dgrDataColumnMonth.DisplayIndex = 3;
            this.dgrDataColumnMonth.ReadOnly = false;
            this.dgrDataColumnMonth.Tag = "SELECT MonthMaster.Id, CAST(MonthMaster.Year AS nvarchar(4)) + '-' + CAST(ListMaster.ListCode AS nvarchar(15)) AS Expr1 FROM MonthMaster INNER JOIN ListMaster ON MonthMaster.Month = ListMaster.ListID WHERE (ListMaster.ListTypeID = 1)";
            this.dgrDataColumnMonth.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnMonth);

            this.dgrDataColumnCounts.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnCounts.HeaderText = "Counts";
            this.dgrDataColumnCounts.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCounts.Name = "dgrDataColumnCounts";
            this.dgrDataColumnCounts.DataPropertyName = "Counts";
            this.dgrDataColumnCounts.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnCounts.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCounts.Width = 80;
            this.dgrDataColumnCounts.Visible = true;
            this.dgrDataColumnCounts.DisplayIndex = 4;
            this.dgrDataColumnCounts.ReadOnly = false;
            this.dgrDataColumnCounts.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCounts);

            this.dgrDataColumnLink.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnLink.HeaderText = "Link";
            this.dgrDataColumnLink.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnLink.Name = "dgrDataColumnLink";
            this.dgrDataColumnLink.DataPropertyName = "Link";
            this.dgrDataColumnLink.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnLink.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnLink.Width = 200;
            this.dgrDataColumnLink.Visible = false;
            this.dgrDataColumnLink.DisplayIndex = 5;
            this.dgrDataColumnLink.ReadOnly = false;
            this.dgrDataColumnLink.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnLink);

            this.dgrDataColumnRemarks.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnRemarks.HeaderText = "Remarks";
            this.dgrDataColumnRemarks.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnRemarks.Name = "dgrDataColumnRemarks";
            this.dgrDataColumnRemarks.DataPropertyName = "Remarks";
            this.dgrDataColumnRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnRemarks.Width = 100;
            this.dgrDataColumnRemarks.Visible = false;
            this.dgrDataColumnRemarks.DisplayIndex = 6;
            this.dgrDataColumnRemarks.ReadOnly = false;
            this.dgrDataColumnRemarks.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnRemarks);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.grpSocialmedia);
            this.grpSocialmedia.Controls.Add(this.btnMaster);
            this.grpSocialmedia.Controls.Add(this.dtp_SocialMedia_StatusDate);
            this.grpSocialmedia.Controls.Add(this.txt_SocialMedia_MasterName);
            this.grpSocialmedia.Controls.Add(this.txt_SocialMedia_Month);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_Id);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_MasterName);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_StatusDate);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_Month);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_Counts);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_Link);
            this.grpSocialmedia.Controls.Add(this.lbl_SocialMedia_Remarks);
            this.grpSocialmedia.Controls.Add(this.txt_SocialMedia_Id);
            this.grpSocialmedia.Controls.Add(this.txt_SocialMedia_Counts);
            this.grpSocialmedia.Controls.Add(this.txt_SocialMedia_Link);
            this.grpSocialmedia.Controls.Add(this.txt_SocialMedia_Remarks);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Socialmedia";
            this.Text = "Digital Activity";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(519, 551);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalGroupBox grpSocialmedia;
        private Kushal.Controls.KushalButton btnMaster;
        private DateTextBox dtp_SocialMedia_StatusDate;
        private Kushal.Controls.KushalComboBox txt_SocialMedia_MasterName;
        private Kushal.Controls.KushalComboBox txt_SocialMedia_Month;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_Id;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_MasterName;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_StatusDate;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_Month;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_Counts;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_Link;
        private Kushal.Controls.KushalLabel lbl_SocialMedia_Remarks;
        private NumericTextBox txt_SocialMedia_Id;
        private NumericTextBox txt_SocialMedia_Counts;
        private Kushal.Controls.KushalTextBox txt_SocialMedia_Link;
        private Kushal.Controls.KushalTextBox txt_SocialMedia_Remarks;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnId;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnMasterName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnStatusDate;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCounts;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnRemarks;
    }
}