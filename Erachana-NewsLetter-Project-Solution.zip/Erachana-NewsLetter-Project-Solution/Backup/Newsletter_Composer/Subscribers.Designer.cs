using Kushal.Controls;
namespace Newsletter_Composer {
    partial class Subscribers {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.btnSearch_S = new Kushal.Controls.KushalButton();
            this.btnClear = new Kushal.Controls.KushalButton();
            this.txt_State = new Kushal.Controls.KushalComboBox();
            this.txt_Country = new Kushal.Controls.KushalComboBox();
            this.lbl_Count = new Kushal.Controls.KushalLabel();
            this.lblCountry = new Kushal.Controls.KushalLabel();
            this.lblState = new Kushal.Controls.KushalLabel();
            this.txt_PartyID = new NumericTextBox();
            this.txt_Search = new Kushal.Controls.KushalTextBox();
            this.grpCustomerdetails = new Kushal.Controls.KushalGroupBox();
            this.btn_Relation_Master = new Kushal.Controls.KushalButton();
            this.txt_Salutation = new Kushal.Controls.KushalComboBox();
            this.cmb_partytype = new Kushal.Controls.KushalComboBox();
            this.lbl_CustomerName = new Kushal.Controls.KushalLabel();
            this.lbl_Companyname = new Kushal.Controls.KushalLabel();
            this.lbl_PartyType = new Kushal.Controls.KushalLabel();
            this.txt_CustomerName = new Kushal.Controls.KushalTextBox();
            this.txt_CompanyName = new Kushal.Controls.KushalTextBox();
            this.grpNewGroupBox1 = new Kushal.Controls.KushalGroupBox();
            this.btnPlaceMaster = new Kushal.Controls.KushalButton();
            this.btnCopy = new Kushal.Controls.KushalButton();
            this.btnHandeledBy = new Kushal.Controls.KushalButton();
            this.txt_PlaceId = new Kushal.Controls.KushalComboBox();
            this.cmb_HandeldBy = new Kushal.Controls.KushalComboBox();
            this.lbl_PlaceId = new Kushal.Controls.KushalLabel();
            this.lbl_Phone1 = new Kushal.Controls.KushalLabel();
            this.lbl_Phone2 = new Kushal.Controls.KushalLabel();
            this.lbl_EmailId = new Kushal.Controls.KushalLabel();
            this.lbl_Website = new Kushal.Controls.KushalLabel();
            this.lbl_EmailId2 = new Kushal.Controls.KushalLabel();
            this.lbl_HandledBy = new Kushal.Controls.KushalLabel();
            this.lbl_State_Name = new Kushal.Controls.KushalLabel();
            this.lbl_country = new Kushal.Controls.KushalLabel();
            this.pnlStatus = new Kushal.Controls.RadioButtonPanel();
            this.rbSubsribe = new Kushal.Controls.KushalRadioButton();
            this.rbUnsubscribe = new Kushal.Controls.KushalRadioButton();
            this.txt_Phone1 = new Kushal.Controls.KushalTextBox();
            this.txt_Phone2 = new Kushal.Controls.KushalTextBox();
            this.txt_EmailId = new Kushal.Controls.KushalTextBox();
            this.txt_Website = new Kushal.Controls.KushalTextBox();
            this.txt_EmailId2 = new Kushal.Controls.KushalTextBox();
            this.grpNewGroupBox4 = new Kushal.Controls.KushalGroupBox();
            this.btnSearch = new Kushal.Controls.KushalButton();
            this.btnExport = new Kushal.Controls.KushalButton();
            this.btnExportIndividual = new Kushal.Controls.KushalButton();
            this.btnImportIndividual = new Kushal.Controls.KushalButton();
            this.btnImportMany = new Kushal.Controls.KushalButton();
            this.btnStatistics = new Kushal.Controls.KushalButton();
            this.lbl_PartyId = new Kushal.Controls.KushalLabel();
            this.grpNewGroupBox2 = new Kushal.Controls.KushalGroupBox();
            this.btnEmail = new Kushal.Controls.KushalButton();
            this.btnEmailBulk = new Kushal.Controls.KushalButton();
            this.dgrData = new System.Windows.Forms.DataGridView();
            this.dgrDataColumnPartyID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnSalutation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnPartyName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnPartyType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnPlaceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnWebsite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnEmail2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnPhone2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnHandeledBy = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dgrDataColumnCompanyName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrDataColumnStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(7, 351);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 16;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"&New";
            this.btnNew.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            

            this.btnSave.Location = new System.Drawing.Point(212, 351);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 17;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"&Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            

            this.btnDelete.Location = new System.Drawing.Point(417, 351);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 18;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"&Delete";
            this.btnDelete.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            

            this.btnClose.Location = new System.Drawing.Point(622, 351);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 19;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"&Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            

            this.btnSearch_S.Location = new System.Drawing.Point(939, 203);
            this.btnSearch_S.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSearch_S.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSearch_S.Name = "btnSearch_S";
            this.btnSearch_S.Enabled = true;
            this.btnSearch_S.Visible = false;
            this.btnSearch_S.TabIndex = 0;
            this.btnSearch_S.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSearch_S.Size = new System.Drawing.Size(30, 30);
            this.btnSearch_S.Text = @"S";
            this.btnSearch_S.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch_S.UseVisualStyleBackColor = false;
            this.btnSearch_S.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSearch_S, @"Search");
            
            

            this.btnClear.Location = new System.Drawing.Point(1033, 7);
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClear.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClear.Name = "btnClear";
            this.btnClear.Enabled = true;
            this.btnClear.Visible = true;
            this.btnClear.TabIndex = 0;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClear.Size = new System.Drawing.Size(30, 30);
            this.btnClear.Text = @"C";
            this.btnClear.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClear, @"Clear Search");
            
            

            this.txt_State.Location = new System.Drawing.Point(429, 497);
            this.txt_State.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_State.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_State.MaxDropDownItems = 10;
            this.txt_State.IntegralHeight = false;
            this.txt_State.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_State.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_State.FormattingEnabled = true;
            this.txt_State.Name = "txt_State";
            this.txt_State.AllowNull = true;
            this.txt_State.FriendlyName = "";
            this.txt_State.Enabled = true;
            this.txt_State.Visible = false;
            this.txt_State.TabIndex = 18;
            this.txt_State.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_State.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_State.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_State.Size = new System.Drawing.Size(194, 30);
            this.txt_State.Tag = "select stateid, statename, statecode, countryid from state";
            this.toolTip1.SetToolTip(this.txt_State, @"");
            
            this.txt_State.SelectedIndexChanged += new System.EventHandler(this.txt_State_Evaluate_SelectedIndexChanged);

            this.txt_Country.Location = new System.Drawing.Point(429, 466);
            this.txt_Country.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Country.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_Country.MaxDropDownItems = 10;
            this.txt_Country.IntegralHeight = false;
            this.txt_Country.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_Country.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Country.FormattingEnabled = true;
            this.txt_Country.Name = "txt_Country";
            this.txt_Country.AllowNull = true;
            this.txt_Country.FriendlyName = "";
            this.txt_Country.Enabled = true;
            this.txt_Country.Visible = false;
            this.txt_Country.TabIndex = 17;
            this.txt_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_Country.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_Country.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Country.Size = new System.Drawing.Size(194, 30);
            this.txt_Country.Tag = "select countryid, countryname from country";
            this.toolTip1.SetToolTip(this.txt_Country, @"");
            
            this.txt_Country.SelectedIndexChanged += new System.EventHandler(this.txt_Country_Evaluate_SelectedIndexChanged);

            this.lbl_Count.AutoSize = false;
            this.lbl_Count.Location = new System.Drawing.Point(961, 315);
            this.lbl_Count.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Count.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Enabled = true;
            this.lbl_Count.Visible = true;
            this.lbl_Count.TabIndex = 0;
            this.lbl_Count.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Count.Size = new System.Drawing.Size(100, 23);
            this.lbl_Count.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Text = @"Count : 0";
            this.toolTip1.SetToolTip(this.lbl_Count, @"");

            this.lblCountry.AutoSize = false;
            this.lblCountry.Location = new System.Drawing.Point(295, 470);
            this.lblCountry.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblCountry.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Enabled = true;
            this.lblCountry.Visible = false;
            this.lblCountry.TabIndex = 0;
            this.lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCountry.Size = new System.Drawing.Size(113, 23);
            this.lblCountry.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry.Text = @"* Country";
            this.toolTip1.SetToolTip(this.lblCountry, @"");

            this.lblState.AutoSize = false;
            this.lblState.Location = new System.Drawing.Point(295, 501);
            this.lblState.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblState.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblState.Name = "lblState";
            this.lblState.Enabled = true;
            this.lblState.Visible = false;
            this.lblState.TabIndex = 0;
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblState.Size = new System.Drawing.Size(113, 23);
            this.lblState.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.Text = @"* State";
            this.toolTip1.SetToolTip(this.lblState, @"");

            this.txt_PartyID.Location = new System.Drawing.Point(818, 268);
            this.txt_PartyID.BackColor = System.Drawing.Color.FromArgb(-32);
            this.txt_PartyID.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PartyID.Name = "txt_PartyID";
            this.txt_PartyID.DefaultValue = null;
            this.txt_PartyID.FriendlyName = "";
            this.txt_PartyID.Enabled = true;
            this.txt_PartyID.Visible = false;
            this.txt_PartyID.ReadOnly = false;
            this.txt_PartyID.TabIndex = 2;
            this.txt_PartyID.MaxValue = 2147483647;
            this.txt_PartyID.MinValue = -2147483648;
            this.txt_PartyID.ValidationMessage = "";
            this.txt_PartyID.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PartyID.Size = new System.Drawing.Size(100, 20);
            this.txt_PartyID.SelectAllOnFocus = true;
            this.txt_PartyID.DoValidation = false;
            this.txt_PartyID.AllowNull = false;
            this.txt_PartyID.TooltipDelay = 5000;
            this.toolTip1.SetToolTip(this.txt_PartyID, @"");

            this.txt_Search.Location = new System.Drawing.Point(748, 9);
            this.txt_Search.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_Search.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Search.Multiline = false;
            this.txt_Search.MaxLength = 256;
            this.txt_Search.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Search.Name = "txt_Search";
            this.txt_Search.Text = @"";
            
            this.txt_Search.AllowNull = true;
            this.txt_Search.DefaultValue = "";
            this.txt_Search.FriendlyName = "txtNewText1";
            this.txt_Search.ValidationType = TextValidation.None;
            this.txt_Search.ValidationExpression = @"";
            this.txt_Search.ValidationMessage = @"";
            this.txt_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Search.Enabled = true;
            this.txt_Search.ReadOnly = false;
            this.txt_Search.Visible = true;
            this.txt_Search.TabIndex = 0;
            this.txt_Search.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Search.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Search.Size = new System.Drawing.Size(286, 27);
            this.toolTip1.SetToolTip(this.txt_Search, @"");
            this.txt_Search.TextChanged += new System.EventHandler(this.txt_Search_Evaluate_TextChanged);

            this.grpCustomerdetails.Location = new System.Drawing.Point(4, 3);
            this.grpCustomerdetails.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpCustomerdetails.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpCustomerdetails.Name = "grpCustomerdetails";
            this.grpCustomerdetails.Enabled = true;
            this.grpCustomerdetails.Visible = true;
            this.grpCustomerdetails.TabIndex = 1;
            this.grpCustomerdetails.TabStop = false;
            this.grpCustomerdetails.Size = new System.Drawing.Size(739, 338);
            this.grpCustomerdetails.Text = @"";
            this.grpCustomerdetails.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCustomerdetails.SendToBack();
            this.toolTip1.SetToolTip(this.grpCustomerdetails, @"");

            this.btn_Relation_Master.Location = new System.Drawing.Point(695, 39);
            this.btn_Relation_Master.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btn_Relation_Master.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btn_Relation_Master.Name = "btn_Relation_Master";
            this.btn_Relation_Master.Enabled = true;
            this.btn_Relation_Master.Visible = true;
            this.btn_Relation_Master.TabIndex = 0;
            this.btn_Relation_Master.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btn_Relation_Master.Size = new System.Drawing.Size(30, 30);
            this.btn_Relation_Master.Text = @"...";
            this.btn_Relation_Master.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Relation_Master.UseVisualStyleBackColor = false;
            this.btn_Relation_Master.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btn_Relation_Master, @"");
            
            

            this.txt_Salutation.Location = new System.Drawing.Point(88, 10);
            this.txt_Salutation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_Salutation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_Salutation.MaxDropDownItems = 10;
            this.txt_Salutation.IntegralHeight = false;
            this.txt_Salutation.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_Salutation.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Salutation.FormattingEnabled = true;
            this.txt_Salutation.Name = "txt_Salutation";
            this.txt_Salutation.AllowNull = true;
            this.txt_Salutation.FriendlyName = "";
            this.txt_Salutation.Enabled = true;
            this.txt_Salutation.Visible = true;
            this.txt_Salutation.TabIndex = 0;
            this.txt_Salutation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_Salutation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_Salutation.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Salutation.Size = new System.Drawing.Size(82, 30);
            this.txt_Salutation.Tag = "select ListID,ListCode from ListMaster where ListTypeID = 3";
            this.toolTip1.SetToolTip(this.txt_Salutation, @"");
            

            this.cmb_partytype.Location = new System.Drawing.Point(515, 40);
            this.cmb_partytype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmb_partytype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmb_partytype.MaxDropDownItems = 10;
            this.cmb_partytype.IntegralHeight = false;
            this.cmb_partytype.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmb_partytype.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmb_partytype.FormattingEnabled = true;
            this.cmb_partytype.Name = "cmb_partytype";
            this.cmb_partytype.AllowNull = true;
            this.cmb_partytype.FriendlyName = "cmbNewDropDown1";
            this.cmb_partytype.Enabled = true;
            this.cmb_partytype.Visible = true;
            this.cmb_partytype.TabIndex = 3;
            this.cmb_partytype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_partytype.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_partytype.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_partytype.Size = new System.Drawing.Size(173, 29);
            this.cmb_partytype.Tag = "Select RelationId,Relation from Relations";
            this.toolTip1.SetToolTip(this.cmb_partytype, @"");
            

            this.lbl_CustomerName.AutoSize = false;
            this.lbl_CustomerName.Location = new System.Drawing.Point(7, 14);
            this.lbl_CustomerName.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_CustomerName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Enabled = true;
            this.lbl_CustomerName.Visible = true;
            this.lbl_CustomerName.TabIndex = 11;
            this.lbl_CustomerName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_CustomerName.Size = new System.Drawing.Size(78, 23);
            this.lbl_CustomerName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerName.Text = @"* Name";
            this.toolTip1.SetToolTip(this.lbl_CustomerName, @"");

            this.lbl_Companyname.AutoSize = false;
            this.lbl_Companyname.Location = new System.Drawing.Point(7, 43);
            this.lbl_Companyname.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Companyname.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Companyname.Name = "lbl_Companyname";
            this.lbl_Companyname.Enabled = true;
            this.lbl_Companyname.Visible = true;
            this.lbl_Companyname.TabIndex = 0;
            this.lbl_Companyname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Companyname.Size = new System.Drawing.Size(78, 23);
            this.lbl_Companyname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Companyname.Text = @"  Company ";
            this.toolTip1.SetToolTip(this.lbl_Companyname, @"");

            this.lbl_PartyType.AutoSize = false;
            this.lbl_PartyType.Location = new System.Drawing.Point(434, 41);
            this.lbl_PartyType.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyType.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyType.Name = "lbl_PartyType";
            this.lbl_PartyType.Enabled = true;
            this.lbl_PartyType.Visible = true;
            this.lbl_PartyType.TabIndex = 0;
            this.lbl_PartyType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyType.Size = new System.Drawing.Size(74, 23);
            this.lbl_PartyType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyType.Text = @"  Relation";
            this.toolTip1.SetToolTip(this.lbl_PartyType, @"");

            this.txt_CustomerName.Location = new System.Drawing.Point(174, 13);
            this.txt_CustomerName.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_CustomerName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_CustomerName.Multiline = false;
            this.txt_CustomerName.MaxLength = 100;
            this.txt_CustomerName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Text = @"";
            
            this.txt_CustomerName.AllowNull = false;
            this.txt_CustomerName.DefaultValue = "";
            this.txt_CustomerName.FriendlyName = "";
            this.txt_CustomerName.ValidationType = TextValidation.None;
            this.txt_CustomerName.ValidationExpression = @"";
            this.txt_CustomerName.ValidationMessage = @"";
            this.txt_CustomerName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_CustomerName.Enabled = true;
            this.txt_CustomerName.ReadOnly = false;
            this.txt_CustomerName.Visible = true;
            this.txt_CustomerName.TabIndex = 1;
            this.txt_CustomerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_CustomerName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerName.Size = new System.Drawing.Size(556, 27);
            this.toolTip1.SetToolTip(this.txt_CustomerName, @"");

            this.txt_CompanyName.Location = new System.Drawing.Point(88, 40);
            this.txt_CompanyName.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_CompanyName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_CompanyName.Multiline = false;
            this.txt_CompanyName.MaxLength = 256;
            this.txt_CompanyName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_CompanyName.Name = "txt_CompanyName";
            this.txt_CompanyName.Text = @"";
            
            this.txt_CompanyName.AllowNull = true;
            this.txt_CompanyName.DefaultValue = "";
            this.txt_CompanyName.FriendlyName = "txtNewText1";
            this.txt_CompanyName.ValidationType = TextValidation.None;
            this.txt_CompanyName.ValidationExpression = @"";
            this.txt_CompanyName.ValidationMessage = @"";
            this.txt_CompanyName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_CompanyName.Enabled = true;
            this.txt_CompanyName.ReadOnly = false;
            this.txt_CompanyName.Visible = true;
            this.txt_CompanyName.TabIndex = 2;
            this.txt_CompanyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_CompanyName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CompanyName.Size = new System.Drawing.Size(346, 29);
            this.toolTip1.SetToolTip(this.txt_CompanyName, @"");

            this.grpNewGroupBox1.Location = new System.Drawing.Point(3, 69);
            this.grpNewGroupBox1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox1.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpNewGroupBox1.Name = "grpNewGroupBox1";
            this.grpNewGroupBox1.Enabled = true;
            this.grpNewGroupBox1.Visible = true;
            this.grpNewGroupBox1.TabIndex = 11;
            this.grpNewGroupBox1.TabStop = false;
            this.grpNewGroupBox1.Size = new System.Drawing.Size(725, 256);
            this.grpNewGroupBox1.Text = @"Contact Details";
            this.grpNewGroupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox1.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox1, @"");

            this.btnPlaceMaster.Location = new System.Drawing.Point(344, 181);
            this.btnPlaceMaster.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnPlaceMaster.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnPlaceMaster.Name = "btnPlaceMaster";
            this.btnPlaceMaster.Enabled = true;
            this.btnPlaceMaster.Visible = true;
            this.btnPlaceMaster.TabIndex = 13;
            this.btnPlaceMaster.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnPlaceMaster.Size = new System.Drawing.Size(30, 30);
            this.btnPlaceMaster.Text = @"...";
            this.btnPlaceMaster.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlaceMaster.UseVisualStyleBackColor = false;
            this.btnPlaceMaster.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnPlaceMaster, @"Place Master");
            
            

            this.btnCopy.Location = new System.Drawing.Point(298, 344);
            this.btnCopy.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnCopy.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Enabled = true;
            this.btnCopy.Visible = true;
            this.btnCopy.TabIndex = 29;
            this.btnCopy.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnCopy.Size = new System.Drawing.Size(110, 29);
            this.btnCopy.Text = @"Copy";
            this.btnCopy.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopy.UseVisualStyleBackColor = false;
            this.btnCopy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnCopy, @"Copy Contact Details");
            
            

            this.btnHandeledBy.Location = new System.Drawing.Point(692, 149);
            this.btnHandeledBy.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnHandeledBy.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnHandeledBy.Name = "btnHandeledBy";
            this.btnHandeledBy.Enabled = true;
            this.btnHandeledBy.Visible = true;
            this.btnHandeledBy.TabIndex = 11;
            this.btnHandeledBy.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnHandeledBy.Size = new System.Drawing.Size(28, 30);
            this.btnHandeledBy.Text = @"...";
            this.btnHandeledBy.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHandeledBy.UseVisualStyleBackColor = false;
            this.btnHandeledBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnHandeledBy, @"");
            
            

            this.txt_PlaceId.Location = new System.Drawing.Point(142, 182);
            this.txt_PlaceId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_PlaceId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_PlaceId.MaxDropDownItems = 12;
            this.txt_PlaceId.IntegralHeight = false;
            this.txt_PlaceId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_PlaceId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_PlaceId.FormattingEnabled = true;
            this.txt_PlaceId.Name = "txt_PlaceId";
            this.txt_PlaceId.AllowNull = false;
            this.txt_PlaceId.FriendlyName = "";
            this.txt_PlaceId.Enabled = true;
            this.txt_PlaceId.Visible = true;
            this.txt_PlaceId.TabIndex = 19;
            this.txt_PlaceId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_PlaceId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_PlaceId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PlaceId.Size = new System.Drawing.Size(194, 30);
            this.txt_PlaceId.Tag = "select Place.PlaceID,Place.PlaceName,State.StateID,State.StateName,State.StateCode,Country.CountryID,Country.CountryName from place inner join state on Place.StateID= State.StateID inner join country on Country.CountryID = state.CountryID";
            this.toolTip1.SetToolTip(this.txt_PlaceId, @"");
            
            this.txt_PlaceId.SelectedIndexChanged += new System.EventHandler(this.txt_PlaceId_Evaluate_SelectedIndexChanged);

            this.cmb_HandeldBy.Location = new System.Drawing.Point(498, 150);
            this.cmb_HandeldBy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmb_HandeldBy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmb_HandeldBy.MaxDropDownItems = 10;
            this.cmb_HandeldBy.IntegralHeight = false;
            this.cmb_HandeldBy.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmb_HandeldBy.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmb_HandeldBy.FormattingEnabled = true;
            this.cmb_HandeldBy.Name = "cmb_HandeldBy";
            this.cmb_HandeldBy.AllowNull = true;
            this.cmb_HandeldBy.FriendlyName = "cmbNewDropDown1";
            this.cmb_HandeldBy.Enabled = true;
            this.cmb_HandeldBy.Visible = true;
            this.cmb_HandeldBy.TabIndex = 10;
            this.cmb_HandeldBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_HandeldBy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_HandeldBy.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_HandeldBy.Size = new System.Drawing.Size(189, 29);
            this.cmb_HandeldBy.Tag = "Select Id,Name from HandeledBy";
            this.toolTip1.SetToolTip(this.cmb_HandeldBy, @"");
            

            this.lbl_PlaceId.AutoSize = false;
            this.lbl_PlaceId.Location = new System.Drawing.Point(8, 186);
            this.lbl_PlaceId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PlaceId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PlaceId.Name = "lbl_PlaceId";
            this.lbl_PlaceId.Enabled = true;
            this.lbl_PlaceId.Visible = true;
            this.lbl_PlaceId.TabIndex = 19;
            this.lbl_PlaceId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PlaceId.Size = new System.Drawing.Size(113, 23);
            this.lbl_PlaceId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PlaceId.Text = @"* Place";
            this.toolTip1.SetToolTip(this.lbl_PlaceId, @"");

            this.lbl_Phone1.AutoSize = false;
            this.lbl_Phone1.Location = new System.Drawing.Point(8, 23);
            this.lbl_Phone1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Phone1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Phone1.Name = "lbl_Phone1";
            this.lbl_Phone1.Enabled = true;
            this.lbl_Phone1.Visible = true;
            this.lbl_Phone1.TabIndex = 23;
            this.lbl_Phone1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Phone1.Size = new System.Drawing.Size(113, 23);
            this.lbl_Phone1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Phone1.Text = @"  Phone";
            this.toolTip1.SetToolTip(this.lbl_Phone1, @"");

            this.lbl_Phone2.AutoSize = false;
            this.lbl_Phone2.Location = new System.Drawing.Point(8, 54);
            this.lbl_Phone2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Phone2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Phone2.Name = "lbl_Phone2";
            this.lbl_Phone2.Enabled = true;
            this.lbl_Phone2.Visible = true;
            this.lbl_Phone2.TabIndex = 25;
            this.lbl_Phone2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Phone2.Size = new System.Drawing.Size(113, 23);
            this.lbl_Phone2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Phone2.Text = @"  Alternate Phone";
            this.toolTip1.SetToolTip(this.lbl_Phone2, @"");

            this.lbl_EmailId.AutoSize = false;
            this.lbl_EmailId.Location = new System.Drawing.Point(8, 87);
            this.lbl_EmailId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_EmailId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_EmailId.Name = "lbl_EmailId";
            this.lbl_EmailId.Enabled = true;
            this.lbl_EmailId.Visible = true;
            this.lbl_EmailId.TabIndex = 27;
            this.lbl_EmailId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_EmailId.Size = new System.Drawing.Size(113, 23);
            this.lbl_EmailId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmailId.Text = @"* Email Id";
            this.toolTip1.SetToolTip(this.lbl_EmailId, @"");

            this.lbl_Website.AutoSize = false;
            this.lbl_Website.Location = new System.Drawing.Point(8, 153);
            this.lbl_Website.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_Website.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_Website.Name = "lbl_Website";
            this.lbl_Website.Enabled = true;
            this.lbl_Website.Visible = true;
            this.lbl_Website.TabIndex = 29;
            this.lbl_Website.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Website.Size = new System.Drawing.Size(113, 23);
            this.lbl_Website.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Website.Text = @"  Website";
            this.toolTip1.SetToolTip(this.lbl_Website, @"");

            this.lbl_EmailId2.AutoSize = false;
            this.lbl_EmailId2.Location = new System.Drawing.Point(8, 120);
            this.lbl_EmailId2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_EmailId2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_EmailId2.Name = "lbl_EmailId2";
            this.lbl_EmailId2.Enabled = true;
            this.lbl_EmailId2.Visible = true;
            this.lbl_EmailId2.TabIndex = 0;
            this.lbl_EmailId2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_EmailId2.Size = new System.Drawing.Size(113, 23);
            this.lbl_EmailId2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmailId2.Text = @"  Alternate Email Id";
            this.toolTip1.SetToolTip(this.lbl_EmailId2, @"");

            this.lbl_HandledBy.AutoSize = false;
            this.lbl_HandledBy.Location = new System.Drawing.Point(418, 153);
            this.lbl_HandledBy.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_HandledBy.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_HandledBy.Name = "lbl_HandledBy";
            this.lbl_HandledBy.Enabled = true;
            this.lbl_HandledBy.Visible = true;
            this.lbl_HandledBy.TabIndex = 0;
            this.lbl_HandledBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_HandledBy.Size = new System.Drawing.Size(79, 23);
            this.lbl_HandledBy.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HandledBy.Text = @"Handled By";
            this.toolTip1.SetToolTip(this.lbl_HandledBy, @"");

            this.lbl_State_Name.AutoSize = false;
            this.lbl_State_Name.Location = new System.Drawing.Point(8, 221);
            this.lbl_State_Name.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_State_Name.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_State_Name.Name = "lbl_State_Name";
            this.lbl_State_Name.Enabled = true;
            this.lbl_State_Name.Visible = true;
            this.lbl_State_Name.TabIndex = 0;
            this.lbl_State_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_State_Name.Size = new System.Drawing.Size(200, 23);
            this.lbl_State_Name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_State_Name.Text = @"  State :";
            this.toolTip1.SetToolTip(this.lbl_State_Name, @"");

            this.lbl_country.AutoSize = false;
            this.lbl_country.Location = new System.Drawing.Point(235, 221);
            this.lbl_country.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_country.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_country.Name = "lbl_country";
            this.lbl_country.Enabled = true;
            this.lbl_country.Visible = true;
            this.lbl_country.TabIndex = 0;
            this.lbl_country.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_country.Size = new System.Drawing.Size(200, 23);
            this.lbl_country.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_country.Text = @"Country :";
            this.toolTip1.SetToolTip(this.lbl_country, @"");

            this.pnlStatus.Location = new System.Drawing.Point(499, 183);
            this.pnlStatus.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.pnlStatus.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.pnlStatus.Name = "pnlStatus";
            this.pnlStatus.AllowNull = true;
            this.pnlStatus.FriendlyName = "pnlRadioButtonPanel1";
            this.pnlStatus.Enabled = true;
            this.pnlStatus.Visible = true;
            this.pnlStatus.Size = new System.Drawing.Size(218, 64);
            this.pnlStatus.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlStatus.SendToBack();

            this.rbSubsribe.AutoSize = true;
            this.rbSubsribe.Location = new System.Drawing.Point(2, 0);
            this.rbSubsribe.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.rbSubsribe.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.rbSubsribe.Name = "rbSubsribe";
            this.rbSubsribe.Enabled = true;
            this.rbSubsribe.Visible = true;
            this.rbSubsribe.TabIndex = 14;
            this.rbSubsribe.Size = new System.Drawing.Size(146, 27);
            this.rbSubsribe.Text = @"Subscribe";
            this.rbSubsribe.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSubsribe.UseVisualStyleBackColor = true;
            this.rbSubsribe.Value = 0;
            this.toolTip1.SetToolTip(this.rbSubsribe, @"");

            this.rbUnsubscribe.AutoSize = true;
            this.rbUnsubscribe.Location = new System.Drawing.Point(2, 27);
            this.rbUnsubscribe.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.rbUnsubscribe.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.rbUnsubscribe.Name = "rbUnsubscribe";
            this.rbUnsubscribe.Enabled = true;
            this.rbUnsubscribe.Visible = true;
            this.rbUnsubscribe.TabIndex = 15;
            this.rbUnsubscribe.Size = new System.Drawing.Size(146, 27);
            this.rbUnsubscribe.Text = @"Unsubscribe";
            this.rbUnsubscribe.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbUnsubscribe.UseVisualStyleBackColor = true;
            this.rbUnsubscribe.Value = 1;
            this.toolTip1.SetToolTip(this.rbUnsubscribe, @"");

            this.txt_Phone1.Location = new System.Drawing.Point(142, 21);
            this.txt_Phone1.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_Phone1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Phone1.Multiline = false;
            this.txt_Phone1.MaxLength = 100;
            this.txt_Phone1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Phone1.Name = "txt_Phone1";
            this.txt_Phone1.Text = @"";
            
            this.txt_Phone1.AllowNull = true;
            this.txt_Phone1.DefaultValue = "";
            this.txt_Phone1.FriendlyName = "";
            this.txt_Phone1.ValidationType = TextValidation.RegularExpression;
            this.txt_Phone1.ValidationExpression = @"^-{0,1}\d+$";
            this.txt_Phone1.ValidationMessage = @"Invalid Phone Number";
            this.txt_Phone1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Phone1.Enabled = true;
            this.txt_Phone1.ReadOnly = false;
            this.txt_Phone1.Visible = true;
            this.txt_Phone1.TabIndex = 5;
            this.txt_Phone1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Phone1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Phone1.Size = new System.Drawing.Size(194, 27);
            this.toolTip1.SetToolTip(this.txt_Phone1, @"");

            this.txt_Phone2.Location = new System.Drawing.Point(142, 52);
            this.txt_Phone2.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_Phone2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Phone2.Multiline = false;
            this.txt_Phone2.MaxLength = 100;
            this.txt_Phone2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Phone2.Name = "txt_Phone2";
            this.txt_Phone2.Text = @"";
            
            this.txt_Phone2.AllowNull = true;
            this.txt_Phone2.DefaultValue = "";
            this.txt_Phone2.FriendlyName = "";
            this.txt_Phone2.ValidationType = TextValidation.RegularExpression;
            this.txt_Phone2.ValidationExpression = @"^-{0,1}\d+$";
            this.txt_Phone2.ValidationMessage = @"Invalid Fax / Phone Number";
            this.txt_Phone2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Phone2.Enabled = true;
            this.txt_Phone2.ReadOnly = false;
            this.txt_Phone2.Visible = true;
            this.txt_Phone2.TabIndex = 6;
            this.txt_Phone2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Phone2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Phone2.Size = new System.Drawing.Size(194, 27);
            this.toolTip1.SetToolTip(this.txt_Phone2, @"");

            this.txt_EmailId.Location = new System.Drawing.Point(142, 86);
            this.txt_EmailId.BackColor = System.Drawing.Color.FromArgb(-8000);
            this.txt_EmailId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_EmailId.Multiline = false;
            this.txt_EmailId.MaxLength = 100;
            this.txt_EmailId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_EmailId.Name = "txt_EmailId";
            this.txt_EmailId.Text = @"";
            
            this.txt_EmailId.AllowNull = true;
            this.txt_EmailId.DefaultValue = "";
            this.txt_EmailId.FriendlyName = "";
            this.txt_EmailId.ValidationType = TextValidation.None;
            this.txt_EmailId.ValidationExpression = @"";
            this.txt_EmailId.ValidationMessage = @"";
            this.txt_EmailId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_EmailId.Enabled = true;
            this.txt_EmailId.ReadOnly = false;
            this.txt_EmailId.Visible = true;
            this.txt_EmailId.TabIndex = 7;
            this.txt_EmailId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_EmailId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmailId.Size = new System.Drawing.Size(273, 27);
            this.toolTip1.SetToolTip(this.txt_EmailId, @"");

            this.txt_Website.Location = new System.Drawing.Point(142, 151);
            this.txt_Website.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_Website.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_Website.Multiline = false;
            this.txt_Website.MaxLength = 100;
            this.txt_Website.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Website.Name = "txt_Website";
            this.txt_Website.Text = @"";
            
            this.txt_Website.AllowNull = true;
            this.txt_Website.DefaultValue = "";
            this.txt_Website.FriendlyName = "";
            this.txt_Website.ValidationType = TextValidation.None;
            this.txt_Website.ValidationExpression = @"";
            this.txt_Website.ValidationMessage = @"";
            this.txt_Website.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_Website.Enabled = true;
            this.txt_Website.ReadOnly = false;
            this.txt_Website.Visible = true;
            this.txt_Website.TabIndex = 28;
            this.txt_Website.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_Website.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Website.Size = new System.Drawing.Size(273, 27);
            this.toolTip1.SetToolTip(this.txt_Website, @"");

            this.txt_EmailId2.Location = new System.Drawing.Point(142, 116);
            this.txt_EmailId2.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txt_EmailId2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txt_EmailId2.Multiline = false;
            this.txt_EmailId2.MaxLength = 256;
            this.txt_EmailId2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_EmailId2.Name = "txt_EmailId2";
            this.txt_EmailId2.Text = @"";
            
            this.txt_EmailId2.AllowNull = true;
            this.txt_EmailId2.DefaultValue = "";
            this.txt_EmailId2.FriendlyName = "txtNewText1";
            this.txt_EmailId2.ValidationType = TextValidation.None;
            this.txt_EmailId2.ValidationExpression = @"";
            this.txt_EmailId2.ValidationMessage = @"";
            this.txt_EmailId2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txt_EmailId2.Enabled = true;
            this.txt_EmailId2.ReadOnly = false;
            this.txt_EmailId2.Visible = true;
            this.txt_EmailId2.TabIndex = 8;
            this.txt_EmailId2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_EmailId2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmailId2.Size = new System.Drawing.Size(273, 29);
            this.toolTip1.SetToolTip(this.txt_EmailId2, @"");

            this.grpNewGroupBox4.Location = new System.Drawing.Point(788, 116);
            this.grpNewGroupBox4.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox4.ForeColor = System.Drawing.Color.FromArgb(-16776961);
            this.grpNewGroupBox4.Name = "grpNewGroupBox4";
            this.grpNewGroupBox4.Enabled = true;
            this.grpNewGroupBox4.Visible = false;
            this.grpNewGroupBox4.TabIndex = 0;
            this.grpNewGroupBox4.TabStop = false;
            this.grpNewGroupBox4.Size = new System.Drawing.Size(165, 113);
            this.grpNewGroupBox4.Text = @"";
            this.grpNewGroupBox4.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox4.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox4, @"");

            this.btnSearch.Location = new System.Drawing.Point(123, 8);
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSearch.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Enabled = true;
            this.btnSearch.Visible = false;
            this.btnSearch.TabIndex = 65;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSearch.Size = new System.Drawing.Size(80, 30);
            this.btnSearch.Text = @"Search";
            this.btnSearch.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSearch, @"");
            
            

            this.btnExport.Location = new System.Drawing.Point(630, 13);
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnExport.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnExport.Name = "btnExport";
            this.btnExport.Enabled = true;
            this.btnExport.Visible = true;
            this.btnExport.TabIndex = 0;
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnExport.Size = new System.Drawing.Size(133, 30);
            this.btnExport.Text = @"&Export - Many";
            this.btnExport.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnExport, @"");
            
            

            this.btnExportIndividual.Location = new System.Drawing.Point(7, 45);
            this.btnExportIndividual.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnExportIndividual.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnExportIndividual.Name = "btnExportIndividual";
            this.btnExportIndividual.Enabled = true;
            this.btnExportIndividual.Visible = false;
            this.btnExportIndividual.TabIndex = 0;
            this.btnExportIndividual.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnExportIndividual.Size = new System.Drawing.Size(133, 30);
            this.btnExportIndividual.Text = @"Export - Individual";
            this.btnExportIndividual.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportIndividual.UseVisualStyleBackColor = false;
            this.btnExportIndividual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnExportIndividual, @"");
            
            

            this.btnImportIndividual.Location = new System.Drawing.Point(6, 4);
            this.btnImportIndividual.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnImportIndividual.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnImportIndividual.Name = "btnImportIndividual";
            this.btnImportIndividual.Enabled = true;
            this.btnImportIndividual.Visible = false;
            this.btnImportIndividual.TabIndex = 0;
            this.btnImportIndividual.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnImportIndividual.Size = new System.Drawing.Size(133, 30);
            this.btnImportIndividual.Text = @"Import - Individual";
            this.btnImportIndividual.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportIndividual.UseVisualStyleBackColor = false;
            this.btnImportIndividual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnImportIndividual, @"");
            
            

            this.btnImportMany.Location = new System.Drawing.Point(6, 27);
            this.btnImportMany.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnImportMany.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnImportMany.Name = "btnImportMany";
            this.btnImportMany.Enabled = true;
            this.btnImportMany.Visible = false;
            this.btnImportMany.TabIndex = 0;
            this.btnImportMany.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnImportMany.Size = new System.Drawing.Size(133, 30);
            this.btnImportMany.Text = @"Import - Many";
            this.btnImportMany.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportMany.UseVisualStyleBackColor = false;
            this.btnImportMany.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnImportMany, @"");
            
            

            this.btnStatistics.Location = new System.Drawing.Point(123, 35);
            this.btnStatistics.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnStatistics.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnStatistics.Name = "btnStatistics";
            this.btnStatistics.Enabled = true;
            this.btnStatistics.Visible = false;
            this.btnStatistics.TabIndex = 0;
            this.btnStatistics.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnStatistics.Size = new System.Drawing.Size(80, 30);
            this.btnStatistics.Text = @"Statistics";
            this.btnStatistics.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatistics.UseVisualStyleBackColor = false;
            this.btnStatistics.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnStatistics, @"");
            
            

            this.lbl_PartyId.AutoSize = false;
            this.lbl_PartyId.Location = new System.Drawing.Point(48, 85);
            this.lbl_PartyId.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lbl_PartyId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lbl_PartyId.Name = "lbl_PartyId";
            this.lbl_PartyId.Enabled = true;
            this.lbl_PartyId.Visible = false;
            this.lbl_PartyId.TabIndex = 3;
            this.lbl_PartyId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_PartyId.Size = new System.Drawing.Size(100, 23);
            this.lbl_PartyId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PartyId.Text = @"Party ID";
            this.toolTip1.SetToolTip(this.lbl_PartyId, @"");

            this.grpNewGroupBox2.Location = new System.Drawing.Point(748, 341);
            this.grpNewGroupBox2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpNewGroupBox2.Name = "grpNewGroupBox2";
            this.grpNewGroupBox2.Enabled = true;
            this.grpNewGroupBox2.Visible = true;
            this.grpNewGroupBox2.TabIndex = 0;
            this.grpNewGroupBox2.TabStop = false;
            this.grpNewGroupBox2.Size = new System.Drawing.Size(314, 43);
            this.grpNewGroupBox2.Text = @"";
            this.grpNewGroupBox2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox2.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox2, @"");

            this.btnEmail.Location = new System.Drawing.Point(6, 7);
            this.btnEmail.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnEmail.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Enabled = true;
            this.btnEmail.Visible = true;
            this.btnEmail.TabIndex = 20;
            this.btnEmail.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnEmail.Size = new System.Drawing.Size(137, 30);
            this.btnEmail.Text = @"E Mail - Individual";
            this.btnEmail.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmail.UseVisualStyleBackColor = false;
            this.btnEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnEmail, @"");
            
            

            this.btnEmailBulk.Location = new System.Drawing.Point(158, 7);
            this.btnEmailBulk.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnEmailBulk.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnEmailBulk.Name = "btnEmailBulk";
            this.btnEmailBulk.Enabled = true;
            this.btnEmailBulk.Visible = true;
            this.btnEmailBulk.TabIndex = 21;
            this.btnEmailBulk.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnEmailBulk.Size = new System.Drawing.Size(137, 30);
            this.btnEmailBulk.Text = @"E Mail - Many";
            this.btnEmailBulk.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmailBulk.UseVisualStyleBackColor = false;
            this.btnEmailBulk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnEmailBulk, @"");
            
            

            this.dgrData.AllowUserToAddRows = false;
            this.dgrData.AllowUserToDeleteRows = false;
            this.dgrData.ColumnHeadersHeight = 25;
            this.dgrData.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrData.Location = new System.Drawing.Point(748, 36);
            this.dgrData.Name = "dgrData";
            this.dgrData.Enabled = true;
            this.dgrData.Visible = true;
            this.dgrData.MultiSelect = false;
            this.dgrData.ReadOnly = true;
            this.dgrData.ShowRowErrors = false;
            this.dgrData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrData.Size = new System.Drawing.Size(314, 277);
            this.dgrData.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrData.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrData.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrData.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrData.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrData.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrData.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrData.TabIndex = 0;
            this.dgrData.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrData, @"");
            this.dgrData.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgrData_DataError);
            this.dgrData.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgrData_RowStateChanged);
            

            this.dgrDataColumnPartyID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnPartyID.HeaderText = "Partyid";
            this.dgrDataColumnPartyID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPartyID.Name = "dgrDataColumnPartyID";
            this.dgrDataColumnPartyID.DataPropertyName = "PartyID";
            this.dgrDataColumnPartyID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnPartyID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPartyID.Width = 100;
            this.dgrDataColumnPartyID.Visible = false;
            this.dgrDataColumnPartyID.DisplayIndex = 0;
            this.dgrDataColumnPartyID.ReadOnly = false;
            this.dgrDataColumnPartyID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPartyID);

            this.dgrDataColumnSalutation.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnSalutation.HeaderText = "Salutation";
            this.dgrDataColumnSalutation.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnSalutation.Name = "dgrDataColumnSalutation";
            this.dgrDataColumnSalutation.DataPropertyName = "Salutation";
            this.dgrDataColumnSalutation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnSalutation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnSalutation.Width = 50;
            this.dgrDataColumnSalutation.Visible = false;
            this.dgrDataColumnSalutation.DisplayIndex = 1;
            this.dgrDataColumnSalutation.ReadOnly = false;
            this.dgrDataColumnSalutation.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnSalutation);

            this.dgrDataColumnPartyName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnPartyName.HeaderText = "Subscriber Name";
            this.dgrDataColumnPartyName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPartyName.Name = "dgrDataColumnPartyName";
            this.dgrDataColumnPartyName.DataPropertyName = "PartyName";
            this.dgrDataColumnPartyName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dgrDataColumnPartyName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPartyName.Width = 180;
            this.dgrDataColumnPartyName.Visible = true;
            this.dgrDataColumnPartyName.DisplayIndex = 2;
            this.dgrDataColumnPartyName.ReadOnly = false;
            this.dgrDataColumnPartyName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPartyName);

            this.dgrDataColumnPartyType.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnPartyType.HeaderText = "Partytype";
            this.dgrDataColumnPartyType.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPartyType.Name = "dgrDataColumnPartyType";
            this.dgrDataColumnPartyType.DataPropertyName = "PartyType";
            this.dgrDataColumnPartyType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnPartyType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPartyType.Width = 100;
            this.dgrDataColumnPartyType.Visible = false;
            this.dgrDataColumnPartyType.DisplayIndex = 3;
            this.dgrDataColumnPartyType.ReadOnly = false;
            this.dgrDataColumnPartyType.Tag = "Select RelationId,Relation from Relations";
            this.dgrDataColumnPartyType.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPartyType);

            this.dgrDataColumnPlaceID.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dgrDataColumnPlaceID.HeaderText = "Placeid";
            this.dgrDataColumnPlaceID.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPlaceID.Name = "dgrDataColumnPlaceID";
            this.dgrDataColumnPlaceID.DataPropertyName = "PlaceID";
            this.dgrDataColumnPlaceID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnPlaceID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPlaceID.Width = 100;
            this.dgrDataColumnPlaceID.Visible = false;
            this.dgrDataColumnPlaceID.DisplayIndex = 4;
            this.dgrDataColumnPlaceID.ReadOnly = false;
            this.dgrDataColumnPlaceID.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPlaceID);

            this.dgrDataColumnEmail.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnEmail.HeaderText = "Email";
            this.dgrDataColumnEmail.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnEmail.Name = "dgrDataColumnEmail";
            this.dgrDataColumnEmail.DataPropertyName = "Email";
            this.dgrDataColumnEmail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnEmail.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnEmail.Width = 100;
            this.dgrDataColumnEmail.Visible = false;
            this.dgrDataColumnEmail.DisplayIndex = 5;
            this.dgrDataColumnEmail.ReadOnly = false;
            this.dgrDataColumnEmail.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnEmail);

            this.dgrDataColumnWebsite.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnWebsite.HeaderText = "Website";
            this.dgrDataColumnWebsite.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnWebsite.Name = "dgrDataColumnWebsite";
            this.dgrDataColumnWebsite.DataPropertyName = "Website";
            this.dgrDataColumnWebsite.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnWebsite.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnWebsite.Width = 100;
            this.dgrDataColumnWebsite.Visible = false;
            this.dgrDataColumnWebsite.DisplayIndex = 6;
            this.dgrDataColumnWebsite.ReadOnly = false;
            this.dgrDataColumnWebsite.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnWebsite);

            this.dgrDataColumnPhone.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnPhone.HeaderText = "Phone";
            this.dgrDataColumnPhone.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPhone.Name = "dgrDataColumnPhone";
            this.dgrDataColumnPhone.DataPropertyName = "Phone";
            this.dgrDataColumnPhone.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnPhone.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPhone.Width = 100;
            this.dgrDataColumnPhone.Visible = false;
            this.dgrDataColumnPhone.DisplayIndex = 7;
            this.dgrDataColumnPhone.ReadOnly = false;
            this.dgrDataColumnPhone.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPhone);

            this.dgrDataColumnEmail2.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnEmail2.HeaderText = "Email2";
            this.dgrDataColumnEmail2.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnEmail2.Name = "dgrDataColumnEmail2";
            this.dgrDataColumnEmail2.DataPropertyName = "Email2";
            this.dgrDataColumnEmail2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnEmail2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnEmail2.Width = 100;
            this.dgrDataColumnEmail2.Visible = false;
            this.dgrDataColumnEmail2.DisplayIndex = 8;
            this.dgrDataColumnEmail2.ReadOnly = false;
            this.dgrDataColumnEmail2.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnEmail2);

            this.dgrDataColumnPhone2.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnPhone2.HeaderText = "Phone2";
            this.dgrDataColumnPhone2.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnPhone2.Name = "dgrDataColumnPhone2";
            this.dgrDataColumnPhone2.DataPropertyName = "Phone2";
            this.dgrDataColumnPhone2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnPhone2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnPhone2.Width = 100;
            this.dgrDataColumnPhone2.Visible = false;
            this.dgrDataColumnPhone2.DisplayIndex = 9;
            this.dgrDataColumnPhone2.ReadOnly = false;
            this.dgrDataColumnPhone2.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnPhone2);

            this.dgrDataColumnRemarks.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnRemarks.HeaderText = "Remarks";
            this.dgrDataColumnRemarks.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnRemarks.Name = "dgrDataColumnRemarks";
            this.dgrDataColumnRemarks.DataPropertyName = "Remarks";
            this.dgrDataColumnRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnRemarks.Width = 100;
            this.dgrDataColumnRemarks.Visible = false;
            this.dgrDataColumnRemarks.DisplayIndex = 10;
            this.dgrDataColumnRemarks.ReadOnly = false;
            this.dgrDataColumnRemarks.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnRemarks);

            this.dgrDataColumnHandeledBy.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnHandeledBy.HeaderText = "Handled By";
            this.dgrDataColumnHandeledBy.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnHandeledBy.Name = "dgrDataColumnHandeledBy";
            this.dgrDataColumnHandeledBy.DataPropertyName = "HandeledBy";
            this.dgrDataColumnHandeledBy.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnHandeledBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnHandeledBy.Width = 100;
            this.dgrDataColumnHandeledBy.Visible = true;
            this.dgrDataColumnHandeledBy.DisplayIndex = 11;
            this.dgrDataColumnHandeledBy.ReadOnly = false;
            this.dgrDataColumnHandeledBy.Tag = "Select Id,Name from HandeledBy";
            this.dgrDataColumnHandeledBy.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnHandeledBy);

            this.dgrDataColumnCompanyName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnCompanyName.HeaderText = "Companyname";
            this.dgrDataColumnCompanyName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnCompanyName.Name = "dgrDataColumnCompanyName";
            this.dgrDataColumnCompanyName.DataPropertyName = "CompanyName";
            this.dgrDataColumnCompanyName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnCompanyName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnCompanyName.Width = 100;
            this.dgrDataColumnCompanyName.Visible = false;
            this.dgrDataColumnCompanyName.DisplayIndex = 12;
            this.dgrDataColumnCompanyName.ReadOnly = false;
            this.dgrDataColumnCompanyName.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnCompanyName);

            this.dgrDataColumnStatus.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrDataColumnStatus.HeaderText = "Status";
            this.dgrDataColumnStatus.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgrDataColumnStatus.Name = "dgrDataColumnStatus";
            this.dgrDataColumnStatus.DataPropertyName = "Status";
            this.dgrDataColumnStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.dgrDataColumnStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgrDataColumnStatus.Width = 100;
            this.dgrDataColumnStatus.Visible = false;
            this.dgrDataColumnStatus.DisplayIndex = 13;
            this.dgrDataColumnStatus.ReadOnly = false;
            this.dgrDataColumnStatus.Tag = "";
            
            
            
            this.dgrData.Columns.Add(this.dgrDataColumnStatus);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSearch_S);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txt_State);
            this.Controls.Add(this.txt_Country);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.txt_PartyID);
            this.Controls.Add(this.txt_Search);
            this.Controls.Add(this.grpCustomerdetails);
            this.grpCustomerdetails.Controls.Add(this.btn_Relation_Master);
            this.grpCustomerdetails.Controls.Add(this.txt_Salutation);
            this.grpCustomerdetails.Controls.Add(this.cmb_partytype);
            this.grpCustomerdetails.Controls.Add(this.lbl_CustomerName);
            this.grpCustomerdetails.Controls.Add(this.lbl_Companyname);
            this.grpCustomerdetails.Controls.Add(this.lbl_PartyType);
            this.grpCustomerdetails.Controls.Add(this.txt_CustomerName);
            this.grpCustomerdetails.Controls.Add(this.txt_CompanyName);
            this.grpCustomerdetails.Controls.Add(this.grpNewGroupBox1);
            this.grpNewGroupBox1.Controls.Add(this.btnPlaceMaster);
            this.grpNewGroupBox1.Controls.Add(this.btnCopy);
            this.grpNewGroupBox1.Controls.Add(this.btnHandeledBy);
            this.grpNewGroupBox1.Controls.Add(this.txt_PlaceId);
            this.grpNewGroupBox1.Controls.Add(this.cmb_HandeldBy);
            this.grpNewGroupBox1.Controls.Add(this.lbl_PlaceId);
            this.grpNewGroupBox1.Controls.Add(this.lbl_Phone1);
            this.grpNewGroupBox1.Controls.Add(this.lbl_Phone2);
            this.grpNewGroupBox1.Controls.Add(this.lbl_EmailId);
            this.grpNewGroupBox1.Controls.Add(this.lbl_Website);
            this.grpNewGroupBox1.Controls.Add(this.lbl_EmailId2);
            this.grpNewGroupBox1.Controls.Add(this.lbl_HandledBy);
            this.grpNewGroupBox1.Controls.Add(this.lbl_State_Name);
            this.grpNewGroupBox1.Controls.Add(this.lbl_country);
            this.grpNewGroupBox1.Controls.Add(this.pnlStatus);
            this.pnlStatus.Controls.Add(this.rbSubsribe);
            this.pnlStatus.Controls.Add(this.rbUnsubscribe);
            this.grpNewGroupBox1.Controls.Add(this.txt_Phone1);
            this.grpNewGroupBox1.Controls.Add(this.txt_Phone2);
            this.grpNewGroupBox1.Controls.Add(this.txt_EmailId);
            this.grpNewGroupBox1.Controls.Add(this.txt_Website);
            this.grpNewGroupBox1.Controls.Add(this.txt_EmailId2);
            this.Controls.Add(this.grpNewGroupBox4);
            this.grpNewGroupBox4.Controls.Add(this.btnSearch);
            this.grpNewGroupBox4.Controls.Add(this.btnExport);
            this.grpNewGroupBox4.Controls.Add(this.btnExportIndividual);
            this.grpNewGroupBox4.Controls.Add(this.btnImportIndividual);
            this.grpNewGroupBox4.Controls.Add(this.btnImportMany);
            this.grpNewGroupBox4.Controls.Add(this.btnStatistics);
            this.grpNewGroupBox4.Controls.Add(this.lbl_PartyId);
            this.Controls.Add(this.grpNewGroupBox2);
            this.grpNewGroupBox2.Controls.Add(this.btnEmail);
            this.grpNewGroupBox2.Controls.Add(this.btnEmailBulk);
            this.Controls.Add(this.dgrData);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "Subscribers";
            this.Text = "Subscribers";
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(1088, 426);
            
            
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalButton btnSearch_S;
        private Kushal.Controls.KushalButton btnClear;
        private Kushal.Controls.KushalComboBox txt_State;
        private Kushal.Controls.KushalComboBox txt_Country;
        private Kushal.Controls.KushalLabel lbl_Count;
        private Kushal.Controls.KushalLabel lblCountry;
        private Kushal.Controls.KushalLabel lblState;
        private NumericTextBox txt_PartyID;
        private Kushal.Controls.KushalTextBox txt_Search;
        private Kushal.Controls.KushalGroupBox grpCustomerdetails;
        private Kushal.Controls.KushalButton btn_Relation_Master;
        private Kushal.Controls.KushalComboBox txt_Salutation;
        private Kushal.Controls.KushalComboBox cmb_partytype;
        private Kushal.Controls.KushalLabel lbl_CustomerName;
        private Kushal.Controls.KushalLabel lbl_Companyname;
        private Kushal.Controls.KushalLabel lbl_PartyType;
        private Kushal.Controls.KushalTextBox txt_CustomerName;
        private Kushal.Controls.KushalTextBox txt_CompanyName;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox1;
        private Kushal.Controls.KushalButton btnPlaceMaster;
        private Kushal.Controls.KushalButton btnCopy;
        private Kushal.Controls.KushalButton btnHandeledBy;
        private Kushal.Controls.KushalComboBox txt_PlaceId;
        private Kushal.Controls.KushalComboBox cmb_HandeldBy;
        private Kushal.Controls.KushalLabel lbl_PlaceId;
        private Kushal.Controls.KushalLabel lbl_Phone1;
        private Kushal.Controls.KushalLabel lbl_Phone2;
        private Kushal.Controls.KushalLabel lbl_EmailId;
        private Kushal.Controls.KushalLabel lbl_Website;
        private Kushal.Controls.KushalLabel lbl_EmailId2;
        private Kushal.Controls.KushalLabel lbl_HandledBy;
        private Kushal.Controls.KushalLabel lbl_State_Name;
        private Kushal.Controls.KushalLabel lbl_country;
        private Kushal.Controls.RadioButtonPanel pnlStatus;
        private Kushal.Controls.KushalRadioButton rbSubsribe;
        private Kushal.Controls.KushalRadioButton rbUnsubscribe;
        private Kushal.Controls.KushalTextBox txt_Phone1;
        private Kushal.Controls.KushalTextBox txt_Phone2;
        private Kushal.Controls.KushalTextBox txt_EmailId;
        private Kushal.Controls.KushalTextBox txt_Website;
        private Kushal.Controls.KushalTextBox txt_EmailId2;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox4;
        private Kushal.Controls.KushalButton btnSearch;
        private Kushal.Controls.KushalButton btnExport;
        private Kushal.Controls.KushalButton btnExportIndividual;
        private Kushal.Controls.KushalButton btnImportIndividual;
        private Kushal.Controls.KushalButton btnImportMany;
        private Kushal.Controls.KushalButton btnStatistics;
        private Kushal.Controls.KushalLabel lbl_PartyId;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox2;
        private Kushal.Controls.KushalButton btnEmail;
        private Kushal.Controls.KushalButton btnEmailBulk;
        private System.Windows.Forms.DataGridView dgrData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPartyID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnSalutation;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPartyName;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnPartyType;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPlaceID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnWebsite;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPhone;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnEmail2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnPhone2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnRemarks;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgrDataColumnHandeledBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnCompanyName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgrDataColumnStatus;
    }
}