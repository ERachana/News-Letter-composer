using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kushal.Controls;
using System.Data;
using System.Collections.Specialized;
using System.Data.SqlServerCe;


namespace Newsletter_Composer
{
    partial class EmailTemplate
    {
        public void AppendContentHeader()
        {
            try
            {
                if (!string.IsNullOrEmpty(cmbContentHeader.Text))
                {
                    txt_ContentHeader.Text = txt_ContentHeader.Text + "{" + cmbContentHeader.Text + "}";
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void AppendContentBody()
        {
            try
            {
                if (!string.IsNullOrEmpty(cmbContentBody.Text))
                {
                    txt_ContentBody.Text = txt_ContentBody.Text + "{" + cmbContentBody.Text + "}";
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void AppendContentFooter()
        {
            try
            {
                if (!string.IsNullOrEmpty(cmbContentFooter.Text))
                {
                    txt_ContentFooter.Text = txt_ContentFooter.Text + "{" + cmbContentFooter.Text + "}";
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public bool PreSaveValidation()
        {
            try
            {
                if (string.IsNullOrEmpty(txt_TemplateName.Text.Trim()))
                {
                    MessageBox.Show("Enter Template Name", "Template Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_TemplateName.Focus();
                    return false;
                }
                if (string.IsNullOrEmpty(txt_Subject.Text.Trim()))
                {
                    MessageBox.Show("Enter Subject", "Subject", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txt_TemplateName.Focus();
                    return false;
                }
                if (string.IsNullOrEmpty(txt_ContentHeader.Text.Trim())
                    && string.IsNullOrEmpty(txt_ContentBody.Text.Trim())
                    && string.IsNullOrEmpty(txt_ContentFooter.Text.Trim()))
                {
                    MessageBox.Show("Enter Template Details", "Template Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                return true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public void Add_File()
        {
            try
            {
                if (formActivated == true)
                {
                    OpenFileDialog dlg = new OpenFileDialog();
                    string strFileName;

                    dlg.Filter = "All files (*.*)|*.*";
                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        this.gFilePath = dlg.FileName;
                        txt_AttachmentPath.Text = dlg.FileName;
                    }
                    else
                        return;
                }
                else
                    return;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public bool PreUpdateValidation()
        {
            try
            {








                /*	if(TypeConverter.ConvertToInt(txt_TemplateID.Text)>0 && (TypeConverter.ConvertToInt(txt_TemplateID.Text)<=2))                				{                					MessageBox.Show("Not able to change default Templates", "Attachment", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					return false;                				}	*/
                if (string.IsNullOrEmpty(txt_AttachmentPath.Text.Trim()))
                {
                    MessageBox.Show("Attachment is missing", "Attachment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                //Copy File

                //string new_file = txt_ID.Text + "_" + System.IO.Path.GetExtension(TypeConverter.ConvertToString(this.gFilePath));

                return true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public bool PreRemove()
        {
            try
            {








                /*	if(TypeConverter.ConvertToInt(txt_TemplateID.Text) > 0 && (TypeConverter.ConvertToInt(txt_TemplateID.Text) <= 2))                				{                					MessageBox.Show("Not able to remove default Templates", "Attachment", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					return false;                				}*/
                return true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return true;
            }
        }
        public bool PreDelete()
        {
            try
            {








                /*	if(TypeConverter.ConvertToInt(txt_TemplateID.Text) > 0 && (TypeConverter.ConvertToInt(txt_TemplateID.Text) <= 2))                				{                					MessageBox.Show("Not able to delete default Templates", "Attachment", MessageBoxButtons.OK, MessageBoxIcon.Warning);                					return false;                				}*/
                return true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public void Load_Fun()
        {
            try
            {
                cmbContentBody.SelectedIndex = -1;
                cmbContentHeader.SelectedIndex = -1;
                cmbContentFooter.SelectedIndex = -1;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public bool Month_Validate()
        {
            try
            {

                if (cmbSelectMonth.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Month", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbSelectMonth.Focus();
                    return false;
                }
                return true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public void Generate_Report()
        {
            try
            {
                string mailbody = null;
                DataTable dt = SqlInterpreter.GetData("SELECT Year FROM MonthMaster WHERE Id =" + Convert.ToInt16(cmbSelectMonth.SelectedValue));
                string fileName = cmbSelectMonth.Text;
                string File_Header = @"<!DOCTYPE html><html><head><link rel=""stylesheet"" type=""text /css"" href=""https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/themes/black-tie/jquery-ui.css""><link rel=""stylesheet"" type=""text /css"" href=""http://static.erachana.net/jslib/bootstrap/css/bootstrap.css""> <script type =""text/javascript""src =""https://code.jquery.com/jquery-1.12.4.js"" ><script type =""text/javascript""src =""http://static.erachana.net/jslib/bootstrap/js/bootstrap.js"" ></script></head><body><div><img src=""http://erachana.net/images/email-header.png"" alt=""&nbsp;"" class=""img-responsive"" style=""height: auto;"" width=""100%""></div><h1><center><font face=""Calibri"" > All in a Month " + fileName + " Report</font></center></h1 >";
                //string File_Header = @"<!DOCTYPE html><html><head><link rel=""stylesheet"" type=""text /css"" href=""https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/themes/black-tie/jquery-ui.css""><link rel=""stylesheet"" type=""text /css"" href=""http://static.erachana.net/jslib/bootstrap/css/bootstrap.css""> <script type =""text/javascript""src =""https://code.jquery.com/jquery-1.12.4.js"" ><script type =""text/javascript""src =""http://static.erachana.net/jslib/bootstrap/js/bootstrap.js"" ></script></head><div><img src=""http://erachana.net/images/email-header.png"" alt=""&nbsp;"" class=""img-responsive"" style=""height: auto;"" width=""100%""></div><body><h1><center><font face=""Calibri"" > All in a Month " + fileName + " Report</font></center></h1 >";
                string Cont_digital = null;
                string Head_Digital = null;
                string project_head = null;
                string product_head = null;

                //DataTable f = SqlInterpreter.GetData("select monthmaster.id, listmaster.listcode from listmaster inner join monthmaster on listmaster.listid = monthmaster.month where listmaster.listtypeid = 1 group by monthmaster.id, listmaster.listcode, listmaster.listtypeid");
                int mDate = 01;
                int mMonth = TypeConverter.ConvertToInt(((DataTable)cmbSelectMonth.DataSource).Rows[cmbSelectMonth.SelectedIndex]["Month"]);
                int mYear = TypeConverter.ConvertToInt(((DataTable)cmbSelectMonth.DataSource).Rows[cmbSelectMonth.SelectedIndex]["Year"]);

                DateTime monthStart = new DateTime(mYear, mMonth, mDate);
                DateTime monthLast = monthStart.AddMonths(1).AddDays(-1);
                DataTable dtPro_check = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM            AppDetails INNER JOIN   ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE        (AppDetails.TypeId = 2) and DOR >= '" + monthStart.ToString("yyyy/MM/dd") + "' and DOR <= '" + monthLast.ToString("yyyy/MM/dd") + "'");
                DataTable dtPro_check2 = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM AppDetails INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE (AppDetails.TypeId = 1) and DOR >= '" + monthStart.ToString("yyyy/MM/dd") + "' and DOR <= '" + monthLast.ToString("yyyy/MM/dd") + "'");
                DataTable dtPro_check3 = SqlInterpreter.GetData("SELECT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM  AppDetails INNER JOIN  ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id INNER JOIN  PartyDetails ON AppDetails.AppId = PartyDetails.ProdId WHERE        (PartyDetails.JoinDate >= '" + monthStart.ToString("yyyy/MM/dd") + "') AND (PartyDetails.JoinDate <= '" + monthLast.ToString("yyyy/MM/dd") + "') AND (AppDetails.TypeId = 1)");
                DataTable dt_check4 = SqlInterpreter.GetData("SELECT SocialMedia.MasterName, SocialMediaMaster.ActivityName, SUM(SocialMedia.Counts) AS totalCount FROM SocialMedia INNER JOIN SocialMediaMaster ON SocialMedia.MasterName = SocialMediaMaster.Id WHERE        (SocialMedia.Month =" + cmbSelectMonth.SelectedValue + " ) GROUP BY  SocialMedia.MasterName,SocialMediaMaster.ActivityName");
                if (dtPro_check.Rows.Count == 0 && dtPro_check2.Rows.Count == 0 && dtPro_check3.Rows.Count == 0 && dt_check4.Rows.Count == 0)
                {

                    MessageBox.Show("Sorry There is No data for selected Month", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {

                    System.IO.DirectoryInfo di = System.IO.Directory.CreateDirectory("C:\\ERachana\\Newsletter Composer\\Month Reports");
                    //DataTable dtProject = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM AppDetails INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId INNER JOIN                          ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE        (AppDetails.TypeId = 2) GROUP BY AppDetails.CategoryId, ProductTypeMaster.CategoryName");
                    using (System.IO.FileStream fs = new System.IO.FileStream(System.IO.Path.Combine(di.FullName, (fileName + ".htm")), System.IO.FileMode.Create))
                    {
                        using (System.IO.StreamWriter w = new System.IO.StreamWriter(fs, Encoding.UTF8))
                        {
                            w.WriteLine(File_Header);
                            mailbody += File_Header;
                            DataTable dtProject = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM            AppDetails INNER JOIN   ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE        (AppDetails.TypeId = 2) and DOR >= '" + monthStart.ToString("yyyy/MM/dd") + "' and DOR <= '" + monthLast.ToString("yyyy/MM/dd") + "'");

                            for (int a = 0; a < dtProject.Rows.Count; a++)
                            {
                                project_head = "<h3> " + dtProject.Rows[a][1] + " Projects</h3>";
                                //				DataTable dtPro_Detail = SqlInterpreter.GetData("SELECT AppDetails.AppDescription, AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath, PartyDetails.CustomerCompany, PartyDetails.LogoPath AS CustomerLogoPath FROM AppDetails INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE AppDetails.TypeId = 2 AND (AppDetails.CategoryId = " + dtProject.Rows[a][0] + ")");
                                DataTable dtPro_Detail = SqlInterpreter.GetData("SELECT AppDetails.AppDescription, AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath, AppDetails.CustomerCompany, AppDetails.CustomerLogo FROM            AppDetails INNER JOIN                          ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id  WHERE        (AppDetails.TypeId = 2) AND (AppDetails.CategoryId =" + dtProject.Rows[a][0] + ") and DOR >= '" + monthStart.ToString("yyyy/MM/dd") + "' and DOR <= '" + monthLast.ToString("yyyy/MM/dd") + "'");
                                for (int b = 0; b < dtPro_Detail.Rows.Count; b++)
                                {
                                    project_head += @"<table style=""border:none;""><tr><td><img src=""" + dtPro_Detail.Rows[b]["LogoPath"].ToString().Replace(" ", "%20") + @"""alt=""&nbsp;"" class=""img-responsive"" style=""height: auto; width: 100px; ""> </td><td> <h4 style=""margin-left:40px;""><a href=""" + dtPro_Detail.Rows[b]["AppLink"].ToString() + @""">" + dtPro_Detail.Rows[b]["AppName"].ToString() + @"</a></h4><p style=""padding-left:30px;display:inline;"">" + dtPro_Detail.Rows[b]["AppDescription"].ToString() + @"</p></td><td><h4 style=""margin-left:40px;text-align:center;"">For</h4> </td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td><img src=""" + dtPro_Detail.Rows[b]["CustomerLogo"].ToString() + @"""alt=""&nbsp;"" class=""img-responsive"" style=""height: auto; width: 100px; ""> </td><td> <h4 style=""display:inline;"">" + dtPro_Detail.Rows[b]["CustomerCompany"].ToString() + "</h4></td></tr></table>";
                                }
                                w.WriteLine(project_head + "<hr>");
                                mailbody += project_head + "<hr>";
                            }
                            DataTable dtProduct = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM AppDetails INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId  INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE (AppDetails.TypeId = 1) and DOR >= '" + monthStart.ToString("yyyy/MM/dd") + "' and DOR <= '" + monthLast.ToString("yyyy/MM/dd") + "'");

                            for (int a = 0; a < dtProduct.Rows.Count; a++)
                            {
                                product_head = "<h3>Products Launched </h3>";
                                mailbody += product_head;
                                product_head = "<h3>" + dtProduct.Rows[a][1] + "</h3>";
                                DataTable dtPro_Detail = SqlInterpreter.GetData("SELECT AppDetails.AppDescription, AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath FROM AppDetails INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id WHERE (AppDetails.TypeId = 1) AND (AppDetails.CategoryId = " + dtProduct.Rows[a][0] + ") GROUP BY AppDetails.AppDescription, AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath ");
                                for (int b = 0; b < dtPro_Detail.Rows.Count; b++)
                                {
                                    product_head += "<table style=\"border:none;\"><tr><td><img src=\"" + dtPro_Detail.Rows[b]["LogoPath"].ToString().Replace(" ", "%20") + "\"alt=\"&nbsp;\" class=\"img-responsive\" style=\"height: auto; width: 100px; \"></td><td> <h4 style=\"margin-left:40px;\"><a href=\"" + dtPro_Detail.Rows[b]["AppLink"].ToString() + "\">" + dtPro_Detail.Rows[b]["AppName"].ToString() + "</a></h4><p style=\"padding-left:30px;display:inline;\">" + dtPro_Detail.Rows[b]["AppDescription"].ToString() + "</p></td></tr></table>";
                                }
                                w.WriteLine(product_head + "<hr>");
                                mailbody += product_head + "<hr>";
                            }
                            DataTable dtProduct_Customer = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.CategoryId, ProductTypeMaster.CategoryName FROM  AppDetails INNER JOIN  ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id INNER JOIN  PartyDetails ON AppDetails.AppId = PartyDetails.ProdId WHERE        (PartyDetails.JoinDate >= '" + monthStart.ToString("yyyy/MM/dd") + "') AND (PartyDetails.JoinDate <= '" + monthLast.ToString("yyyy/MM/dd") + "') AND (AppDetails.TypeId = 1)");
                            if (dtProduct_Customer.Rows.Count > 0)
                            {
                                w.WriteLine("<h4>New Customers for Our Products </h4>");

                                mailbody += "<h4>New Customers for Our Products </h4>";
                                for (int a = 0; a < dtProduct_Customer.Rows.Count; a++)
                                {
                                    w.WriteLine("<h3> " + dtProduct_Customer.Rows[a][1] + "</h3>");

                                    mailbody += "<h3> " + dtProduct_Customer.Rows[a][1] + "</h3>";

                                    DataTable dtPro_Detail = SqlInterpreter.GetData("SELECT DISTINCT AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath,AppDetails.AppId,AppDetails.AppDescription FROM AppDetails INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId WHERE (AppDetails.TypeId = 1) AND (AppDetails.CategoryId =" + dtProduct_Customer.Rows[a][0] + ") ");
                                    //DataTable dtPro_Detail = SqlInterpreter.GetData("SELECT AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath,AppDetails.AppId FROM AppDetails INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId WHERE (AppDetails.TypeId = 1) AND (AppDetails.CategoryId =" + dtProduct_Customer.Rows[a][0] + ")GROUP BY AppDetails.AppName, AppDetails.AppLink, AppDetails.LogoPath");
                                    for (int b = 0; b < dtPro_Detail.Rows.Count; b++)
                                    {
                                        w.WriteLine(@"<table style=""border:none;""><tr><td><img src=""" + dtPro_Detail.Rows[b]["LogoPath"].ToString().Replace(" ", "%20") + @"""alt=""&nbsp;"" class=""img - responsive"" style=""height: auto; width: 100px;""></td> <td><h4 style=""margin-left:40px;""><a href=""" + dtPro_Detail.Rows[b][1].ToString() + @""">" + dtPro_Detail.Rows[b][0].ToString() + @"</a></h4><p style=""padding-left:30px;display:inline;"">" + dtPro_Detail.Rows[b][4].ToString() + @"</p></td></tr></table> <table style=""border:none;""><tr>");

                                        mailbody += @"<table style=""border:none;""><tr><td><img src=""" + dtPro_Detail.Rows[b]["LogoPath"].ToString().Replace(" ", "%20") + @"""alt=""&nbsp;"" class=""img - responsive"" style=""height: auto; width: 100px;""></td> <td><h4 style=""margin-left:40px;""><a href=""" + dtPro_Detail.Rows[b][1].ToString() + @""">" + dtPro_Detail.Rows[b][0].ToString() + @"</a></h4><p style=""padding-left:30px;display:inline;"">" + dtPro_Detail.Rows[b][4].ToString() + @"</p></td></tr></table> <table style=""border:none;""><tr>";

                                        DataTable dtPro_cus = SqlInterpreter.GetData("SELECT PartyDetails.LogoPath, PartyDetails.JoinDate, PartyDetails.CustomerCompany FROM AppDetails INNER JOIN ProductTypeMaster ON AppDetails.CategoryId = ProductTypeMaster.Id INNER JOIN PartyDetails ON AppDetails.AppId = PartyDetails.ProdId WHERE (AppDetails.TypeId = 1) AND (AppDetails.CategoryId = " + dtProduct_Customer.Rows[a][0] + ") AND (AppDetails.AppId = " + dtPro_Detail.Rows[b][3] + ") AND (PartyDetails.JoinDate >= '" + monthStart.ToString("yyyy/MM/dd") + "') AND (PartyDetails.JoinDate <= '" + monthLast.ToString("yyyy/MM/dd") + "')");
                                        for (int c = 0; c < dtPro_cus.Rows.Count; c++)
                                        {
                                            if (((c + 1) % 4) != 0)
                                            {
                                                w.WriteLine(@"<td><table style=""border:none;""><tr><td><img src=""" + dtPro_cus.Rows[c]["LogoPath"].ToString().Replace(" ", "%20") + @""" alt=""&nbsp;"" class=""img-responsive"" style=""height: auto; width: 100px;""></td><td><h4 style=""margin-left:40px;"">" + dtPro_cus.Rows[c]["CustomerCompany"].ToString() + "</h4></td></tr></table></td>");

                                                mailbody += @"<td><table style=""border:none;""><tr><td><img src=""" + dtPro_cus.Rows[c]["LogoPath"].ToString().Replace(" ", "%20") + @""" alt=""&nbsp;"" class=""img-responsive"" style=""height: auto; width: 100px;""></td><td><h4 style=""margin-left:40px;"">" + dtPro_cus.Rows[c]["CustomerCompany"].ToString() + "</h4></td></tr></table></td>";
                                            }
                                            else
                                            {
                                                w.WriteLine(@"<td><table style=""border:none;""><tr><td><img src=""" + dtPro_cus.Rows[c]["LogoPath"].ToString().Replace(" ", "%20") + @""" alt=""&nbsp;"" class=""img-responsive"" style=""height: auto; width: 100px;""></td><td><h4 style=""margin-left:40px;"">" + dtPro_cus.Rows[c]["CustomerCompany"].ToString() + "</h4></td></tr></table></td></tr>");

                                                mailbody += @"<td><table style=""border:none;""><tr><td><img src=""" + dtPro_cus.Rows[c]["LogoPath"].ToString().Replace(" ", "%20") + @""" alt=""&nbsp;"" class=""img-responsive"" style=""height: auto; width: 100px;""></td><td><h4 style=""margin-left:40px;"">" + dtPro_cus.Rows[c]["CustomerCompany"].ToString() + "</h4></td></tr></table></td></tr>";

                                            }

                                        }
                                        w.WriteLine("</tr></table>");
                                        mailbody += "</tr></table>";
                                    }
                                    w.WriteLine("<hr>");
                                    mailbody += "<hr>";
                                }
                            }

                            DataTable dt1 = SqlInterpreter.GetData("SELECT SocialMedia.MasterName, SocialMediaMaster.ActivityName, SUM(SocialMedia.Counts) AS totalCount FROM SocialMedia INNER JOIN SocialMediaMaster ON SocialMedia.MasterName = SocialMediaMaster.Id WHERE        (SocialMedia.Month =" + cmbSelectMonth.SelectedValue+ " ) GROUP BY  SocialMedia.MasterName,SocialMediaMaster.ActivityName");
                            if (dt1 != null && dt1.Rows.Count > 0)
                                for (int i = 0; i < dt1.Rows.Count; i++)
                                {
                                    Cont_digital += "<h5>" + dt1.Rows[i][1] + " : " + dt1.Rows[i][2] + "</h5>";
                                }
                            if (Cont_digital != null && Cont_digital.Length > 0)
                            {
                                Head_Digital = "<h3> Web Presence for the Month</h3>"+Cont_digital;
                            }
                            Head_Digital += @"<div style=""height: 200px;width:100%;display: block;background: #2196F3 linear-gradient(50deg, #526e9c, powderblue);text-align: center;""><div style="" padding-left: 20px; line-height: 15px;padding-top: 7px;""><p style=""color:#fff;padding-top:10px;"">Visit website: <span style=""color:#fff;""> www.erachana.net</span>  Contact Email: <span style=""color:#fff;"">info@erachana.net</span>Gtalk ID:<a href=""mayihelp.kushal@gmail.com"" target=""_blank"">mayihelp.kushal@gmail.com</a><br>Skype ID: 9964077688</p><p><span class=""fa fa-phone"" style="" margin-top: -5px;color: #ffffff;""> Mobile No : +91-9964077688 , Support No: 080-23199709</span></p><p style=""color:#fff;"">We are active on Social Media you can connect with us on – <a style=""color:#fff;"" href=""https://www.facebook.com/erachanasoftware/"">Facebook</a>, <a href=""https://plus.google.com/u/0/+ErachanaNet"" style=""color:#fff;"">Google Plus</a> , <a style=""color:#fff;"" href=""https://twitter.com/ERachanaTech"">Twitter</a> <span style=""color:#fff;"">or</span> <a style=""color:#fff;"" href=""https://www.youtube.com/channel/UCBrUaXBp82gU5b6capzw8ZA"">YouTube</a> </p><p style=""color:#ffffff; font-weight: 500; margin-top: -4px; line-height: 18px;""><span class=""fa fa-map-marker"" style=""color: #fff;""></span> No. 35, Opp to Eshwar Hospital Saraswathipuram First Main Road II Cross, Geleyarabalaga,<br> Bengaluru – 560096</p><br></div></div></body></html >";



                            w.WriteLine(Head_Digital);
                            mailbody += Head_Digital;

                            System.IO.DirectoryInfo di1 = System.IO.Directory.CreateDirectory("C:\\ERachana\\Newsletter Composer\\Month Reports");
                            using (System.IO.FileStream fs1 = new System.IO.FileStream(System.IO.Path.Combine(di1.FullName, (fileName + ".txt")), System.IO.FileMode.Create))
                            {
                                using (System.IO.StreamWriter w1 = new System.IO.StreamWriter(fs1, Encoding.UTF8))
                                {
                                    w1.WriteLine(mailbody);
                                    //System.Diagnostics.Process.Start(System.IO.Path.Combine(di.FullName, (fileName + ".htm")));
                                }
                            }

                            txt_ContentBody.Text = System.IO.Path.Combine(di1.FullName, (fileName + ".txt"));
                            gIsfile = 1;
                            //string result = mailbody.Remove(mailbody.IndexOf("\""), "\\\"".Length).Insert(mailbody.IndexOf("\\\""), """);

                            //System.Diagnostics.Process.Start(System.IO.Path.Combine(di.FullName, (fileName + ".htm")));
                        }
                        fs.Close();
                    }



                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void Preview_Function()
        {
            try
            {
                if (txt_ContentBody.Text.Trim().Length > 0)
                {
                    DataTable dt = SqlInterpreter.GetData("SELECT Year FROM MonthMaster WHERE Id =" + Convert.ToInt16(cmbSelectMonth.SelectedValue));
                    string fileName = cmbSelectMonth.Text;
                    System.IO.DirectoryInfo di = System.IO.Directory.CreateDirectory("C:\\ERachana\\Newsletter Composer\\Month Reports");
                    using (System.IO.FileStream fs = new System.IO.FileStream(System.IO.Path.Combine(di.FullName, (fileName + ".htm")), System.IO.FileMode.Create))
                    {
                        using (System.IO.StreamWriter w = new System.IO.StreamWriter(fs, Encoding.UTF8))
                        {
                            string readText = System.IO.File.ReadAllText(System.IO.Path.Combine(di.FullName, (fileName + ".txt")));
                            w.WriteLine(readText);
                            System.Diagnostics.Process.Start(System.IO.Path.Combine(di.FullName, (fileName + ".htm")));
                        }
                    }
                }

            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void Edit_Html()
        {
            try
            {
                if (txt_ContentBody.Text.Trim().Length > 0)
                {
                    DataTable dt = SqlInterpreter.GetData("SELECT Year FROM MonthMaster WHERE Id =" + Convert.ToInt16(cmbSelectMonth.SelectedValue));
                    string fileName = cmbSelectMonth.Text;
                    System.IO.DirectoryInfo di = System.IO.Directory.CreateDirectory("C:\\ERachana\\Newsletter Composer\\Month Reports");
                    using (System.IO.FileStream fs = new System.IO.FileStream(System.IO.Path.Combine(di.FullName, (fileName + ".txt")), System.IO.FileMode.Create))
                    {

                        System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.Combine(di.FullName, (fileName + ".txt")));
                    }
                }
                else
                {
                    MessageBox.Show("No File selected", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void PostSave_Update()
        {
            try
            {
                if (Convert.ToInt16(gIsfile) > 0)
                {
                    SqlInterpreter.ExecuteSQL("update EmailTemplate set IsFile=1 where TemplateID = " + txt_TemplateID.Text);
                    gIsfile = 0;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unexpected error occured!" + Environment.NewLine + exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}