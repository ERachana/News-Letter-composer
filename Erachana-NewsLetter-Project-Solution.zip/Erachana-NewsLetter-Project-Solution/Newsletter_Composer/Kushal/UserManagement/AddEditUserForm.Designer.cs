using Kushal.Controls;
namespace Newsletter_Composer {
    partial class AddEditUserForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnNew = new Kushal.Controls.KushalButton();
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnDelete = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.grpNewGroupBox1 = new Kushal.Controls.KushalGroupBox();
            this.chkStatus = new Kushal.Controls.KushalCheckBox();
            this.chkAdministrator = new Kushal.Controls.KushalCheckBox();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel3 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel4 = new Kushal.Controls.KushalLabel();
            this.txtId = new Kushal.Controls.KushalTextBox();
            this.txtName = new Kushal.Controls.KushalTextBox();
            this.txtUserId = new Kushal.Controls.KushalTextBox();
            this.txtPassword = new Kushal.Controls.KushalTextBox();
            this.dgrUsers = new System.Windows.Forms.DataGridView();
            this.colPassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAdmin = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUserId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuspendLayout();
            
            
            this.btnNew.Location = new System.Drawing.Point(26, 238);
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnNew.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Enabled = true;
            this.btnNew.Visible = true;
            this.btnNew.TabIndex = 0;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnNew.Size = new System.Drawing.Size(80, 30);
            this.btnNew.Text = @"New";
            this.btnNew.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnNew, @"");
            
            
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);

            this.btnSave.Location = new System.Drawing.Point(188, 238);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            this.btnDelete.Location = new System.Drawing.Point(350, 238);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Enabled = true;
            this.btnDelete.Visible = true;
            this.btnDelete.TabIndex = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Text = @"Delete";
            this.btnDelete.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnDelete, @"");
            
            
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

            this.btnClose.Location = new System.Drawing.Point(512, 238);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.grpNewGroupBox1.Location = new System.Drawing.Point(28, 11);
            this.grpNewGroupBox1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.grpNewGroupBox1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.grpNewGroupBox1.Name = "grpNewGroupBox1";
            this.grpNewGroupBox1.Enabled = true;
            this.grpNewGroupBox1.Visible = true;
            this.grpNewGroupBox1.TabIndex = 0;
            this.grpNewGroupBox1.TabStop = false;
            this.grpNewGroupBox1.Size = new System.Drawing.Size(560, 210);
            this.grpNewGroupBox1.Text = @"";
            this.grpNewGroupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNewGroupBox1.SendToBack();
            this.toolTip1.SetToolTip(this.grpNewGroupBox1, @"");

            this.chkStatus.AutoSize = true;
            this.chkStatus.Location = new System.Drawing.Point(117, 147);
            this.chkStatus.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.chkStatus.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chkStatus.Name = "chkStatus";
            this.chkStatus.DefaultChecked = false;
            this.chkStatus.FriendlyName = "";
            this.chkStatus.Enabled = true;
            this.chkStatus.Visible = true;
            this.chkStatus.TabIndex = 0;
            this.chkStatus.Size = new System.Drawing.Size(150, 25);
            this.chkStatus.Text = @"Is this user active ?";
            this.chkStatus.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStatus.UseVisualStyleBackColor = true;
            this.toolTip1.SetToolTip(this.chkStatus, @"");

            this.chkAdministrator.AutoSize = true;
            this.chkAdministrator.Location = new System.Drawing.Point(117, 177);
            this.chkAdministrator.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.chkAdministrator.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.chkAdministrator.Name = "chkAdministrator";
            this.chkAdministrator.DefaultChecked = false;
            this.chkAdministrator.FriendlyName = "";
            this.chkAdministrator.Enabled = true;
            this.chkAdministrator.Visible = true;
            this.chkAdministrator.TabIndex = 0;
            this.chkAdministrator.Size = new System.Drawing.Size(150, 25);
            this.chkAdministrator.Text = @"Is administrator ?";
            this.chkAdministrator.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAdministrator.UseVisualStyleBackColor = true;
            this.toolTip1.SetToolTip(this.chkAdministrator, @"");

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(15, 10);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(100, 23);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"Id";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(15, 44);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(100, 20);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @"Name";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.lblNewLabel3.AutoSize = false;
            this.lblNewLabel3.Location = new System.Drawing.Point(15, 78);
            this.lblNewLabel3.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel3.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel3.Name = "lblNewLabel3";
            this.lblNewLabel3.Enabled = true;
            this.lblNewLabel3.Visible = true;
            this.lblNewLabel3.TabIndex = 0;
            this.lblNewLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel3.Size = new System.Drawing.Size(100, 23);
            this.lblNewLabel3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel3.Text = @"User Id";
            this.toolTip1.SetToolTip(this.lblNewLabel3, @"");

            this.lblNewLabel4.AutoSize = false;
            this.lblNewLabel4.Location = new System.Drawing.Point(15, 112);
            this.lblNewLabel4.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel4.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel4.Name = "lblNewLabel4";
            this.lblNewLabel4.Enabled = true;
            this.lblNewLabel4.Visible = true;
            this.lblNewLabel4.TabIndex = 0;
            this.lblNewLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel4.Size = new System.Drawing.Size(100, 20);
            this.lblNewLabel4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel4.Text = @"Password";
            this.toolTip1.SetToolTip(this.lblNewLabel4, @"");

            this.txtId.Location = new System.Drawing.Point(116, 10);
            this.txtId.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtId.Multiline = false;
            this.txtId.MaxLength = 256;
            this.txtId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtId.Name = "txtId";
            this.txtId.Text = @"";
            
            this.txtId.AllowNull = false;
            this.txtId.DefaultValue = "";
            this.txtId.FriendlyName = "";
            this.txtId.ValidationType = TextValidation.None;
            this.txtId.ValidationExpression = @"";
            this.txtId.ValidationMessage = @"";
            this.txtId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtId.Enabled = true;
            this.txtId.ReadOnly = false;
            this.txtId.Visible = true;
            this.txtId.TabIndex = 0;
            this.txtId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtId.Size = new System.Drawing.Size(400, 31);
            this.toolTip1.SetToolTip(this.txtId, @"");

            this.txtName.Location = new System.Drawing.Point(116, 44);
            this.txtName.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtName.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtName.Multiline = false;
            this.txtName.MaxLength = 256;
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.Name = "txtName";
            this.txtName.Text = @"";
            
            this.txtName.AllowNull = false;
            this.txtName.DefaultValue = "";
            this.txtName.FriendlyName = "";
            this.txtName.ValidationType = TextValidation.None;
            this.txtName.ValidationExpression = @"";
            this.txtName.ValidationMessage = @"";
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtName.Enabled = true;
            this.txtName.ReadOnly = false;
            this.txtName.Visible = true;
            this.txtName.TabIndex = 0;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtName.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Size = new System.Drawing.Size(400, 31);
            this.toolTip1.SetToolTip(this.txtName, @"");

            this.txtUserId.Location = new System.Drawing.Point(116, 78);
            this.txtUserId.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtUserId.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtUserId.Multiline = false;
            this.txtUserId.MaxLength = 256;
            this.txtUserId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Text = @"";
            
            this.txtUserId.AllowNull = false;
            this.txtUserId.DefaultValue = "";
            this.txtUserId.FriendlyName = "";
            this.txtUserId.ValidationType = TextValidation.None;
            this.txtUserId.ValidationExpression = @"";
            this.txtUserId.ValidationMessage = @"";
            this.txtUserId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtUserId.Enabled = true;
            this.txtUserId.ReadOnly = false;
            this.txtUserId.Visible = true;
            this.txtUserId.TabIndex = 0;
            this.txtUserId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtUserId.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserId.Size = new System.Drawing.Size(400, 31);
            this.toolTip1.SetToolTip(this.txtUserId, @"");

            this.txtPassword.Location = new System.Drawing.Point(117, 112);
            this.txtPassword.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtPassword.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtPassword.Multiline = false;
            this.txtPassword.MaxLength = 256;
            this.txtPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Text = @"";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.AllowNull = false;
            this.txtPassword.DefaultValue = "";
            this.txtPassword.FriendlyName = "";
            this.txtPassword.ValidationType = TextValidation.None;
            this.txtPassword.ValidationExpression = @"";
            this.txtPassword.ValidationMessage = @"";
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtPassword.Enabled = true;
            this.txtPassword.ReadOnly = false;
            this.txtPassword.Visible = true;
            this.txtPassword.TabIndex = 0;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPassword.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Size = new System.Drawing.Size(400, 31);
            this.toolTip1.SetToolTip(this.txtPassword, @"");

            this.dgrUsers.AllowUserToAddRows = false;
            this.dgrUsers.AllowUserToDeleteRows = false;
            this.dgrUsers.ColumnHeadersHeight = 25;
            this.dgrUsers.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrUsers.Location = new System.Drawing.Point(27, 277);
            this.dgrUsers.Name = "dgrUsers";
            this.dgrUsers.Enabled = true;
            this.dgrUsers.Visible = true;
            this.dgrUsers.MultiSelect = false;
            this.dgrUsers.ReadOnly = true;
            this.dgrUsers.ShowRowErrors = false;
            this.dgrUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrUsers.Size = new System.Drawing.Size(567, 200);
            this.dgrUsers.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrUsers.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrUsers.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrUsers.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrUsers.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrUsers.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrUsers.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrUsers.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrUsers.TabIndex = 0;
            this.dgrUsers.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrUsers, @"");
            
            
            

            this.colPassword.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colPassword.HeaderText = "Password";
            this.colPassword.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colPassword.Name = "colPassword";
            this.colPassword.DataPropertyName = "Pass";
            this.colPassword.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colPassword.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colPassword.Width = 100;
            this.colPassword.Visible = false;
            //this.colPassword.DisplayIndex = 0;
            this.colPassword.ReadOnly = false;
            this.colPassword.Tag = "";
            
            
            
            this.dgrUsers.Columns.Add(this.colPassword);

            this.colAdmin.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colAdmin.HeaderText = "Admin";
            this.colAdmin.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colAdmin.Name = "colAdmin";
            this.colAdmin.DataPropertyName = "IsAdmin";
            this.colAdmin.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colAdmin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colAdmin.Width = 100;
            this.colAdmin.Visible = true;
            //this.colAdmin.DisplayIndex = 0;
            this.colAdmin.ReadOnly = false;
            this.colAdmin.Tag = "";
            
            
            
            this.dgrUsers.Columns.Add(this.colAdmin);

            this.colStatus.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colStatus.HeaderText = "Status";
            this.colStatus.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colStatus.Name = "colStatus";
            this.colStatus.DataPropertyName = "IsActive";
            this.colStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colStatus.Width = 100;
            this.colStatus.Visible = true;
            //this.colStatus.DisplayIndex = 0;
            this.colStatus.ReadOnly = false;
            this.colStatus.Tag = "";
            
            
            
            this.dgrUsers.Columns.Add(this.colStatus);

            this.colId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colId.HeaderText = "Id";
            this.colId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colId.Name = "colId";
            this.colId.DataPropertyName = "Id";
            this.colId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colId.Width = 100;
            this.colId.Visible = true;
            //this.colId.DisplayIndex = 0;
            this.colId.ReadOnly = false;
            this.colId.Tag = "";
            
            
            
            this.dgrUsers.Columns.Add(this.colId);

            this.colName.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colName.HeaderText = "Name";
            this.colName.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colName.Name = "colName";
            this.colName.DataPropertyName = "Name";
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colName.Width = 100;
            this.colName.Visible = true;
            //this.colName.DisplayIndex = 0;
            this.colName.ReadOnly = false;
            this.colName.Tag = "";
            
            
            
            this.dgrUsers.Columns.Add(this.colName);

            this.colUserId.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colUserId.HeaderText = "User Id";
            this.colUserId.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colUserId.Name = "colUserId";
            this.colUserId.DataPropertyName = "UserId";
            this.colUserId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colUserId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colUserId.Width = 100;
            this.colUserId.Visible = true;
            //this.colUserId.DisplayIndex = 0;
            this.colUserId.ReadOnly = false;
            this.colUserId.Tag = "";
            
            
            
            this.dgrUsers.Columns.Add(this.colUserId);


            
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpNewGroupBox1);
            this.grpNewGroupBox1.Controls.Add(this.chkStatus);
            this.grpNewGroupBox1.Controls.Add(this.chkAdministrator);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel1);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel2);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel3);
            this.grpNewGroupBox1.Controls.Add(this.lblNewLabel4);
            this.grpNewGroupBox1.Controls.Add(this.txtId);
            this.grpNewGroupBox1.Controls.Add(this.txtName);
            this.grpNewGroupBox1.Controls.Add(this.txtUserId);
            this.grpNewGroupBox1.Controls.Add(this.txtPassword);
            this.Controls.Add(this.dgrUsers);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "AddEditUserForm";
            this.Text = "Manage Users";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(635, 535);
            
                        this.Load += new System.EventHandler(this.AddEditUserForm_Load);
            this.Activated += new System.EventHandler(this.AddEditUserForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnNew;
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnDelete;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalGroupBox grpNewGroupBox1;
        private Kushal.Controls.KushalCheckBox chkStatus;
        private Kushal.Controls.KushalCheckBox chkAdministrator;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private Kushal.Controls.KushalLabel lblNewLabel3;
        private Kushal.Controls.KushalLabel lblNewLabel4;
        private Kushal.Controls.KushalTextBox txtId;
        private Kushal.Controls.KushalTextBox txtName;
        private Kushal.Controls.KushalTextBox txtUserId;
        private Kushal.Controls.KushalTextBox txtPassword;
        private System.Windows.Forms.DataGridView dgrUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPassword;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colAdmin;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUserId;
    }
}