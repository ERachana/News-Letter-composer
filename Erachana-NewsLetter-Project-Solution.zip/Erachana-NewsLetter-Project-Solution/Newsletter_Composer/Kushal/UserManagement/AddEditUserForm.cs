using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class AddEditUserForm : Form {
        private DataAdapter dataAdapter;
        private bool newRecord = false;
        private string keyField = "Id";
        public AddEditUserForm() {
            InitializeComponent();
            colId.DisplayIndex = 0;
            colUserId.DisplayIndex = 1;
            colName.DisplayIndex = 2;
            colAdmin.DisplayIndex = 3;
            colStatus.DisplayIndex = 4;
            dgrUsers.RowStateChanged +=new DataGridViewRowStateChangedEventHandler(dgrUsers_RowStateChanged);
        }

		private void AddEditUserForm_Activated(object sender, EventArgs e) {
		
		}

        private void AddEditUserForm_Load(object sender, EventArgs e) {
            dataAdapter = DataAdapter.Current;
            dataAdapter.Clear("user");
            DataTable dt = dataAdapter.LoadData("select * from kushal_user", "kushal_user");
            if (dt != null) {
                dgrUsers.DataSource = dt;
            }
        }

        private void txtId_TextChanged(object sender, EventArgs e) {
            foreach (DataGridViewRow row in dgrUsers.Rows) {
                if (Convert.ToString(row.Cells["colId"].Value) == txtId.Text) {
                    row.Selected = true;
                }
            }
        }

        private long GetAutoIncrementValue() {
            long value = 0;
            if (String.IsNullOrEmpty("Id") == false) {
                string sql = @"SELECT MAX(Id) FROM kushal_user;";
                DataTable dt1 = dataAdapter.LoadData(sql, "value" + Guid.NewGuid().ToString());
                if (dt1 != null && dt1.Rows.Count > 1) {
                    value = Convert.ToInt64(dt1.Rows[1][0]);
                } else if (dt1 != null && dt1.Rows.Count > 0) {
                    if (dt1.Rows[0][0] == DBNull.Value) {
                        value = 0;
                    } else {
                        value = Convert.ToInt64(dt1.Rows[0][0]);
                    }
                }
            }
            return value;
        }

        private void btnNew_Click(object sender, EventArgs e) {
            txtName.Text = txtUserId.Text = txtPassword.Text = string.Empty;
            chkStatus.Checked = true;
            long currentId = GetAutoIncrementValue();
            txtId.Text = Convert.ToString(currentId + 1);
            newRecord = true;
            dgrUsers.ClearSelection();
        }

        private void btnSave_Click(object sender, EventArgs e) {
            if (newRecord) {
                int rowcount = dgrUsers.Rows.Count;
                bool success = AddNewRecord();
                if (success) {
                    dgrUsers.Rows[dgrUsers.Rows.Count - 1].Selected = true;
                } else if (rowcount < dgrUsers.Rows.Count) {
                    dgrUsers.Rows.RemoveAt(dgrUsers.Rows.Count - 1);
                }
            } else {
                UpdateRecord();
            }
        }

        private bool AddNewRecord() {
            DataTable table = (DataTable)dgrUsers.DataSource;
            List<object> vals = new List<object>();
            vals.Add(txtId.Text);
            vals.Add(txtName.Text);
            vals.Add(txtUserId.Text);
            vals.Add(EncryptDecrypt.Encrypt(txtPassword.Text));
            vals.Add(chkAdministrator.Checked);
            vals.Add(chkStatus.Checked);
            table.Rows.Add(vals.ToArray());
            try {
                dataAdapter.Update(table.TableName);
            } catch (Exception e) {
                MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void UpdateRecord() {
            if (dgrUsers.SelectedRows != null && dgrUsers.SelectedRows.Count > 0) {
                int rowIndex = dgrUsers.SelectedRows[0].Index;
                DataTable table = (DataTable)dgrUsers.DataSource;
                table.Rows[rowIndex][0] = txtId.Text;
                table.Rows[rowIndex][1] = txtName.Text;
                table.Rows[rowIndex][2] = txtUserId.Text;
                table.Rows[rowIndex][3] = EncryptDecrypt.Encrypt(txtPassword.Text);
                table.Rows[rowIndex][4] = chkAdministrator.Checked;
                table.Rows[rowIndex][5] = chkStatus.Checked;
                dataAdapter.Update(table.TableName);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e) {
            DataTable table = (DataTable)dgrUsers.DataSource;
            if (dgrUsers.SelectedRows != null && dgrUsers.SelectedRows.Count > 0) {
                if (MessageBox.Show("Do you really want to delete this row?", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) == DialogResult.OK) {
                    foreach (DataGridViewColumn column in dgrUsers.Columns) {
                        if (column.DataPropertyName == keyField) {
                            dataAdapter.DeleteRow(table, Convert.ToString(dgrUsers.SelectedRows[0].Cells[column.Name].Value), keyField);
                            dgrUsers.Rows.RemoveAt(dgrUsers.SelectedRows[0].Index);
                            table.AcceptChanges();
                            break;
                        }
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.No;
        }

        private void dgrUsers_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e) {
            if (e.StateChanged != DataGridViewElementStates.Selected)
                return;

            if (dgrUsers.SelectedRows != null && dgrUsers.SelectedRows.Count > 0) {
                // Set input values
                int rowIndex = dgrUsers.SelectedRows[0].Index;
                txtId.Text = Convert.ToString(dgrUsers["colId", rowIndex].Value);
                txtName.Text = (string)dgrUsers["colName", rowIndex].Value;
                txtUserId.Text = (string)dgrUsers["colUserId", rowIndex].Value;
                txtPassword.Text = EncryptDecrypt.Decrypt((string)dgrUsers["colPassword", rowIndex].Value);
                chkAdministrator.Checked = (bool)dgrUsers["colAdmin", rowIndex].Value;
                chkStatus.Checked = (bool)dgrUsers["colStatus", rowIndex].Value;
                this.newRecord = false;
            }
        }
    }
}
