using Kushal.Controls;
namespace Newsletter_Composer {
    partial class ChangePasswordForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel3 = new Kushal.Controls.KushalLabel();
            this.txtCurrentPassword = new Kushal.Controls.KushalTextBox();
            this.txtNewPassword = new Kushal.Controls.KushalTextBox();
            this.txtConfirmPassword = new Kushal.Controls.KushalTextBox();
            this.SuspendLayout();
            
            
            this.btnSave.Location = new System.Drawing.Point(257, 132);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            this.btnClose.Location = new System.Drawing.Point(351, 132);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(17, 22);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(120, 20);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"Current Password";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(17, 57);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(100, 20);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @"New Password";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.lblNewLabel3.AutoSize = false;
            this.lblNewLabel3.Location = new System.Drawing.Point(17, 92);
            this.lblNewLabel3.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel3.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel3.Name = "lblNewLabel3";
            this.lblNewLabel3.Enabled = true;
            this.lblNewLabel3.Visible = true;
            this.lblNewLabel3.TabIndex = 0;
            this.lblNewLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel3.Size = new System.Drawing.Size(118, 20);
            this.lblNewLabel3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel3.Text = @"Confirm Password";
            this.toolTip1.SetToolTip(this.lblNewLabel3, @"");

            this.txtCurrentPassword.Location = new System.Drawing.Point(138, 22);
            this.txtCurrentPassword.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtCurrentPassword.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtCurrentPassword.Multiline = false;
            this.txtCurrentPassword.MaxLength = 256;
            this.txtCurrentPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCurrentPassword.Name = "txtCurrentPassword";
            this.txtCurrentPassword.Text = @"";
            this.txtCurrentPassword.PasswordChar = '*';
            this.txtCurrentPassword.AllowNull = false;
            this.txtCurrentPassword.DefaultValue = "";
            this.txtCurrentPassword.FriendlyName = "";
            this.txtCurrentPassword.ValidationType = TextValidation.None;
            this.txtCurrentPassword.ValidationExpression = @"";
            this.txtCurrentPassword.ValidationMessage = @"";
            this.txtCurrentPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtCurrentPassword.Enabled = true;
            this.txtCurrentPassword.ReadOnly = false;
            this.txtCurrentPassword.Visible = true;
            this.txtCurrentPassword.TabIndex = 0;
            this.txtCurrentPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCurrentPassword.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentPassword.Size = new System.Drawing.Size(294, 31);
            this.toolTip1.SetToolTip(this.txtCurrentPassword, @"");

            this.txtNewPassword.Location = new System.Drawing.Point(138, 57);
            this.txtNewPassword.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtNewPassword.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtNewPassword.Multiline = false;
            this.txtNewPassword.MaxLength = 256;
            this.txtNewPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Text = @"";
            this.txtNewPassword.PasswordChar = '*';
            this.txtNewPassword.AllowNull = false;
            this.txtNewPassword.DefaultValue = "";
            this.txtNewPassword.FriendlyName = "";
            this.txtNewPassword.ValidationType = TextValidation.None;
            this.txtNewPassword.ValidationExpression = @"";
            this.txtNewPassword.ValidationMessage = @"";
            this.txtNewPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtNewPassword.Enabled = true;
            this.txtNewPassword.ReadOnly = false;
            this.txtNewPassword.Visible = true;
            this.txtNewPassword.TabIndex = 0;
            this.txtNewPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNewPassword.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewPassword.Size = new System.Drawing.Size(294, 31);
            this.toolTip1.SetToolTip(this.txtNewPassword, @"");

            this.txtConfirmPassword.Location = new System.Drawing.Point(138, 89);
            this.txtConfirmPassword.BackColor = System.Drawing.Color.FromArgb(-1);
            this.txtConfirmPassword.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.txtConfirmPassword.Multiline = false;
            this.txtConfirmPassword.MaxLength = 256;
            this.txtConfirmPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Text = @"";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.AllowNull = false;
            this.txtConfirmPassword.DefaultValue = "";
            this.txtConfirmPassword.FriendlyName = "";
            this.txtConfirmPassword.ValidationType = TextValidation.None;
            this.txtConfirmPassword.ValidationExpression = @"";
            this.txtConfirmPassword.ValidationMessage = @"";
            this.txtConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtConfirmPassword.Enabled = true;
            this.txtConfirmPassword.ReadOnly = false;
            this.txtConfirmPassword.Visible = true;
            this.txtConfirmPassword.TabIndex = 0;
            this.txtConfirmPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtConfirmPassword.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPassword.Size = new System.Drawing.Size(294, 31);
            this.toolTip1.SetToolTip(this.txtConfirmPassword, @"");


            
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblNewLabel1);
            this.Controls.Add(this.lblNewLabel2);
            this.Controls.Add(this.lblNewLabel3);
            this.Controls.Add(this.txtCurrentPassword);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.txtConfirmPassword);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "ChangePasswordForm";
            this.Text = "Change Password";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(464, 216);
            
                        this.Load += new System.EventHandler(this.ChangePasswordForm_Load);
            this.Activated += new System.EventHandler(this.ChangePasswordForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private Kushal.Controls.KushalLabel lblNewLabel3;
        private Kushal.Controls.KushalTextBox txtCurrentPassword;
        private Kushal.Controls.KushalTextBox txtNewPassword;
        private Kushal.Controls.KushalTextBox txtConfirmPassword;
    }
}