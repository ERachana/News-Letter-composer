using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class ChangePasswordForm : Form {
        public ChangePasswordForm() {
            InitializeComponent();
        }

        private void ChangePasswordForm_Load(object sender, EventArgs e) {

        }

		private void ChangePasswordForm_Activated(object sender, EventArgs e) {
		
		}

        public string UserId { get; set; }

        private void btnSave_Click(object sender, EventArgs e) {
            if (String.IsNullOrEmpty(txtCurrentPassword.Text)) {
                MessageBox.Show("Current password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (String.IsNullOrEmpty(txtNewPassword.Text)) {
                MessageBox.Show("New password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (String.IsNullOrEmpty(txtConfirmPassword.Text)) {
                MessageBox.Show("Confirm password cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtNewPassword.Text != txtConfirmPassword.Text) {
                MessageBox.Show("New password and confirm password does not match. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtCurrentPassword.Text == txtNewPassword.Text) {
                MessageBox.Show("New password cannot be same as current password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate current password
            DataAdapter dataAdapter = DataAdapter.Current;
            DataTable dt = dataAdapter.LoadData(String.Format("SELECT * FROM kushal_user WHERE UserId = '{0}' AND Pass = '{1}'", UserId, EncryptDecrypt.Encrypt(txtCurrentPassword.Text)), "user_current_password");
            if (dt == null || dt.Rows.Count == 0) {
                MessageBox.Show("Validation failed. Please enter correct current password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Update new password
            int rowsUpdated = dataAdapter.ExecuteSql(String.Format("UPDATE kushal_user SET Pass = '{0}' WHERE UserId = '{1}'", EncryptDecrypt.Encrypt(txtNewPassword.Text), UserId));
            if (rowsUpdated > 0) {
                MessageBox.Show("Password successfully updated", "Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            this.DialogResult = DialogResult.OK;
        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.No;
        }
    }
}
