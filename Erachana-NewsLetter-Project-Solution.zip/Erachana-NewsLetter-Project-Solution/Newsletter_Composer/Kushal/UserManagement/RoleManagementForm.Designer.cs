using Kushal.Controls;
namespace Newsletter_Composer {
    partial class RoleManagementForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            
            this.btnSave = new Kushal.Controls.KushalButton();
            this.btnClose = new Kushal.Controls.KushalButton();
            this.cmbUsers = new Kushal.Controls.KushalComboBox();
            this.lblNewLabel1 = new Kushal.Controls.KushalLabel();
            this.lblNewLabel2 = new Kushal.Controls.KushalLabel();
            this.dgrModules = new System.Windows.Forms.DataGridView();
            this.colDelete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colView = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colEdit = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colModule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNew = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SuspendLayout();
            
            
            this.btnSave.Location = new System.Drawing.Point(14, 280);
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Enabled = true;
            this.btnSave.Visible = true;
            this.btnSave.TabIndex = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.Text = @"Save";
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnSave, @"");
            
            
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            this.btnClose.Location = new System.Drawing.Point(368, 280);
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Enabled = true;
            this.btnClose.Visible = true;
            this.btnClose.TabIndex = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.Text = @"Close";
            this.btnClose.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.btnClose, @"");
            
            
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            this.cmbUsers.Location = new System.Drawing.Point(120, 11);
            this.cmbUsers.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbUsers.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbUsers.MaxDropDownItems = 10;
            this.cmbUsers.IntegralHeight = false;
            this.cmbUsers.BackColor = System.Drawing.Color.FromArgb(-1);
            this.cmbUsers.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.cmbUsers.FormattingEnabled = true;
            this.cmbUsers.Name = "cmbUsers";
            this.cmbUsers.AllowNull = false;
            this.cmbUsers.FriendlyName = "";
            this.cmbUsers.Enabled = true;
            this.cmbUsers.Visible = true;
            this.cmbUsers.TabIndex = 0;
            this.cmbUsers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbUsers.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUsers.Size = new System.Drawing.Size(328, 29);
            this.cmbUsers.Tag = "";
            this.toolTip1.SetToolTip(this.cmbUsers, @"");
            

            this.lblNewLabel1.AutoSize = false;
            this.lblNewLabel1.Location = new System.Drawing.Point(14, 12);
            this.lblNewLabel1.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel1.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel1.Name = "lblNewLabel1";
            this.lblNewLabel1.Enabled = true;
            this.lblNewLabel1.Visible = true;
            this.lblNewLabel1.TabIndex = 0;
            this.lblNewLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel1.Size = new System.Drawing.Size(89, 23);
            this.lblNewLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel1.Text = @"Login Name";
            this.toolTip1.SetToolTip(this.lblNewLabel1, @"");

            this.lblNewLabel2.AutoSize = false;
            this.lblNewLabel2.Location = new System.Drawing.Point(14, 46);
            this.lblNewLabel2.BackColor = System.Drawing.Color.FromArgb(-986896);
            this.lblNewLabel2.ForeColor = System.Drawing.Color.FromArgb(-16777216);
            this.lblNewLabel2.Name = "lblNewLabel2";
            this.lblNewLabel2.Enabled = true;
            this.lblNewLabel2.Visible = true;
            this.lblNewLabel2.TabIndex = 0;
            this.lblNewLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNewLabel2.Size = new System.Drawing.Size(100, 20);
            this.lblNewLabel2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewLabel2.Text = @"User Roles";
            this.toolTip1.SetToolTip(this.lblNewLabel2, @"");

            this.dgrModules.AllowUserToAddRows = false;
            this.dgrModules.AllowUserToDeleteRows = false;
            this.dgrModules.ColumnHeadersHeight = 25;
            this.dgrModules.Dock = System.Windows.Forms.DockStyle.None;
            this.dgrModules.Location = new System.Drawing.Point(14, 72);
            this.dgrModules.Name = "dgrModules";
            this.dgrModules.Enabled = true;
            this.dgrModules.Visible = true;
            this.dgrModules.MultiSelect = false;
            this.dgrModules.ReadOnly = false;
            this.dgrModules.ShowRowErrors = false;
            this.dgrModules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrModules.Size = new System.Drawing.Size(434, 200);
            this.dgrModules.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrModules.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgrModules.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dgrModules.DefaultCellStyle.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrModules.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dgrModules.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgrModules.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgrModules.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrModules.TabIndex = 0;
            this.dgrModules.Tag = @"";
            this.toolTip1.SetToolTip(this.dgrModules, @"");
            
            
            

            this.colDelete.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDelete.HeaderText = "Delete";
            this.colDelete.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDelete.Name = "colDelete";
            this.colDelete.DataPropertyName = "";
            this.colDelete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colDelete.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colDelete.Width = 100;
            this.colDelete.Visible = true;
            //this.colDelete.DisplayIndex = 0;
            this.colDelete.ReadOnly = false;
            this.colDelete.Tag = "";
            
            
            
            this.dgrModules.Columns.Add(this.colDelete);

            this.colView.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colView.HeaderText = "View";
            this.colView.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colView.Name = "colView";
            this.colView.DataPropertyName = "";
            this.colView.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colView.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colView.Width = 100;
            this.colView.Visible = true;
            //this.colView.DisplayIndex = 0;
            this.colView.ReadOnly = false;
            this.colView.Tag = "";
            
            
            
            this.dgrModules.Columns.Add(this.colView);

            this.colEdit.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEdit.HeaderText = "Edit";
            this.colEdit.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEdit.Name = "colEdit";
            this.colEdit.DataPropertyName = "";
            this.colEdit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colEdit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colEdit.Width = 100;
            this.colEdit.Visible = true;
            //this.colEdit.DisplayIndex = 0;
            this.colEdit.ReadOnly = false;
            this.colEdit.Tag = "";
            
            
            
            this.dgrModules.Columns.Add(this.colEdit);

            this.colModule.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colModule.HeaderText = "Module";
            this.colModule.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colModule.Name = "colModule";
            this.colModule.DataPropertyName = "";
            this.colModule.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colModule.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colModule.Width = 100;
            this.colModule.Visible = true;
            //this.colModule.DisplayIndex = 0;
            this.colModule.ReadOnly = false;
            this.colModule.Tag = "";
            
            
            
            this.dgrModules.Columns.Add(this.colModule);

            this.colNew.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colNew.HeaderText = "New";
            this.colNew.HeaderCell.Style.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colNew.Name = "colNew";
            this.colNew.DataPropertyName = "";
            this.colNew.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.NotSet;
            this.colNew.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colNew.Width = 100;
            this.colNew.Visible = true;
            //this.colNew.DisplayIndex = 0;
            this.colNew.ReadOnly = false;
            this.colNew.Tag = "";
            
            
            
            this.dgrModules.Columns.Add(this.colNew);


            
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.cmbUsers);
            this.Controls.Add(this.lblNewLabel1);
            this.Controls.Add(this.lblNewLabel2);
            this.Controls.Add(this.dgrModules);
            
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;

            this.AutoScroll = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(-986896);
            
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            
            
            this.Name = "RoleManagementForm";
            this.Text = "User Role Management";
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size = new System.Drawing.Size(479, 355);
            
                        this.Load += new System.EventHandler(this.RoleManagementForm_Load);
            this.Activated += new System.EventHandler(this.RoleManagementForm_Activated);
            
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        
        private Kushal.Controls.KushalButton btnSave;
        private Kushal.Controls.KushalButton btnClose;
        private Kushal.Controls.KushalComboBox cmbUsers;
        private Kushal.Controls.KushalLabel lblNewLabel1;
        private Kushal.Controls.KushalLabel lblNewLabel2;
        private System.Windows.Forms.DataGridView dgrModules;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colDelete;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colView;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEdit;
        private System.Windows.Forms.DataGridViewTextBoxColumn colModule;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colNew;
    }
}