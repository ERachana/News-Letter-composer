using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Newsletter_Composer {
    public partial class RoleManagementForm : Form {
        private DataAdapter dataAdapter;
        private bool loading = false;

        public RoleManagementForm() {
            InitializeComponent();

            colModule.DisplayIndex = 0;
            colNew.DisplayIndex = 1;
            colEdit.DisplayIndex = 2;
            colDelete.DisplayIndex = 3;
            colView.DisplayIndex = 4;

            cmbUsers.SelectedIndexChanged +=new EventHandler(cmbUsers_SelectedIndexChanged);
        }

		private void RoleManagementForm_Activated(object sender, EventArgs e) {
		
		}

        private void RoleManagementForm_Load(object sender, EventArgs e) {
            loading = true;
            // Load users
            dataAdapter = DataAdapter.Current;
            DataTable dt = dataAdapter.LoadData("SELECT * FROM [kushal_user]", "users");
            if (dt != null) {
                Dictionary<int, string> users = new Dictionary<int, string>();
                foreach (DataRow row in dt.Rows) {
                    int id = Convert.ToInt32(row["Id"]);
                    string userId = (string)row["UserId"];
                    
                    users.Add(id, userId);
                }

                cmbUsers.DataSource = new BindingSource(users, null);
                cmbUsers.DisplayMember = "Value";
                cmbUsers.ValueMember = "Key";
                cmbUsers.SelectedIndex = -1;
            }

            // Load modules
            DataTable dtModules = dataAdapter.LoadData("SELECT * FROM [module]", "modules");
            
            if (dt != null) {
                foreach (DataRow row in dtModules.Rows) {
                    int id = Convert.ToInt32(row["Id"]);
                    string name = (string)row["Name"];

                    int index = dgrModules.Rows.Add();
                    dgrModules[3, index].Value = name;
                    dgrModules.Rows[index].Tag = id;
                }
            }

            loading = false;
        }

        private void cmbUsers_SelectedIndexChanged(object sender, EventArgs e) {
            if (cmbUsers.SelectedValue == null || loading) {
                dgrModules.Enabled = false;
                return;
            }

            int userId = (int)cmbUsers.SelectedValue;

            // Check whether user is Admin
            DataTable dtKushalUser = dataAdapter.LoadData(String.Format(@"SELECT * FROM [kushal_user] WHERE Id = {0}", userId), "kushal_user" + Guid.NewGuid().ToString());
            if (dtKushalUser != null && dtKushalUser.Rows.Count > 0) {
                bool isAdmin = (bool)dtKushalUser.Rows[0]["IsAdmin"];
                if (isAdmin) {
                    MessageBox.Show("Admin user will have all priviledges. Hence admin user priviledges cannot be changed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dgrModules.Enabled = false;
                    return;
                }
            }

            dgrModules.Enabled = true;
            
            foreach (DataGridViewRow gridRow in dgrModules.Rows) {
                gridRow.Cells[colNew.Name].Value = gridRow.Cells[colDelete.Name].Value
                    = gridRow.Cells[colEdit.Name].Value = gridRow.Cells[colView.Name].Value = false;
            }

            // Load modules
            DataTable dtPriviledges = dataAdapter.LoadData(String.Format(@"SELECT * FROM [module_user_mapping] WHERE [_User]={0}", userId), "user_modules" + Guid.NewGuid().ToString());
            if (dtPriviledges != null) {
                foreach (DataRow row in dtPriviledges.Rows) {
                    bool newPriviledge = (bool)row["_New"];
                    bool editPriviledge = (bool)row["_Edit"];
                    bool deletePriviledge = (bool)row["_Delete"];
                    bool viewPriviledge = (bool)row["_View"];
                    int moduleId = Convert.ToInt32(row["_Module"]);
                    foreach (DataGridViewRow gridRow in dgrModules.Rows) {
                        int mId = (int)gridRow.Tag;
                        if (mId == moduleId) {
                            gridRow.Cells[colNew.Name].Value = newPriviledge;
                            gridRow.Cells[colDelete.Name].Value = deletePriviledge;
                            gridRow.Cells[colEdit.Name].Value = editPriviledge;
                            gridRow.Cells[colView.Name].Value = viewPriviledge;
                            break;
                        }
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e) {
            if (cmbUsers.SelectedValue == null) {
                MessageBox.Show("No user selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int userId = (int)cmbUsers.SelectedValue;
            foreach (DataGridViewRow row in dgrModules.Rows) {
                int moduleId = Convert.ToInt32(row.Tag);
                int newPriviledge = ((bool)row.Cells[colNew.Name].Value) ? 1 : 0;
                int editPriviledge = ((bool)row.Cells[colEdit.Name].Value) ? 1 : 0;
                int deletePriviledge = ((bool)row.Cells[colDelete.Name].Value) ? 1 : 0;
                int viewPriviledge = ((bool)row.Cells[colView.Name].Value) ? 1 : 0;
                string sql = string.Empty;
                DataTable dt = dataAdapter.LoadData(String.Format("SELECT * FROM [module_user_mapping] WHERE [_Module] = {0} AND [_User] = {1}", moduleId, userId), "SaveModuleUser");
                if (dt != null && dt.Rows.Count > 0) {
                    sql = String.Format("UPDATE [module_user_mapping] SET [_New] = {2}, [_Edit] = {3}, [_Delete] = {4}, [_View] = {5} WHERE [_Module] = {0} AND [_User] = {1}", moduleId, userId, newPriviledge, editPriviledge, deletePriviledge, viewPriviledge);
                } else {
                    sql = String.Format("INSERT into [module_user_mapping] VALUES({0}, {1}, {2}, {3}, {4}, {5})", moduleId, userId, newPriviledge, editPriviledge, deletePriviledge, viewPriviledge);
                }
                dataAdapter.ExecuteSql(sql);
            }
            MessageBox.Show("User roles are successfully saved", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.DialogResult = DialogResult.No;
        }
    }
}
